<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Charge extends MY_Controller {

	public function __construct() {
		parent::__construct();
	}
	public function index()
	{
		$this->checkAdminAuth();
		
		$this->data['page'] = 'admin/charge/index';
		$this->load_view($this->data);
	}

	/**
	 * Load category add view
	 */
	public function add($id = null)
	{
		$this->checkAdminAuth();

		ini_set('display_errors', 1);
		if($id != null){
			$this->data['details'] = $this->common_model->select_row('delivery_charges', ['id'=> $id], 'delivery_charges.*');
		}
		$this->data['page'] = 'admin/charge/add';
		$this->load_view($this->data);
	}

	//Add_edit function for charge
	public function chargeSave()
	{
		$this->checkAdminAuth();
		$postData = $this->input->post();

		$this->data = [];
		$this->data['item_quantity'] = $postData['item_quantity'];
		$this->data['amount'] = $postData['amount'];
		
		if(empty($postData['id'])){
			if($this->common_model->add('delivery_charges', $this->data)){
				$this->session->set_flashdata('success', 'Charge added successfully');
				redirect('admin/charge', 'refresh');
			}else{
				$this->session->set_flashdata('error', 'Unable to add charge');
				redirect('admin/charge/add', 'refresh');
			}
		}else{
			if($this->common_model->update('delivery_charges', $this->data,['id'=> $postData['id']])){
				$this->session->set_flashdata('success', 'Charge updated successfully');
				redirect('admin/charge/edit/'.$postData['id'], 'refresh');
			}else{
				$this->session->set_flashdata('error', 'Unable to update charge');
				redirect('admin/charge/edit/'.$postData['id'], 'refresh');
			}
		}
	}
	public function get()
	{
		$this->isJSON(file_get_contents('php://input'));
		$postData = $this->extract_json(file_get_contents('php://input'));
		if (!empty($postData)) {
			if($postData['source'] ==""){
				$this->response = array('status' => array('error_code' => 1, 'message' => 'Incomplete request'), 'result' => array('data' => $this->obj));
				$this->outputJson($this->response);
			}
			if($postData['source'] === 'WEB'){
				$where = array('delivery_charges.status !='=> 3);
			}else{
				$where = array('delivery_charges.status'=> 1);
			}
			$select = 'delivery_charges.*';
			$this->obj = $this->common_model->select('delivery_charges', $where, $select, 'delivery_charges.id', 'ASC');
			
			if($postData['source'] === 'WEB'){
				$this->data['charges'] = $this->obj;
				//print_r($this->data);
				$html = $this->load->view('admin/ajax-view', $this->data, true);
				$this->response = array('status' => array('error_code' => 0, 'message' => 'Success'), 'result' => $html);
			}else{
				$this->response = array('status' => array('error_code' => 0, 'message' => 'No data found'), 'result' => array('data' => $this->obj));
			}
		}
		else {
			$this->response = array('status' => array('error_code' => 1, 'message' => 'BAD REQUEST'), 'result' => array('data' => $this->obj));
		}
		$this->outputJson($this->response);
	}
}