<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Subscription extends MY_Controller {

	public function __construct() {
		parent::__construct();
	$this->load->model('mcommon');
	$this->load->model('common_model');	
	}
	public function index()
	{
		$this->checkAdminAuth();
		$this->data = [];
		$join = array(
						'membership_types'=>'subscription.membership_type_id = membership_types.membership_type_id'
					 );
		$where = 'subscription.status=1';
		$this->data['details'] = $this->mcommon->membership_list('subscription',$where,$join,'INNER');
		$this->data['page'] = 'admin/subscription/index';
		$this->load_view($this->data);
	}

	/**
	 * Load category add view
	 */
	public function add($id = null)
	{
		$this->checkAdminAuth();
		if($id != null){
		$this->data['details'] = $this->common_model->select_row('subscription', ['subscription_id'=> $id], 'subscription.*');
		}
		$this->data['page'] = 'admin/subscription/add';
		$this->load_view($this->data);
	}

	//Add_edit function for subscription
	public function subscriptionsave()
	{
		$this->checkAdminAuth();
		$postData = $this->input->post();
		$this->data = [];
		$this->data['membership_type_id'] = $postData['subscription_name'];
		$this->data['subscription_type'] = $postData['subscription_type'];
		$this->data['amount'] = $postData['amount'];
		$this->data['status']	  = 1;
        
		if(empty($postData['subscription_id'])){
           //Use for same subscription
			$condition = ' `membership_type_id` = "'.$postData['subscription_name'].'"';	
			$condition .= ' And `subscription_type` = "'.$postData['subscription_type'].'"  ';	
			$is_exist = $this->mcommon->getRow('subscription',$condition);		
			//echo $this->db->last_query();exit();		
			if(!empty($is_exist)){
				$this->session->set_flashdata('error_msg','Record already exist.');
				redirect('admin/subscription/add', 'refresh');		
			} else {
			if($this->common_model->add('subscription', $this->data)){
				$this->session->set_flashdata('success', 'subscription added successfully');
				redirect('admin/subscription/add', 'refresh');
			} else {
			$this->session->set_flashdata('success', 'Unable to added successfully');
			redirect('admin/subscription/add', 'refresh');	
			}
		   }
		} else {
			if($this->common_model->update('subscription', $this->data,['subscription_id'=> $postData['subscription_id']])){
				$this->session->set_flashdata('success', 'subscription updated successfully');
				redirect('admin/subscription/add/'.$postData['subscription_id'], 'refresh');
			}else{
				$this->session->set_flashdata('error', 'Unable to update subscription');
				redirect('admin/subscription/add/'.$postData['subscription_id'], 'refresh');
			}
		}
	}


	public function subscriptionlist()
	{
		$this->isJSON(file_get_contents('php://input'));
		$postData = $this->extract_json(file_get_contents('php://input'));
		ini_set('display_errors', 1);
		if($postData){
			$this->data = [];
			$condition = array('st.status' => 1);

			$this->join[] = ['table' => 'subscription s', 'on' => 's.membership_type_id = st.membership_type_id', 'type' => 'left'];
			$this->data = $this->common_model->select('membership_types st',$condition, 'st.*, st.description subscription_description, s.*', 'st.membership_type', 'ASC', $this->join);
			/**
			 * Modifyed by Chayan as required by app team
			 * on 11/10/2020 
			*/

			// if($membership){
			// 	foreach ($membership as $value){
			// 		$this->data[] = array(
			// 								'membership_type_id' => $value['membership_type_id'],
			// 								'membership_type'    => $value['membership_type'],
			// 								'list'        		 => $this->common_model->select('subscription', ['membership_type_id'=> $value['membership_type_id'], 'status'=> 1], 'subscription.*'),
			// 								);
			// 	}
			// }
			if($this->data){
				$this->response = array('status' => array('error_code' => 0, 'message' => 'Success'), 'result' => array('data' => $this->data));
			 }else{
				$this->response = array('status' => array('error_code' => 1, 'message' => "No data found"), 'result' => array('data' => $this->data));
			 }
            
        }else{
           $this->response = array('status' => array('error_code' => 1, 'message' => 'BAD REQUEST'), 'result' => array('data' => $this->obj));
        }
		$this->outputJson($this->response);
	}


   


	/*
		** Bulk data upload
	*/
	//upload bulk/csv tools
	public function csvUpload()
	{
		$filename = $_FILES['image']['name'];
		$allowed =  array('csv');
		$ext = pathinfo($filename, PATHINFO_EXTENSION);
		if (in_array($ext, $allowed)) {
			$image_file = time().'_'.$filename;
			$imgPath = getcwd()."/uploads/".$image_file;
			if(file_exists($imgPath)){
				unlink($imgPath);
			}
			move_uploaded_file($_FILES['image']['tmp_name'], $imgPath);

			$csvData = $this->readCSV($imgPath);
			// echo '<pre>';
			// print_r($csvData); die;
			$this->data = [];
			for($i=1; $i< count($csvData); $i++){
				if($data = $csvData[$i]){
					if (!$this->common_model->select_row('users', array("email" => $data[2]), 'user_id')) {
					$this->data[] = array(
							'role_id'=> 3,
							'fname'=> $data[0],
							'lname'=> $data[1],
							'email'=> $data[2],
							'mobile'=> $data[3],
							'password'=> MD5($data[4]),
							'address'=> $data[5]
						);
					}
				}
			}
			if($this->data){
				$this->common_model->batch_insert('users', $this->data);
				$this->response=array('status'=>array('error_code'=>0,'message'=>'Data uuccessfully uploaded '),'result'=>array('data'=>$this->obj));
			}
		}else{
			$this->response=array('status'=>array('error_code'=>1,'message'=>'Upload only csv files'),'result'=>array('data'=>$this->obj));
		}
		$this->outputJson($this->response);
	}

	public function get_product() {
		     $vendor_id=$_POST['product_id']; 
	        $query_cont = $this->mcommon->getRows('products',$condition=array('vendor_id'=>$vendor_id,'status'=>1));
	        $option = '';
	        $option.='<option value="">Select Product</option>';
            foreach ($query_cont as  $value) { 
			 $option .= '<option value="'.$value['product_id'].'">'.$value['product_name'].'</option>';
	        }
	        echo $option ;

      }
}