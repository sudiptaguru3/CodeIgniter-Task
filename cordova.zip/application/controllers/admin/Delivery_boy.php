<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Delivery_boy extends MY_Controller {

	public function __construct() {
		parent::__construct();
	}
	public function index()
	{
		$this->checkAdminAuth();
		
		$this->data['page'] = 'admin/delivery_boy/index';
		$this->load_view($this->data);
	}

	/**
	 * Load category add view
	 */
	public function add($id = null)
	{
		$this->checkAdminAuth();
		if($id != null){
			$this->data['details'] = $this->common_model->select_row('users', ['user_id'=> $id], 'users.*');
		}
		$this->data['page'] = 'admin/delivery_boy/add';
		$this->load_view($this->data);
	}

	//Add_edit function for delivery boy
	public function deliverySave()
	{
		$this->checkAdminAuth();
		$this->form_validation->set_rules('fname','First name','trim|required');
		$this->form_validation->set_rules('lname','Last name','trim|required');
		$this->form_validation->set_rules('email','Email','trim|required');
	   
	    if ($this->form_validation->run() == FALSE) {
			$this->session->set_flashdata('error', 'Please fill all required fields');
			$this->add();
		}
		else{
			$postData = $this->input->post();
			$this->data = [];
			$this->data['role_id']	= 3;
			$this->data['fname'] = $postData['fname'];
			$this->data['lname'] = $postData['lname'];
			$this->data['email'] = $postData['email'];
			$this->data['mobile'] = $postData['mobile'];
			if(!empty($postData['password'])){
				$this->data['password'] = MD5($postData['password']);
			}
			$this->data['address'] = $postData['address'];
			
			if(empty($postData['user_id'])){
				$isData = $this->common_model->select_row('users', ['email'=> $postData['email'], 'status !='=> 3], 'user_id');
				if(!empty($isData)){
					$this->session->set_flashdata('error', 'Delivery boy already exists');
					redirect('admin/delivery/add', 'refresh');
				}
				if($user_id = $this->common_model->add('users', $this->data)){
					if($postData['vendor']){
						$this->data = [];
						foreach($postData['vendor'] as $value){
							$this->data[] = array(
								'user_id'=> $user_id,
								'vendor_id'=> $value,
							);
						}
						$this->common_model->batch_insert('delivery_vendor', $this->data);
					}
					$this->session->set_flashdata('success', 'Delivery boy added successfully');
					redirect('admin/delivery', 'refresh');
				}else{
					$this->session->set_flashdata('error', 'Unable to add delivery boy');
					redirect('admin/delivery/add', 'refresh');
				}
			}else{
				//remove old users
				$this->db->where('user_id', $postData['user_id']);
				$this->db->delete('delivery_vendor');
				if($postData['vendor']){
					$this->data = [];
					foreach($postData['vendor'] as $value){
						$this->data[] = array(
							'user_id'=> $postData['user_id'],
							'vendor_id'=> $value,
						);
					}
					$this->common_model->batch_insert('delivery_vendor', $this->data);
				}

				//Update data val
				$this->data = [];
				$this->data['role_id']	= 3;
				$this->data['fname'] = $postData['fname'];
				$this->data['lname'] = $postData['lname'];
				$this->data['email'] = $postData['email'];
				$this->data['mobile'] = $postData['mobile'];
				if(!empty($postData['password'])){
					$this->data['password'] = MD5($postData['password']);
				}
				$this->data['address'] = $postData['address'];


				if($this->common_model->update('users', $this->data,['user_id'=> $postData['user_id']])){
					//echo $this->db->last_query(); die;
					$this->session->set_flashdata('success', 'Delivery boy updated successfully');
					redirect('admin/delivery/edit/'.$postData['user_id'], 'refresh');
				}else{
					$this->session->set_flashdata('error', 'Unable to update delivery boy');
					redirect('admin/delivery/edit/'.$postData['user_id'], 'refresh');
				}
			}
		}
	}
	public function get()
	{
		$this->isJSON(file_get_contents('php://input'));
		$postData = $this->extract_json(file_get_contents('php://input'));
		if (!empty($postData)) {
			if($postData['source'] ==""){
				$this->response = array('status' => array('error_code' => 1, 'message' => 'Incomplete request'), 'result' => array('data' => $this->obj));
				$this->outputJson($this->response);
			}
			if($postData['source'] === 'WEB'){
				$where = array('users.status !='=> 3);
			}else{
				$where = array('users.status'=> 1);
			}
			$where['role_id'] = 3;	//2 is alise for delivery boy 
			$select = 'users.*';
			$this->obj = $this->common_model->select('users', $where, $select, 'users.fname', 'ASC');
			//echo $this->db->last_query(); die;

			if($postData['source'] === 'WEB'){
				$this->data['delivery'] = $this->obj;
				//print_r($this->data);
				$html = $this->load->view('admin/ajax-view', $this->data, true);
				$this->response = array('status' => array('error_code' => 0, 'message' => 'Success'), 'result' => $html);
			}else{
				$this->response = array('status' => array('error_code' => 0, 'message' => 'Logout successfully'), 'result' => array('data' => $this->obj));
			}
		}
		else {
			$this->response = array('status' => array('error_code' => 1, 'message' => 'BAD REQUEST'), 'result' => array('data' => $this->obj));
		}
		$this->outputJson($this->response);
	}

	/*
		** Bulk data upload
	*/
	//upload bulk/csv tools
	public function csvUpload()
	{
		$filename = $_FILES['image']['name'];
		$allowed =  array('csv');
		$ext = pathinfo($filename, PATHINFO_EXTENSION);
		if (in_array($ext, $allowed)) {
			$image_file = time().'_'.$filename;
			$imgPath = getcwd()."/uploads/".$image_file;
			if(file_exists($imgPath)){
				unlink($imgPath);
			}
			move_uploaded_file($_FILES['image']['tmp_name'], $imgPath);

			$csvData = $this->readCSV($imgPath);
			// echo '<pre>';
			// print_r($csvData); die;
			$this->data = [];
			for($i=1; $i< count($csvData); $i++){
				if($data = $csvData[$i]){
					if (!$this->common_model->select_row('users', array("email" => $data[2]), 'user_id')) {
					$this->data[] = array(
							'role_id'=> 3,
							'fname'=> $data[0],
							'lname'=> $data[1],
							'email'=> $data[2],
							'mobile'=> $data[3],
							'password'=> MD5($data[4]),
							'address'=> $data[5]
						);
					}
				}
			}
			if($this->data){
				$this->common_model->batch_insert('users', $this->data);
				$this->response=array('status'=>array('error_code'=>0,'message'=>'Data uuccessfully uploaded '),'result'=>array('data'=>$this->obj));
			}
		}else{
			$this->response=array('status'=>array('error_code'=>1,'message'=>'Upload only csv files'),'result'=>array('data'=>$this->obj));
		}
		$this->outputJson($this->response);
	}
}