<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Vendor extends MY_Controller {

	public function __construct() {
		parent::__construct();
	}
	public function index()
	{
		$this->checkAdminAuth();
		
		$this->data['page'] = 'admin/vendor/index';
		$this->load_view($this->data);
	}

	/**
	 * Load category add view
	 */
	public function add($id = null)
	{
		$this->checkAdminAuth();
		if($id != null){
			$where= array('users.user_id'=> $id);
			$select = 'users.mobile, users.email, vd.*, vd.status vendor_status, IF(vd.vendor_image IS NULL, "", CONCAT("'.base_url().'uploads/vendor/",vd.vendor_image)) as vendor_image,';

			$this->join[] = ['table' => 'users', 'on' => 'users.user_id = vd.user_id', 'type' => 'left'];
			$this->obj = $this->common_model->select('vendor_details vd', $where, $select, 'vd.vendor_name', 'ASC', $this->join);
			if(!empty($this->obj)){
				$this->data['details'] = $this->obj[0];
			}else{
				$this->data['details'] = [];
			}
		}
		$this->data['page'] = 'admin/vendor/add';
		$this->load_view($this->data);
	}

	//Add_edit function for category
	public function vendorSave()
	{
		$this->checkAdminAuth();
		$postData = $this->input->post();
		$weekArray = array('sunday', 'monday', 'tuesday', 'wednesday', 'thursday', 'fryday', 'saturday');

		$this->data = [];
		$this->data['role_id']	= 2;	//for vendor
		$this->data['email'] = $postData['email'];
		$this->data['mobile'] = $postData['mobile'];
		$this->data['password'] = MD5('123456');
		
		if(empty($postData['vendor_id'])){
			$isData = $this->common_model->select_row('users', ['email'=> $postData['email'], 'status !='=> 3], 'user_id');
			if(!empty($isData)){
				$this->session->set_flashdata('error', 'Email already exists');
				redirect('admin/vendor/add', 'refresh');
			}
			if($user_id = $this->common_model->add('users', $this->data)){
				//add details for a vendor
				$this->data = array(
					'user_id'=> $user_id,		
					'vendor_name' => $postData['name'],
					'address' => $postData['address']
				);
				if($_FILES['image']['name']){
					$filename = $_FILES['image']['name'];
					$allowed =  array('gif', 'png', 'jpg', 'jpeg', 'JPG', 'JPEG', 'PNG', 'GIF');
					$ext = pathinfo($filename, PATHINFO_EXTENSION);
					ini_set('display_errors', 1);
					if (in_array($ext, $allowed)) {
						$image_file = time().'_'.strtolower(str_replace(' ', '~', $productName))."." . $ext;
						$imgPath = getcwd()."/uploads/vendor/".$image_file;
						if(move_uploaded_file($_FILES['image']['tmp_name'], $imgPath)){
							$this->data['vendor_image'] = $image_file;
						}
					}
				}
				$vendor_id = $this->common_model->add('vendor_details', $this->data); //add vendor details
				//Insert categories for vendor
				if($postData['category']){
					$this->data = [];
					foreach($postData['category'] as $value){
						$this->data[] = array(
							'vendor_id'=> $vendor_id,
							'category_id'=> $value,
						);
					}
					$this->common_model->batch_insert('vendor_category', $this->data);
				}
				//Insert timing for vendor
				if($postData['time']){
					$this->data = [];
					for($i = 0; $i<count($postData['time']); $i++){
						$key = $postData['time'][$i];
						if($postData['open'][$key]!="" && $postData['close'][$key]!=""){
							$this->data[] = array(
								'vendor_id'=> $vendor_id,
								'day'=> $weekArray[$key],
								'open'=> $postData['open'][$key],
								'close'=> $postData['close'][$key],
							);
						}
					}
					$this->common_model->batch_insert('vendor_timing', $this->data);
				}

				$this->session->set_flashdata('success', 'Vendor added successfully');
				redirect('admin/vendor', 'refresh');
			}else{
				$this->session->set_flashdata('error', 'Unable to adde vendor');
				redirect('admin/vendor/add', 'refresh');
			}
		}else{
			//get userId
			$userDetails=$this->common_model->select_row('vendor_details', ['vendor_id'=> $postData['vendor_id']], 'user_id');
			if(empty($userDetails)){
				$this->session->set_flashdata('error', 'Unable to update vendor');
				redirect('admin/vendor/edit/'.$userDetails->user_id, 'refresh');
			}
			//update user table
			$this->common_model->update('users', $this->data, ['user_id'=> $userDetails->user_id]);

			$this->data = array(	
				'vendor_name' => $postData['name'],
				'address' => $postData['address']
			);
			if($_FILES['image']['name']){
				$filename = $_FILES['image']['name'];
				$allowed =  array('gif', 'png', 'jpg', 'jpeg', 'JPG', 'JPEG', 'PNG', 'GIF');
				$ext = pathinfo($filename, PATHINFO_EXTENSION);
	
				if (in_array($ext, $allowed)) {
					$image_file = time().'_'.strtolower(str_replace(' ', '~', $productName))."." . $ext;
					$imgPath = getcwd()."/uploads/vendor/".$image_file;
					if(move_uploaded_file($_FILES['image']['tmp_name'], $imgPath)){
						$this->data['vendor_image'] = $image_file;
					}
				}
			}
			if($this->common_model->update('vendor_details', $this->data, ['vendor_id'=> $postData['vendor_id']])){
				//remove old
				$this->db->where('vendor_id', $postData['vendor_id']);
				$this->db->delete('vendor_category');
				//Insert new categories for vendor
				if($postData['category']){
					$this->data = [];
					foreach($postData['category'] as $value){
						$this->data[] = array(
							'vendor_id'=> $postData['vendor_id'],
							'category_id'=> $value,
						);
					}
					$this->common_model->batch_insert('vendor_category', $this->data);
				}

				//update timing
				$this->db->where('vendor_id', $postData['vendor_id']);
				$this->db->delete('vendor_timing');
				if($postData['time']){
					$this->data = [];
					for($i = 0; $i<count($postData['time']); $i++){
						$key = $postData['time'][$i];
						if($postData['open'][$key]!="" && $postData['close'][$key]!=""){
							$this->data[] = array(
								'vendor_id'=> $postData['vendor_id'],
								'day'=> $weekArray[$key],
								'open'=> $postData['open'][$key],
								'close'=> $postData['close'][$key],
							);
						}
					}
					$this->common_model->batch_insert('vendor_timing', $this->data);
				}

				$this->session->set_flashdata('success', 'Vendor updated successfully');
				redirect('admin/vendor/edit/'.$userDetails->user_id, 'refresh');
			}else{
				$this->session->set_flashdata('error', 'Unable to update vendor');
				redirect('admin/vendor/edit/'.$userDetails->user_id, 'refresh');
			}
		}
	}
	/**
	 * @request Mob, cat_id/null
	 */
	public function get()
	{
		$this->isJSON(file_get_contents('php://input'));
		$postData = $this->extract_json(file_get_contents('php://input'));
		if (!empty($postData)) {
			if($postData['source'] ==""){
				$this->response = array('status' => array('error_code' => 1, 'message' => 'Incomplete request'), 'result' => array('data' => $this->obj));
				$this->outputJson($this->response);
			}
			if($postData['source'] === 'WEB'){
				$where = array('users.status !='=> 3);
			}else{
				$where = array('users.status'=> 1);
			}
			$where['users.role_id'] = 2;	//2 is alise for (vendor in web === store in app)
			
			$select = 'users.email, vd.*, vd.status vendor_status, IF(vd.vendor_image IS NULL, "", CONCAT("'.base_url().'uploads/vendor/",vd.vendor_image)) as vendor_image,';
			
			/*
				** filter vendor/store category wise
				@request cat_id
			*/
			if(isset($postData['cat_id']) && $postData['cat_id'] != ""){
				$where['vc.category_id'] = $postData['cat_id'];
				$this->join[] = ['table' => 'vendor_category vc', 'on' => 'vc.vendor_id = vd.vendor_id', 'type' => 'left'];
			}

			$this->join[] = ['table' => 'users', 'on' => 'users.user_id = vd.user_id', 'type' => 'left'];
			$this->obj = $this->common_model->select('vendor_details vd', $where, $select, 'vd.vendor_name', 'ASC', $this->join);
			//echo $this->db->last_query(); die;

			if($postData['source'] === 'WEB'){
				$this->data['vendors'] = $this->obj;
				//print_r($this->data);
				$html = $this->load->view('admin/ajax-view', $this->data, true);
				$this->response = array('status' => array('error_code' => 0, 'message' => 'Success'), 'result' => $html);
			}else{
				$this->response = array('status' => array('error_code' => 0, 'message' => 'Success'), 'result' => array('data' => $this->obj));
			}
		}
		else {
			$this->response = array('status' => array('error_code' => 1, 'message' => 'BAD REQUEST'), 'result' => array('data' => $this->obj));
		}
		$this->outputJson($this->response);
	}

	/*
		** Bulk data upload
	*/
	//upload bulk/csv tools
	public function csvUpload()
	{
		$filename = $_FILES['image']['name'];
		$allowed =  array('csv');
		$ext = pathinfo($filename, PATHINFO_EXTENSION);
		if (in_array($ext, $allowed)) {
			$image_file = time().'_'.$filename;
			$imgPath = getcwd()."/uploads/".$image_file;
			if(file_exists($imgPath)){
				unlink($imgPath);
			}
			move_uploaded_file($_FILES['image']['tmp_name'], $imgPath);

			$csvData = $this->readCSV($imgPath);
			// echo '<pre>';
			// print_r($csvData); die;
			$this->data = [];
			for($i=1; $i< count($csvData); $i++){
				if($data = $csvData[$i]){
					if (!$this->common_model->select_row('users', array("email" => $data[2]), 'user_id')) {
					$this->data[] = array(
							'role_id'=> 2,
							'fname'=> $data[0],
							'lname'=> $data[1],
							'email'=> $data[2],
							'mobile'=> $data[3],
							'password'=> MD5('123456'),
							'address'=> $data[4]
						);
					}
				}
			}
			if($this->data){
				$this->common_model->batch_insert('users', $this->data);
				$this->response=array('status'=>array('error_code'=>0,'message'=>'Data uuccessfully uploaded '),'result'=>array('data'=>$this->obj));
			}
		}else{
			$this->response=array('status'=>array('error_code'=>1,'message'=>'Upload only csv files'),'result'=>array('data'=>$this->obj));
		}
		$this->outputJson($this->response);
	}
}