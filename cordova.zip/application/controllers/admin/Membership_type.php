<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Membership_type extends MY_Controller {

	public function __construct() {
		parent::__construct();
	}
	public function index()
	{
		$this->checkAdminAuth();
		
		$this->data['page'] = 'admin/membership_type/index';
		$this->load_view($this->data);
	}

	/**
	 * Load category add view
	 */
	public function add($id = null)
	{
		$this->checkAdminAuth();
		if($id != null){
			$this->data['details'] = $this->common_model->select_row('membership_types', ['membership_type_id'=> $id], 'membership_types.*');
		}
		$this->data['page'] = 'admin/membership_type/add';
		$this->load_view($this->data);
	}

	//Add_edit function for category
	public function membershipTypeSave()
	{
		$this->checkAdminAuth();
		$postData = $this->input->post();
		$this->data = [];
		ini_set('display_errors', 1);
		$this->data['membership_type'] = $postData['name'];
		$this->data['description'] = $postData['description'];
		//print_r($this->data); die;
		if(empty($postData['id'])){
			$isData = $this->common_model->select_row('membership_types', ['LOWER(membership_type)'=> strtolower($name)], 'membership_type_id');
		
			if(!empty($isData)){
				$this->session->set_flashdata('error', 'Membership type already exists');
				redirect('admin/membership_type/add', 'refresh');
			}
		}
		if(empty($postData['id'])){
			//print_r($this->data); die;
			if($this->common_model->add('membership_types', $this->data)){
				echo $id;
				$this->session->set_flashdata('success', 'Membership type added successfully');
				redirect('admin/membership_type', 'refresh');
			}else{
				$this->session->set_flashdata('error', 'Unable to add Membership type-----');
				redirect('admin/membership_type/add', 'refresh');
			}
		}else{
			//print_r($this->data); die;
			if($this->common_model->update('membership_types', $this->data,['membership_type_id'=> $postData['id']])){
				//echo $this->db->last_query(); die;
				$this->session->set_flashdata('success', 'Membership types updated successfully');
				redirect('admin/membership-type/edit/'.$postData['id'], 'refresh');
			}else{
				$this->session->set_flashdata('error', 'Unable to update Membership types444');
				redirect('admin/membership-type/edit/'.$postData['id'], 'refresh');
			}
		}
	}
	public function get()
	{
		ini_set('display_errors', 1);
		$this->isJSON(file_get_contents('php://input'));
		$postData = $this->extract_json(file_get_contents('php://input'));
		if (!empty($postData)) {
			if($postData['source'] ==""){
				$this->response = array('status' => array('error_code' => 1, 'message' => 'Incomplete request'), 'result' => array('data' => $this->obj));
				$this->outputJson($this->response);
			}
			if($postData['source'] === 'WEB'){
				$where = array('membership_types.status !='=> 3);
			}else{
				$where = array('membership_types.status'=> 1);
			}
			$select = 'membership_types.*';
			$this->obj = $this->common_model->select('membership_types', $where, $select, 'membership_types.membership_type_id', 'DESC');
			 
			if($postData['source'] === 'WEB'){
				$this->data['membership_types'] = $this->obj;
				$html = $this->load->view('admin/ajax-view', $this->data, true);
				$this->response = array('status' => array('error_code' => 0, 'message' => 'Success'), 'result' => $html);
			}else{
				if(!empty($this->obj)){
					$this->response = array('status' => array('error_code' => 0, 'message' => 'Success'), 'result' => array('data' => $this->obj));
				}else{
					$this->response = array('status' => array('error_code' => 0, 'message' => 'No data found'), 'result' => array('data' => $this->obj));
				}
			}
		}
		else {
			$this->response = array('status' => array('error_code' => 1, 'message' => 'BAD REQUEST'), 'result' => array('data' => $this->obj));
		}

		$this->outputJson($this->response);
	}
}