<!DOCTYPE html>
<html>
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <meta name="viewport" content="width=device-width, initial-scale=1.0" />
        <title>Get affordable and professional web designing service from Fitser, AU</title>
        <meta name="description"  content="We are an Australian based web designing agency offering the professional web designing service at very nominal prices. For more visit www.fitser.com." />
        <!--<link rel="shortcut icon" href="<?//=base_url()?>public/front_assets/css/images/favIcon.png" type="image/x-icon">
        <link rel="icon" href="<?//=base_url()?>public/front_assets/css/images/favIcon.png" type="image/x-icon">-->
        
        <!--<link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,500,700" rel="stylesheet">-->
        <!-- BOOTSTRAP STYLE -->
        <!--<link rel="stylesheet" type="text/css" href="<?//=base_url()?>public/front_assets/css/bootstrap.min.css"/>-->
        <link rel="stylesheet" type="text/css" href="<?=base_url()?>public/front_assets/css/bootstrap-datetimepicker.css"/>
        
        <!-- JQUERY LIBRARY -->
        <script type="text/javascript" src="<?=base_url()?>public/front_assets/js/jquery-2.1.4.js" ></script>
        	
        <!-- BOOTSTRAP SCRIPTS -->
        <script type="text/javascript" src="<?=base_url()?>public/front_assets/js/bootstrap.min.js" defer></script>
        <script type="text/javascript" src="<?=base_url()?>public/front_assets/js/moment-with-locales.js" defer></script>
        <script type="text/javascript" src="<?=base_url()?>public/front_assets/js/bootstrap-datetimepicker.js" defer></script>
        <script src="<?=base_url()?>public/front_assets/js/jquery.counterup.min.js" defer></script>
        <script src="<?=base_url()?>public/front_assets/js/script.js" defer></script>
        <!-- FONT AWESOME-->
        <!--<link rel="stylesheet" type="text/css" href="<?//=base_url()?>public/front_assets/css/font-awesome.css"/>-->
        
        <!--<link rel="stylesheet" type="text/css" href="<?//=base_url()?>public/front_assets/owlcarousel/animate.css">-->
        <!--<link rel="stylesheet" href="<?//=base_url()?>public/front_assets/owlcarousel/owl.carousel.min.css">
        <link rel="stylesheet" href="<?//=base_url()?>public/front_assets/owlcarousel/owl.theme.default.min.css">-->
        <script src="<?=base_url()?>public/front_assets/owlcarousel/owl.carousel.min.js" defer></script>
        <!-- SITE STYLES -->
        <link href="https://fonts.googleapis.com/css?family=Lato:100,100i,300,300i,400,400i,700,700i,900,900i|Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i|Roboto:100,100i,300,300i,400,400i,500,500i,700,700i,900,900i" rel="stylesheet"> 
        
        <link rel="stylesheet" type="text/css" href="<?=base_url()?>public/front_assets/css/all.css"/>
        <!--<link rel="stylesheet" type="text/css" href="<?//=base_url()?>public/front_assets/css/intlTelInput.css" />-->
        <style>
            #contact_submit {
        		background: #990000;
        	    text-align: center;
        	    color: #fff;
        	    width: 100%;
        	    padding: 15px;
        	    font-family: 'Lato', sans-serif;
        	    font-weight: 700;
        	    font-size: 15px;
        	    border: 0;
        	}
        	input.error {
        	    border: 1px dotted red;
        	}
        	textarea.error {
        	    border: 1px dotted red;
        	}
        .form-group {
          position: relative;
        }
        </style>
        <script>
          (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
          (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
          m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
          })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
        
          ga('create', 'UA-85455930-1', 'auto');
          ga('send', 'pageview');
        </script>
        <!-- Global site tag (gtag.js) - Google Ads: 784397410 -->
        <script async src="https://www.googletagmanager.com/gtag/js?id=AW-784397410"></script>
        <script>
          window.dataLayer = window.dataLayer || [];
          function gtag(){dataLayer.push(arguments);}
          gtag('js', new Date());
        
          gtag('config', 'AW-784397410');
        </script>

    </head>
    <body>
    <div class="side_quote"> <img class="show_side" src="<?=base_url()?>public/front_assets/css/images/request.png">
        <form action="" method="post" id="contact_form2" class="contact_form">
            <div class="form-group">
               <input type="text" class="form-control" id="name" placeholder="Name" name="name" required autocomplete="off">
            </div>
            <div class="form-group">
                <input type="email" class="form-control" id="email" placeholder="Email" name="email" required autocomplete="off">
            </div>
            <div class="form-group">
                <div class="row">
                    <div class="col-xs-3">
                      <input type="text" class="form-control" id="country_code2" placeholder="Country Code" name="country_code" title="Country Code">
                    </div>
                    <!-- col-sm-4 -->
                    <div class="col-xs-9">
                      <input type="text" class="form-control" id="phone" placeholder="Phone" name="phone" required autocomplete="off">
                    </div>
                    <!-- col-sm-8 -->
                </div>
            </div>
            <!--<div class="form-group">
                <input type="text" class="form-control" id="schedule2" placeholder="Schedule" name="schedule" required autocomplete="off" readonly>
            </div>-->
            <div class="form-group">
                <textarea class="form-control" id="message" placeholder="Requirement" rows="2" name="message" autocomplete="off"></textarea>
            </div>
            <div class=" text-left">
                <button type="submit" class="btn btn-success">Submit</button>
                <button class="btn btn-danger">Close</button>
            </div>
        </form>
    </div>
    <header class="land_header">
        <div class="container">
            <div class="row">
                <div class="col-sm-3">
                    <a href="https://www.fitser.com/" class="logo"><img src="<?=base_url()?>public/front_assets/css/images/logo.png" alt="*" /></a>
                </div>
                <!-- col-sm-3 -->
                <div class="col-sm-9">
                    <div class="wrapCallUs"> <span class="callUs"><img src="<?=base_url()?>public/front_assets/css/images/iconPhone.png" alt="*">Call Us Today : <span class="flag"><img src="<?=base_url()?>public/front_assets/css/images/flagUsa.png" alt="*"></span> <a href="tel:(+1) 3605383135">(+1) 3605383135 </a> <span class="flag"><img src="<?=base_url()?>public/front_assets/css/images/flagAus.png" alt="*"></span><a href="tel:(+61) 280113465">(+61) 280113465</a> </span>
                      <ul class="listSocialTop">
                        <li><a href="https://www.facebook.com/FitserNews" target="_blank"><i class="fa fa-facebook"></i></a></li>
                        <li><a href="https://twitter.com/FitserNews" target="_blank"><i class="fa fa-twitter"></i></a></li>            
                        <li><a href="https://www.linkedin.com/company/fitser" target="_blank"><i class="fa fa-linkedin"></i></a></li>
                        <li><a href="https://www.youtube.com/c/FitserNews" target="_blank"><i class="fa fa-youtube"></i></a></li>
                      </ul>
                    </div>
                </div>
                <!-- col-sm-9 -->
            </div>
        </div>
    </header>
    <div class="wraperBanner"> <img src="<?=base_url()?>public/front_assets/css/images/bgBanner.jpg" alt="" />
        
        <div class="wrapperBannerContent">
            <div class="container">
                <div class="row">
                    <div class="col-md-8">
                        <div class="banner_caption web_des">
                            <h2>Provides Professional Website Design Services Worldwide</h2>
                            <!-- <h4>USER FRIENDLY DESIGN</h4> -->
                        </div>
                    </div>
        
                    <div class="col-md-4">
                        <div class="banner_form">
            <div class="wraperGITForm" id="GITForm">
                <h2>Get in Touch with Us </h2>
                <div class="GITBody">
                    <form action="" method="post" id="contact_form" class="contact_form">
                      <?php if($this->session->flashdata('success_msg')){?>
                        <div class="success_msg">
                            <p><?php echo $this->session->flashdata('success_msg'); ?></p>
                        </div>
                      <?php }?>
                      <div class="form-group">
                          <input type="text" class="form-control" id="name" placeholder="Name" name="name" required autocomplete="off">
                      </div>
                      <div class="form-group">
                          <input type="email" class="form-control" id="email" placeholder="Email" name="email" required autocomplete="off">
                      </div>
                      <div class="form-group">
                          <div class="row">
                              <div class="col-xs-3">
                                  <input type="text" class="form-control" id="country_code" placeholder="Country Code" name="country_code" title="Country Code">
                              </div>
                              <!-- col-sm-4 -->
                              <div class="col-xs-9">
                                  <input type="text" class="form-control" id="phone" placeholder="Phone" name="phone" required autocomplete="off">
                              </div>
                              <!-- col-sm-8 -->
                          </div>
                          
                      </div>
                      <!--<div class="form-group">
                          <input type="text" class="form-control" id="schedule" placeholder="Schedule" name="schedule" required autocomplete="off" readonly>
                      </div>-->
                      <div class="form-group">
                          <textarea class="form-control" id="message" placeholder="Requirement" rows="2" name="message" autocomplete="off"></textarea>
                      </div>
                      <div class="">
                        <input type="submit" class="btn btn-default" id="contact_submit" value="Submit">
                      </div>
                    </form>
                </div>
            </div>
            <!-- wraperGITForm -->
        </div>
                    </div>
                </div>
            </div>
        </div>
                    
        
        
        
        
        <!-- text-right -->
    </div>

    <!-- wraperBanner -->
    <div class="sectionWelcome welcomepage">
      <div class="container">
        <h1>Web Design Services</h1>
        <p>Are you looking for a reliable, eye-catching, user-friendly, and positive result yielding website for your company? Look no further than Fitser. It is the best <b>web design company</b> to provide the customers with the opportunity to grow and become a unique identity amongst their counterparts. We specialize in creating websites that work best for dynamic online space and thus are the best <b>custom web design company</b>.</p>
        <p>As a <b>web design and development company</b>, we offer our clients end-to-end website solutions along with web designing and programming, search engine optimization, logo designing, graphic designing, and content writing services. With a dynamic team of <b>professional web design agency</b> at the helm, we deliver our clients industry-specific and high-quality website designs.</p>
        <p>By leveraging our in-depth knowledge and programming information, we have attained a prominent global position in the industry. No wonders, we have established a stellar reputation of a <b>responsive website design company</b>. Fitser is correctly recognized as the best <b>graphics design company</b> and <b>logo design company</b> as it offers affordable, appealing, and vibrant web solutions to different size businesses globally.  We offer web design and web development services in UK, Panama, Australia and Romania apart from India.</p>
        <h1>Why Choose Us</h1>

        <div class="row">
          <div class="col-sm-6">
            <ul class="listService">
              <li>Modern Templates</li>
              <li>Dynamic &amp; Engaging Web Designs</li>
              <li>Hand-Picked Developers &amp; Designers</li>
              <li>Meticulous Process Monitoring </li>
              <li>Creative and Innovative Solutions</li>
              
            </ul>
          </div>
          <div class="col-sm-6">
            <ul class="listService">    
              <li>Industry-Specific Web Development</li>
              <li>Amicable &amp; Responsive Approach</li>
              <li>24/7 Customer Support</li>
              <li>Passionate group of designers</li>
              <li>Free consultation</li>
            </ul>
          </div>
        </div>
        <p><a href="#GITForm" class="btnCallBack">Request a Call Back</a></p>
      </div>
    </div>
    <!-- sectionWelcome -->

    <!-- Portfolio:Start -->
    <div class="home-portfolio">
        <div class="container">
            <h2>Our Portfolio</h2>
            <div class="port_box">
                <!--<div class="portfolio-view-all"> <a href="#">view all</a> </div>-->
                <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 portfolio-nav">
                    <div>
                        <div class="left-nav">
                            <ul class="nav nav-pills nav-stacked">
                                <li class="active"><a data-toggle="tab" href="#menu-1">All</a></li>
                                <li><a data-toggle="tab" href="#menu-2">Mobile App</a></li>
                                <li><a data-toggle="tab" href="#menu-3">Web Design</a></li>
                                <li><a data-toggle="tab" href="#menu-4">Graphic design</a></li>
                                <li><a data-toggle="tab" href="#menu-5">Logo Design</a></li>
                                <!-- <li><a data-toggle="tab" href="#menu-6">illustration</a></li> -->
                            </ul>
                        </div>
                        <div class="clearfix"></div>
                        <h1 class="portfolio-heading">our portfolio</h1>
                        <h1 class="portfolio-link-no">01</h1>
                    </div>
                </div>
                <!--/.col4-->
                <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 portfolio-wrapper">
                    <div class="tab-content">
                        <div id="menu-1" class="tab-pane fade in active">
                            <div class="row">
                                <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
                                    <div class="row">
                                        <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 portfolio-padding-fixer"> <img src="<?=base_url()?>public/front_assets/images/mob2.png" class="img-responsive center-block">
                                            <div class="overlay-portfolio">
                                                <div>
                                                    <div>
                                                        <h1>LEMON GROUP MESSENGER</h1>
                                                        <p>Mobile App</p>
                                                        <!--<a href="#"> <i class="fa fa-arrows-alt" aria-hidden="true"></i> </a>
                                                        <a href="#"> <i class="fa fa-paperclip" aria-hidden="true"></i> </a>-->
                                                    </div>
                                                </div>
                                            </div>
                                            <!--/.overlay-portfolio-->
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 portfolio-padding-fixer"> <img src="<?=base_url()?>public/front_assets/images/web1.png" class="img-responsive center-block">
                                            <div class="overlay-portfolio">
                                                <div>
                                                    <div>
                                                        <h1>STAR SHIP</h1>
                                                        <p>Web Design</p>
                                                        <!--<a href="#"> <i class="fa fa-arrows-alt" aria-hidden="true"></i> </a>
                                                        <a href="#"> <i class="fa fa-paperclip" aria-hidden="true"></i> </a>-->
                                                    </div>
                                                </div>
                                            </div>
                                            <!--/.overlay-portfolio-->
                                        </div>
                                    </div>
                                    <!--/.row-->
                                    <div class="row">
                                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 portfolio-padding-fixer"> <img src="<?=base_url()?>public/front_assets/images/web4.png" class="img-responsive center-block">
                                            <div class="overlay-portfolio">
                                                <div>
                                                    <div>
                                                        <h1>BASSI GROUP</h1>
                                                        <p>Web Design</p>
                                                        <!--<a href="#"> <i class="fa fa-arrows-alt" aria-hidden="true"></i> </a>
                                                        <a href="#"> <i class="fa fa-paperclip" aria-hidden="true"></i> </a>-->
                                                    </div>
                                                </div>
                                            </div>
                                            <!--/.overlay-portfolio-->
                                        </div>
                                    </div>
                                    <!--/.row-->
                                </div>
                                <!--/.col6-->
                                <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 portfolio-padding-fixer"> <img src="<?=base_url()?>public/front_assets/images/grap3.png" class="img-responsive center-block">
                                    <div class="overlay-portfolio">
                                        <div>
                                            <div>
                                                <h1>GLOBAL</h1>
                                                <p>Graphic Design</p>
                                                <!--<a href="#"> <i class="fa fa-arrows-alt" aria-hidden="true"></i> </a>
                                                <a href="#"> <i class="fa fa-paperclip" aria-hidden="true"></i> </a>-->
                                            </div>
                                        </div>
                                    </div>
                                    <!--/.overlay-portfolio-->
                                </div>
                                <!--/.col6-->
                            </div>
                            <!--/.row-->
                            <div class="row">
                                <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 portfolio-padding-fixer"> <img src="<?=base_url()?>public/front_assets/images/web5.png" class="img-responsive center-block">
                                    <div class="overlay-portfolio">
                                        <div>
                                            <div>
                                                <h1>GREETINGS</h1>
                                                <p>Web Design</p>
                                                <!--<a href="#"> <i class="fa fa-arrows-alt" aria-hidden="true"></i> </a>
                                                <a href="#"> <i class="fa fa-paperclip" aria-hidden="true"></i> </a>-->
                                            </div>
                                        </div>
                                    </div>
                                    <!--/.overlay-portfolio-->
                                </div>
                                <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 portfolio-padding-fixer"> <img src="<?=base_url()?>public/front_assets/images/web6.png" class="img-responsive center-block">
                                    <div class="overlay-portfolio">
                                        <div>
                                            <div>
                                                <h1>SKATE</h1>
                                                <p>Web Design</p>
                                                <!--<a href="#"> <i class="fa fa-arrows-alt" aria-hidden="true"></i> </a>
                                                <a href="#"> <i class="fa fa-paperclip" aria-hidden="true"></i> </a>-->
                                            </div>
                                        </div>
                                    </div>
                                    <!--/.overlay-portfolio-->
                                </div>
                            </div>
                            <!--/.row-->
                        </div>
                        <div id="menu-2" class="tab-pane fade">
                            <div class="row">
                                <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
                                    <div class="row">
                                        <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 portfolio-padding-fixer"> <img src="<?=base_url()?>public/front_assets/images/mob1.png" class="img-responsive center-block">
                                            <div class="overlay-portfolio">
                                                <div>
                                                    <div>
                                                        <h1>KITCHEN OF POSSIBILITIES</h1>
                                                        <p>Mobile App</p>
                                                        <!--<a href="#"> <i class="fa fa-arrows-alt" aria-hidden="true"></i> </a>
                                                        <a href="#"> <i class="fa fa-paperclip" aria-hidden="true"></i> </a>-->
                                                    </div>
                                                </div>
                                            </div>
                                            <!--/.overlay-portfolio-->
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 portfolio-padding-fixer"> <img src="<?=base_url()?>public/front_assets/images/mob2.png" class="img-responsive center-block">
                                            <div class="overlay-portfolio">
                                                <div>
                                                    <div>
                                                        <h1>lemon group messenger</h1>
                                                        <p>Mobile App</p>
                                                        <!--<a href="#"> <i class="fa fa-arrows-alt" aria-hidden="true"></i> </a>
                                                        <a href="#"> <i class="fa fa-paperclip" aria-hidden="true"></i> </a>-->
                                                    </div>
                                                </div>
                                            </div>
                                            <!--/.overlay-portfolio-->
                                        </div>
                                    </div>
                                    <!--/.row-->
                                    <div class="row">
                                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 portfolio-padding-fixer"> <img src="<?=base_url()?>public/front_assets/images/mob4.png" class="img-responsive center-block">
                                            <div class="overlay-portfolio">
                                                <div>
                                                    <div>
                                                        <h1>dealmeals</h1>
                                                        <p>Mobile App</p>
                                                        <!--<a href="#"> <i class="fa fa-arrows-alt" aria-hidden="true"></i> </a>
                                                        <a href="#"> <i class="fa fa-paperclip" aria-hidden="true"></i> </a>-->
                                                    </div>
                                                </div>
                                            </div>
                                            <!--/.overlay-portfolio-->
                                        </div>
                                    </div>
                                    <!--/.row-->
                                </div>
                                <!--/.col6-->
                                <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 portfolio-padding-fixer"> <img src="<?=base_url()?>public/front_assets/images/mob3.png" class="img-responsive center-block">
                                    <div class="overlay-portfolio">
                                        <div>
                                            <div>
                                                <h1>shnarped hockey</h1>
                                                <p>Mobile App</p>
                                                <!--<a href="#"> <i class="fa fa-arrows-alt" aria-hidden="true"></i> </a>
                                                <a href="#"> <i class="fa fa-paperclip" aria-hidden="true"></i> </a>-->
                                            </div>
                                        </div>
                                    </div>
                                    <!--/.overlay-portfolio-->
                                </div>
                                <!--/.col6-->
                            </div>
                            <!--/.row-->
                            <div class="row">
                                <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 portfolio-padding-fixer"> <img src="<?=base_url()?>public/front_assets/images/mob5.png" class="img-responsive center-block">
                                    <div class="overlay-portfolio">
                                        <div>
                                            <div>
                                                <h1>sweet bouquet</h1>
                                                <p>Mobile App</p>
                                                <!--<a href="#"> <i class="fa fa-arrows-alt" aria-hidden="true"></i> </a>
                                                <a href="#"> <i class="fa fa-paperclip" aria-hidden="true"></i> </a>-->
                                            </div>
                                        </div>
                                    </div>
                                    <!--/.overlay-portfolio-->
                                </div>
                                <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 portfolio-padding-fixer"> <img src="<?=base_url()?>public/front_assets/images/mob6.png" class="img-responsive center-block">
                                    <div class="overlay-portfolio">
                                        <div>
                                            <div>
                                                <h1>THE MOON AND YOU</h1>
                                                <p>Mobile App</p>
                                                <!--<a href="#"> <i class="fa fa-arrows-alt" aria-hidden="true"></i> </a>
                                                <a href="#"> <i class="fa fa-paperclip" aria-hidden="true"></i> </a>-->
                                            </div>
                                        </div>
                                    </div>
                                    <!--/.overlay-portfolio-->
                                </div>
                            </div>
                            <!--/.row-->
                        </div>
                        <div id="menu-3" class="tab-pane fade">
                            <div class="row">
                                <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
                                    <div class="row">
                                        <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 portfolio-padding-fixer"> <img src="<?=base_url()?>public/front_assets/images/web1.png" class="img-responsive center-block">
                                            <div class="overlay-portfolio">
                                                <div>
                                                    <div>
                                                        <h1>STAR SHIP</h1>
                                                        <p>Web Design</p>
                                                        <!--<a href="#"> <i class="fa fa-arrows-alt" aria-hidden="true"></i> </a>
                                                        <a href="#"> <i class="fa fa-paperclip" aria-hidden="true"></i> </a>-->
                                                    </div>
                                                </div>
                                            </div>
                                            <!--/.overlay-portfolio-->
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 portfolio-padding-fixer"> <img src="<?=base_url()?>public/front_assets/images/web2.png" class="img-responsive center-block">
                                            <div class="overlay-portfolio">
                                                <div>
                                                    <div>
                                                        <h1>SMASH REPAIRS</h1>
                                                        <p>Web Design</p>
                                                        <!--<a href="#"> <i class="fa fa-arrows-alt" aria-hidden="true"></i> </a>
                                                        <a href="#"> <i class="fa fa-paperclip" aria-hidden="true"></i> </a>-->
                                                    </div>
                                                </div>
                                            </div>
                                            <!--/.overlay-portfolio-->
                                        </div>
                                    </div>
                                    <!--/.row-->
                                    <div class="row">
                                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 portfolio-padding-fixer"> <img src="<?=base_url()?>public/front_assets/images/web4.png" class="img-responsive center-block">
                                            <div class="overlay-portfolio">
                                                <div>
                                                    <div>
                                                        <h1>BASSI GROUP</h1>
                                                        <p>Web Design</p>
                                                        <!--<a href="#"> <i class="fa fa-arrows-alt" aria-hidden="true"></i> </a>
                                                        <a href="#"> <i class="fa fa-paperclip" aria-hidden="true"></i> </a>-->
                                                    </div>
                                                </div>
                                            </div>
                                            <!--/.overlay-portfolio-->
                                        </div>
                                    </div>
                                    <!--/.row-->
                                </div>
                                <!--/.col6-->
                                <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 portfolio-padding-fixer"> <img src="<?=base_url()?>public/front_assets/images/web3.png" class="img-responsive center-block">
                                    <div class="overlay-portfolio">
                                        <div>
                                            <div>
                                                <h1>GLOBAL</h1>
                                                <p>Web Design</p>
                                                <!--<a href="#"> <i class="fa fa-arrows-alt" aria-hidden="true"></i> </a>
                                                <a href="#"> <i class="fa fa-paperclip" aria-hidden="true"></i> </a>-->
                                            </div>
                                        </div>
                                    </div>
                                    <!--/.overlay-portfolio-->
                                </div>
                                <!--/.col6-->
                            </div>
                            <!--/.row-->
                            <div class="row">
                                <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 portfolio-padding-fixer"> <img src="<?=base_url()?>public/front_assets/images/web5.png" class="img-responsive center-block">
                                    <div class="overlay-portfolio">
                                        <div>
                                            <div>
                                                <h1>GREETINGS</h1>
                                                <p>Web Design</p>
                                                <!--<a href="#"> <i class="fa fa-arrows-alt" aria-hidden="true"></i> </a>
                                                <a href="#"> <i class="fa fa-paperclip" aria-hidden="true"></i> </a>-->
                                            </div>
                                        </div>
                                    </div>
                                    <!--/.overlay-portfolio-->
                                </div>
                                <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 portfolio-padding-fixer"> <img src="<?=base_url()?>public/front_assets/images/web6.png" class="img-responsive center-block">
                                    <div class="overlay-portfolio">
                                        <div>
                                            <div>
                                                <h1>SKATE</h1>
                                                <p>Web Design</p>
                                                <!--<a href="#"> <i class="fa fa-arrows-alt" aria-hidden="true"></i> </a>
                                                <a href="#"> <i class="fa fa-paperclip" aria-hidden="true"></i> </a>-->
                                            </div>
                                        </div>
                                    </div>
                                    <!--/.overlay-portfolio-->
                                </div>
                            </div>
                            <!--/.row-->
                        </div>
                        <div id="menu-4" class="tab-pane fade">
                            <div class="row">
                                <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
                                    <div class="row">
                                        <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 portfolio-padding-fixer"> <img src="<?=base_url()?>public/front_assets/images/grap1.png" class="img-responsive center-block">
                                            <div class="overlay-portfolio">
                                                <div>
                                                    <div>
                                                        <h1>SMB</h1>
                                                        <p>Graphic Design</p>
                                                        <!--<a href="#"> <i class="fa fa-arrows-alt" aria-hidden="true"></i> </a>
                                                        <a href="#"> <i class="fa fa-paperclip" aria-hidden="true"></i> </a>-->
                                                    </div>
                                                </div>
                                            </div>
                                            <!--/.overlay-portfolio-->
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 portfolio-padding-fixer"> <img src="<?=base_url()?>public/front_assets/images/grap2.png" class="img-responsive center-block">
                                            <div class="overlay-portfolio">
                                                <div>
                                                    <div>
                                                        <h1>ZAPPER</h1>
                                                        <p>Graphic Design</p>
                                                        <!--<a href="#"> <i class="fa fa-arrows-alt" aria-hidden="true"></i> </a>
                                                        <a href="#"> <i class="fa fa-paperclip" aria-hidden="true"></i> </a>-->
                                                    </div>
                                                </div>
                                            </div>
                                            <!--/.overlay-portfolio-->
                                        </div>
                                    </div>
                                    <!--/.row-->
                                    <div class="row">
                                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 portfolio-padding-fixer"> <img src="<?=base_url()?>public/front_assets/images/grap4.png" class="img-responsive center-block">
                                            <div class="overlay-portfolio">
                                                <div>
                                                    <div>
                                                        <h1>TERMINATOR 9</h1>
                                                        <p>Graphic Design</p>
                                                        <!--<a href="#"> <i class="fa fa-arrows-alt" aria-hidden="true"></i> </a>
                                                        <a href="#"> <i class="fa fa-paperclip" aria-hidden="true"></i> </a>-->
                                                    </div>
                                                </div>
                                            </div>
                                            <!--/.overlay-portfolio-->
                                        </div>
                                    </div>
                                    <!--/.row-->
                                </div>
                                <!--/.col6-->
                                <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 portfolio-padding-fixer"> <img src="<?=base_url()?>public/front_assets/images/grap3.png" class="img-responsive center-block">
                                    <div class="overlay-portfolio">
                                        <div>
                                            <div>
                                                <h1>GLOBAL</h1>
                                                <p>Graphic Design</p>
                                                <!--<a href="#"> <i class="fa fa-arrows-alt" aria-hidden="true"></i> </a>
                                                <a href="#"> <i class="fa fa-paperclip" aria-hidden="true"></i> </a>-->
                                            </div>
                                        </div>
                                    </div>
                                    <!--/.overlay-portfolio-->
                                </div>
                                <!--/.col6-->
                            </div>
                            <!--/.row-->
                            <div class="row">
                                <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 portfolio-padding-fixer"> <img src="<?=base_url()?>public/front_assets/images/grap5.png" class="img-responsive center-block">
                                    <div class="overlay-portfolio">
                                        <div>
                                            <div>
                                                <h1>WINDOWS PC</h1>
                                                <p>Graphic Design</p>
                                                <!--<a href="#"> <i class="fa fa-arrows-alt" aria-hidden="true"></i> </a>
                                                <a href="#"> <i class="fa fa-paperclip" aria-hidden="true"></i> </a>-->
                                            </div>
                                        </div>
                                    </div>
                                    <!--/.overlay-portfolio-->
                                </div>
                                <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 portfolio-padding-fixer"> <img src="<?=base_url()?>public/front_assets/images/grap6.png" class="img-responsive center-block">
                                    <div class="overlay-portfolio">
                                        <div>
                                            <div>
                                                <h1>ZOOM / STEP IT</h1>
                                                <p>Graphic Design</p>
                                                <!--<a href="#"> <i class="fa fa-arrows-alt" aria-hidden="true"></i> </a>
                                                <a href="#"> <i class="fa fa-paperclip" aria-hidden="true"></i> </a>-->
                                            </div>
                                        </div>
                                    </div>
                                    <!--/.overlay-portfolio-->
                                </div>
                            </div>
                            <!--/.row-->
                        </div>
                        <div id="menu-5" class="tab-pane fade">
                            <div class="row">
                                <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
                                    <div class="row">
                                        <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 portfolio-padding-fixer"> <img src="<?=base_url()?>public/front_assets/images/plogo1.png" class="img-responsive center-block">
                                            <div class="overlay-portfolio">
                                                <div>
                                                    <div>
                                                        <h1>Parfumerie Nasreen</h1>
                                                        <p>Logo Design</p>
                                                        <!--<a href="#"> <i class="fa fa-arrows-alt" aria-hidden="true"></i> </a>
                                                        <a href="#"> <i class="fa fa-paperclip" aria-hidden="true"></i> </a>-->
                                                    </div>
                                                </div>
                                            </div>
                                            <!--/.overlay-portfolio-->
                                        </div>
                                        <div class="col-lg-6 col-md-6 col-sm-12 col-xs-12 portfolio-padding-fixer"> <img src="<?=base_url()?>public/front_assets/images/plogo2.png" class="img-responsive center-block">
                                            <div class="overlay-portfolio">
                                                <div>
                                                    <div>
                                                        <h1>Champions</h1>
                                                        <p>Logo Design</p>
                                                        <!--<a href="#"> <i class="fa fa-arrows-alt" aria-hidden="true"></i> </a>
                                                        <a href="#"> <i class="fa fa-paperclip" aria-hidden="true"></i> </a>-->
                                                    </div>
                                                </div>
                                            </div>
                                            <!--/.overlay-portfolio-->
                                        </div>
                                    </div>
                                    <!--/.row-->
                                    <div class="row">
                                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12 portfolio-padding-fixer"> <img src="<?=base_url()?>public/front_assets/images/plogo3.png" class="img-responsive center-block">
                                            <div class="overlay-portfolio">
                                                <div>
                                                    <div>
                                                        <h1>dreamtime solutions</h1>
                                                        <p>logo Design</p>
                                                        <!--<a href="#"> <i class="fa fa-arrows-alt" aria-hidden="true"></i> </a>
                                                        <a href="#"> <i class="fa fa-paperclip" aria-hidden="true"></i> </a>-->
                                                    </div>
                                                </div>
                                            </div>
                                            <!--/.overlay-portfolio-->
                                        </div>
                                    </div>
                                    <!--/.row-->
                                </div>
                                <!--/.col6-->
                                <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 portfolio-padding-fixer"> <img src="<?=base_url()?>public/front_assets/images/plogo6.png" class="img-responsive center-block">
                                    <div class="overlay-portfolio">
                                        <div>
                                            <div>
                                                <h1>Encore</h1>
                                                <p>Logo Design</p>
                                                <!--<a href="#"> <i class="fa fa-arrows-alt" aria-hidden="true"></i> </a>
                                                <a href="#"> <i class="fa fa-paperclip" aria-hidden="true"></i> </a>-->
                                            </div>
                                        </div>
                                    </div>
                                    <!--/.overlay-portfolio-->
                                </div>
                                <!--/.col6-->
                            </div>
                            <!--/.row-->
                            <div class="row">
                                <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12 portfolio-padding-fixer"> <img src="<?=base_url()?>public/front_assets/images/plogo4.png" class="img-responsive center-block">
                                    <div class="overlay-portfolio">
                                        <div>
                                            <div>
                                                <h1>Bella's</h1>
                                                <p>Logo design</p>
                                                <!--<a href="#"> <i class="fa fa-arrows-alt" aria-hidden="true"></i> </a>
                                                <a href="#"> <i class="fa fa-paperclip" aria-hidden="true"></i> </a>-->
                                            </div>
                                        </div>
                                    </div>
                                    <!--/.overlay-portfolio-->
                                </div>
                                <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12 portfolio-padding-fixer"> <img src="<?=base_url()?>public/front_assets/images/plogo5.png" class="img-responsive center-block">
                                    <div class="overlay-portfolio">
                                        <div>
                                            <div>
                                                <h1>Busmycar</h1>
                                                <p>Logo Design</p>
                                                <!--<a href="#"> <i class="fa fa-arrows-alt" aria-hidden="true"></i> </a>
                                                <a href="#"> <i class="fa fa-paperclip" aria-hidden="true"></i> </a>-->
                                            </div>
                                        </div>
                                    </div>
                                    <!--/.overlay-portfolio-->
                                </div>
                            </div>
                            <!--/.row-->
                        </div>
                    </div>
                    <!--/.tab-content-->
                </div>
                <!--/.col8-->
            </div>
            <!--/.row-->
        </div>
        <!--/.container-->
    </div>
    <!--/.row-->
    <!-- Portfolio:End -->

    <div class="sectionClientSay">
  <div class="container">
    <h1>WHAT OUR CLIENT SAYS</h1>
    <div class="wraperTestimonials">
      <div class="iconTestimonial"> <img src="<?=base_url()?>public/front_assets/css/images/iconTestimonial.png" alt="*" /> </div>
      <div class="owl-carousel owl-theme sliderTestimonial">
        <div class="item">
          <div class="wrapTestimonials">
            <div class="contentTestimonials">
              <p class="author">HELEN</p>
              <p>Thank you to Fitser for designing my new website.  Sukhwinder (Harry) in particular was very helpful in ensuring that everything to do with the website was done to my satisfaction.  I also thank Sukhwinder (Harry) for his continued assistance with the website to make sure it’s everything that I had hoped it would be.  I was really happy with the price too as it was less than half of what I was quoted from another company.  I highly recommend Fitser.</p>
            </div>
            <!-- contentTestimonials --> 
          </div>
        </div>
        <!-- item -->
        <div class="item">
          <div class="wrapTestimonials">
            <div class="contentTestimonials">
              <p class="author">GRANT COOPER</p>
              <p>Gary, I just want to tell you how impressed I am with the quality of the logos you sent. Your team is obviously very talented, and your customer service is world class. Again, thank you for all you have done to exceed my expectations.</p>
              
            </div>
            <!-- contentTestimonials --> 
            
          </div>
        </div>
        <!-- item -->
        <div class="item">
          <div class="wrapTestimonials">
            <div class="contentTestimonials">
              <p class="author">Anthony Klump</p>
              <p>I have no hesitation in recommending Fitser to anyone requiring a web-site.I found them not only to be very professional to deal with but proactive, on time and above all helpful. I’m extremely happy with the work done by Sukhwinder (Harry) and the team of designers and programmers at Fitser, the end result exceeded my expectations.</p>
            </div>
            <!-- contentTestimonials -->             
          </div>
        </div>
        <!-- item -->
      </div>
      <!-- owl-carousol --> 
    </div>
    <!-- wraperTestimonials --> 
    <a href="#GITForm" class="btnCallBack">Request a Call Back</a> </div>
</div>
    <!-- sectionClientSay -->
    <div class="sectionCounter">
        <div class="container">
            <div class="row">
                <div class="col-sm-3">
                    <div class="wraperCounter">
                        <h3>Projects</h3>
                        <div class="numscroller numscroller-big-bottom" data-slno="5" data-min="0" data-max="620" data-delay="1" data-increment="1">0</div>
                    </div>
                </div>
                <!-- col-sm-3 -->
                <div class="col-sm-3">
                    <div class="wraperCounter">
                        <h3>Working Days</h3>
                        <div class="numscroller numscroller-big-bottom" data-slno="5" data-min="0" data-max="365" data-delay="1" data-increment="1">0</div>
                    </div>
                </div>
                <!-- col-sm-3 -->
                <div class="col-sm-3">
                    <div class="wraperCounter">
                        <h3>Team Member</h3>
                        <div class="numscroller numscroller-big-bottom" data-slno="5" data-min="0" data-max="100" data-delay="1" data-increment="1">0</div>
                    </div>
                </div>
                <!-- col-sm-3 -->
                <div class="col-sm-3">
                    <div class="wraperCounter">
                        <h3>Happy Clients</h3>
                        <div class="numscroller numscroller-big-bottom" data-slno="5" data-min="0" data-max="500" data-delay="1" data-increment="1">0</div>
                    </div>
                </div>
                <!-- col-sm-3 -->
            </div>
        </div>
    </div>
    <!-- sectionCounter -->
    <section class="callback">
        <div class="container">
            <h3>Have Questions? Feel Free To Ask Us!</h3>
            <a href="#" class="callback_bttn">Request A call back</a> </div>
    </section>
    <section class="footer">
        <div class="container">
            <h3>Contact Us</h3>
            <span><i class="fa fa-phone" aria-hidden="true"></i><span class="flag"><img src="<?=base_url()?>public/front_assets/css/images/flagUsa.png" alt="*" /></span> <a href="tel:(+1) 3605383135">(+1) 3605383135 </a>
            <span class="flag"><img src="<?=base_url()?>public/front_assets/css/images/flagAus.png" alt="*" /></span><a href="tel:(+61) 280113465">(+61) 280113465</a></span>
            <div> <span><i class="fa fa-envelope" aria-hidden="true"></i><a href="mailto:info@fitser.com">info@fitser.com</a></span> </div>
        </div>
    </section>
    <div class="sectionFooterBottom">
        <div class="container">
            <p>© <?=date('Y')?> <a href="https://www.fitser.com" target="_blank" style="color: white;">Fitser</a>  . All Rights Reserved</p>
        </div>
    </div>
    <!-- sectionFooterBottom -->
    <script src="<?=base_url()?>public/front_assets/js/numscroller-1.0.js"></script>
    <script src="<?=base_url()?>public/front_assets/js/intlTelInput.js"></script>
    <script src="<?=base_url()?>public/front_assets/js/jquery.validate.min.js"></script>
    <script src="<?=base_url()?>public/front_assets/js/custom.js" type="text/javascript"></script>
    <script>
          $(function () {
                /*$('#schedule').datetimepicker({
                    format: 'DD-MM-YYYY HH:mm',
                    ignoreReadonly: true,
                    minDate:new Date()
                });
                $('#schedule2').datetimepicker({
                    format: 'DD-MM-YYYY HH:mm',
                    ignoreReadonly: true,
                    minDate:new Date()
                });*/
            });
        var input = document.querySelector("#country_code");
        window.intlTelInput(input, {
          autoPlaceholder: "off",
          separateDialCode: true,
          onlyCountries: ['us', 'ca', 'au'],
          preferredCountries: []
        });
        var input2 = document.querySelector("#country_code2");
        window.intlTelInput(input2, {
          autoPlaceholder: "off",
          separateDialCode: true,
          onlyCountries: ['us', 'ca', 'au'],
          preferredCountries: []
        });
        $("#contact_form2").validate({
          errorPlacement: function(error, element) {
          // Append error within linked label
          $( element )
            .closest( "form" )
              .find( "label[for='" + element.attr( "id" ) + "']" )
                .append( error );
        },
        errorElement: "span",
        messages: {
          name: {
            required: " (required)"
          },
          email: {
            required: " (required)",
            email: true
          },
          phone: {
            required: " (required)"
          },
          schedule: {
            required: " (required)"
          },
          message: {
            required: " (required)"
          }
        }
        })
        $("#contact_form").validate({
          errorPlacement: function(error, element) {
          // Append error within linked label
          $( element )
            .closest( "form" )
              .find( "label[for='" + element.attr( "id" ) + "']" )
                .append( error );
        },
        errorElement: "span",
        messages: {
          name: {
            required: " (required)"
          },
          email: {
            required: " (required)",
            email: true
          },
          phone: {
            required: " (required)"
          },
          schedule: {
            required: " (required)"
          },
          message: {
            required: " (required)"
          }
        }
        })
    </script>
    <!--DATE TIME PICKER-->
</body>
</html>