<!-- header section -->
      <!-- Begin Page Content -->
      <div class="container-fluid">
        <!-- Page Heading -->
        <!-- Content Row -->  
        <div class="neworder">
        	<div class="row">
                <div class="col-md-6 col-sm-12 col-xs-12">
                	<div class="neworder_l_inner">
                    	<h3>Product <?=isset($details)?'Edit':'Add'?></h3>
                    </div>
                </div>
                <div class="col-md-6 col-sm-12 col-xs-12">
                	<div class="neworder_r">
                    	<ul>
                        	<li><a href="<?=base_url('admin/product')?>">Product List</a></li>                          
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <form id="frm-product" action="<?=base_url('admin/product/save')?>" method="POST" enctype="multipart/form-data">
        <input type="hidden" name="product_id" value="<?=isset($details)?$details->product_id:''?>">
          <div class="view_panel">
            <div class="row">
                  <div class="col-md-4 col-sm-12 col-xs-12">
                    <div class="form-group">
                        <label>Select Vendor <sup>*</sup></label>
                          <select class="form-control" id="vendor" name="vendor" required>
                          <option value="">Select Vendor</option>
                            <?php
			                                  $this->join[] = ['table' => 'users u', 'on' => 'u.user_id = vd.user_id', 'type' => 'left'];
                              $vendors = $this->common_model->select('vendor_details vd', ['vd.status'=> 1, 'u.role_id'=> 2], 'vd.*', 'vd.vendor_name', 'asc', $this->join);
                              if($vendors){
                                foreach($vendors as $value){
                                  $status = '';
                                  if(isset($details)){
                                    //vendor_id::vendor_details
                                    if($details->vendor_id == $value->vendor_id){
                                      $status = 'selected';
                                    }
                                  }
                                  echo '<option value="'.$value->vendor_id.'" '.$status.'>'.$value->vendor_name.'</option>';
                                }
                              }else{
                                echo '<option value="'.$value->vendor_id.'">No vendor found. <a href="'.base_url("admin/vendor/add").'">Add vendor</a></option>';
                              }
                            ?>
                          </select>
                      </div>
                  </div>  
                <div class="col-md-4 col-sm-12 col-xs-12">
                    <div class="form-group">
                        <label>Product ID <sup>*</sup></label>
                        <input class="form-control" name="product_suk_id" id="product_suk_id" type="text" placeholder="" value="<?=isset($details)?$details->product_suk_id:set_value('product_suk_id')?>" required/>
                      </div>
                  </div>
                  
                  <div class="col-md-4 col-sm-12 col-xs-12">
                    <div class="form-group">
                        <label>Product name <sup>*</sup></label>                       
                          <input class="form-control" name="product_name" name="product_name" type="text" placeholder="" value="<?=isset($details)?$details->product_name:set_value('product_name')?>" required/>
                      </div>
                  </div>  
                  
                  <div class="col-md-4 col-sm-12 col-xs-12">
                    <div class="form-group">
                        <label>Product Category <sup>*</sup></label>
                          <select class="form-control" id="category" name="category" required>
                          <option value="">Select Category</option>
                            <?php
                              $categories = $this->common_model->select('categories', ['status'=> 1], 'categories.*');
                              if($categories){
                                foreach($categories as $value){
                                  $status = '';
                                  if(isset($details)){
                                    if($details->category_id == $value->category_id){
                                      $status = 'selected';
                                    }
                                  }
                                  echo '<option value="'.$value->category_id.'" '.$status.'>'.$value->category_name.'</option>';
                                }
                              }else{
                                echo '<option value="'.$value->category_id.'">No category found. <a href="'.base_url("admin/category/add").'">Add category</a></option>';
                              }
                            ?>
                          </select>
                      </div>
                  </div>  
                  
                  <div class="col-md-4 col-sm-12 col-xs-12">
                    <div class="form-group">
                      <label>Product Price <sup>*</sup></label>
                      <input class="form-control" type="number" min="1" step=".001" id="price" name="price"  value="<?=isset($details)?round($details->price, 2):set_value('price')?>" required />
                    </div>
                  </div>
                  <div class="col-md-4 col-sm-12 col-xs-12">
                    <div class="form-group">
                      <label>Product Image <sup>*</sup></label>
                      <input class="form-control" type="file" id="image" name="image" accept="image/*"  <?=isset($details)?'':'required'?> />
                    </div>
                  </div>
                  <div class="col-md-4 col-sm-12 col-xs-12 image-section" style="display:<?=isset($details)?'':'none'?>">
                    <div class="form-group">
                      <img src="<?=isset($details)?base_url('uploads/product/').$details->product_image:base_url('uploads/product/').'no_image.png'?>" alt="preview" id="preview-image" style="width: 100%; border:1px solid #ccc; padding:5px; display: <?=isset($details)?'':'none'?>">
                    </div>
                  </div>                  
                  <div class="col-md-4 col-sm-12 col-xs-12">
                    <div class="form-group">
                        <label>Description</label>                       
                          <textarea class="form-control" id="description" name="description" placeholder="Description.."><?=isset($details)?$details->description:set_value('description')?></textarea>
                      </div>
                  </div>
                  <div class="col-md-12 col-sm-12 col-xs-12">
                    <div class="form-group" align="right">
                      <input type="submit"  id="btn-save-product" value="Submit"/>
                      </div>
                  </div>
              </div>
          </div>
        </form>
        
        <!-- Content Row -->
        <!-- Content Row -->
      </div>
      <!-- /.container-fluid -->
      <!-- footer section -->
      <script>
	$(document).ready(function () {
		function readURL(input, previewElement) {
      if(input.files[0]['type']== 'image/jpg' || input.files[0]['type']== 'image/jpeg' || input.files[0]['type']== 'image/gif' || input.files[0]['type'] == 'image/png'){
        if (input.files && input.files[0]) {
          var reader = new FileReader();

          reader.onload = function (e) {
            $('.image-section').show();
            $(previewElement).attr('src', e.target.result);
            $(previewElement).show();
          }
          reader.readAsDataURL(input.files[0]); // convert to base64 string
        }
      }
      else{
        $("#image").val('');
            $('.image-section').hide();
        swalAlert('Please select a valid image', 'warning');
        return false;
      }
		}

		$("#image").change(function () {
			readURL(this, '#preview-image');
		});
	})

</script>