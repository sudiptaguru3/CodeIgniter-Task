<!-- header section -->
<!-- Begin Page Content -->
<div class="container-fluid">
	<!-- Page Heading -->

	<!-- Content Row -->
	<div class="neworder">
		<div class="row">
			<div class="col-md-6 col-sm-12 col-xs-12">
				<div class="neworder_l_inner">
					<h3><?=isset($details)?'Edit':'Add'?> Delivery</h3>
				</div>
			</div>
			<div class="col-md-6 col-sm-12 col-xs-12">
				<div class="neworder_r">
					<ul>
						<li><a href="<?=base_url('admin/delivery')?>">Delivery List</a></li>
					</ul>
				</div>
			</div>
		</div>
  </div>
  <form id="frm-vendor" action="<?=base_url('admin/delivery/save')?>" method="POST" enctype="multipart/form-data">
    <input type="hidden" name="user_id" value="<?=isset($details)?$details->user_id:''?>">
    <div class="view_panel">
      <div class="row">
        <div class="col-md-4 col-sm-12 col-xs-12">
          <div class="form-group">
              <label>Select Vendor <sup>*</sup></label>
                <select class="form-control chosen-select" data-placeholder="Select vendor" id="vendor" name="vendor[]" required multiple>
                <option value="">Select Vendor</option>
                <?php
                    $this->join[] = ['table' => 'users u', 'on' => 'u.user_id = vd.user_id', 'type' => 'left'];
                    $vendors = $this->common_model->select('vendor_details vd', ['vd.status'=> 1, 'u.role_id'=> 2], 'vd.*', 'vd.vendor_name', 'asc', $this->join);
                    if($vendors){
                      if(isset($details)){
                        $selectedVendors = $this->common_model->select('delivery_vendor', ['user_id'=> $details->user_id], 'delivery_vendor.vendor_id');
                        $vendorArray = array_column($selectedVendors,"vendor_id");
                      }
                      foreach($vendors as $value){
                        $status = '';
                        if(isset($details)){
                          //vendor_id::vendor_details
                          if(in_array($value->vendor_id, $vendorArray)){
                            $status = 'selected';
                          }
                        }
                        echo '<option value="'.$value->vendor_id.'" '.$status.'>'.$value->vendor_name.'</option>';
                      }
                    }else{
                      echo '<option value="'.$value->vendor_id.'">No vendor found. <a href="'.base_url("admin/vendor/add").'">Add vendor</a></option>';
                    }
                  ?>
                </select>
            </div>
        </div>
        <div class="col-md-4 col-sm-12 col-xs-12">
          <div class="form-group">
            <label>First Name <sup>*</sup></label>
            <input class="form-control" type="text" id="fname" name="fname" placeholder="First name" required value="<?=isset($details)?$details->fname:''?>"/>
          </div>
        </div>
        <div class="col-md-4 col-sm-12 col-xs-12">
          <div class="form-group">
            <label>Last Name <sup>*</sup></label>
            <input class="form-control" type="text" id="lname" name="lname" placeholder="Last name" required value="<?=isset($details)?$details->lname:''?>"/>
          </div>
        </div>
        <div class="col-md-4 col-sm-12 col-xs-12">
          <div class="form-group">
            <label>Email <sup>*</sup></label>
            <input class="form-control" type="email" id="email" name="email" placeholder="abcd@mail.com" required value="<?=isset($details)?$details->email:''?>"/>
          </div>
        </div>
        <div class="col-md-4 col-sm-12 col-xs-12">
          <div class="form-group">
            <label>Mobile <sup>*</sup></label>
            <input class="form-control" type="tel" minlength="10" maxlength="15" id="mobile" name="mobile" placeholder="98786543987" required value="<?=isset($details)?$details->mobile:''?>" oninput="this.value = this.value.replace(/[^0-9]/g, '')"/>
          </div>
        </div>
        <div class="col-md-4 col-sm-12 col-xs-12">
          <div class="form-group">
            <label>Address <sup>*</sup></label>
            <input class="form-control" type="text" id="address" name="address" placeholder="Address" required value="<?=isset($details)?$details->address:''?>"/>
          </div>
        </div>
        <div class="col-md-4 col-sm-12 col-xs-12">
          <div class="form-group">
            <label>Password <sup>*</sup></label>
            <input class="form-control" type="password" id="password" name="password" placeholder="*******"  value="<?=isset($details)?'':'required'?>"/>
          </div>
        </div>       
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="form-group" align="right">
            <input type="submit" id="btn-save" value="Submit" />
          </div>
        </div>
      </div>
    </div>
  </form>
	<!-- Content Row -->
	<!-- Content Row -->
</div>
<!-- /.container-fluid -->
<!-- footer section -->
<script>
$(document).ready(function(){
  $(".chosen-select").chosen({
      placeholder_text_single: "Select Vendor",
    });
})
</script>
