<?php
if (isset($membership_types)) {
	if (!empty($membership_types)) {
		foreach ($membership_types as $key => $value) {
			if ($value->status == 0) {
				$status = '<a href="javascript:void(0)" id="' . $value->membership_type_id . '" class="change-p-status text-danger" data-status="1" data-table="membership_types" data-key-id="membership_type_id" data-id="' . $value->membership_type_id . '">Inactive</a>';
			} else if ($value->status == 1) {
				$status = '<a href="javascript:void(0)" id="' . $value->membership_type_id . '" class="change-p-status text-success" data-status="0" data-table="membership_types" data-key-id="membership_type_id" data-id="' . $value->membership_type_id . '">Active</a>';
			}
			$html .= '<tr>
						<td>' . ($key+1) . '</td>
                    	<td>' . $value->membership_type . '</td>
                    	<td>' . substr($value->description,100).'...' . '</td>
                    	<td>' . $status . '</td>
						<td>
							<a class="edit_class" href="'.base_url("admin/membership-type/edit/".$value->membership_type_id).'"><img src="'.base_url("public/admin/").'img/pinkedit.png" alt="pinkedit"/></a>
                    		<a href="javascript:void(0)" class="btn btn-gray change-p-status" data-fnc="getOperationAreaList" data-status="3" data-f="del" data-table="membership_types" data-key-id="membership_type_id" data-id="' . $value->membership_type_id . '"><i class="fa fa-trash"></i></a>
                    	</td>
                    </tr>';
		}
	}else{
		$html .='<tr>
				<td colspan="3" align="center">
					No data found
				</td>
			</tr>';
	}
	echo $html;
} //end membership_types
if (isset($categories)) {
	if (!empty($categories)) {
		foreach ($categories as $key => $value) {
			if ($value->status == 0) {
				$status = '<a href="javascript:void(0)" id="' . $value->category_id . '" class="change-p-status text-danger" data-status="1" data-table="categories" data-key-id="category_id" data-id="' . $value->category_id . '">Inactive</a>';
			} else if ($value->status == 1) {
				$status = '<a href="javascript:void(0)" id="' . $value->category_id . '" class="change-p-status text-success" data-status="0" data-table="categories" data-key-id="category_id" data-id="' . $value->category_id . '">Active</a>';
			}
			$html .= '<tr>
						<td>' . ($key+1) . '</td>
                    	<td><span>' . $value->category_name . '</span></td>
                    	<td><img class="cat_img_table" src="' . $value->category_image . '" alt="cat1"/></td>
                    	<td>' . $status . '</td>
						<td>
							<a class="edit_class" href="'.base_url("admin/category/edit/".$value->category_id).'"><img src="'.base_url("public/admin/").'img/pinkedit.png" alt="pinkedit"/></a>
                    		<a href="javascript:void(0)" class="btn btn-gray change-p-status" data-fnc="getOperationAreaList" data-status="3" data-f="del" data-table="categories" data-key-id="category_id" data-id="' . $value->category_id . '"><i class="fa fa-trash"></i></a>
                    	</td>
                    </tr>';
		}
	}else{
		$html .='<tr>
				<td colspan="5" align="center">
					No data found
				</td>
			</tr>';
	}
	echo $html;
} //end Categories
if (isset($vendors)) {
	if (!empty($vendors)) {
		foreach ($vendors as $key => $value) {
			if ($value->status == 0) {
				$status = '<a href="javascript:void(0)" id="' . $value->user_id . '" class="change-p-status text-danger" data-status="1" data-table="users" data-key-id="user_id" data-id="' . $value->user_id . '">Inactive</a>';
			} else if ($value->status == 1) {
				$status = '<a href="javascript:void(0)" id="' . $value->user_id . '" class="change-p-status text-success" data-status="0" data-table="users" data-key-id="user_id" data-id="' . $value->user_id . '">Active</a>';
			}
			$html .= '<tr>
						<td>' . ($key+1) . '</td>
						<td>' . ucwords($value->vendor_name) . '</td>
                    	<td><span>' . $value->email . '</span></td>
						<td>' . $value->address . '</td>
                    	<td><img class="cat_img_table" src="' . $value->vendor_image . '" alt="vendor"/></td>
                    	<td>' . $status . '</td>
						<td>
							<a class="edit_class" href="'.base_url("admin/vendor/edit/".$value->user_id).'"><img src="'.base_url("public/admin/").'img/pinkedit.png" alt="pinkedit"/></a>
                    		<a href="javascript:void(0)" class="btn btn-gray change-p-status" data-status="3" data-f="del" data-table="users" data-key-id="user_id" data-id="' . $value->user_id . '"><i class="fa fa-trash"></i></a>
                    	</td>
                    </tr>';
		}
	}else{
		$html .='<tr>
				<td colspan="7" align="center">
					No data found
				</td>
			</tr>';
	}
	echo $html;
} //end Vendors
if (isset($delivery)) {
	if (!empty($delivery)) {
		foreach ($delivery as $key => $value) {
			if ($value->status == 0) {
				$status = '<a href="javascript:void(0)" id="' . $value->user_id . '" class="change-p-status text-danger" data-status="1" data-table="users" data-key-id="user_id" data-id="' . $value->user_id . '">Inactive</a>';
			} else if ($value->status == 1) {
				$status = '<a href="javascript:void(0)" id="' . $value->user_id . '" class="change-p-status text-success" data-status="0" data-table="users" data-key-id="user_id" data-id="' . $value->user_id . '">Active</a>';
			}
			$html .= '<tr>
						<td>' . ($key+1) . '</td>
						<td>' . ucwords($value->fname.' '.$value->lname) . '</td>
                    	<td><span>' . $value->email . '</span></td>
                    	<td>' . $value->mobile . '</td>
						<td>' . $value->address . '</td>
                    	<td>' . $status . '</td>
						<td>
							<a class="edit_class" href="'.base_url("admin/delivery/edit/".$value->user_id).'"><img src="'.base_url("public/admin/").'img/pinkedit.png" alt="pinkedit"/></a>
                    		<a href="javascript:void(0)" class="btn btn-gray change-p-status" data-status="3" data-f="del" data-table="users" data-key-id="user_id" data-id="' . $value->user_id . '"><i class="fa fa-trash"></i></a>
                    	</td>
                    </tr>';
		}
	}else{
		$html .='<tr>
				<td colspan="7" align="center">
					No data found
				</td>
			</tr>';
	}
	echo $html;
} //end Delivery boy
if (isset($products)) {
	if (!empty($products)) {
		foreach ($products as $key => $value) {
			if ($value->status == 0) {
				$status = '<a href="javascript:void(0)" id="' . $value->product_id . '" class="change-p-status text-danger" data-status="1" data-table="products" data-key-id="product_id" data-id="' . $value->product_id . '">Inactive</a>';
			} else if ($value->status == 1) {
				$status = '<a href="javascript:void(0)" id="' . $value->product_id . '" class="change-p-status text-success" data-status="0" data-table="products" data-key-id="product_id" data-id="' . $value->product_id . '">Active</a>';
			}
			if($value->product_image ==""){
				$value->product_image = base_url('uploads/no_image.png');
			}
			$html .= '<tr>
						<td>' . ($key+1) . '</td>
						<td>#' . $value->product_suk_id . '</td>
                    	<td>' . $value->product_name . '</td>
                    	<td><span>' . $value->category_name . '</span></td>
						<td><img class="cat_img_table" src="' . $value->product_image . '" alt="cat1"/></td>
						<td>' . substr($value->description,0, 50) . '..</td>
						<td>$'.round($value->price, 2).'</td>
						<td>'.ucwords($value->vendor_name).'</td>
                    	<td>' . $status . '</td>
						<td>
							<a class="edit_class" href="'.base_url("admin/product/edit/".$value->product_id).'"><img src="'.base_url("public/admin/").'img/pinkedit.png" alt="pinkedit"/></a>
                    		<a href="javascript:void(0)" class="btn btn-gray change-p-status" data-fnc="getOperationAreaList" data-status="3" data-f="del" data-table="products" data-key-id="product_id" data-id="' . $value->product_id . '"><i class="fa fa-trash"></i></a>
                    	</td>
                    </tr>';
		}
	}else{
		$html .='<tr>
				<td colspan="8" align="center">
					No data found
				</td>
			</tr>';
	}
	echo $html;
} //end Produces
if (isset($charges)) {
	if (!empty($charges)) {
		foreach ($charges as $key => $value) {
			if ($value->status == 0) {
				$status = '<a href="javascript:void(0)" id="' . $value->id . '" class="change-p-status text-danger" data-status="1" data-table="delivery_charges" data-key-id="id" data-id="' . $value->id . '">Inactive</a>';
			} else if ($value->status == 1) {
				$status = '<a href="javascript:void(0)" id="' . $value->id . '" class="change-p-status text-success" data-status="0" data-table="delivery_charges" data-key-id="id" data-id="' . $value->id . '">Active</a>';
			}
			$html .= '<tr>
						<td>' . ($key+1) . '</td>
						<td>' . $value->item_quantity . '</td>
                    	<td>' . round($value->amount, 2) . '</td>
                    	<td>' . $status . '</td>
						<td>
							<a class="edit_class" href="'.base_url("admin/charge/edit/".$value->id).'"><img src="'.base_url("public/admin/").'img/pinkedit.png" alt="pinkedit"/></a>
                    		<a href="javascript:void(0)" class="btn btn-gray change-p-status" data-fnc="getOperationAreaList" data-status="3" data-f="del" data-table="delivery_charges" data-key-id="id" data-id="' . $value->id . '"><i class="fa fa-trash"></i></a>
                    	</td>
                    </tr>';
		}
	}else{
		$html .='<tr>
				<td colspan="8" align="center">
					No data found
				</td>
			</tr>';
	}
	echo $html;
} //end Charge
