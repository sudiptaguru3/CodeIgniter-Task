<?php
$membership_type_query = $this->db->query('SELECT * FROM membership_types WHERE `status` = 1'); 
$membership_type=$membership_type_query->result_array();
?>

<!-- header section -->
<!-- Begin Page Content -->
<div class="container-fluid">
  <!-- Page Heading -->

  <!-- Content Row -->
  <div class="neworder">
    <div class="row">
      <div class="col-md-6 col-sm-12 col-xs-12">
        <div class="neworder_l_inner">
          <h3>Subscription <?=isset($details)?'Edit':'Add'?></h3>
        </div>
      </div>
      <div class="col-md-6 col-sm-12 col-xs-12">
        <div class="neworder_r">
          <ul>
            <li><a href="<?=base_url('admin/subscription')?>">Subscription List</a></li>
          </ul>
        </div>
      </div>
    </div>
  </div>
  <?php if ($this->session->flashdata('success_msg')) : ?>
        <div class="alert alert-success">
            <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
            <?php echo $this->session->flashdata('success_msg') ?>
        </div>
    <?php endif ?>
    <?php if ($this->session->flashdata('error_msg')) : ?>
        <div class="alert alert-danger">
            <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
            <?php echo $this->session->flashdata('error_msg') ?>
        </div>
    <?php endif ?>
  <form id="frm-vendor" action="<?=base_url('admin/subscription/subscriptionsave')?>" method="POST" enctype="multipart/form-data">
    <input type="hidden" name="subscription_id" value="<?=isset($details)?$details->subscription_id:''?>">
    <div class="view_panel">
      <div class="row">

        
        <div class="col-md-4 col-sm-12 col-xs-12">
          <div class="form-group">
            <label>Select Subscription Name *</label>
            <select class="form-control" id="subscription_name" name="subscription_name" value="<?=isset($details)?$details->subscription_name:''?>" required="">
                <option value="">Select Subscription Name</option>
                <?php if(!empty($membership_type)){
                  foreach ($membership_type as $key => $value) { ?>
                 <option value="<?php echo $value['membership_type_id']; ?>" <?php if($value['membership_type_id']==$details->membership_type_id) { ?>selected="" <?php } ?>><?php echo $value['membership_type']; ?></option>
                 <?php            
                  }
                  } ?>
            </select>
          </div>
        </div> 

        <div class="col-md-4 col-sm-12 col-xs-12">
          <div class="form-group">
              <label>Select Subscription Type *</label>
                <select class="form-control" id="subscription_type" name="subscription_type" value="<?=isset($details)?$details->subscription_type:''?>" required="">
                <option value="">Select Subscription Type</option>
                <option value="Monthly" <?php if($details->subscription_type=="Monthly"){ ?>selected=""<?php } ?>>Monthly</option>
                <option value="Yearly" <?php if($details->subscription_type=="Yearly"){ ?>selected=""<?php } ?>>Yearly</option> </select>
          </div>
        </div>
      
        <div class="col-md-4 col-sm-12 col-xs-12">
          <div class="form-group">
            <label>Amount *</label>
            <input class="form-control" type="number" id="amount" name="amount" placeholder="Enter Amount " required value="<?=isset($details)?$details->amount:''?>"/>
          </div>
        </div>      
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="form-group" align="right">
            <input type="submit" id="btn-save" value="Submit" />
          </div>
        </div>
      </div>
    </div>
  </form>
  <!-- Content Row -->
  <!-- Content Row -->
</div>
<!-- /.container-fluid -->
<!-- footer section -->
<script>
$(document).ready(function(){
  $(".chosen-select").chosen();
})
</script>

