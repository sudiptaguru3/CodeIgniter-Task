<!-- Header section -->
      <!-- Begin Page Content -->
      <div class="container-fluid">
        <!-- Page Heading -->        
        <!-- Content Row -->
        <div class="neworder">
        	<div class="row">
                <div class="col-md-6 col-sm-12 col-xs-12">
                	<div class="neworder_l_inner">
                    	<h3>Offer</h3>
                    </div>
                </div>
                <div class="col-md-6 col-sm-12 col-xs-12">
                	<div class="neworder_r">
                    	<ul>
                        	<li><a href="<?= base_url('admin/offer/add')?>">Add Offer</a></li>                          
                        	<!-- <li><a href="javascript:void(0)" data-toggle="modal" data-target="#csvModal">CSV Upload</a></li>                           -->
                        </ul>
                    </div>
                </div>
            </div>
        </div>        
        <div class="dashboard_table">
        	<div class="table_panel">
              <div class="table-responsive">
                <table class="table table-bordered caltable" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>Sl No.</th>
                      <th>Store Name</th>
                      <th>Minimum Amount</th>
                      <th>Maximum Amount</th>
                      <th>Discount(Percentage)</th>
                      <th>Status</th>
                      <th>Action</th>
                    </tr>
                  </thead>                 
            <tbody>
            <?php 
            if(!empty($details)){
            foreach ($details as $key => $value) { ?>
            <?php
            if ($value['status'] == 0) {
            $status = '<a href="javascript:void(0)" id="' . $value['offer_id'] . '" class="change-p-status text-danger" data-status="1" data-table="offer" data-key-id="offer_id" data-id="'.$value['offer_id'].'">Inactive</a>';
            } else if ($value['status'] == 1) {
            $status = '<a href="javascript:void(0)" id="' . $value['offer_id'] . '" class="change-p-status text-success" data-status="0" data-table="offer" data-key-id="offer_id" data-id="'.$value['offer_id'].'">Active</a>';
            }
           ?>
            <tr role="row" class="odd">
            <td class="sorting_1"><?=($key+1)?></td>
            <td><?php echo $value['vendor_name']; ?></td>
            <td><?php echo $value['minimum_amount']; ?></td>
            <td><?php echo $value['maximum_amount']; ?></td>
            <td><?php echo $value['percentage']; ?></td>
            <td><?=$status?></td>
            <td>
              <a class="edit_class" href="<?=base_url('admin/offer/add/'.$value['offer_id'])?>"><img src="<?=base_url()?>public/admin/img/pinkedit.png" alt="pinkedit"></a>
              <a href="javascript:void(0)" class="btn btn-gray change-p-status" data-status="3" data-f="del" data-table="offer" data-key-id="offer_id" data-id="<?=$value['offer_id']?>"><i class="fa fa-trash"></i> Delete</a>
            </td>
            </tr>
            <?php            
            }
            } ?>
            </tbody>
          </table>  
          </div>
          </div>
        </div>
        <!-- Content Row -->
        <!-- Content Row -->
      </div>
      <!-- /.container-fluid -->
      <!-- Footer Area -->
      <!-- csv upload modal -->
      <!-- Logout Modal-->
      <div class="modal fade" id="csvModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="exampleModalLabel">Ready to Upload Delivery Boy List (.csv)</h5>
              <button class="close" type="button" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">×</span> </button>
            </div>
            <form id="frm-csv" action="" mathod="post">
              <div class="modal-body">
                  <div class="form-group">
                    <label>Select Delivery Boy List</label>
                    <input class="form-control" type="file" id="image" name="image" required />
                    <a href="<?=base_url('uploads/delivery.csv')?>">Download sample</a>
                  </div>
              </div>
              <div class="modal-footer">
                <button class="btn btn-secondary" type="button" data-dismiss="modal">Cancel</button>
                <button type="submit" class="btn btn-primary" href="javascript:void(0)" id="btn-upload">Upload</button> </div>
            </div>
          </form>
        </div>
      </div>
      
      <script>
        $(document).ready(function(){
           $('#dataTable').DataTable({
                        });

          $("#image").change(function () {
            //readURL(this, '#preview-product');
            if(this.files[0]['type'] != 'application/vnd.ms-excel'){
              $("#image").val('');
                swalAlert('Please select a valid CSV', 'warning');
                return false;
              }
          });
          //start uploading
          $('#frm-csv').submit(function(e){
              e.preventDefault();
              var formData = new FormData(this);
              $.ajax({
              type: "POST",
              url: base_url + "delivery/csv-upload",
              data: formData,
                  cache: false,
                  contentType: false,
                  processData: false,
              beforeSend: function() {
              },
              success: function(res) {
                if (res.status.error_code == 0) {
                        swalAlert(res.status.message, "success");
                        location.reload();
                    } else {
                        swalAlert(res.status.message, "warning");
                    }
              }
            })
          })
        })
       
      </script>