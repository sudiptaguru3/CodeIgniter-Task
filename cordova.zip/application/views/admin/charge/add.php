<!-- header section -->
<!-- Begin Page Content -->
<div class="container-fluid">
	<!-- Page Heading -->

	<!-- Content Row -->
	<div class="neworder">
		<div class="row">
			<div class="col-md-6 col-sm-12 col-xs-12">
				<div class="neworder_l_inner">
					<h3>Charge <?=isset($details)?'Edit':'Add'?></h3>
				</div>
			</div>
			<div class="col-md-6 col-sm-12 col-xs-12">
				<div class="neworder_r">
					<ul>
						<li><a href="<?=base_url('admin/charge')?>">Delivery Charge List</a></li>
					</ul>
				</div>
			</div>
		</div>
  </div>
  <form id="frm-charge" action="<?=base_url('admin/charge/save')?>" method="POST" enctype="multipart/form-data">
    <input type="hidden" name="id" value="<?=isset($details)?$details->id:''?>">
    <div class="view_panel">
      <div class="row">
        <div class="col-md-4 col-sm-12 col-xs-12">
          <div class="form-group">
            <label>Quantity *</label>
            <input class="form-control" type="text" id="item_quantity" name="item_quantity" placeholder="Quantity" required value="<?=isset($details)?$details->item_quantity:''?>"/>
          </div>
        </div>
        <div class="col-md-4 col-sm-12 col-xs-12">
          <div class="form-group">
            <label>Amount *</label>
            <input class="form-control" type="number" min="1" id="amount" name="amount" placeholder="amount" required value="<?=isset($details)?round($details->amount, 2):''?>"/>
          </div>
        </div>        
        <div class="col-md-12 col-sm-12 col-xs-12">
          <div class="form-group" align="right">
            <input type="submit" id="btn-save" value="Submit" />
          </div>
        </div>
      </div>
    </div>
  </form>
	<!-- Content Row -->
	<!-- Content Row -->
</div>
<!-- /.container-fluid -->
<!-- footer section -->
