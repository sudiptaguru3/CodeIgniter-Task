<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home_m extends CI_Model
{


	public function __construct()
	{
		parent::__construct();
		
	}

	function get_search_result($sql){
        $q = $this -> db -> query($sql);
        $result =   $q -> result_array();
    
        $arr = array();
       
        
        foreach ($result as $k => $row){
            $arr[] = $row;
            $arr[$k]['schedule'] = $this -> db -> get_where('foodtruck_schedule', ['truck_owner_id' => $row['user_id']]) -> first_row('array');
           // $arr[$k]['menu'] = $this -> db -> get_where('food_menu', ['user_id' => $row['user_id']]) -> result_array();
            $arr[$k]['truck_images'] = $this -> db -> get_where('truck_images', ['user_id' => $row['user_id']]) -> first_row('array');

        }

       return $arr;
    }

    function get_search_detail($uid){
        $f = array();
        
        // truck detail
      
        $f['truck'] = $this -> db -> get_where('truck_details',['user_id' => $uid]) -> row_array();
//echo $this->db->last_query();die;
        // truck images

        $f['truck_images'] =  $this -> db -> get_where('truck_images',['user_id' => $uid]) -> result_array();

        // sched

        $f['schedule'] =  $this -> db -> get_where('foodtruck_schedule',['truck_owner_id' => $uid]) -> result_array();

        // menu

        $f['menu'] =  $this -> db -> get_where('food_menu',['user_id' => $uid]) -> result_array();

        // chef

        $f['chef'] =  $this -> db -> get_where('chef',['uid' => $uid]) -> result_array();

        // truck owner dtail

        $f['user_detail'] =  $this -> db -> get_where('user',['user_id' => $uid]) -> row_array();

        return $f;

    }
}
