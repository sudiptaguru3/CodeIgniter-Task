<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Foodtruck_m extends CI_Model
{
	private $_table = 'user';

	public function __construct()
	{
		parent::__construct();
		
	}

	function get($group_id){

			$this -> db -> where('status','1');
			$this -> db -> where('group_id', $group_id);
			$this -> db -> order_by('first_name');
			$q = $this -> db -> get($this -> _table);
			return $q -> result_array();
	
	}


	function get_all(){
		$sql = "SELECT u.first_name, u.last_name, u.email,u.mobile, u.user_id as uid, t.*
		FROM user u, truck_details t
		WHERE u.user_id = t.user_id
		ORDER BY first_name";

		return $this -> db -> query($sql) -> result_array();
	}

	function get_detail($id){
	
			$sql = "SELECT u.first_name, u.last_name, u.email,u.mobile, u.user_id as uid, t.*
			FROM user u, truck_details t
			WHERE u.user_id = t.user_id
			AND u.user_id = '$id'";
			return $this -> db -> query($sql) -> row_array();
		
		
		
	}
	
	function get_row($id){
	    $this -> db -> where('group_id', $group_id);
		return $this -> db -> get_where('user');
	}
	
	function get_menu_images($id){
		return $this -> db -> get_where('food_menu', ['user_id' => $id]) -> result_array();
		
	}

}
