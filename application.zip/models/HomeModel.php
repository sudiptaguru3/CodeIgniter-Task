<?php

class HomeModel extends CI_Model{
    function __construct() { 
        // Set table name 
        $this->table = 'slug'; 
    }
    function register($insertArray){
        
        if($this->db->insert('slug',$insertArray)){
            return true;
        }else{
            return false;
        }
    }

    public function get_data($id=0)
    {
        if($id==0)
        {
            $query = $this->db->get('slug')->result();
            return $query;
        }
        else
        {
            $this->db->where('id',$id);
            $query = $this->db->get('slug')->result();
            return $query;
        }
        
    }

    public function getUserdata()
    {
        $this->load->database();
        $this->db->where("id",1);
        $q=$this->db->get("slug");
        return $q->result_array();
    }
}

?>