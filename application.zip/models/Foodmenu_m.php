<?php
class Foodmenu_m extends CI_Model
{
	public $_table = 'food_menu';
	
	function __construct ()
	{
		parent::__construct();
	}

	public function get_menu_detail($id)
	{
		$this -> db -> where('user_id', $id);
		return $this -> db -> get($this -> _table) -> result_array();
	}
	
	 
}