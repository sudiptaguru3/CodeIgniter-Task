<div class="content-wrapper">
<div class="content-header">
   <div class="container-fluid">
      <div class="row mb-2">
         <div class="col-sm-6">
         </div>
         <!-- /.col -->
         <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
               <li><a href="<?=base_url('administrator/UserController')?>">List CMs</a></li>
            </ol>
         </div>
         <!-- /.col -->
      </div>
      <!-- /.row -->
   </div>
   <!-- /.container-fluid -->
</div>
<!-- Main content -->
<section class="content">
   <div class="container-fluid">
   <div class="row">
   <!-- left column -->
   <div class="col-md-12">
    <?php echo validation_errors(); ?>
            <?php
               if($this -> session -> flashdata('success')) {?>
            <div class="alert alert-info" role="alert">
               <?=$this -> session -> flashdata('success')?>
            </div>
            <?php } ?>
            <?php
               if($this -> session -> flashdata('error')) {?>
            <div class="alert alert-danger" role="alert">
               <?=$this -> session -> flashdata('error')?>
            </div>
            <?php } ?>
   <!-- general form elements -->
   <div class="card card-primary">
      <div class="card-header">
         <h3 class="card-title">Edit User</h3>
      </div>
      <!-- /.card-header -->


       <div class="card-body">   
         <form action="<?= base_url('UserController/updateData') ?>" method="post">
            <input type="hidden" class="" id="" name="user_id" value="<?php echo $cms['user_id'] ?>">
            <div class="form-group">
               <label for="exampleInputEmail1"> First Name</label>
               <input type="text" class="form-control" id="first_name" name="first_name" value="<?php echo $cms['first_name'] ?>">
            </div>
            <div class="form-group">
               <label for="exampleInputEmail1"> Last Name</label>
               <input type="text" class="form-control" id="last_name" name="last_name" value="<?php echo $cms['last_name'] ?>">
            </div>
            <div class="form-group">
               <label for="exampleInputEmail1"> Mobile</label>
               <input type="number" class="form-control mobile" id="mobile" name="mobile" value="<?php echo $cms['mobile'] ?>">
               <!-- <input type="number" value="<?=set_value('mobile')?>" name="mobile" placeholder="Phone..." maxlength="10" class="mobile"> -->
            </div>
            <div class="form-group">
               <label for="exampleInputEmail1"> Email</label>
               <input type="text" class="form-control" id="email" name="email" value="<?php echo $cms['email'] ?>">
            </div>
            
           <!--  <div class="form-group">
               <label for="exampleInputEmail1">Description</label>
              
                <textarea name="slug" value="" placeholder="Enter content"><?php echo $cms['content'] ?>
                </textarea>
            </div> -->
           
            <!-- /.card-body -->
      </div>
    
      <div class="card-footer">
      <button type="submit" class="btn btn-primary">Submit</button>
      </div>
      </form>
     </div>
     </div>
      
     </div>
      </div>
</section>
</div>
<!-- <script src="https://cdn.ckeditor.com/4.16.0/standard/ckeditor.js"></script>
<script>
   CKEDITOR.replace( 'slug' );
</script> -->
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script type="text/javascript">
  $('.mobile').keypress(function(e) {
      var arr = [];
      var kk = e.which;
   
      for (i = 48; i < 58; i++)
          arr.push(i);
   
      if (!(arr.indexOf(kk)>=0))
          e.preventDefault();
  });
</script>