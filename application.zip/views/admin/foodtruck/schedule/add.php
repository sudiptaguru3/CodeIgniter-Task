<link rel="stylesheet" href="//cdnjs.cloudflare.com/ajax/libs/timepicker/1.3.5/jquery.timepicker.min.css">

<script src="//cdnjs.cloudflare.com/ajax/libs/timepicker/1.3.5/jquery.timepicker.min.js"></script>
 <script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyDlLzPELOjOEuzfy5ky8pbx-dZfkC2ib2Y&libraries=places"></script>
 <div class="content-wrapper">
<div class="content-header">
   <div class="container-fluid">
      <div class="row mb-2">
         <div class="col-sm-6">
         </div>
         <!-- /.col -->
         <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
               <li><a href="<?=base_url('administrator/Foodtruck/manage/'.$u['uid'])?>"><i class="fa fa-tasks"></i> Manage Food truck</a></li>
            </ol>
         </div>
         <!-- /.col -->
      </div>
      <!-- /.row -->
   </div>
   <!-- /.container-fluid -->
</div>
    <!-- Main content -->
  <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">
             <?php if($this -> session -> flashdata('success')) {?>
                <div class="alert alert-info" role="alert">
                  <?=$this -> session -> flashdata('success')?>
                </div>

            <?php } ?>

          </div>
        </div>
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- general form elements -->
          <div class="card">
              <div class="card-header">
                <h3 class="card-title">Add Schedule</h3>

                <div class="card-tools">
                  <div class="input-group input-group-sm" style="width: 150px;">
                    <button class="btn btn-primary" id="save-btn">Publish</button>
                  </div>
                </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body table-responsive p-0">				
                 <table id="sched_table" class="table table-hover text-nowrap">                                                     
                  <tbody>                                                          
                       <?php
						$day = ['MON','TUE','WED','THU','FRI','SAT','SUN',];

						 foreach ($day as $k=> $d) {
						   $k++;
						   ?>
						<tr>
										<td><input type="checkbox" class="day" name="day" value="<?php echo $d?>" /> <?php echo $d?></td>

										

<td>
  
     <div class="form-group">

    
  <input type="text"  class="form-control timepicker start_time" placeholder="Start time">
 

    </div>

</td>

<td>
 

   
      
  
     <div class="form-group">

     
  <input type="text" class="form-control timepicker end_time" placeholder="End time">
 
</div>
    </div>
   
</td>
		 <td>  
			<input type="text" name="location" id="<?php echo 'loc_'.$k?>" class="form-control location" placeholder="location" />
		</td>

                                                               
                                                              

                                                            </tr>
													<?php
												 }
												 ?>
                                                  
                                                        </tbody>
                                                    </table>
              </div>
              <!-- /.card-body -->
            </div>

          </div>


       
 
          
              </div>
           
      </div>
    </section>
  </div>
 <input type="hidden" id="truck_owner_id" value="<?=$u['uid']?>" />
  <script>
   $(document).ready(function(){
    $('.timepicker').timepicker({
	timeFormat: 'H:mm',

    dropdown: true,
    scrollbar: true
		
	});
	
	initialize();
});
  </script>
  
  <script>
function initialize() {

    var acInputs = document.getElementsByClassName("location");

    for (var i = 0; i < acInputs.length; i++) {

        var autocomplete = new google.maps.places.Autocomplete(acInputs[i]);
        autocomplete.inputId = acInputs[i].id;

        google.maps.event.addListener(autocomplete, 'place_changed', function () {
            document.getElementById("log").innerHTML = 'You used input with id ' + this.inputId;
        });
    }
}

</script>

<script>
$(function(){
    $("#save-btn").click(function(e){
        e.preventDefault();
 
        var table_data =  [];
        var sub;
        $("#sched_table tbody tr").each(function(row,tr){
      
             sub = {
                        'day': $(this).find('td:eq(0)').find(":input").val(),
                        'start_time':$(this).find('td:eq(1)').find(":input").val(),
                        'end_time': $(this).find('td:eq(2)').find(":input").val(),
                        'location': $(this).find('td:eq(3)').find(":input").val()
            }
          table_data.push(sub);

        });
		
        var truck_owner_id = $("#truck_owner_id").val();
      
		
        $.ajax({
            url:"<?=base_url('administrator/Foodtruck/save_schedule_ajax')?>",
            data:{schedule_data:table_data,truck_owner_id:truck_owner_id},
            type:'post',
			dataType: 'json'
        }).done(function(res){
            if (res == '1'){
               alert('Added successfully...');
            } else {
              alert('Problem occured...');
            }
        }).catch(function(error){
				console.log(error);
        });
  });
});
</script>
  
  