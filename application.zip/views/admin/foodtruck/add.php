<div class="content-wrapper">
<div class="content-header">
   <div class="container-fluid">
      <div class="row mb-2">
         <div class="col-sm-6">
         </div>
         <!-- /.col -->
         <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
               <li><a href="<?=base_url('administrator/Foodtruck')?>"><i class="fa fa-list"></i> List Food Truck</a></li>
            </ol>
         </div>
         <!-- /.col -->
      </div>
      <!-- /.row -->
   </div>
   <!-- /.container-fluid -->
</div>
<!-- Main content -->
<section class="content">
   <div class="container-fluid">
   <div class="row">
   <!-- left column -->
   <div class="col-md-12">
   <!-- general form elements -->
  
         <!-- general form elements -->
        <?php
         if($this -> session -> flashdata('uploaderror')) {
           $er =  $this -> session -> flashdata('uploaderror');
          echo  $er;
           
         } 
         ?>


         <?php echo validation_errors(); ?>
         <?php
            if($this -> session -> flashdata('success')) {?>
         <div class="alert alert-info" role="alert">
            <?=$this -> session -> flashdata('success')?>
         </div>
         <?php } ?>
         <?php
            if($this -> session -> flashdata('error')) {?>
         <div class="alert alert-danger" role="alert">
            <?=$this -> session -> flashdata('error')?>
         </div>
         <?php } ?>
    
   <div class="card card-primary">
      <div class="card-header">
         <h3 class="card-title">Add Truck Details</h3>
      </div>
      <!-- /.card-header -->
      <!-- form start -->
      <div class="card-body">
         <form action="" method="post" autocomplete="off" enctype="multipart/form-data">
         <div class="row">
          <div class="col-sm-6">
         <div class="form-group">
               <label for="role">Select Owner name</label>
               <select class="form-control" name="owner_id" id="owner_id">
                  <option value="">--select--</option>
                 <?php
                   if (count($details)){
                   foreach ($details as $d){?>
                  <option value="<?=$d['user_id']?>"><?= $d['first_name'].' '.$d['last_name']?></option>
                  <?php 
                  }
               } 
               ?>
                               
               </select>
            </div>
            </div>

            <div class="col-sm-6">
            <div class="form-group">
               <label for="exampleInputEmail1">Truck Name</label>
               <input type="text" class="form-control" id="truck_name" name="truck_name" value="<?=set_value('truck_name')?>" placeholder="Enter food truck name">
            </div>
            </div>
            </div>
           
            <div class="row">
           <div class="col-sm-6">
            <div class="form-group">
               <label for="exampleInputEmail1">Email ID</label>
               <input type="text" class="form-control" id="email" disabled name="email"   value="<?=set_value('email')?>"  autocomplete="off" placeholder="Email...">
            </div>
            </div>
            <div class="col-sm-6">
            <div class="form-group">
               <label for="exampleInputEmail1">Contact No.</label>
               <input type="text" class="form-control" id="mobile" disabled name="mobile" value="<?=set_value('mobile')?>"  placeholder="Contact no ...">
            </div>
              </div>
              </div>

              <div class="row">
           <div class="col-sm-6">
            <div class="form-group">
               <label for="exampleInputEmail1">Facebook</label>
               <input type="text" class="form-control" id="facebook" name="facebook"  value="<?=set_value('facebook')?>"   placeholder="Facebook...">
            </div>
            </div>
            
           <div class="col-sm-6">
            <div class="form-group">
               <label for="exampleInputEmail1">Twitter</label>
               <input type="text" class="form-control" id="twitter" name="twitter"  value="<?=set_value('twitter')?>"  placeholder="Twitter...">
            </div>
            </div>
            </div>
			
			
			
              <div class="row">
           <div class="col-sm-6">
            <div class="form-group">
               <label for="exampleInputEmail1">LinkedIn</label>
               <input type="text" class="form-control" id="linkedin" name="linkedin" value="<?=set_value('linkedin')?>"  placeholder="LinkedIn...">
            </div>
			</div>

			 <div class="col-sm-6">
            <div class="form-group">
               <label for="exampleInputEmail1">Website</label>
               <input type="text" class="form-control" id="website" name="website"  value="<?=set_value('website')?>" placeholder="Website...">
            </div>
			</div>
			</div>

            <div class="form-group">
               <label for="exampleInputEmail1">Upload Truck Image</label>
               <input type="file" class="form-control" id="file" name="files[]" multiple  />
            </div>
           
         
            <!-- /.card-body -->
      </div>
    
      <div class="card-footer">
      <button type="submit" class="btn btn-primary">Submit</button>
      </div>
      </form>
     </div>
     </div>
     
     </div>
      </div>
</section>
</div>

<script>
$(function(){
  $("#owner_id").change(function(){
     var user_id = this.value;

     if (this.value == ""){
        alert("Please select owner name...");
        return false;
     }

     $.ajax({
               url: '<?=base_url('administrator/Foodtruck/get_user_detail_by_id_ajax')?>',
               type:'post',
               data:{user_id:user_id}

     }).done(function(res){
        var data = JSON.parse(res);
        $("#email").val(data.email);
        $("#mobile").val(data.mobile);

     }).catch(function(){

     });
  });
})
</script>