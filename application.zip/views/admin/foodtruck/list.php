<div class="content-wrapper">
<div class="content-header">
   <div class="container-fluid">
      <div class="row mb-2">
         <div class="col-sm-6">
         </div>
         <!-- /.col -->
         <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
               <li><a href="<?=base_url('administrator/Foodtruck/add')?>"><i class="fa fa-plus"></i> Add Food Truck</a></li>
            </ol>
         </div>
         <!-- /.col -->
      </div>
      <!-- /.row -->
   </div>
   <!-- /.container-fluid -->
</div>
    <!-- Main content -->
  <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">
             <?php if($this -> session -> flashdata('success')) {?>
                <div class="alert alert-info" role="alert">
                  <?=$this -> session -> flashdata('success')?>
                </div>

            <?php } ?>

          </div>
        </div>
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- general form elements -->
          <div class="card">
              <div class="card-header">
                <h3 class="card-title">Food Truck List</h3>

                <div class="card-tools">
                  <div class="input-group input-group-sm" style="width: 150px;">
                    <input type="text" name="table_search" class="form-control float-right" placeholder="Search">

                    <div class="input-group-append">
                      <button type="submit" class="btn btn-default">
                        <i class="fas fa-search"></i>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body table-responsive p-0">
                <table class="table table-hover text-nowrap">
                  <thead>
                    <tr>
                    <th>Truck Name</th>
                      <th>Owner name</th>
                     
                      <th>Contact</th>
                      <th>Email</th>
                      <th>Created</th>
                      <th>Action</th>
                      
                  </thead>
                  <tbody>
                  <?php
                  if (count($truck_list)){
                    foreach ($truck_list as  $k => $u) {?>
                    <tr>
                   
                      <td><?=$u['first_name'].' '.$u['last_name']?></td>
                      <td><?=$u['truck_name']?></td>
                      <td><?=$u['mobile']?></td>
                      <td><?=$u['email']?></td>
                      <td><?=date('j-m-y',strtotime($u['created_at']))?></td>
                      <td>
					  <a href="<?=base_url('administrator/Foodtruck/view/'.$u['uid'])?>"><i class="fa fa-eye"></i></a> | 
					  <a href="<?=base_url('administrator/Foodtruck/manage/'.$u['uid'])?>"><i class="fa fa-tasks"></i></a>
					  </td>
                    
                   
                    
                    </tr>
                   <?php 
                 }
                 }
                   ?>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>

          </div>


       
 
          
              </div>
           
      </div>
    </section>
  </div>