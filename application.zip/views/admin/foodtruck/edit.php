<div class="content-wrapper">
<div class="content-header">
   <div class="container-fluid">
      <div class="row mb-2">
         <div class="col-sm-6">
         </div>
         <!-- /.col -->
         <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
               <li><a href="<?=base_url('administrator/User')?>"><i class="fa fa-plus"></i> List User</a></li>
            </ol>
         </div>
         <!-- /.col -->
      </div>
      <!-- /.row -->
   </div>
   <!-- /.container-fluid -->
</div>
<!-- Main content -->
<section class="content">
   <div class="container-fluid">
   <div class="row">
   <!-- left column -->
   <div class="col-md-6">
   <!-- general form elements -->
   <div class="card card-primary">
      <div class="card-header">
         <h3 class="card-title">Edit User</h3>
      </div>
      <!-- /.card-header -->
      <!-- form start -->
      <div class="card-body">
         <form action="<?=base_url('administrator/User/update/'.$user['user_id'])?>" method="post">
         <input type="hidden" name="user_id" value="<?=$user['user_id']?>"  />
            <div class="form-group">
               <label for="exampleInputEmail1">First Name</label>
               <input type="text" class="form-control" id="first_name" name="first_name" value="<?=set_value('first_name',$user['first_name'])?>" placeholder="Enter first name">
            </div>
            <div class="form-group">
               <label for="exampleInputEmail1">Last Name</label>
               <input type="text" class="form-control" id="last_name" name="last_name"  value="<?=set_value('last_name',$user['last_name'])?>" placeholder="Enter last name">
            </div>

            <div class="form-group">
               <label for="exampleInputEmail1">Email</label>
               <input type="text" class="form-control" disabled  value="<?=$user['email']?>">
            </div>

            <div class="form-group">
               <label for="exampleInputEmail1">Password</label>
               <input type="password" class="form-control" name="password"  />
            </div>
         

            <div class="form-group">
               <label for="role">Select Role</label>
               <select class="form-control" name="role" id="role">
                  <option value="">--select--</option>
                  <?php
                     foreach ($group as $g) {?>
                  <option value="<?=$g['group_id']?>"  <?php if ($g['group_id'] == $user['group_id']) echo ' selected';?>><?=$g['name']?></option>
                  <?php } ?>
               </select>
            </div>
            <div class="form-check-inline">
               <input class="form-check-input" type="radio" name="status" value="1" <?php if ($user['status'] == '1') echo ' checked'?>>
               <label class="form-check-label">Active</label>
            </div>
            <div class="form-check-inline">
               <input class="form-check-input" type="radio" name="status" value="0" <?php if ($user['status'] == '0') echo ' checked'?>>
               <label class="form-check-label">Inactive</label>
            </div>
            <!-- /.card-body -->
    
    
      <div class="card-footer">
      <button type="submit" class="btn btn-primary">Update</button>
      </div>
      </form>
     </div>
     </div>
     </div>
      <div class="col-md-6">
         <!-- general form elements -->
       
         <?php
            if($this -> session -> flashdata('success')) {?>
         <div class="alert alert-info" role="alert">
            <?=$this -> session -> flashdata('success')?>
         </div>
         <?php } ?>
         <?php
            if($this -> session -> flashdata('error')) {?>
         <div class="alert alert-danger" role="alert">
            <?=$this -> session -> flashdata('error')?>
         </div>
         <?php } ?>

          <?php
            if($this -> session -> flashdata('fail')) {?>
         <div class="alert alert-danger" role="alert">
            <?=$this -> session -> flashdata('fail')?>
         </div>
         <?php } ?>
      </div>
     </div>
      </div>
</section>
</div>