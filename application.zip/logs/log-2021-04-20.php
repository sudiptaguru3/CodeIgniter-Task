<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-04-20 15:30:40 --> Config Class Initialized
INFO - 2021-04-20 15:30:40 --> Hooks Class Initialized
DEBUG - 2021-04-20 15:30:40 --> UTF-8 Support Enabled
INFO - 2021-04-20 15:30:40 --> Utf8 Class Initialized
INFO - 2021-04-20 15:30:40 --> URI Class Initialized
DEBUG - 2021-04-20 15:30:40 --> No URI present. Default controller set.
INFO - 2021-04-20 15:30:40 --> Router Class Initialized
INFO - 2021-04-20 15:30:40 --> Output Class Initialized
INFO - 2021-04-20 15:30:40 --> Security Class Initialized
DEBUG - 2021-04-20 15:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 15:30:40 --> Input Class Initialized
INFO - 2021-04-20 15:30:40 --> Language Class Initialized
INFO - 2021-04-20 15:30:40 --> Loader Class Initialized
INFO - 2021-04-20 15:30:40 --> Helper loaded: url_helper
INFO - 2021-04-20 15:30:40 --> Helper loaded: form_helper
INFO - 2021-04-20 15:30:40 --> Helper loaded: common_helper
INFO - 2021-04-20 15:30:40 --> Helper loaded: util_helper
INFO - 2021-04-20 15:30:40 --> Helper loaded: user_helper
INFO - 2021-04-20 15:30:40 --> Database Driver Class Initialized
DEBUG - 2021-04-20 15:30:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 15:30:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 15:30:40 --> Form Validation Class Initialized
INFO - 2021-04-20 15:30:40 --> Controller Class Initialized
INFO - 2021-04-20 15:30:40 --> Model Class Initialized
INFO - 2021-04-20 15:30:40 --> Model Class Initialized
INFO - 2021-04-20 15:30:40 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-20 15:30:40 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-20 15:30:40 --> Final output sent to browser
DEBUG - 2021-04-20 15:30:40 --> Total execution time: 0.0463
INFO - 2021-04-20 15:30:40 --> Config Class Initialized
INFO - 2021-04-20 15:30:40 --> Hooks Class Initialized
DEBUG - 2021-04-20 15:30:40 --> UTF-8 Support Enabled
INFO - 2021-04-20 15:30:40 --> Utf8 Class Initialized
INFO - 2021-04-20 15:30:40 --> URI Class Initialized
INFO - 2021-04-20 15:30:40 --> Router Class Initialized
INFO - 2021-04-20 15:30:40 --> Output Class Initialized
INFO - 2021-04-20 15:30:40 --> Security Class Initialized
DEBUG - 2021-04-20 15:30:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 15:30:40 --> Input Class Initialized
INFO - 2021-04-20 15:30:40 --> Language Class Initialized
ERROR - 2021-04-20 15:30:40 --> 404 Page Not Found: Fassets/img
INFO - 2021-04-20 15:30:42 --> Config Class Initialized
INFO - 2021-04-20 15:30:42 --> Hooks Class Initialized
DEBUG - 2021-04-20 15:30:42 --> UTF-8 Support Enabled
INFO - 2021-04-20 15:30:42 --> Utf8 Class Initialized
INFO - 2021-04-20 15:30:42 --> URI Class Initialized
INFO - 2021-04-20 15:30:42 --> Router Class Initialized
INFO - 2021-04-20 15:30:42 --> Output Class Initialized
INFO - 2021-04-20 15:30:42 --> Security Class Initialized
DEBUG - 2021-04-20 15:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 15:30:42 --> Input Class Initialized
INFO - 2021-04-20 15:30:42 --> Language Class Initialized
INFO - 2021-04-20 15:30:42 --> Loader Class Initialized
INFO - 2021-04-20 15:30:42 --> Helper loaded: url_helper
INFO - 2021-04-20 15:30:42 --> Helper loaded: form_helper
INFO - 2021-04-20 15:30:42 --> Helper loaded: common_helper
INFO - 2021-04-20 15:30:42 --> Helper loaded: util_helper
INFO - 2021-04-20 15:30:42 --> Helper loaded: user_helper
INFO - 2021-04-20 15:30:42 --> Database Driver Class Initialized
DEBUG - 2021-04-20 15:30:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 15:30:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 15:30:42 --> Form Validation Class Initialized
INFO - 2021-04-20 15:30:42 --> Controller Class Initialized
INFO - 2021-04-20 15:30:42 --> Model Class Initialized
INFO - 2021-04-20 15:30:42 --> Model Class Initialized
INFO - 2021-04-20 15:30:42 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\register.php
INFO - 2021-04-20 15:30:42 --> Final output sent to browser
DEBUG - 2021-04-20 15:30:42 --> Total execution time: 0.0264
INFO - 2021-04-20 15:30:42 --> Config Class Initialized
INFO - 2021-04-20 15:30:42 --> Hooks Class Initialized
INFO - 2021-04-20 15:30:42 --> Config Class Initialized
INFO - 2021-04-20 15:30:42 --> Hooks Class Initialized
DEBUG - 2021-04-20 15:30:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-20 15:30:42 --> UTF-8 Support Enabled
INFO - 2021-04-20 15:30:42 --> Utf8 Class Initialized
INFO - 2021-04-20 15:30:42 --> Utf8 Class Initialized
INFO - 2021-04-20 15:30:42 --> URI Class Initialized
INFO - 2021-04-20 15:30:42 --> URI Class Initialized
INFO - 2021-04-20 15:30:42 --> Router Class Initialized
INFO - 2021-04-20 15:30:42 --> Router Class Initialized
INFO - 2021-04-20 15:30:42 --> Output Class Initialized
INFO - 2021-04-20 15:30:42 --> Output Class Initialized
INFO - 2021-04-20 15:30:42 --> Security Class Initialized
INFO - 2021-04-20 15:30:42 --> Security Class Initialized
DEBUG - 2021-04-20 15:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 15:30:42 --> Input Class Initialized
DEBUG - 2021-04-20 15:30:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 15:30:42 --> Input Class Initialized
INFO - 2021-04-20 15:30:42 --> Language Class Initialized
INFO - 2021-04-20 15:30:42 --> Language Class Initialized
ERROR - 2021-04-20 15:30:42 --> 404 Page Not Found: Fasset/img
ERROR - 2021-04-20 15:30:42 --> 404 Page Not Found: Fasset/img
INFO - 2021-04-20 16:09:18 --> Config Class Initialized
INFO - 2021-04-20 16:09:18 --> Hooks Class Initialized
DEBUG - 2021-04-20 16:09:18 --> UTF-8 Support Enabled
INFO - 2021-04-20 16:09:18 --> Utf8 Class Initialized
INFO - 2021-04-20 16:09:18 --> URI Class Initialized
DEBUG - 2021-04-20 16:09:18 --> No URI present. Default controller set.
INFO - 2021-04-20 16:09:18 --> Router Class Initialized
INFO - 2021-04-20 16:09:18 --> Output Class Initialized
INFO - 2021-04-20 16:09:18 --> Security Class Initialized
DEBUG - 2021-04-20 16:09:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 16:09:18 --> Input Class Initialized
INFO - 2021-04-20 16:09:18 --> Language Class Initialized
INFO - 2021-04-20 16:09:18 --> Loader Class Initialized
INFO - 2021-04-20 16:09:18 --> Helper loaded: url_helper
INFO - 2021-04-20 16:09:18 --> Helper loaded: form_helper
INFO - 2021-04-20 16:09:18 --> Helper loaded: common_helper
INFO - 2021-04-20 16:09:18 --> Helper loaded: util_helper
INFO - 2021-04-20 16:09:18 --> Helper loaded: user_helper
INFO - 2021-04-20 16:09:18 --> Database Driver Class Initialized
DEBUG - 2021-04-20 16:09:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 16:09:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 16:09:18 --> Form Validation Class Initialized
INFO - 2021-04-20 16:09:18 --> Controller Class Initialized
INFO - 2021-04-20 16:09:18 --> Model Class Initialized
INFO - 2021-04-20 16:09:18 --> Model Class Initialized
INFO - 2021-04-20 16:09:18 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-20 16:09:18 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-20 16:09:18 --> Final output sent to browser
DEBUG - 2021-04-20 16:09:18 --> Total execution time: 0.0300
INFO - 2021-04-20 16:09:29 --> Config Class Initialized
INFO - 2021-04-20 16:09:29 --> Hooks Class Initialized
DEBUG - 2021-04-20 16:09:29 --> UTF-8 Support Enabled
INFO - 2021-04-20 16:09:29 --> Utf8 Class Initialized
INFO - 2021-04-20 16:09:29 --> URI Class Initialized
INFO - 2021-04-20 16:09:29 --> Router Class Initialized
INFO - 2021-04-20 16:09:29 --> Output Class Initialized
INFO - 2021-04-20 16:09:29 --> Security Class Initialized
DEBUG - 2021-04-20 16:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 16:09:29 --> Input Class Initialized
INFO - 2021-04-20 16:09:29 --> Language Class Initialized
INFO - 2021-04-20 16:09:29 --> Loader Class Initialized
INFO - 2021-04-20 16:09:29 --> Helper loaded: url_helper
INFO - 2021-04-20 16:09:29 --> Helper loaded: form_helper
INFO - 2021-04-20 16:09:29 --> Helper loaded: common_helper
INFO - 2021-04-20 16:09:29 --> Helper loaded: util_helper
INFO - 2021-04-20 16:09:29 --> Helper loaded: user_helper
INFO - 2021-04-20 16:09:29 --> Database Driver Class Initialized
DEBUG - 2021-04-20 16:09:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 16:09:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 16:09:29 --> Form Validation Class Initialized
INFO - 2021-04-20 16:09:29 --> Controller Class Initialized
INFO - 2021-04-20 16:09:29 --> Model Class Initialized
INFO - 2021-04-20 16:09:29 --> Model Class Initialized
INFO - 2021-04-20 16:09:29 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\register.php
INFO - 2021-04-20 16:09:29 --> Final output sent to browser
DEBUG - 2021-04-20 16:09:29 --> Total execution time: 0.0265
INFO - 2021-04-20 16:09:29 --> Config Class Initialized
INFO - 2021-04-20 16:09:29 --> Hooks Class Initialized
INFO - 2021-04-20 16:09:29 --> Config Class Initialized
INFO - 2021-04-20 16:09:29 --> Hooks Class Initialized
DEBUG - 2021-04-20 16:09:29 --> UTF-8 Support Enabled
INFO - 2021-04-20 16:09:29 --> Utf8 Class Initialized
DEBUG - 2021-04-20 16:09:29 --> UTF-8 Support Enabled
INFO - 2021-04-20 16:09:29 --> Utf8 Class Initialized
INFO - 2021-04-20 16:09:29 --> URI Class Initialized
INFO - 2021-04-20 16:09:29 --> URI Class Initialized
INFO - 2021-04-20 16:09:29 --> Router Class Initialized
INFO - 2021-04-20 16:09:29 --> Router Class Initialized
INFO - 2021-04-20 16:09:29 --> Output Class Initialized
INFO - 2021-04-20 16:09:29 --> Output Class Initialized
INFO - 2021-04-20 16:09:29 --> Security Class Initialized
INFO - 2021-04-20 16:09:29 --> Security Class Initialized
DEBUG - 2021-04-20 16:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 16:09:29 --> Input Class Initialized
DEBUG - 2021-04-20 16:09:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 16:09:29 --> Language Class Initialized
INFO - 2021-04-20 16:09:29 --> Input Class Initialized
INFO - 2021-04-20 16:09:29 --> Language Class Initialized
ERROR - 2021-04-20 16:09:29 --> 404 Page Not Found: Fasset/img
ERROR - 2021-04-20 16:09:29 --> 404 Page Not Found: Fasset/img
INFO - 2021-04-20 16:38:38 --> Config Class Initialized
INFO - 2021-04-20 16:38:38 --> Hooks Class Initialized
DEBUG - 2021-04-20 16:38:38 --> UTF-8 Support Enabled
INFO - 2021-04-20 16:38:38 --> Utf8 Class Initialized
INFO - 2021-04-20 16:38:38 --> URI Class Initialized
DEBUG - 2021-04-20 16:38:38 --> No URI present. Default controller set.
INFO - 2021-04-20 16:38:38 --> Router Class Initialized
INFO - 2021-04-20 16:38:38 --> Output Class Initialized
INFO - 2021-04-20 16:38:38 --> Security Class Initialized
DEBUG - 2021-04-20 16:38:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 16:38:38 --> Input Class Initialized
INFO - 2021-04-20 16:38:38 --> Language Class Initialized
INFO - 2021-04-20 16:38:38 --> Loader Class Initialized
INFO - 2021-04-20 16:38:38 --> Helper loaded: url_helper
INFO - 2021-04-20 16:38:38 --> Helper loaded: form_helper
INFO - 2021-04-20 16:38:38 --> Helper loaded: common_helper
INFO - 2021-04-20 16:38:38 --> Helper loaded: util_helper
INFO - 2021-04-20 16:38:38 --> Helper loaded: user_helper
INFO - 2021-04-20 16:38:38 --> Database Driver Class Initialized
DEBUG - 2021-04-20 16:38:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 16:38:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 16:38:38 --> Form Validation Class Initialized
INFO - 2021-04-20 16:38:38 --> Controller Class Initialized
INFO - 2021-04-20 16:38:38 --> Model Class Initialized
INFO - 2021-04-20 16:38:38 --> Model Class Initialized
INFO - 2021-04-20 16:38:38 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-20 16:38:38 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-20 16:38:38 --> Final output sent to browser
DEBUG - 2021-04-20 16:38:38 --> Total execution time: 0.0297
INFO - 2021-04-20 16:39:27 --> Config Class Initialized
INFO - 2021-04-20 16:39:27 --> Hooks Class Initialized
DEBUG - 2021-04-20 16:39:27 --> UTF-8 Support Enabled
INFO - 2021-04-20 16:39:27 --> Utf8 Class Initialized
INFO - 2021-04-20 16:39:27 --> URI Class Initialized
INFO - 2021-04-20 16:39:27 --> Router Class Initialized
INFO - 2021-04-20 16:39:27 --> Output Class Initialized
INFO - 2021-04-20 16:39:27 --> Security Class Initialized
DEBUG - 2021-04-20 16:39:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 16:39:27 --> Input Class Initialized
INFO - 2021-04-20 16:39:27 --> Language Class Initialized
ERROR - 2021-04-20 16:39:27 --> 404 Page Not Found: user/Cms/index
INFO - 2021-04-20 17:07:28 --> Config Class Initialized
INFO - 2021-04-20 17:07:28 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:07:28 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:07:28 --> Utf8 Class Initialized
INFO - 2021-04-20 17:07:28 --> URI Class Initialized
INFO - 2021-04-20 17:07:28 --> Router Class Initialized
INFO - 2021-04-20 17:07:28 --> Output Class Initialized
INFO - 2021-04-20 17:07:28 --> Security Class Initialized
DEBUG - 2021-04-20 17:07:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:07:28 --> Input Class Initialized
INFO - 2021-04-20 17:07:28 --> Language Class Initialized
ERROR - 2021-04-20 17:07:28 --> 404 Page Not Found: user/Cms/index
INFO - 2021-04-20 17:07:30 --> Config Class Initialized
INFO - 2021-04-20 17:07:30 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:07:30 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:07:30 --> Utf8 Class Initialized
INFO - 2021-04-20 17:07:30 --> URI Class Initialized
DEBUG - 2021-04-20 17:07:30 --> No URI present. Default controller set.
INFO - 2021-04-20 17:07:30 --> Router Class Initialized
INFO - 2021-04-20 17:07:30 --> Output Class Initialized
INFO - 2021-04-20 17:07:30 --> Security Class Initialized
DEBUG - 2021-04-20 17:07:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:07:30 --> Input Class Initialized
INFO - 2021-04-20 17:07:30 --> Language Class Initialized
INFO - 2021-04-20 17:07:30 --> Loader Class Initialized
INFO - 2021-04-20 17:07:30 --> Helper loaded: url_helper
INFO - 2021-04-20 17:07:30 --> Helper loaded: form_helper
INFO - 2021-04-20 17:07:30 --> Helper loaded: common_helper
INFO - 2021-04-20 17:07:30 --> Helper loaded: util_helper
INFO - 2021-04-20 17:07:30 --> Helper loaded: user_helper
INFO - 2021-04-20 17:07:30 --> Database Driver Class Initialized
DEBUG - 2021-04-20 17:07:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 17:07:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 17:07:30 --> Form Validation Class Initialized
INFO - 2021-04-20 17:07:30 --> Controller Class Initialized
INFO - 2021-04-20 17:07:30 --> Model Class Initialized
INFO - 2021-04-20 17:07:30 --> Model Class Initialized
INFO - 2021-04-20 17:07:30 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-20 17:07:30 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-20 17:07:30 --> Final output sent to browser
DEBUG - 2021-04-20 17:07:30 --> Total execution time: 0.0318
INFO - 2021-04-20 17:16:36 --> Config Class Initialized
INFO - 2021-04-20 17:16:36 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:16:36 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:16:36 --> Utf8 Class Initialized
INFO - 2021-04-20 17:16:36 --> URI Class Initialized
INFO - 2021-04-20 17:16:36 --> Router Class Initialized
INFO - 2021-04-20 17:16:36 --> Output Class Initialized
INFO - 2021-04-20 17:16:36 --> Security Class Initialized
DEBUG - 2021-04-20 17:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:16:36 --> Input Class Initialized
INFO - 2021-04-20 17:16:36 --> Language Class Initialized
INFO - 2021-04-20 17:16:36 --> Loader Class Initialized
INFO - 2021-04-20 17:16:36 --> Helper loaded: url_helper
INFO - 2021-04-20 17:16:36 --> Helper loaded: form_helper
INFO - 2021-04-20 17:16:36 --> Helper loaded: common_helper
INFO - 2021-04-20 17:16:36 --> Helper loaded: util_helper
INFO - 2021-04-20 17:16:36 --> Helper loaded: user_helper
INFO - 2021-04-20 17:16:36 --> Database Driver Class Initialized
DEBUG - 2021-04-20 17:16:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 17:16:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 17:16:36 --> Form Validation Class Initialized
INFO - 2021-04-20 17:16:36 --> Controller Class Initialized
INFO - 2021-04-20 17:16:36 --> Model Class Initialized
INFO - 2021-04-20 17:16:36 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\viewaccount.php
INFO - 2021-04-20 17:16:36 --> Final output sent to browser
DEBUG - 2021-04-20 17:16:36 --> Total execution time: 0.0291
INFO - 2021-04-20 17:16:36 --> Config Class Initialized
INFO - 2021-04-20 17:16:36 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:16:36 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:16:36 --> Utf8 Class Initialized
INFO - 2021-04-20 17:16:36 --> Config Class Initialized
INFO - 2021-04-20 17:16:36 --> URI Class Initialized
INFO - 2021-04-20 17:16:36 --> Hooks Class Initialized
INFO - 2021-04-20 17:16:36 --> Router Class Initialized
INFO - 2021-04-20 17:16:36 --> Output Class Initialized
DEBUG - 2021-04-20 17:16:36 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:16:36 --> Utf8 Class Initialized
INFO - 2021-04-20 17:16:36 --> Security Class Initialized
INFO - 2021-04-20 17:16:36 --> URI Class Initialized
DEBUG - 2021-04-20 17:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:16:36 --> Input Class Initialized
INFO - 2021-04-20 17:16:36 --> Language Class Initialized
INFO - 2021-04-20 17:16:36 --> Router Class Initialized
ERROR - 2021-04-20 17:16:36 --> 404 Page Not Found: Assets/plugins
INFO - 2021-04-20 17:16:36 --> Output Class Initialized
INFO - 2021-04-20 17:16:36 --> Security Class Initialized
DEBUG - 2021-04-20 17:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:16:36 --> Input Class Initialized
INFO - 2021-04-20 17:16:36 --> Language Class Initialized
ERROR - 2021-04-20 17:16:36 --> 404 Page Not Found: Assets/plugins
INFO - 2021-04-20 17:16:36 --> Config Class Initialized
INFO - 2021-04-20 17:16:36 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:16:36 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:16:36 --> Utf8 Class Initialized
INFO - 2021-04-20 17:16:36 --> URI Class Initialized
INFO - 2021-04-20 17:16:36 --> Router Class Initialized
INFO - 2021-04-20 17:16:36 --> Output Class Initialized
INFO - 2021-04-20 17:16:36 --> Security Class Initialized
DEBUG - 2021-04-20 17:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:16:36 --> Input Class Initialized
INFO - 2021-04-20 17:16:36 --> Language Class Initialized
ERROR - 2021-04-20 17:16:36 --> 404 Page Not Found: Assets/plugins
INFO - 2021-04-20 17:16:40 --> Config Class Initialized
INFO - 2021-04-20 17:16:40 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:16:40 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:16:40 --> Utf8 Class Initialized
INFO - 2021-04-20 17:16:40 --> URI Class Initialized
INFO - 2021-04-20 17:16:40 --> Router Class Initialized
INFO - 2021-04-20 17:16:40 --> Output Class Initialized
INFO - 2021-04-20 17:16:40 --> Security Class Initialized
DEBUG - 2021-04-20 17:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:16:40 --> Input Class Initialized
INFO - 2021-04-20 17:16:40 --> Language Class Initialized
INFO - 2021-04-20 17:16:40 --> Loader Class Initialized
INFO - 2021-04-20 17:16:40 --> Helper loaded: url_helper
INFO - 2021-04-20 17:16:40 --> Helper loaded: form_helper
INFO - 2021-04-20 17:16:40 --> Helper loaded: common_helper
INFO - 2021-04-20 17:16:40 --> Helper loaded: util_helper
INFO - 2021-04-20 17:16:40 --> Helper loaded: user_helper
INFO - 2021-04-20 17:16:40 --> Database Driver Class Initialized
DEBUG - 2021-04-20 17:16:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 17:16:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 17:16:40 --> Form Validation Class Initialized
INFO - 2021-04-20 17:16:40 --> Controller Class Initialized
INFO - 2021-04-20 17:16:40 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\register.php
INFO - 2021-04-20 17:16:40 --> Final output sent to browser
DEBUG - 2021-04-20 17:16:40 --> Total execution time: 0.0804
INFO - 2021-04-20 17:16:40 --> Config Class Initialized
INFO - 2021-04-20 17:16:40 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:16:40 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:16:40 --> Utf8 Class Initialized
INFO - 2021-04-20 17:16:40 --> Config Class Initialized
INFO - 2021-04-20 17:16:40 --> Hooks Class Initialized
INFO - 2021-04-20 17:16:40 --> URI Class Initialized
INFO - 2021-04-20 17:16:40 --> Router Class Initialized
DEBUG - 2021-04-20 17:16:40 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:16:40 --> Utf8 Class Initialized
INFO - 2021-04-20 17:16:40 --> Output Class Initialized
INFO - 2021-04-20 17:16:40 --> URI Class Initialized
INFO - 2021-04-20 17:16:40 --> Router Class Initialized
INFO - 2021-04-20 17:16:40 --> Security Class Initialized
DEBUG - 2021-04-20 17:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:16:40 --> Input Class Initialized
INFO - 2021-04-20 17:16:40 --> Output Class Initialized
INFO - 2021-04-20 17:16:40 --> Language Class Initialized
INFO - 2021-04-20 17:16:40 --> Security Class Initialized
ERROR - 2021-04-20 17:16:40 --> 404 Page Not Found: Fasset/img
DEBUG - 2021-04-20 17:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:16:40 --> Input Class Initialized
INFO - 2021-04-20 17:16:40 --> Language Class Initialized
ERROR - 2021-04-20 17:16:40 --> 404 Page Not Found: Fasset/img
INFO - 2021-04-20 17:16:42 --> Config Class Initialized
INFO - 2021-04-20 17:16:42 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:16:42 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:16:42 --> Utf8 Class Initialized
INFO - 2021-04-20 17:16:42 --> URI Class Initialized
INFO - 2021-04-20 17:16:42 --> Router Class Initialized
INFO - 2021-04-20 17:16:42 --> Output Class Initialized
INFO - 2021-04-20 17:16:42 --> Security Class Initialized
DEBUG - 2021-04-20 17:16:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:16:42 --> Input Class Initialized
INFO - 2021-04-20 17:16:42 --> Language Class Initialized
INFO - 2021-04-20 17:16:42 --> Loader Class Initialized
INFO - 2021-04-20 17:16:42 --> Helper loaded: url_helper
INFO - 2021-04-20 17:16:42 --> Helper loaded: form_helper
INFO - 2021-04-20 17:16:42 --> Helper loaded: common_helper
INFO - 2021-04-20 17:16:42 --> Helper loaded: util_helper
INFO - 2021-04-20 17:16:42 --> Helper loaded: user_helper
INFO - 2021-04-20 17:16:42 --> Database Driver Class Initialized
DEBUG - 2021-04-20 17:16:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 17:16:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 17:16:42 --> Form Validation Class Initialized
INFO - 2021-04-20 17:16:42 --> Controller Class Initialized
INFO - 2021-04-20 17:16:42 --> Model Class Initialized
INFO - 2021-04-20 17:16:42 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\viewaccount.php
INFO - 2021-04-20 17:16:42 --> Final output sent to browser
DEBUG - 2021-04-20 17:16:42 --> Total execution time: 0.0286
INFO - 2021-04-20 17:16:45 --> Config Class Initialized
INFO - 2021-04-20 17:16:45 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:16:45 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:16:45 --> Utf8 Class Initialized
INFO - 2021-04-20 17:16:45 --> URI Class Initialized
INFO - 2021-04-20 17:16:45 --> Router Class Initialized
INFO - 2021-04-20 17:16:45 --> Output Class Initialized
INFO - 2021-04-20 17:16:45 --> Security Class Initialized
DEBUG - 2021-04-20 17:16:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:16:45 --> Input Class Initialized
INFO - 2021-04-20 17:16:45 --> Language Class Initialized
INFO - 2021-04-20 17:16:45 --> Loader Class Initialized
INFO - 2021-04-20 17:16:45 --> Helper loaded: url_helper
INFO - 2021-04-20 17:16:45 --> Helper loaded: form_helper
INFO - 2021-04-20 17:16:45 --> Helper loaded: common_helper
INFO - 2021-04-20 17:16:45 --> Helper loaded: util_helper
INFO - 2021-04-20 17:16:45 --> Helper loaded: user_helper
INFO - 2021-04-20 17:16:45 --> Database Driver Class Initialized
DEBUG - 2021-04-20 17:16:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 17:16:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 17:16:45 --> Form Validation Class Initialized
INFO - 2021-04-20 17:16:45 --> Controller Class Initialized
INFO - 2021-04-20 17:16:45 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\register.php
INFO - 2021-04-20 17:16:45 --> Final output sent to browser
DEBUG - 2021-04-20 17:16:45 --> Total execution time: 0.0277
INFO - 2021-04-20 17:16:50 --> Config Class Initialized
INFO - 2021-04-20 17:16:50 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:16:50 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:16:50 --> Utf8 Class Initialized
INFO - 2021-04-20 17:16:50 --> URI Class Initialized
INFO - 2021-04-20 17:16:50 --> Router Class Initialized
INFO - 2021-04-20 17:16:50 --> Output Class Initialized
INFO - 2021-04-20 17:16:50 --> Security Class Initialized
DEBUG - 2021-04-20 17:16:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:16:50 --> Input Class Initialized
INFO - 2021-04-20 17:16:50 --> Language Class Initialized
INFO - 2021-04-20 17:16:50 --> Loader Class Initialized
INFO - 2021-04-20 17:16:50 --> Helper loaded: url_helper
INFO - 2021-04-20 17:16:50 --> Helper loaded: form_helper
INFO - 2021-04-20 17:16:50 --> Helper loaded: common_helper
INFO - 2021-04-20 17:16:50 --> Helper loaded: util_helper
INFO - 2021-04-20 17:16:50 --> Helper loaded: user_helper
INFO - 2021-04-20 17:16:50 --> Database Driver Class Initialized
DEBUG - 2021-04-20 17:16:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 17:16:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 17:16:50 --> Form Validation Class Initialized
INFO - 2021-04-20 17:16:50 --> Controller Class Initialized
INFO - 2021-04-20 17:16:50 --> Model Class Initialized
INFO - 2021-04-20 17:16:50 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\viewaccount.php
INFO - 2021-04-20 17:16:50 --> Final output sent to browser
DEBUG - 2021-04-20 17:16:50 --> Total execution time: 0.0287
INFO - 2021-04-20 17:17:29 --> Config Class Initialized
INFO - 2021-04-20 17:17:29 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:17:29 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:17:29 --> Utf8 Class Initialized
INFO - 2021-04-20 17:17:29 --> URI Class Initialized
INFO - 2021-04-20 17:17:29 --> Router Class Initialized
INFO - 2021-04-20 17:17:29 --> Output Class Initialized
INFO - 2021-04-20 17:17:29 --> Security Class Initialized
DEBUG - 2021-04-20 17:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:17:29 --> Input Class Initialized
INFO - 2021-04-20 17:17:29 --> Language Class Initialized
INFO - 2021-04-20 17:17:29 --> Loader Class Initialized
INFO - 2021-04-20 17:17:29 --> Helper loaded: url_helper
INFO - 2021-04-20 17:17:29 --> Helper loaded: form_helper
INFO - 2021-04-20 17:17:29 --> Helper loaded: common_helper
INFO - 2021-04-20 17:17:29 --> Helper loaded: util_helper
INFO - 2021-04-20 17:17:29 --> Helper loaded: user_helper
INFO - 2021-04-20 17:17:29 --> Database Driver Class Initialized
DEBUG - 2021-04-20 17:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 17:17:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 17:17:29 --> Form Validation Class Initialized
INFO - 2021-04-20 17:17:29 --> Controller Class Initialized
INFO - 2021-04-20 17:17:29 --> Model Class Initialized
INFO - 2021-04-20 17:17:29 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\viewaccount.php
INFO - 2021-04-20 17:17:29 --> Final output sent to browser
DEBUG - 2021-04-20 17:17:29 --> Total execution time: 0.0286
INFO - 2021-04-20 17:17:29 --> Config Class Initialized
INFO - 2021-04-20 17:17:29 --> Hooks Class Initialized
INFO - 2021-04-20 17:17:29 --> Config Class Initialized
INFO - 2021-04-20 17:17:29 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:17:29 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:17:29 --> Utf8 Class Initialized
DEBUG - 2021-04-20 17:17:29 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:17:29 --> Utf8 Class Initialized
INFO - 2021-04-20 17:17:29 --> URI Class Initialized
INFO - 2021-04-20 17:17:29 --> URI Class Initialized
INFO - 2021-04-20 17:17:29 --> Router Class Initialized
INFO - 2021-04-20 17:17:29 --> Router Class Initialized
INFO - 2021-04-20 17:17:29 --> Output Class Initialized
INFO - 2021-04-20 17:17:29 --> Output Class Initialized
INFO - 2021-04-20 17:17:29 --> Security Class Initialized
INFO - 2021-04-20 17:17:29 --> Security Class Initialized
DEBUG - 2021-04-20 17:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-20 17:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:17:29 --> Input Class Initialized
INFO - 2021-04-20 17:17:29 --> Input Class Initialized
INFO - 2021-04-20 17:17:29 --> Language Class Initialized
INFO - 2021-04-20 17:17:29 --> Language Class Initialized
ERROR - 2021-04-20 17:17:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2021-04-20 17:17:29 --> 404 Page Not Found: Assets/plugins
INFO - 2021-04-20 17:17:29 --> Config Class Initialized
INFO - 2021-04-20 17:17:29 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:17:29 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:17:29 --> Utf8 Class Initialized
INFO - 2021-04-20 17:17:29 --> URI Class Initialized
INFO - 2021-04-20 17:17:29 --> Router Class Initialized
INFO - 2021-04-20 17:17:29 --> Output Class Initialized
INFO - 2021-04-20 17:17:29 --> Security Class Initialized
DEBUG - 2021-04-20 17:17:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:17:29 --> Input Class Initialized
INFO - 2021-04-20 17:17:29 --> Language Class Initialized
ERROR - 2021-04-20 17:17:29 --> 404 Page Not Found: Assets/plugins
INFO - 2021-04-20 17:17:33 --> Config Class Initialized
INFO - 2021-04-20 17:17:33 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:17:33 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:17:33 --> Utf8 Class Initialized
INFO - 2021-04-20 17:17:33 --> URI Class Initialized
INFO - 2021-04-20 17:17:33 --> Router Class Initialized
INFO - 2021-04-20 17:17:33 --> Output Class Initialized
INFO - 2021-04-20 17:17:33 --> Security Class Initialized
DEBUG - 2021-04-20 17:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:17:33 --> Input Class Initialized
INFO - 2021-04-20 17:17:33 --> Language Class Initialized
INFO - 2021-04-20 17:17:33 --> Loader Class Initialized
INFO - 2021-04-20 17:17:33 --> Helper loaded: url_helper
INFO - 2021-04-20 17:17:33 --> Helper loaded: form_helper
INFO - 2021-04-20 17:17:33 --> Helper loaded: common_helper
INFO - 2021-04-20 17:17:33 --> Helper loaded: util_helper
INFO - 2021-04-20 17:17:33 --> Helper loaded: user_helper
INFO - 2021-04-20 17:17:33 --> Database Driver Class Initialized
DEBUG - 2021-04-20 17:17:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 17:17:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 17:17:33 --> Form Validation Class Initialized
INFO - 2021-04-20 17:17:33 --> Controller Class Initialized
INFO - 2021-04-20 17:17:33 --> Model Class Initialized
INFO - 2021-04-20 17:17:33 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\viewaccount.php
INFO - 2021-04-20 17:17:33 --> Final output sent to browser
DEBUG - 2021-04-20 17:17:33 --> Total execution time: 0.0270
INFO - 2021-04-20 17:17:33 --> Config Class Initialized
INFO - 2021-04-20 17:17:33 --> Hooks Class Initialized
INFO - 2021-04-20 17:17:33 --> Config Class Initialized
INFO - 2021-04-20 17:17:33 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:17:33 --> UTF-8 Support Enabled
DEBUG - 2021-04-20 17:17:33 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:17:33 --> Utf8 Class Initialized
INFO - 2021-04-20 17:17:33 --> Utf8 Class Initialized
INFO - 2021-04-20 17:17:33 --> URI Class Initialized
INFO - 2021-04-20 17:17:33 --> URI Class Initialized
INFO - 2021-04-20 17:17:33 --> Router Class Initialized
INFO - 2021-04-20 17:17:33 --> Router Class Initialized
INFO - 2021-04-20 17:17:33 --> Output Class Initialized
INFO - 2021-04-20 17:17:33 --> Output Class Initialized
INFO - 2021-04-20 17:17:33 --> Security Class Initialized
INFO - 2021-04-20 17:17:33 --> Security Class Initialized
DEBUG - 2021-04-20 17:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-20 17:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:17:33 --> Input Class Initialized
INFO - 2021-04-20 17:17:33 --> Input Class Initialized
INFO - 2021-04-20 17:17:33 --> Language Class Initialized
INFO - 2021-04-20 17:17:33 --> Language Class Initialized
ERROR - 2021-04-20 17:17:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2021-04-20 17:17:33 --> 404 Page Not Found: Assets/plugins
INFO - 2021-04-20 17:17:33 --> Config Class Initialized
INFO - 2021-04-20 17:17:33 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:17:33 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:17:33 --> Utf8 Class Initialized
INFO - 2021-04-20 17:17:33 --> URI Class Initialized
INFO - 2021-04-20 17:17:33 --> Router Class Initialized
INFO - 2021-04-20 17:17:33 --> Output Class Initialized
INFO - 2021-04-20 17:17:33 --> Security Class Initialized
DEBUG - 2021-04-20 17:17:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:17:33 --> Input Class Initialized
INFO - 2021-04-20 17:17:33 --> Language Class Initialized
ERROR - 2021-04-20 17:17:33 --> 404 Page Not Found: Assets/plugins
INFO - 2021-04-20 17:18:07 --> Config Class Initialized
INFO - 2021-04-20 17:18:07 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:18:07 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:18:07 --> Utf8 Class Initialized
INFO - 2021-04-20 17:18:07 --> URI Class Initialized
INFO - 2021-04-20 17:18:07 --> Router Class Initialized
INFO - 2021-04-20 17:18:07 --> Output Class Initialized
INFO - 2021-04-20 17:18:07 --> Security Class Initialized
DEBUG - 2021-04-20 17:18:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:18:07 --> Input Class Initialized
INFO - 2021-04-20 17:18:07 --> Language Class Initialized
ERROR - 2021-04-20 17:18:07 --> 404 Page Not Found: Cms/index
INFO - 2021-04-20 17:18:09 --> Config Class Initialized
INFO - 2021-04-20 17:18:09 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:18:09 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:18:09 --> Utf8 Class Initialized
INFO - 2021-04-20 17:18:09 --> URI Class Initialized
INFO - 2021-04-20 17:18:09 --> Router Class Initialized
INFO - 2021-04-20 17:18:09 --> Output Class Initialized
INFO - 2021-04-20 17:18:09 --> Security Class Initialized
DEBUG - 2021-04-20 17:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:18:09 --> Input Class Initialized
INFO - 2021-04-20 17:18:09 --> Language Class Initialized
INFO - 2021-04-20 17:18:09 --> Loader Class Initialized
INFO - 2021-04-20 17:18:09 --> Helper loaded: url_helper
INFO - 2021-04-20 17:18:09 --> Helper loaded: form_helper
INFO - 2021-04-20 17:18:09 --> Helper loaded: common_helper
INFO - 2021-04-20 17:18:09 --> Helper loaded: util_helper
INFO - 2021-04-20 17:18:09 --> Helper loaded: user_helper
INFO - 2021-04-20 17:18:09 --> Database Driver Class Initialized
DEBUG - 2021-04-20 17:18:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 17:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 17:18:09 --> Form Validation Class Initialized
INFO - 2021-04-20 17:18:09 --> Controller Class Initialized
INFO - 2021-04-20 17:18:09 --> Model Class Initialized
INFO - 2021-04-20 17:18:09 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\viewaccount.php
INFO - 2021-04-20 17:18:09 --> Final output sent to browser
DEBUG - 2021-04-20 17:18:09 --> Total execution time: 0.0284
INFO - 2021-04-20 17:18:10 --> Config Class Initialized
INFO - 2021-04-20 17:18:10 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:18:10 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:18:10 --> Utf8 Class Initialized
INFO - 2021-04-20 17:18:10 --> URI Class Initialized
INFO - 2021-04-20 17:18:10 --> Router Class Initialized
INFO - 2021-04-20 17:18:10 --> Output Class Initialized
INFO - 2021-04-20 17:18:10 --> Security Class Initialized
DEBUG - 2021-04-20 17:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:18:10 --> Input Class Initialized
INFO - 2021-04-20 17:18:10 --> Language Class Initialized
INFO - 2021-04-20 17:18:10 --> Loader Class Initialized
INFO - 2021-04-20 17:18:10 --> Helper loaded: url_helper
INFO - 2021-04-20 17:18:10 --> Helper loaded: form_helper
INFO - 2021-04-20 17:18:10 --> Helper loaded: common_helper
INFO - 2021-04-20 17:18:10 --> Helper loaded: util_helper
INFO - 2021-04-20 17:18:10 --> Helper loaded: user_helper
INFO - 2021-04-20 17:18:10 --> Database Driver Class Initialized
DEBUG - 2021-04-20 17:18:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 17:18:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 17:18:10 --> Form Validation Class Initialized
INFO - 2021-04-20 17:18:10 --> Controller Class Initialized
INFO - 2021-04-20 17:18:10 --> Model Class Initialized
INFO - 2021-04-20 17:18:10 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\viewaccount.php
INFO - 2021-04-20 17:18:10 --> Final output sent to browser
DEBUG - 2021-04-20 17:18:10 --> Total execution time: 0.0303
INFO - 2021-04-20 17:18:11 --> Config Class Initialized
INFO - 2021-04-20 17:18:11 --> Hooks Class Initialized
INFO - 2021-04-20 17:18:11 --> Config Class Initialized
INFO - 2021-04-20 17:18:11 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:18:11 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:18:11 --> Utf8 Class Initialized
DEBUG - 2021-04-20 17:18:11 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:18:11 --> Utf8 Class Initialized
INFO - 2021-04-20 17:18:11 --> URI Class Initialized
INFO - 2021-04-20 17:18:11 --> Router Class Initialized
INFO - 2021-04-20 17:18:11 --> URI Class Initialized
INFO - 2021-04-20 17:18:11 --> Router Class Initialized
INFO - 2021-04-20 17:18:11 --> Output Class Initialized
INFO - 2021-04-20 17:18:11 --> Output Class Initialized
INFO - 2021-04-20 17:18:11 --> Security Class Initialized
DEBUG - 2021-04-20 17:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:18:11 --> Security Class Initialized
INFO - 2021-04-20 17:18:11 --> Input Class Initialized
INFO - 2021-04-20 17:18:11 --> Language Class Initialized
DEBUG - 2021-04-20 17:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:18:11 --> Input Class Initialized
INFO - 2021-04-20 17:18:11 --> Language Class Initialized
ERROR - 2021-04-20 17:18:11 --> 404 Page Not Found: Assets/plugins
ERROR - 2021-04-20 17:18:11 --> 404 Page Not Found: Assets/plugins
INFO - 2021-04-20 17:19:24 --> Config Class Initialized
INFO - 2021-04-20 17:19:24 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:19:24 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:19:24 --> Utf8 Class Initialized
INFO - 2021-04-20 17:19:24 --> URI Class Initialized
INFO - 2021-04-20 17:19:24 --> Router Class Initialized
INFO - 2021-04-20 17:19:24 --> Output Class Initialized
INFO - 2021-04-20 17:19:24 --> Security Class Initialized
DEBUG - 2021-04-20 17:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:19:24 --> Input Class Initialized
INFO - 2021-04-20 17:19:24 --> Language Class Initialized
INFO - 2021-04-20 17:19:24 --> Loader Class Initialized
INFO - 2021-04-20 17:19:24 --> Helper loaded: url_helper
INFO - 2021-04-20 17:19:24 --> Helper loaded: form_helper
INFO - 2021-04-20 17:19:24 --> Helper loaded: common_helper
INFO - 2021-04-20 17:19:24 --> Helper loaded: util_helper
INFO - 2021-04-20 17:19:24 --> Helper loaded: user_helper
INFO - 2021-04-20 17:19:24 --> Database Driver Class Initialized
DEBUG - 2021-04-20 17:19:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 17:19:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 17:19:24 --> Form Validation Class Initialized
INFO - 2021-04-20 17:19:24 --> Controller Class Initialized
INFO - 2021-04-20 17:19:24 --> Model Class Initialized
INFO - 2021-04-20 17:19:24 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\viewaccount.php
INFO - 2021-04-20 17:19:24 --> Final output sent to browser
DEBUG - 2021-04-20 17:19:24 --> Total execution time: 0.0388
INFO - 2021-04-20 17:19:24 --> Config Class Initialized
INFO - 2021-04-20 17:19:24 --> Hooks Class Initialized
INFO - 2021-04-20 17:19:24 --> Config Class Initialized
INFO - 2021-04-20 17:19:24 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:19:24 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:19:24 --> Utf8 Class Initialized
DEBUG - 2021-04-20 17:19:24 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:19:24 --> URI Class Initialized
INFO - 2021-04-20 17:19:24 --> Utf8 Class Initialized
INFO - 2021-04-20 17:19:24 --> Router Class Initialized
INFO - 2021-04-20 17:19:24 --> URI Class Initialized
INFO - 2021-04-20 17:19:24 --> Output Class Initialized
INFO - 2021-04-20 17:19:24 --> Router Class Initialized
INFO - 2021-04-20 17:19:24 --> Security Class Initialized
INFO - 2021-04-20 17:19:24 --> Output Class Initialized
DEBUG - 2021-04-20 17:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:19:24 --> Input Class Initialized
INFO - 2021-04-20 17:19:24 --> Security Class Initialized
INFO - 2021-04-20 17:19:24 --> Language Class Initialized
DEBUG - 2021-04-20 17:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:19:24 --> Input Class Initialized
ERROR - 2021-04-20 17:19:24 --> 404 Page Not Found: Assets/plugins
INFO - 2021-04-20 17:19:24 --> Language Class Initialized
ERROR - 2021-04-20 17:19:24 --> 404 Page Not Found: Assets/plugins
INFO - 2021-04-20 17:19:24 --> Config Class Initialized
INFO - 2021-04-20 17:19:24 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:19:24 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:19:24 --> Utf8 Class Initialized
INFO - 2021-04-20 17:19:24 --> URI Class Initialized
INFO - 2021-04-20 17:19:24 --> Router Class Initialized
INFO - 2021-04-20 17:19:24 --> Output Class Initialized
INFO - 2021-04-20 17:19:24 --> Security Class Initialized
DEBUG - 2021-04-20 17:19:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:19:24 --> Input Class Initialized
INFO - 2021-04-20 17:19:24 --> Language Class Initialized
ERROR - 2021-04-20 17:19:24 --> 404 Page Not Found: Assets/plugins
INFO - 2021-04-20 17:24:02 --> Config Class Initialized
INFO - 2021-04-20 17:24:02 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:24:02 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:24:02 --> Utf8 Class Initialized
INFO - 2021-04-20 17:24:02 --> URI Class Initialized
INFO - 2021-04-20 17:24:02 --> Router Class Initialized
INFO - 2021-04-20 17:24:02 --> Output Class Initialized
INFO - 2021-04-20 17:24:02 --> Security Class Initialized
DEBUG - 2021-04-20 17:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:24:02 --> Input Class Initialized
INFO - 2021-04-20 17:24:02 --> Language Class Initialized
INFO - 2021-04-20 17:24:02 --> Loader Class Initialized
INFO - 2021-04-20 17:24:02 --> Helper loaded: url_helper
INFO - 2021-04-20 17:24:02 --> Helper loaded: form_helper
INFO - 2021-04-20 17:24:02 --> Helper loaded: common_helper
INFO - 2021-04-20 17:24:02 --> Helper loaded: util_helper
INFO - 2021-04-20 17:24:02 --> Helper loaded: user_helper
INFO - 2021-04-20 17:24:02 --> Database Driver Class Initialized
DEBUG - 2021-04-20 17:24:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 17:24:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 17:24:02 --> Form Validation Class Initialized
INFO - 2021-04-20 17:24:02 --> Controller Class Initialized
INFO - 2021-04-20 17:24:02 --> Model Class Initialized
INFO - 2021-04-20 17:24:02 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\viewaccount.php
INFO - 2021-04-20 17:24:02 --> Final output sent to browser
DEBUG - 2021-04-20 17:24:02 --> Total execution time: 0.0390
INFO - 2021-04-20 17:24:02 --> Config Class Initialized
INFO - 2021-04-20 17:24:02 --> Hooks Class Initialized
INFO - 2021-04-20 17:24:02 --> Config Class Initialized
INFO - 2021-04-20 17:24:02 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:24:02 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:24:02 --> Utf8 Class Initialized
DEBUG - 2021-04-20 17:24:02 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:24:02 --> Utf8 Class Initialized
INFO - 2021-04-20 17:24:02 --> URI Class Initialized
INFO - 2021-04-20 17:24:02 --> URI Class Initialized
INFO - 2021-04-20 17:24:02 --> Router Class Initialized
INFO - 2021-04-20 17:24:02 --> Router Class Initialized
INFO - 2021-04-20 17:24:02 --> Output Class Initialized
INFO - 2021-04-20 17:24:02 --> Output Class Initialized
INFO - 2021-04-20 17:24:02 --> Security Class Initialized
INFO - 2021-04-20 17:24:02 --> Security Class Initialized
DEBUG - 2021-04-20 17:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:24:02 --> Input Class Initialized
INFO - 2021-04-20 17:24:02 --> Language Class Initialized
DEBUG - 2021-04-20 17:24:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:24:02 --> Input Class Initialized
INFO - 2021-04-20 17:24:02 --> Language Class Initialized
ERROR - 2021-04-20 17:24:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2021-04-20 17:24:02 --> 404 Page Not Found: Assets/plugins
INFO - 2021-04-20 17:26:29 --> Config Class Initialized
INFO - 2021-04-20 17:26:29 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:26:29 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:26:29 --> Utf8 Class Initialized
INFO - 2021-04-20 17:26:29 --> URI Class Initialized
INFO - 2021-04-20 17:26:29 --> Router Class Initialized
INFO - 2021-04-20 17:26:29 --> Output Class Initialized
INFO - 2021-04-20 17:26:29 --> Security Class Initialized
DEBUG - 2021-04-20 17:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:26:29 --> Input Class Initialized
INFO - 2021-04-20 17:26:29 --> Language Class Initialized
INFO - 2021-04-20 17:26:29 --> Loader Class Initialized
INFO - 2021-04-20 17:26:29 --> Helper loaded: url_helper
INFO - 2021-04-20 17:26:29 --> Helper loaded: form_helper
INFO - 2021-04-20 17:26:29 --> Helper loaded: common_helper
INFO - 2021-04-20 17:26:29 --> Helper loaded: util_helper
INFO - 2021-04-20 17:26:29 --> Helper loaded: user_helper
INFO - 2021-04-20 17:26:29 --> Database Driver Class Initialized
DEBUG - 2021-04-20 17:26:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 17:26:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 17:26:29 --> Form Validation Class Initialized
INFO - 2021-04-20 17:26:29 --> Controller Class Initialized
INFO - 2021-04-20 17:26:29 --> Model Class Initialized
INFO - 2021-04-20 17:26:29 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\viewaccount.php
INFO - 2021-04-20 17:26:29 --> Final output sent to browser
DEBUG - 2021-04-20 17:26:29 --> Total execution time: 0.0382
INFO - 2021-04-20 17:26:29 --> Config Class Initialized
INFO - 2021-04-20 17:26:29 --> Hooks Class Initialized
INFO - 2021-04-20 17:26:29 --> Config Class Initialized
INFO - 2021-04-20 17:26:29 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:26:29 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:26:29 --> Utf8 Class Initialized
INFO - 2021-04-20 17:26:29 --> URI Class Initialized
DEBUG - 2021-04-20 17:26:29 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:26:29 --> Utf8 Class Initialized
INFO - 2021-04-20 17:26:29 --> Router Class Initialized
INFO - 2021-04-20 17:26:29 --> URI Class Initialized
INFO - 2021-04-20 17:26:29 --> Output Class Initialized
INFO - 2021-04-20 17:26:29 --> Router Class Initialized
INFO - 2021-04-20 17:26:29 --> Security Class Initialized
INFO - 2021-04-20 17:26:29 --> Output Class Initialized
DEBUG - 2021-04-20 17:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:26:29 --> Input Class Initialized
INFO - 2021-04-20 17:26:29 --> Language Class Initialized
INFO - 2021-04-20 17:26:29 --> Security Class Initialized
DEBUG - 2021-04-20 17:26:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-20 17:26:29 --> 404 Page Not Found: Assets/plugins
INFO - 2021-04-20 17:26:29 --> Input Class Initialized
INFO - 2021-04-20 17:26:29 --> Language Class Initialized
ERROR - 2021-04-20 17:26:29 --> 404 Page Not Found: Assets/plugins
INFO - 2021-04-20 17:26:29 --> Config Class Initialized
INFO - 2021-04-20 17:26:29 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:26:29 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:26:29 --> Utf8 Class Initialized
INFO - 2021-04-20 17:26:29 --> URI Class Initialized
INFO - 2021-04-20 17:26:29 --> Router Class Initialized
INFO - 2021-04-20 17:26:29 --> Output Class Initialized
INFO - 2021-04-20 17:26:29 --> Security Class Initialized
DEBUG - 2021-04-20 17:26:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:26:29 --> Input Class Initialized
INFO - 2021-04-20 17:26:29 --> Language Class Initialized
ERROR - 2021-04-20 17:26:29 --> 404 Page Not Found: Assets/plugins
INFO - 2021-04-20 17:30:08 --> Config Class Initialized
INFO - 2021-04-20 17:30:08 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:30:08 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:30:08 --> Utf8 Class Initialized
INFO - 2021-04-20 17:30:08 --> URI Class Initialized
DEBUG - 2021-04-20 17:30:08 --> No URI present. Default controller set.
INFO - 2021-04-20 17:30:08 --> Router Class Initialized
INFO - 2021-04-20 17:30:08 --> Output Class Initialized
INFO - 2021-04-20 17:30:08 --> Security Class Initialized
DEBUG - 2021-04-20 17:30:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:30:08 --> Input Class Initialized
INFO - 2021-04-20 17:30:08 --> Language Class Initialized
INFO - 2021-04-20 17:30:08 --> Loader Class Initialized
INFO - 2021-04-20 17:30:08 --> Helper loaded: url_helper
INFO - 2021-04-20 17:30:08 --> Helper loaded: form_helper
INFO - 2021-04-20 17:30:08 --> Helper loaded: common_helper
INFO - 2021-04-20 17:30:08 --> Helper loaded: util_helper
INFO - 2021-04-20 17:30:08 --> Helper loaded: user_helper
INFO - 2021-04-20 17:30:08 --> Database Driver Class Initialized
DEBUG - 2021-04-20 17:30:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 17:30:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 17:30:08 --> Form Validation Class Initialized
INFO - 2021-04-20 17:30:08 --> Controller Class Initialized
INFO - 2021-04-20 17:30:08 --> Model Class Initialized
INFO - 2021-04-20 17:30:08 --> Model Class Initialized
INFO - 2021-04-20 17:30:08 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-20 17:30:08 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-20 17:30:08 --> Final output sent to browser
DEBUG - 2021-04-20 17:30:08 --> Total execution time: 0.0393
INFO - 2021-04-20 17:30:21 --> Config Class Initialized
INFO - 2021-04-20 17:30:21 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:30:21 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:30:21 --> Utf8 Class Initialized
INFO - 2021-04-20 17:30:21 --> URI Class Initialized
INFO - 2021-04-20 17:30:21 --> Router Class Initialized
INFO - 2021-04-20 17:30:21 --> Output Class Initialized
INFO - 2021-04-20 17:30:21 --> Security Class Initialized
DEBUG - 2021-04-20 17:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:30:21 --> Input Class Initialized
INFO - 2021-04-20 17:30:21 --> Language Class Initialized
INFO - 2021-04-20 17:30:21 --> Loader Class Initialized
INFO - 2021-04-20 17:30:21 --> Helper loaded: url_helper
INFO - 2021-04-20 17:30:21 --> Helper loaded: form_helper
INFO - 2021-04-20 17:30:21 --> Helper loaded: common_helper
INFO - 2021-04-20 17:30:21 --> Helper loaded: util_helper
INFO - 2021-04-20 17:30:21 --> Helper loaded: user_helper
INFO - 2021-04-20 17:30:21 --> Database Driver Class Initialized
DEBUG - 2021-04-20 17:30:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 17:30:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 17:30:21 --> Form Validation Class Initialized
INFO - 2021-04-20 17:30:21 --> Controller Class Initialized
INFO - 2021-04-20 17:30:21 --> Model Class Initialized
INFO - 2021-04-20 17:30:21 --> Model Class Initialized
INFO - 2021-04-20 17:30:21 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\register.php
INFO - 2021-04-20 17:30:21 --> Final output sent to browser
DEBUG - 2021-04-20 17:30:21 --> Total execution time: 0.0376
INFO - 2021-04-20 17:30:21 --> Config Class Initialized
INFO - 2021-04-20 17:30:21 --> Config Class Initialized
INFO - 2021-04-20 17:30:21 --> Hooks Class Initialized
INFO - 2021-04-20 17:30:21 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:30:21 --> UTF-8 Support Enabled
DEBUG - 2021-04-20 17:30:21 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:30:21 --> Utf8 Class Initialized
INFO - 2021-04-20 17:30:21 --> Utf8 Class Initialized
INFO - 2021-04-20 17:30:21 --> URI Class Initialized
INFO - 2021-04-20 17:30:21 --> URI Class Initialized
INFO - 2021-04-20 17:30:21 --> Router Class Initialized
INFO - 2021-04-20 17:30:21 --> Router Class Initialized
INFO - 2021-04-20 17:30:21 --> Output Class Initialized
INFO - 2021-04-20 17:30:21 --> Output Class Initialized
INFO - 2021-04-20 17:30:21 --> Security Class Initialized
INFO - 2021-04-20 17:30:21 --> Security Class Initialized
DEBUG - 2021-04-20 17:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-20 17:30:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:30:21 --> Input Class Initialized
INFO - 2021-04-20 17:30:21 --> Input Class Initialized
INFO - 2021-04-20 17:30:21 --> Language Class Initialized
INFO - 2021-04-20 17:30:21 --> Language Class Initialized
ERROR - 2021-04-20 17:30:21 --> 404 Page Not Found: Fasset/img
ERROR - 2021-04-20 17:30:21 --> 404 Page Not Found: Fasset/img
INFO - 2021-04-20 17:30:26 --> Config Class Initialized
INFO - 2021-04-20 17:30:26 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:30:26 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:30:26 --> Utf8 Class Initialized
INFO - 2021-04-20 17:30:26 --> URI Class Initialized
DEBUG - 2021-04-20 17:30:26 --> No URI present. Default controller set.
INFO - 2021-04-20 17:30:26 --> Router Class Initialized
INFO - 2021-04-20 17:30:26 --> Output Class Initialized
INFO - 2021-04-20 17:30:26 --> Security Class Initialized
DEBUG - 2021-04-20 17:30:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:30:26 --> Input Class Initialized
INFO - 2021-04-20 17:30:26 --> Language Class Initialized
INFO - 2021-04-20 17:30:26 --> Loader Class Initialized
INFO - 2021-04-20 17:30:26 --> Helper loaded: url_helper
INFO - 2021-04-20 17:30:26 --> Helper loaded: form_helper
INFO - 2021-04-20 17:30:26 --> Helper loaded: common_helper
INFO - 2021-04-20 17:30:26 --> Helper loaded: util_helper
INFO - 2021-04-20 17:30:26 --> Helper loaded: user_helper
INFO - 2021-04-20 17:30:26 --> Database Driver Class Initialized
DEBUG - 2021-04-20 17:30:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 17:30:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 17:30:26 --> Form Validation Class Initialized
INFO - 2021-04-20 17:30:26 --> Controller Class Initialized
INFO - 2021-04-20 17:30:26 --> Model Class Initialized
INFO - 2021-04-20 17:30:26 --> Model Class Initialized
INFO - 2021-04-20 17:30:26 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-20 17:30:26 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-20 17:30:26 --> Final output sent to browser
DEBUG - 2021-04-20 17:30:26 --> Total execution time: 0.0279
INFO - 2021-04-20 17:30:28 --> Config Class Initialized
INFO - 2021-04-20 17:30:28 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:30:28 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:30:28 --> Utf8 Class Initialized
INFO - 2021-04-20 17:30:28 --> URI Class Initialized
INFO - 2021-04-20 17:30:28 --> Router Class Initialized
INFO - 2021-04-20 17:30:28 --> Output Class Initialized
INFO - 2021-04-20 17:30:28 --> Security Class Initialized
DEBUG - 2021-04-20 17:30:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:30:28 --> Input Class Initialized
INFO - 2021-04-20 17:30:28 --> Language Class Initialized
INFO - 2021-04-20 17:30:28 --> Loader Class Initialized
INFO - 2021-04-20 17:30:28 --> Helper loaded: url_helper
INFO - 2021-04-20 17:30:28 --> Helper loaded: form_helper
INFO - 2021-04-20 17:30:28 --> Helper loaded: common_helper
INFO - 2021-04-20 17:30:28 --> Helper loaded: util_helper
INFO - 2021-04-20 17:30:28 --> Helper loaded: user_helper
INFO - 2021-04-20 17:30:28 --> Database Driver Class Initialized
DEBUG - 2021-04-20 17:30:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 17:30:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 17:30:28 --> Form Validation Class Initialized
INFO - 2021-04-20 17:30:28 --> Controller Class Initialized
INFO - 2021-04-20 17:30:28 --> Model Class Initialized
INFO - 2021-04-20 17:30:28 --> Model Class Initialized
INFO - 2021-04-20 17:30:28 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\register.php
INFO - 2021-04-20 17:30:28 --> Final output sent to browser
DEBUG - 2021-04-20 17:30:28 --> Total execution time: 0.0282
INFO - 2021-04-20 17:30:33 --> Config Class Initialized
INFO - 2021-04-20 17:30:33 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:30:33 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:30:33 --> Utf8 Class Initialized
INFO - 2021-04-20 17:30:33 --> URI Class Initialized
DEBUG - 2021-04-20 17:30:33 --> No URI present. Default controller set.
INFO - 2021-04-20 17:30:33 --> Router Class Initialized
INFO - 2021-04-20 17:30:33 --> Output Class Initialized
INFO - 2021-04-20 17:30:33 --> Security Class Initialized
DEBUG - 2021-04-20 17:30:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:30:33 --> Input Class Initialized
INFO - 2021-04-20 17:30:33 --> Language Class Initialized
INFO - 2021-04-20 17:30:33 --> Loader Class Initialized
INFO - 2021-04-20 17:30:33 --> Helper loaded: url_helper
INFO - 2021-04-20 17:30:33 --> Helper loaded: form_helper
INFO - 2021-04-20 17:30:33 --> Helper loaded: common_helper
INFO - 2021-04-20 17:30:33 --> Helper loaded: util_helper
INFO - 2021-04-20 17:30:33 --> Helper loaded: user_helper
INFO - 2021-04-20 17:30:33 --> Database Driver Class Initialized
DEBUG - 2021-04-20 17:30:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 17:30:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 17:30:33 --> Form Validation Class Initialized
INFO - 2021-04-20 17:30:33 --> Controller Class Initialized
INFO - 2021-04-20 17:30:33 --> Model Class Initialized
INFO - 2021-04-20 17:30:33 --> Model Class Initialized
INFO - 2021-04-20 17:30:33 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-20 17:30:33 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-20 17:30:33 --> Final output sent to browser
DEBUG - 2021-04-20 17:30:33 --> Total execution time: 0.0281
INFO - 2021-04-20 17:31:04 --> Config Class Initialized
INFO - 2021-04-20 17:31:04 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:31:04 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:31:04 --> Utf8 Class Initialized
INFO - 2021-04-20 17:31:04 --> URI Class Initialized
INFO - 2021-04-20 17:31:04 --> Router Class Initialized
INFO - 2021-04-20 17:31:04 --> Output Class Initialized
INFO - 2021-04-20 17:31:04 --> Security Class Initialized
DEBUG - 2021-04-20 17:31:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:31:04 --> Input Class Initialized
INFO - 2021-04-20 17:31:04 --> Language Class Initialized
INFO - 2021-04-20 17:31:04 --> Loader Class Initialized
INFO - 2021-04-20 17:31:04 --> Helper loaded: url_helper
INFO - 2021-04-20 17:31:04 --> Helper loaded: form_helper
INFO - 2021-04-20 17:31:04 --> Helper loaded: common_helper
INFO - 2021-04-20 17:31:04 --> Helper loaded: util_helper
INFO - 2021-04-20 17:31:04 --> Helper loaded: user_helper
INFO - 2021-04-20 17:31:04 --> Database Driver Class Initialized
DEBUG - 2021-04-20 17:31:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 17:31:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 17:31:04 --> Form Validation Class Initialized
INFO - 2021-04-20 17:31:04 --> Controller Class Initialized
INFO - 2021-04-20 17:31:04 --> Model Class Initialized
INFO - 2021-04-20 17:31:04 --> Model Class Initialized
INFO - 2021-04-20 17:31:04 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\register.php
INFO - 2021-04-20 17:31:04 --> Final output sent to browser
DEBUG - 2021-04-20 17:31:04 --> Total execution time: 0.0377
INFO - 2021-04-20 17:31:07 --> Config Class Initialized
INFO - 2021-04-20 17:31:07 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:31:07 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:31:07 --> Utf8 Class Initialized
INFO - 2021-04-20 17:31:07 --> URI Class Initialized
DEBUG - 2021-04-20 17:31:07 --> No URI present. Default controller set.
INFO - 2021-04-20 17:31:07 --> Router Class Initialized
INFO - 2021-04-20 17:31:07 --> Output Class Initialized
INFO - 2021-04-20 17:31:07 --> Security Class Initialized
DEBUG - 2021-04-20 17:31:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:31:07 --> Input Class Initialized
INFO - 2021-04-20 17:31:07 --> Language Class Initialized
INFO - 2021-04-20 17:31:07 --> Loader Class Initialized
INFO - 2021-04-20 17:31:07 --> Helper loaded: url_helper
INFO - 2021-04-20 17:31:07 --> Helper loaded: form_helper
INFO - 2021-04-20 17:31:07 --> Helper loaded: common_helper
INFO - 2021-04-20 17:31:07 --> Helper loaded: util_helper
INFO - 2021-04-20 17:31:07 --> Helper loaded: user_helper
INFO - 2021-04-20 17:31:07 --> Database Driver Class Initialized
DEBUG - 2021-04-20 17:31:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 17:31:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 17:31:07 --> Form Validation Class Initialized
INFO - 2021-04-20 17:31:07 --> Controller Class Initialized
INFO - 2021-04-20 17:31:07 --> Model Class Initialized
INFO - 2021-04-20 17:31:07 --> Model Class Initialized
INFO - 2021-04-20 17:31:07 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-20 17:31:07 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-20 17:31:07 --> Final output sent to browser
DEBUG - 2021-04-20 17:31:07 --> Total execution time: 0.0282
INFO - 2021-04-20 17:35:57 --> Config Class Initialized
INFO - 2021-04-20 17:35:57 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:35:57 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:35:57 --> Utf8 Class Initialized
INFO - 2021-04-20 17:35:57 --> URI Class Initialized
INFO - 2021-04-20 17:35:57 --> Router Class Initialized
INFO - 2021-04-20 17:35:57 --> Output Class Initialized
INFO - 2021-04-20 17:35:57 --> Security Class Initialized
DEBUG - 2021-04-20 17:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:35:57 --> Input Class Initialized
INFO - 2021-04-20 17:35:57 --> Language Class Initialized
INFO - 2021-04-20 17:35:57 --> Loader Class Initialized
INFO - 2021-04-20 17:35:57 --> Helper loaded: url_helper
INFO - 2021-04-20 17:35:57 --> Helper loaded: form_helper
INFO - 2021-04-20 17:35:57 --> Helper loaded: common_helper
INFO - 2021-04-20 17:35:57 --> Helper loaded: util_helper
INFO - 2021-04-20 17:35:57 --> Helper loaded: user_helper
INFO - 2021-04-20 17:35:57 --> Database Driver Class Initialized
DEBUG - 2021-04-20 17:35:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 17:35:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 17:35:57 --> Form Validation Class Initialized
INFO - 2021-04-20 17:35:57 --> Controller Class Initialized
INFO - 2021-04-20 17:35:57 --> Model Class Initialized
INFO - 2021-04-20 17:35:57 --> Model Class Initialized
INFO - 2021-04-20 17:35:57 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\register.php
INFO - 2021-04-20 17:35:57 --> Final output sent to browser
DEBUG - 2021-04-20 17:35:57 --> Total execution time: 0.0274
INFO - 2021-04-20 17:36:07 --> Config Class Initialized
INFO - 2021-04-20 17:36:07 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:36:07 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:36:07 --> Utf8 Class Initialized
INFO - 2021-04-20 17:36:07 --> URI Class Initialized
DEBUG - 2021-04-20 17:36:07 --> No URI present. Default controller set.
INFO - 2021-04-20 17:36:07 --> Router Class Initialized
INFO - 2021-04-20 17:36:07 --> Output Class Initialized
INFO - 2021-04-20 17:36:07 --> Security Class Initialized
DEBUG - 2021-04-20 17:36:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:36:07 --> Input Class Initialized
INFO - 2021-04-20 17:36:07 --> Language Class Initialized
INFO - 2021-04-20 17:36:07 --> Loader Class Initialized
INFO - 2021-04-20 17:36:07 --> Helper loaded: url_helper
INFO - 2021-04-20 17:36:07 --> Helper loaded: form_helper
INFO - 2021-04-20 17:36:07 --> Helper loaded: common_helper
INFO - 2021-04-20 17:36:07 --> Helper loaded: util_helper
INFO - 2021-04-20 17:36:07 --> Helper loaded: user_helper
INFO - 2021-04-20 17:36:07 --> Database Driver Class Initialized
DEBUG - 2021-04-20 17:36:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 17:36:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 17:36:07 --> Form Validation Class Initialized
INFO - 2021-04-20 17:36:07 --> Controller Class Initialized
INFO - 2021-04-20 17:36:07 --> Model Class Initialized
INFO - 2021-04-20 17:36:07 --> Model Class Initialized
INFO - 2021-04-20 17:36:07 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-20 17:36:07 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-20 17:36:07 --> Final output sent to browser
DEBUG - 2021-04-20 17:36:07 --> Total execution time: 0.0286
INFO - 2021-04-20 17:37:01 --> Config Class Initialized
INFO - 2021-04-20 17:37:01 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:37:01 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:37:01 --> Utf8 Class Initialized
INFO - 2021-04-20 17:37:01 --> URI Class Initialized
INFO - 2021-04-20 17:37:01 --> Router Class Initialized
INFO - 2021-04-20 17:37:01 --> Output Class Initialized
INFO - 2021-04-20 17:37:01 --> Security Class Initialized
DEBUG - 2021-04-20 17:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:37:01 --> Input Class Initialized
INFO - 2021-04-20 17:37:01 --> Language Class Initialized
ERROR - 2021-04-20 17:37:01 --> 404 Page Not Found: administrator/User_controller/index
INFO - 2021-04-20 17:37:13 --> Config Class Initialized
INFO - 2021-04-20 17:37:13 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:37:13 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:37:13 --> Utf8 Class Initialized
INFO - 2021-04-20 17:37:13 --> URI Class Initialized
DEBUG - 2021-04-20 17:37:13 --> No URI present. Default controller set.
INFO - 2021-04-20 17:37:13 --> Router Class Initialized
INFO - 2021-04-20 17:37:13 --> Output Class Initialized
INFO - 2021-04-20 17:37:13 --> Security Class Initialized
DEBUG - 2021-04-20 17:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:37:13 --> Input Class Initialized
INFO - 2021-04-20 17:37:13 --> Language Class Initialized
INFO - 2021-04-20 17:37:13 --> Loader Class Initialized
INFO - 2021-04-20 17:37:13 --> Helper loaded: url_helper
INFO - 2021-04-20 17:37:13 --> Helper loaded: form_helper
INFO - 2021-04-20 17:37:13 --> Helper loaded: common_helper
INFO - 2021-04-20 17:37:13 --> Helper loaded: util_helper
INFO - 2021-04-20 17:37:13 --> Helper loaded: user_helper
INFO - 2021-04-20 17:37:13 --> Database Driver Class Initialized
DEBUG - 2021-04-20 17:37:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 17:37:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 17:37:13 --> Form Validation Class Initialized
INFO - 2021-04-20 17:37:13 --> Controller Class Initialized
INFO - 2021-04-20 17:37:13 --> Model Class Initialized
INFO - 2021-04-20 17:37:13 --> Model Class Initialized
INFO - 2021-04-20 17:37:13 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-20 17:37:13 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-20 17:37:13 --> Final output sent to browser
DEBUG - 2021-04-20 17:37:13 --> Total execution time: 0.0307
INFO - 2021-04-20 17:37:27 --> Config Class Initialized
INFO - 2021-04-20 17:37:27 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:37:27 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:37:27 --> Utf8 Class Initialized
INFO - 2021-04-20 17:37:27 --> URI Class Initialized
INFO - 2021-04-20 17:37:27 --> Router Class Initialized
INFO - 2021-04-20 17:37:27 --> Output Class Initialized
INFO - 2021-04-20 17:37:27 --> Security Class Initialized
DEBUG - 2021-04-20 17:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:37:27 --> Input Class Initialized
INFO - 2021-04-20 17:37:27 --> Language Class Initialized
INFO - 2021-04-20 17:37:27 --> Loader Class Initialized
INFO - 2021-04-20 17:37:27 --> Helper loaded: url_helper
INFO - 2021-04-20 17:37:27 --> Helper loaded: form_helper
INFO - 2021-04-20 17:37:27 --> Helper loaded: common_helper
INFO - 2021-04-20 17:37:27 --> Helper loaded: util_helper
INFO - 2021-04-20 17:37:27 --> Helper loaded: user_helper
INFO - 2021-04-20 17:37:27 --> Database Driver Class Initialized
DEBUG - 2021-04-20 17:37:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 17:37:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 17:37:27 --> Form Validation Class Initialized
INFO - 2021-04-20 17:37:27 --> Controller Class Initialized
INFO - 2021-04-20 17:38:48 --> Config Class Initialized
INFO - 2021-04-20 17:38:48 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:38:48 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:38:48 --> Utf8 Class Initialized
INFO - 2021-04-20 17:38:48 --> URI Class Initialized
INFO - 2021-04-20 17:38:48 --> Router Class Initialized
INFO - 2021-04-20 17:38:48 --> Output Class Initialized
INFO - 2021-04-20 17:38:48 --> Security Class Initialized
DEBUG - 2021-04-20 17:38:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:38:48 --> Input Class Initialized
INFO - 2021-04-20 17:38:48 --> Language Class Initialized
ERROR - 2021-04-20 17:38:48 --> 404 Page Not Found: administrator/User_controller/register
INFO - 2021-04-20 17:38:54 --> Config Class Initialized
INFO - 2021-04-20 17:38:54 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:38:54 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:38:54 --> Utf8 Class Initialized
INFO - 2021-04-20 17:38:54 --> URI Class Initialized
INFO - 2021-04-20 17:38:54 --> Router Class Initialized
INFO - 2021-04-20 17:38:54 --> Output Class Initialized
INFO - 2021-04-20 17:38:54 --> Security Class Initialized
DEBUG - 2021-04-20 17:38:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:38:54 --> Input Class Initialized
INFO - 2021-04-20 17:38:54 --> Language Class Initialized
INFO - 2021-04-20 17:38:54 --> Loader Class Initialized
INFO - 2021-04-20 17:38:54 --> Helper loaded: url_helper
INFO - 2021-04-20 17:38:54 --> Helper loaded: form_helper
INFO - 2021-04-20 17:38:54 --> Helper loaded: common_helper
INFO - 2021-04-20 17:38:54 --> Helper loaded: util_helper
INFO - 2021-04-20 17:38:54 --> Helper loaded: user_helper
INFO - 2021-04-20 17:38:54 --> Database Driver Class Initialized
DEBUG - 2021-04-20 17:38:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 17:38:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 17:38:54 --> Form Validation Class Initialized
INFO - 2021-04-20 17:38:54 --> Controller Class Initialized
INFO - 2021-04-20 17:38:55 --> Config Class Initialized
INFO - 2021-04-20 17:38:55 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:38:55 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:38:55 --> Utf8 Class Initialized
INFO - 2021-04-20 17:38:55 --> URI Class Initialized
DEBUG - 2021-04-20 17:38:55 --> No URI present. Default controller set.
INFO - 2021-04-20 17:38:55 --> Router Class Initialized
INFO - 2021-04-20 17:38:55 --> Output Class Initialized
INFO - 2021-04-20 17:38:55 --> Security Class Initialized
DEBUG - 2021-04-20 17:38:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:38:55 --> Input Class Initialized
INFO - 2021-04-20 17:38:55 --> Language Class Initialized
INFO - 2021-04-20 17:38:55 --> Loader Class Initialized
INFO - 2021-04-20 17:38:55 --> Helper loaded: url_helper
INFO - 2021-04-20 17:38:55 --> Helper loaded: form_helper
INFO - 2021-04-20 17:38:55 --> Helper loaded: common_helper
INFO - 2021-04-20 17:38:55 --> Helper loaded: util_helper
INFO - 2021-04-20 17:38:55 --> Helper loaded: user_helper
INFO - 2021-04-20 17:38:55 --> Database Driver Class Initialized
DEBUG - 2021-04-20 17:38:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 17:38:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 17:38:55 --> Form Validation Class Initialized
INFO - 2021-04-20 17:38:55 --> Controller Class Initialized
INFO - 2021-04-20 17:38:55 --> Model Class Initialized
INFO - 2021-04-20 17:38:55 --> Model Class Initialized
INFO - 2021-04-20 17:38:55 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-20 17:38:55 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-20 17:38:55 --> Final output sent to browser
DEBUG - 2021-04-20 17:38:55 --> Total execution time: 0.0380
INFO - 2021-04-20 17:39:18 --> Config Class Initialized
INFO - 2021-04-20 17:39:18 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:39:18 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:39:18 --> Utf8 Class Initialized
INFO - 2021-04-20 17:39:18 --> URI Class Initialized
INFO - 2021-04-20 17:39:18 --> Router Class Initialized
INFO - 2021-04-20 17:39:18 --> Output Class Initialized
INFO - 2021-04-20 17:39:18 --> Security Class Initialized
DEBUG - 2021-04-20 17:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:39:18 --> Input Class Initialized
INFO - 2021-04-20 17:39:18 --> Language Class Initialized
INFO - 2021-04-20 17:39:18 --> Loader Class Initialized
INFO - 2021-04-20 17:39:18 --> Helper loaded: url_helper
INFO - 2021-04-20 17:39:18 --> Helper loaded: form_helper
INFO - 2021-04-20 17:39:18 --> Helper loaded: common_helper
INFO - 2021-04-20 17:39:18 --> Helper loaded: util_helper
INFO - 2021-04-20 17:39:18 --> Helper loaded: user_helper
INFO - 2021-04-20 17:39:18 --> Database Driver Class Initialized
DEBUG - 2021-04-20 17:39:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 17:39:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 17:39:18 --> Form Validation Class Initialized
INFO - 2021-04-20 17:39:18 --> Controller Class Initialized
INFO - 2021-04-20 17:39:18 --> Model Class Initialized
INFO - 2021-04-20 17:39:18 --> Model Class Initialized
INFO - 2021-04-20 17:39:18 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\register.php
INFO - 2021-04-20 17:39:18 --> Final output sent to browser
DEBUG - 2021-04-20 17:39:18 --> Total execution time: 0.0271
INFO - 2021-04-20 17:39:18 --> Config Class Initialized
INFO - 2021-04-20 17:39:18 --> Config Class Initialized
INFO - 2021-04-20 17:39:18 --> Hooks Class Initialized
INFO - 2021-04-20 17:39:18 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:39:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-20 17:39:18 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:39:18 --> Utf8 Class Initialized
INFO - 2021-04-20 17:39:18 --> Utf8 Class Initialized
INFO - 2021-04-20 17:39:18 --> URI Class Initialized
INFO - 2021-04-20 17:39:18 --> URI Class Initialized
INFO - 2021-04-20 17:39:18 --> Router Class Initialized
INFO - 2021-04-20 17:39:18 --> Router Class Initialized
INFO - 2021-04-20 17:39:18 --> Output Class Initialized
INFO - 2021-04-20 17:39:18 --> Output Class Initialized
INFO - 2021-04-20 17:39:18 --> Security Class Initialized
INFO - 2021-04-20 17:39:18 --> Security Class Initialized
DEBUG - 2021-04-20 17:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:39:18 --> Input Class Initialized
INFO - 2021-04-20 17:39:18 --> Language Class Initialized
DEBUG - 2021-04-20 17:39:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:39:18 --> Input Class Initialized
INFO - 2021-04-20 17:39:18 --> Language Class Initialized
ERROR - 2021-04-20 17:39:18 --> 404 Page Not Found: Fasset/img
ERROR - 2021-04-20 17:39:18 --> 404 Page Not Found: Fasset/img
INFO - 2021-04-20 17:39:37 --> Config Class Initialized
INFO - 2021-04-20 17:39:37 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:39:37 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:39:37 --> Utf8 Class Initialized
INFO - 2021-04-20 17:39:37 --> URI Class Initialized
INFO - 2021-04-20 17:39:37 --> Router Class Initialized
INFO - 2021-04-20 17:39:37 --> Output Class Initialized
INFO - 2021-04-20 17:39:37 --> Security Class Initialized
DEBUG - 2021-04-20 17:39:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:39:37 --> Input Class Initialized
INFO - 2021-04-20 17:39:37 --> Language Class Initialized
INFO - 2021-04-20 17:39:37 --> Loader Class Initialized
INFO - 2021-04-20 17:39:37 --> Helper loaded: url_helper
INFO - 2021-04-20 17:39:37 --> Helper loaded: form_helper
INFO - 2021-04-20 17:39:37 --> Helper loaded: common_helper
INFO - 2021-04-20 17:39:37 --> Helper loaded: util_helper
INFO - 2021-04-20 17:39:37 --> Helper loaded: user_helper
INFO - 2021-04-20 17:39:37 --> Database Driver Class Initialized
DEBUG - 2021-04-20 17:39:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 17:39:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 17:39:37 --> Form Validation Class Initialized
INFO - 2021-04-20 17:39:37 --> Controller Class Initialized
INFO - 2021-04-20 17:39:37 --> Model Class Initialized
INFO - 2021-04-20 17:39:37 --> Model Class Initialized
ERROR - 2021-04-20 17:39:37 --> 404 Page Not Found: 
INFO - 2021-04-20 17:39:39 --> Config Class Initialized
INFO - 2021-04-20 17:39:39 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:39:39 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:39:39 --> Utf8 Class Initialized
INFO - 2021-04-20 17:39:39 --> URI Class Initialized
INFO - 2021-04-20 17:39:39 --> Router Class Initialized
INFO - 2021-04-20 17:39:39 --> Output Class Initialized
INFO - 2021-04-20 17:39:39 --> Security Class Initialized
DEBUG - 2021-04-20 17:39:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:39:39 --> Input Class Initialized
INFO - 2021-04-20 17:39:39 --> Language Class Initialized
INFO - 2021-04-20 17:39:39 --> Loader Class Initialized
INFO - 2021-04-20 17:39:39 --> Helper loaded: url_helper
INFO - 2021-04-20 17:39:39 --> Helper loaded: form_helper
INFO - 2021-04-20 17:39:39 --> Helper loaded: common_helper
INFO - 2021-04-20 17:39:39 --> Helper loaded: util_helper
INFO - 2021-04-20 17:39:39 --> Helper loaded: user_helper
INFO - 2021-04-20 17:39:39 --> Database Driver Class Initialized
DEBUG - 2021-04-20 17:39:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 17:39:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 17:39:39 --> Form Validation Class Initialized
INFO - 2021-04-20 17:39:39 --> Controller Class Initialized
INFO - 2021-04-20 17:39:39 --> Model Class Initialized
INFO - 2021-04-20 17:39:39 --> Model Class Initialized
INFO - 2021-04-20 17:39:39 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\register.php
INFO - 2021-04-20 17:39:39 --> Final output sent to browser
DEBUG - 2021-04-20 17:39:39 --> Total execution time: 0.0402
INFO - 2021-04-20 17:39:40 --> Config Class Initialized
INFO - 2021-04-20 17:39:40 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:39:40 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:39:40 --> Utf8 Class Initialized
INFO - 2021-04-20 17:39:40 --> URI Class Initialized
DEBUG - 2021-04-20 17:39:40 --> No URI present. Default controller set.
INFO - 2021-04-20 17:39:40 --> Router Class Initialized
INFO - 2021-04-20 17:39:40 --> Output Class Initialized
INFO - 2021-04-20 17:39:40 --> Security Class Initialized
DEBUG - 2021-04-20 17:39:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:39:40 --> Input Class Initialized
INFO - 2021-04-20 17:39:40 --> Language Class Initialized
INFO - 2021-04-20 17:39:40 --> Loader Class Initialized
INFO - 2021-04-20 17:39:40 --> Helper loaded: url_helper
INFO - 2021-04-20 17:39:40 --> Helper loaded: form_helper
INFO - 2021-04-20 17:39:40 --> Helper loaded: common_helper
INFO - 2021-04-20 17:39:40 --> Helper loaded: util_helper
INFO - 2021-04-20 17:39:40 --> Helper loaded: user_helper
INFO - 2021-04-20 17:39:40 --> Database Driver Class Initialized
DEBUG - 2021-04-20 17:39:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 17:39:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 17:39:40 --> Form Validation Class Initialized
INFO - 2021-04-20 17:39:40 --> Controller Class Initialized
INFO - 2021-04-20 17:39:40 --> Model Class Initialized
INFO - 2021-04-20 17:39:40 --> Model Class Initialized
INFO - 2021-04-20 17:39:40 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-20 17:39:40 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-20 17:39:40 --> Final output sent to browser
DEBUG - 2021-04-20 17:39:40 --> Total execution time: 0.0351
INFO - 2021-04-20 17:40:05 --> Config Class Initialized
INFO - 2021-04-20 17:40:05 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:40:05 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:40:05 --> Utf8 Class Initialized
INFO - 2021-04-20 17:40:05 --> URI Class Initialized
INFO - 2021-04-20 17:40:05 --> Router Class Initialized
INFO - 2021-04-20 17:40:05 --> Output Class Initialized
INFO - 2021-04-20 17:40:05 --> Security Class Initialized
DEBUG - 2021-04-20 17:40:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:40:05 --> Input Class Initialized
INFO - 2021-04-20 17:40:05 --> Language Class Initialized
INFO - 2021-04-20 17:40:05 --> Loader Class Initialized
INFO - 2021-04-20 17:40:05 --> Helper loaded: url_helper
INFO - 2021-04-20 17:40:05 --> Helper loaded: form_helper
INFO - 2021-04-20 17:40:05 --> Helper loaded: common_helper
INFO - 2021-04-20 17:40:05 --> Helper loaded: util_helper
INFO - 2021-04-20 17:40:05 --> Helper loaded: user_helper
INFO - 2021-04-20 17:40:05 --> Database Driver Class Initialized
DEBUG - 2021-04-20 17:40:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 17:40:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 17:40:05 --> Form Validation Class Initialized
INFO - 2021-04-20 17:40:05 --> Controller Class Initialized
INFO - 2021-04-20 17:40:05 --> Model Class Initialized
INFO - 2021-04-20 17:40:05 --> Model Class Initialized
INFO - 2021-04-20 17:40:05 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\register.php
INFO - 2021-04-20 17:40:05 --> Final output sent to browser
DEBUG - 2021-04-20 17:40:05 --> Total execution time: 0.0263
INFO - 2021-04-20 17:40:11 --> Config Class Initialized
INFO - 2021-04-20 17:40:11 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:40:11 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:40:11 --> Utf8 Class Initialized
INFO - 2021-04-20 17:40:11 --> URI Class Initialized
DEBUG - 2021-04-20 17:40:11 --> No URI present. Default controller set.
INFO - 2021-04-20 17:40:11 --> Router Class Initialized
INFO - 2021-04-20 17:40:11 --> Output Class Initialized
INFO - 2021-04-20 17:40:11 --> Security Class Initialized
DEBUG - 2021-04-20 17:40:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:40:11 --> Input Class Initialized
INFO - 2021-04-20 17:40:11 --> Language Class Initialized
INFO - 2021-04-20 17:40:11 --> Loader Class Initialized
INFO - 2021-04-20 17:40:11 --> Helper loaded: url_helper
INFO - 2021-04-20 17:40:11 --> Helper loaded: form_helper
INFO - 2021-04-20 17:40:11 --> Helper loaded: common_helper
INFO - 2021-04-20 17:40:11 --> Helper loaded: util_helper
INFO - 2021-04-20 17:40:11 --> Helper loaded: user_helper
INFO - 2021-04-20 17:40:11 --> Database Driver Class Initialized
DEBUG - 2021-04-20 17:40:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 17:40:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 17:40:11 --> Form Validation Class Initialized
INFO - 2021-04-20 17:40:11 --> Controller Class Initialized
INFO - 2021-04-20 17:40:11 --> Model Class Initialized
INFO - 2021-04-20 17:40:11 --> Model Class Initialized
INFO - 2021-04-20 17:40:11 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-20 17:40:11 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-20 17:40:11 --> Final output sent to browser
DEBUG - 2021-04-20 17:40:11 --> Total execution time: 0.0297
INFO - 2021-04-20 17:40:34 --> Config Class Initialized
INFO - 2021-04-20 17:40:34 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:40:34 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:40:34 --> Utf8 Class Initialized
INFO - 2021-04-20 17:40:34 --> URI Class Initialized
INFO - 2021-04-20 17:40:34 --> Router Class Initialized
INFO - 2021-04-20 17:40:34 --> Output Class Initialized
INFO - 2021-04-20 17:40:34 --> Security Class Initialized
DEBUG - 2021-04-20 17:40:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:40:34 --> Input Class Initialized
INFO - 2021-04-20 17:40:34 --> Language Class Initialized
ERROR - 2021-04-20 17:40:34 --> 404 Page Not Found: administrator/Register/index
INFO - 2021-04-20 17:42:05 --> Config Class Initialized
INFO - 2021-04-20 17:42:05 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:42:05 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:42:05 --> Utf8 Class Initialized
INFO - 2021-04-20 17:42:05 --> URI Class Initialized
INFO - 2021-04-20 17:42:05 --> Router Class Initialized
INFO - 2021-04-20 17:42:05 --> Output Class Initialized
INFO - 2021-04-20 17:42:05 --> Security Class Initialized
DEBUG - 2021-04-20 17:42:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:42:05 --> Input Class Initialized
INFO - 2021-04-20 17:42:05 --> Language Class Initialized
ERROR - 2021-04-20 17:42:05 --> 404 Page Not Found: administrator/Register/index
INFO - 2021-04-20 17:42:14 --> Config Class Initialized
INFO - 2021-04-20 17:42:14 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:42:14 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:42:14 --> Utf8 Class Initialized
INFO - 2021-04-20 17:42:14 --> URI Class Initialized
DEBUG - 2021-04-20 17:42:14 --> No URI present. Default controller set.
INFO - 2021-04-20 17:42:14 --> Router Class Initialized
INFO - 2021-04-20 17:42:14 --> Output Class Initialized
INFO - 2021-04-20 17:42:14 --> Security Class Initialized
DEBUG - 2021-04-20 17:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:42:14 --> Input Class Initialized
INFO - 2021-04-20 17:42:14 --> Language Class Initialized
INFO - 2021-04-20 17:42:14 --> Loader Class Initialized
INFO - 2021-04-20 17:42:14 --> Helper loaded: url_helper
INFO - 2021-04-20 17:42:14 --> Helper loaded: form_helper
INFO - 2021-04-20 17:42:14 --> Helper loaded: common_helper
INFO - 2021-04-20 17:42:14 --> Helper loaded: util_helper
INFO - 2021-04-20 17:42:14 --> Helper loaded: user_helper
INFO - 2021-04-20 17:42:14 --> Database Driver Class Initialized
DEBUG - 2021-04-20 17:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 17:42:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 17:42:14 --> Form Validation Class Initialized
INFO - 2021-04-20 17:42:14 --> Controller Class Initialized
INFO - 2021-04-20 17:42:14 --> Model Class Initialized
INFO - 2021-04-20 17:42:14 --> Model Class Initialized
INFO - 2021-04-20 17:42:14 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-20 17:42:14 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-20 17:42:14 --> Final output sent to browser
DEBUG - 2021-04-20 17:42:14 --> Total execution time: 0.0388
INFO - 2021-04-20 17:42:17 --> Config Class Initialized
INFO - 2021-04-20 17:42:17 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:42:17 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:42:17 --> Utf8 Class Initialized
INFO - 2021-04-20 17:42:17 --> URI Class Initialized
INFO - 2021-04-20 17:42:17 --> Router Class Initialized
INFO - 2021-04-20 17:42:17 --> Output Class Initialized
INFO - 2021-04-20 17:42:17 --> Security Class Initialized
DEBUG - 2021-04-20 17:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:42:17 --> Input Class Initialized
INFO - 2021-04-20 17:42:17 --> Language Class Initialized
INFO - 2021-04-20 17:42:17 --> Loader Class Initialized
INFO - 2021-04-20 17:42:17 --> Helper loaded: url_helper
INFO - 2021-04-20 17:42:17 --> Helper loaded: form_helper
INFO - 2021-04-20 17:42:17 --> Helper loaded: common_helper
INFO - 2021-04-20 17:42:17 --> Helper loaded: util_helper
INFO - 2021-04-20 17:42:17 --> Helper loaded: user_helper
INFO - 2021-04-20 17:42:17 --> Database Driver Class Initialized
DEBUG - 2021-04-20 17:42:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 17:42:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 17:42:17 --> Form Validation Class Initialized
INFO - 2021-04-20 17:42:17 --> Controller Class Initialized
INFO - 2021-04-20 17:42:17 --> Model Class Initialized
INFO - 2021-04-20 17:42:17 --> Model Class Initialized
INFO - 2021-04-20 17:42:17 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\register.php
INFO - 2021-04-20 17:42:17 --> Final output sent to browser
DEBUG - 2021-04-20 17:42:17 --> Total execution time: 0.0259
INFO - 2021-04-20 17:42:17 --> Config Class Initialized
INFO - 2021-04-20 17:42:17 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:42:17 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:42:17 --> Config Class Initialized
INFO - 2021-04-20 17:42:17 --> Utf8 Class Initialized
INFO - 2021-04-20 17:42:17 --> Hooks Class Initialized
INFO - 2021-04-20 17:42:17 --> URI Class Initialized
INFO - 2021-04-20 17:42:17 --> Router Class Initialized
DEBUG - 2021-04-20 17:42:17 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:42:17 --> Utf8 Class Initialized
INFO - 2021-04-20 17:42:17 --> URI Class Initialized
INFO - 2021-04-20 17:42:17 --> Output Class Initialized
INFO - 2021-04-20 17:42:17 --> Router Class Initialized
INFO - 2021-04-20 17:42:17 --> Security Class Initialized
DEBUG - 2021-04-20 17:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:42:17 --> Output Class Initialized
INFO - 2021-04-20 17:42:17 --> Input Class Initialized
INFO - 2021-04-20 17:42:17 --> Language Class Initialized
INFO - 2021-04-20 17:42:17 --> Security Class Initialized
ERROR - 2021-04-20 17:42:17 --> 404 Page Not Found: Fasset/img
DEBUG - 2021-04-20 17:42:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:42:17 --> Input Class Initialized
INFO - 2021-04-20 17:42:17 --> Language Class Initialized
ERROR - 2021-04-20 17:42:17 --> 404 Page Not Found: Fasset/img
INFO - 2021-04-20 17:42:23 --> Config Class Initialized
INFO - 2021-04-20 17:42:23 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:42:23 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:42:23 --> Utf8 Class Initialized
INFO - 2021-04-20 17:42:23 --> URI Class Initialized
DEBUG - 2021-04-20 17:42:23 --> No URI present. Default controller set.
INFO - 2021-04-20 17:42:23 --> Router Class Initialized
INFO - 2021-04-20 17:42:23 --> Output Class Initialized
INFO - 2021-04-20 17:42:23 --> Security Class Initialized
DEBUG - 2021-04-20 17:42:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:42:23 --> Input Class Initialized
INFO - 2021-04-20 17:42:23 --> Language Class Initialized
INFO - 2021-04-20 17:42:23 --> Loader Class Initialized
INFO - 2021-04-20 17:42:23 --> Helper loaded: url_helper
INFO - 2021-04-20 17:42:23 --> Helper loaded: form_helper
INFO - 2021-04-20 17:42:23 --> Helper loaded: common_helper
INFO - 2021-04-20 17:42:23 --> Helper loaded: util_helper
INFO - 2021-04-20 17:42:23 --> Helper loaded: user_helper
INFO - 2021-04-20 17:42:23 --> Database Driver Class Initialized
DEBUG - 2021-04-20 17:42:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 17:42:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 17:42:23 --> Form Validation Class Initialized
INFO - 2021-04-20 17:42:23 --> Controller Class Initialized
INFO - 2021-04-20 17:42:23 --> Model Class Initialized
INFO - 2021-04-20 17:42:23 --> Model Class Initialized
INFO - 2021-04-20 17:42:23 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-20 17:42:23 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-20 17:42:23 --> Final output sent to browser
DEBUG - 2021-04-20 17:42:23 --> Total execution time: 0.0278
INFO - 2021-04-20 17:45:07 --> Config Class Initialized
INFO - 2021-04-20 17:45:07 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:45:07 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:45:07 --> Utf8 Class Initialized
INFO - 2021-04-20 17:45:07 --> URI Class Initialized
DEBUG - 2021-04-20 17:45:07 --> No URI present. Default controller set.
INFO - 2021-04-20 17:45:07 --> Router Class Initialized
INFO - 2021-04-20 17:45:07 --> Output Class Initialized
INFO - 2021-04-20 17:45:07 --> Security Class Initialized
DEBUG - 2021-04-20 17:45:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:45:07 --> Input Class Initialized
INFO - 2021-04-20 17:45:07 --> Language Class Initialized
INFO - 2021-04-20 17:45:07 --> Loader Class Initialized
INFO - 2021-04-20 17:45:07 --> Helper loaded: url_helper
INFO - 2021-04-20 17:45:07 --> Helper loaded: form_helper
INFO - 2021-04-20 17:45:07 --> Helper loaded: common_helper
INFO - 2021-04-20 17:45:07 --> Helper loaded: util_helper
INFO - 2021-04-20 17:45:07 --> Helper loaded: user_helper
INFO - 2021-04-20 17:45:07 --> Database Driver Class Initialized
DEBUG - 2021-04-20 17:45:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 17:45:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 17:45:07 --> Form Validation Class Initialized
INFO - 2021-04-20 17:45:07 --> Controller Class Initialized
INFO - 2021-04-20 17:45:07 --> Model Class Initialized
INFO - 2021-04-20 17:45:07 --> Model Class Initialized
INFO - 2021-04-20 17:45:07 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-20 17:45:07 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-20 17:45:07 --> Final output sent to browser
DEBUG - 2021-04-20 17:45:07 --> Total execution time: 0.0390
INFO - 2021-04-20 17:45:37 --> Config Class Initialized
INFO - 2021-04-20 17:45:37 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:45:37 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:45:37 --> Utf8 Class Initialized
INFO - 2021-04-20 17:45:37 --> URI Class Initialized
DEBUG - 2021-04-20 17:45:37 --> No URI present. Default controller set.
INFO - 2021-04-20 17:45:37 --> Router Class Initialized
INFO - 2021-04-20 17:45:37 --> Output Class Initialized
INFO - 2021-04-20 17:45:37 --> Security Class Initialized
DEBUG - 2021-04-20 17:45:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:45:37 --> Input Class Initialized
INFO - 2021-04-20 17:45:37 --> Language Class Initialized
INFO - 2021-04-20 17:45:37 --> Loader Class Initialized
INFO - 2021-04-20 17:45:37 --> Helper loaded: url_helper
INFO - 2021-04-20 17:45:37 --> Helper loaded: form_helper
INFO - 2021-04-20 17:45:37 --> Helper loaded: common_helper
INFO - 2021-04-20 17:45:37 --> Helper loaded: util_helper
INFO - 2021-04-20 17:45:37 --> Helper loaded: user_helper
INFO - 2021-04-20 17:45:37 --> Database Driver Class Initialized
DEBUG - 2021-04-20 17:45:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 17:45:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 17:45:37 --> Form Validation Class Initialized
INFO - 2021-04-20 17:45:37 --> Controller Class Initialized
INFO - 2021-04-20 17:45:37 --> Model Class Initialized
INFO - 2021-04-20 17:45:37 --> Model Class Initialized
INFO - 2021-04-20 17:45:37 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-20 17:45:37 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-20 17:45:37 --> Final output sent to browser
DEBUG - 2021-04-20 17:45:37 --> Total execution time: 0.0291
INFO - 2021-04-20 17:45:39 --> Config Class Initialized
INFO - 2021-04-20 17:45:39 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:45:39 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:45:39 --> Utf8 Class Initialized
INFO - 2021-04-20 17:45:39 --> URI Class Initialized
DEBUG - 2021-04-20 17:45:39 --> No URI present. Default controller set.
INFO - 2021-04-20 17:45:39 --> Router Class Initialized
INFO - 2021-04-20 17:45:39 --> Output Class Initialized
INFO - 2021-04-20 17:45:39 --> Security Class Initialized
DEBUG - 2021-04-20 17:45:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:45:39 --> Input Class Initialized
INFO - 2021-04-20 17:45:39 --> Language Class Initialized
INFO - 2021-04-20 17:45:39 --> Loader Class Initialized
INFO - 2021-04-20 17:45:39 --> Helper loaded: url_helper
INFO - 2021-04-20 17:45:39 --> Helper loaded: form_helper
INFO - 2021-04-20 17:45:39 --> Helper loaded: common_helper
INFO - 2021-04-20 17:45:39 --> Helper loaded: util_helper
INFO - 2021-04-20 17:45:39 --> Helper loaded: user_helper
INFO - 2021-04-20 17:45:39 --> Database Driver Class Initialized
DEBUG - 2021-04-20 17:45:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 17:45:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 17:45:39 --> Form Validation Class Initialized
INFO - 2021-04-20 17:45:39 --> Controller Class Initialized
INFO - 2021-04-20 17:45:39 --> Model Class Initialized
INFO - 2021-04-20 17:45:39 --> Model Class Initialized
INFO - 2021-04-20 17:45:39 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-20 17:45:39 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-20 17:45:39 --> Final output sent to browser
DEBUG - 2021-04-20 17:45:39 --> Total execution time: 0.0264
INFO - 2021-04-20 17:47:44 --> Config Class Initialized
INFO - 2021-04-20 17:47:44 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:47:44 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:47:44 --> Utf8 Class Initialized
INFO - 2021-04-20 17:47:44 --> URI Class Initialized
DEBUG - 2021-04-20 17:47:44 --> No URI present. Default controller set.
INFO - 2021-04-20 17:47:44 --> Router Class Initialized
INFO - 2021-04-20 17:47:44 --> Output Class Initialized
INFO - 2021-04-20 17:47:44 --> Security Class Initialized
DEBUG - 2021-04-20 17:47:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:47:44 --> Input Class Initialized
INFO - 2021-04-20 17:47:44 --> Language Class Initialized
INFO - 2021-04-20 17:47:44 --> Loader Class Initialized
INFO - 2021-04-20 17:47:44 --> Helper loaded: url_helper
INFO - 2021-04-20 17:47:44 --> Helper loaded: form_helper
INFO - 2021-04-20 17:47:44 --> Helper loaded: common_helper
INFO - 2021-04-20 17:47:44 --> Helper loaded: util_helper
INFO - 2021-04-20 17:47:44 --> Helper loaded: user_helper
INFO - 2021-04-20 17:47:44 --> Database Driver Class Initialized
DEBUG - 2021-04-20 17:47:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 17:47:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 17:47:44 --> Form Validation Class Initialized
INFO - 2021-04-20 17:47:44 --> Controller Class Initialized
INFO - 2021-04-20 17:47:44 --> Model Class Initialized
INFO - 2021-04-20 17:47:44 --> Model Class Initialized
INFO - 2021-04-20 17:47:44 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-20 17:47:44 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-20 17:47:44 --> Final output sent to browser
DEBUG - 2021-04-20 17:47:44 --> Total execution time: 0.0279
INFO - 2021-04-20 17:47:57 --> Config Class Initialized
INFO - 2021-04-20 17:47:57 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:47:57 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:47:57 --> Utf8 Class Initialized
INFO - 2021-04-20 17:47:57 --> URI Class Initialized
DEBUG - 2021-04-20 17:47:57 --> No URI present. Default controller set.
INFO - 2021-04-20 17:47:57 --> Router Class Initialized
INFO - 2021-04-20 17:47:57 --> Output Class Initialized
INFO - 2021-04-20 17:47:57 --> Security Class Initialized
DEBUG - 2021-04-20 17:47:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:47:57 --> Input Class Initialized
INFO - 2021-04-20 17:47:57 --> Language Class Initialized
INFO - 2021-04-20 17:47:57 --> Loader Class Initialized
INFO - 2021-04-20 17:47:57 --> Helper loaded: url_helper
INFO - 2021-04-20 17:47:57 --> Helper loaded: form_helper
INFO - 2021-04-20 17:47:57 --> Helper loaded: common_helper
INFO - 2021-04-20 17:47:57 --> Helper loaded: util_helper
INFO - 2021-04-20 17:47:57 --> Helper loaded: user_helper
INFO - 2021-04-20 17:47:57 --> Database Driver Class Initialized
DEBUG - 2021-04-20 17:47:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 17:47:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 17:47:57 --> Form Validation Class Initialized
INFO - 2021-04-20 17:47:57 --> Controller Class Initialized
INFO - 2021-04-20 17:47:57 --> Model Class Initialized
INFO - 2021-04-20 17:47:57 --> Model Class Initialized
INFO - 2021-04-20 17:47:57 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-20 17:47:57 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-20 17:47:57 --> Final output sent to browser
DEBUG - 2021-04-20 17:47:57 --> Total execution time: 0.0265
INFO - 2021-04-20 17:48:24 --> Config Class Initialized
INFO - 2021-04-20 17:48:24 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:48:24 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:48:24 --> Utf8 Class Initialized
INFO - 2021-04-20 17:48:24 --> URI Class Initialized
INFO - 2021-04-20 17:48:24 --> Router Class Initialized
INFO - 2021-04-20 17:48:24 --> Output Class Initialized
INFO - 2021-04-20 17:48:24 --> Security Class Initialized
DEBUG - 2021-04-20 17:48:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:48:24 --> Input Class Initialized
INFO - 2021-04-20 17:48:24 --> Language Class Initialized
ERROR - 2021-04-20 17:48:24 --> 404 Page Not Found: Home/search
INFO - 2021-04-20 17:48:27 --> Config Class Initialized
INFO - 2021-04-20 17:48:27 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:48:27 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:48:27 --> Utf8 Class Initialized
INFO - 2021-04-20 17:48:27 --> URI Class Initialized
DEBUG - 2021-04-20 17:48:27 --> No URI present. Default controller set.
INFO - 2021-04-20 17:48:27 --> Router Class Initialized
INFO - 2021-04-20 17:48:27 --> Output Class Initialized
INFO - 2021-04-20 17:48:27 --> Security Class Initialized
DEBUG - 2021-04-20 17:48:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:48:27 --> Input Class Initialized
INFO - 2021-04-20 17:48:27 --> Language Class Initialized
INFO - 2021-04-20 17:48:27 --> Loader Class Initialized
INFO - 2021-04-20 17:48:27 --> Helper loaded: url_helper
INFO - 2021-04-20 17:48:27 --> Helper loaded: form_helper
INFO - 2021-04-20 17:48:27 --> Helper loaded: common_helper
INFO - 2021-04-20 17:48:27 --> Helper loaded: util_helper
INFO - 2021-04-20 17:48:27 --> Helper loaded: user_helper
INFO - 2021-04-20 17:48:27 --> Database Driver Class Initialized
DEBUG - 2021-04-20 17:48:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 17:48:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 17:48:27 --> Form Validation Class Initialized
INFO - 2021-04-20 17:48:27 --> Controller Class Initialized
INFO - 2021-04-20 17:48:27 --> Model Class Initialized
INFO - 2021-04-20 17:48:27 --> Model Class Initialized
INFO - 2021-04-20 17:48:27 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-20 17:48:27 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-20 17:48:27 --> Final output sent to browser
DEBUG - 2021-04-20 17:48:27 --> Total execution time: 0.0275
INFO - 2021-04-20 17:49:27 --> Config Class Initialized
INFO - 2021-04-20 17:49:27 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:49:27 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:49:27 --> Utf8 Class Initialized
INFO - 2021-04-20 17:49:27 --> URI Class Initialized
INFO - 2021-04-20 17:49:27 --> Router Class Initialized
INFO - 2021-04-20 17:49:27 --> Output Class Initialized
INFO - 2021-04-20 17:49:27 --> Security Class Initialized
DEBUG - 2021-04-20 17:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:49:27 --> Input Class Initialized
INFO - 2021-04-20 17:49:27 --> Language Class Initialized
INFO - 2021-04-20 17:49:27 --> Loader Class Initialized
INFO - 2021-04-20 17:49:27 --> Helper loaded: url_helper
INFO - 2021-04-20 17:49:27 --> Helper loaded: form_helper
INFO - 2021-04-20 17:49:27 --> Helper loaded: common_helper
INFO - 2021-04-20 17:49:27 --> Helper loaded: util_helper
INFO - 2021-04-20 17:49:27 --> Helper loaded: user_helper
INFO - 2021-04-20 17:49:27 --> Database Driver Class Initialized
DEBUG - 2021-04-20 17:49:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 17:49:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 17:49:27 --> Form Validation Class Initialized
INFO - 2021-04-20 17:49:27 --> Controller Class Initialized
INFO - 2021-04-20 17:49:27 --> Model Class Initialized
INFO - 2021-04-20 17:49:27 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\viewaccount.php
INFO - 2021-04-20 17:49:27 --> Final output sent to browser
DEBUG - 2021-04-20 17:49:27 --> Total execution time: 0.0294
INFO - 2021-04-20 17:49:27 --> Config Class Initialized
INFO - 2021-04-20 17:49:27 --> Hooks Class Initialized
INFO - 2021-04-20 17:49:27 --> Config Class Initialized
INFO - 2021-04-20 17:49:27 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:49:27 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:49:27 --> Utf8 Class Initialized
INFO - 2021-04-20 17:49:27 --> URI Class Initialized
DEBUG - 2021-04-20 17:49:27 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:49:27 --> Utf8 Class Initialized
INFO - 2021-04-20 17:49:27 --> Router Class Initialized
INFO - 2021-04-20 17:49:27 --> URI Class Initialized
INFO - 2021-04-20 17:49:27 --> Output Class Initialized
INFO - 2021-04-20 17:49:27 --> Router Class Initialized
INFO - 2021-04-20 17:49:27 --> Security Class Initialized
INFO - 2021-04-20 17:49:27 --> Output Class Initialized
DEBUG - 2021-04-20 17:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:49:27 --> Input Class Initialized
INFO - 2021-04-20 17:49:27 --> Security Class Initialized
INFO - 2021-04-20 17:49:27 --> Language Class Initialized
DEBUG - 2021-04-20 17:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:49:27 --> Input Class Initialized
ERROR - 2021-04-20 17:49:27 --> 404 Page Not Found: Assets/plugins
INFO - 2021-04-20 17:49:27 --> Language Class Initialized
ERROR - 2021-04-20 17:49:27 --> 404 Page Not Found: Assets/plugins
INFO - 2021-04-20 17:49:27 --> Config Class Initialized
INFO - 2021-04-20 17:49:27 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:49:27 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:49:27 --> Utf8 Class Initialized
INFO - 2021-04-20 17:49:27 --> URI Class Initialized
INFO - 2021-04-20 17:49:27 --> Router Class Initialized
INFO - 2021-04-20 17:49:27 --> Output Class Initialized
INFO - 2021-04-20 17:49:27 --> Security Class Initialized
DEBUG - 2021-04-20 17:49:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:49:27 --> Input Class Initialized
INFO - 2021-04-20 17:49:27 --> Language Class Initialized
ERROR - 2021-04-20 17:49:27 --> 404 Page Not Found: Assets/plugins
INFO - 2021-04-20 17:49:53 --> Config Class Initialized
INFO - 2021-04-20 17:49:53 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:49:53 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:49:53 --> Utf8 Class Initialized
INFO - 2021-04-20 17:49:53 --> URI Class Initialized
DEBUG - 2021-04-20 17:49:53 --> No URI present. Default controller set.
INFO - 2021-04-20 17:49:53 --> Router Class Initialized
INFO - 2021-04-20 17:49:53 --> Output Class Initialized
INFO - 2021-04-20 17:49:53 --> Security Class Initialized
DEBUG - 2021-04-20 17:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:49:53 --> Input Class Initialized
INFO - 2021-04-20 17:49:53 --> Language Class Initialized
INFO - 2021-04-20 17:49:53 --> Loader Class Initialized
INFO - 2021-04-20 17:49:53 --> Helper loaded: url_helper
INFO - 2021-04-20 17:49:53 --> Helper loaded: form_helper
INFO - 2021-04-20 17:49:53 --> Helper loaded: common_helper
INFO - 2021-04-20 17:49:53 --> Helper loaded: util_helper
INFO - 2021-04-20 17:49:53 --> Helper loaded: user_helper
INFO - 2021-04-20 17:49:53 --> Database Driver Class Initialized
DEBUG - 2021-04-20 17:49:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 17:49:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 17:49:53 --> Form Validation Class Initialized
INFO - 2021-04-20 17:49:53 --> Controller Class Initialized
INFO - 2021-04-20 17:49:53 --> Model Class Initialized
INFO - 2021-04-20 17:49:53 --> Model Class Initialized
INFO - 2021-04-20 17:49:53 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-20 17:49:53 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-20 17:49:53 --> Final output sent to browser
DEBUG - 2021-04-20 17:49:53 --> Total execution time: 0.0279
INFO - 2021-04-20 17:53:04 --> Config Class Initialized
INFO - 2021-04-20 17:53:04 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:53:04 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:53:04 --> Utf8 Class Initialized
INFO - 2021-04-20 17:53:04 --> URI Class Initialized
DEBUG - 2021-04-20 17:53:04 --> No URI present. Default controller set.
INFO - 2021-04-20 17:53:04 --> Router Class Initialized
INFO - 2021-04-20 17:53:04 --> Output Class Initialized
INFO - 2021-04-20 17:53:04 --> Security Class Initialized
DEBUG - 2021-04-20 17:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:53:04 --> Input Class Initialized
INFO - 2021-04-20 17:53:04 --> Language Class Initialized
INFO - 2021-04-20 17:53:04 --> Loader Class Initialized
INFO - 2021-04-20 17:53:04 --> Helper loaded: url_helper
INFO - 2021-04-20 17:53:04 --> Helper loaded: form_helper
INFO - 2021-04-20 17:53:04 --> Helper loaded: common_helper
INFO - 2021-04-20 17:53:04 --> Helper loaded: util_helper
INFO - 2021-04-20 17:53:04 --> Helper loaded: user_helper
INFO - 2021-04-20 17:53:04 --> Database Driver Class Initialized
DEBUG - 2021-04-20 17:53:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 17:53:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 17:53:04 --> Form Validation Class Initialized
INFO - 2021-04-20 17:53:04 --> Controller Class Initialized
INFO - 2021-04-20 17:53:04 --> Model Class Initialized
INFO - 2021-04-20 17:53:04 --> Model Class Initialized
INFO - 2021-04-20 17:53:04 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-20 17:53:04 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-20 17:53:04 --> Final output sent to browser
DEBUG - 2021-04-20 17:53:04 --> Total execution time: 0.0379
INFO - 2021-04-20 17:53:07 --> Config Class Initialized
INFO - 2021-04-20 17:53:07 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:53:07 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:53:07 --> Utf8 Class Initialized
INFO - 2021-04-20 17:53:07 --> URI Class Initialized
INFO - 2021-04-20 17:53:07 --> Router Class Initialized
INFO - 2021-04-20 17:53:07 --> Output Class Initialized
INFO - 2021-04-20 17:53:07 --> Security Class Initialized
DEBUG - 2021-04-20 17:53:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:53:07 --> Input Class Initialized
INFO - 2021-04-20 17:53:07 --> Language Class Initialized
INFO - 2021-04-20 17:53:07 --> Loader Class Initialized
INFO - 2021-04-20 17:53:07 --> Helper loaded: url_helper
INFO - 2021-04-20 17:53:07 --> Helper loaded: form_helper
INFO - 2021-04-20 17:53:07 --> Helper loaded: common_helper
INFO - 2021-04-20 17:53:07 --> Helper loaded: util_helper
INFO - 2021-04-20 17:53:07 --> Helper loaded: user_helper
INFO - 2021-04-20 17:53:07 --> Database Driver Class Initialized
DEBUG - 2021-04-20 17:53:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 17:53:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 17:53:07 --> Form Validation Class Initialized
INFO - 2021-04-20 17:53:07 --> Controller Class Initialized
INFO - 2021-04-20 17:53:07 --> Model Class Initialized
INFO - 2021-04-20 17:53:07 --> Model Class Initialized
INFO - 2021-04-20 17:53:07 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\register.php
INFO - 2021-04-20 17:53:07 --> Final output sent to browser
DEBUG - 2021-04-20 17:53:07 --> Total execution time: 0.0369
INFO - 2021-04-20 17:53:12 --> Config Class Initialized
INFO - 2021-04-20 17:53:12 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:53:12 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:53:12 --> Utf8 Class Initialized
INFO - 2021-04-20 17:53:12 --> URI Class Initialized
DEBUG - 2021-04-20 17:53:12 --> No URI present. Default controller set.
INFO - 2021-04-20 17:53:12 --> Router Class Initialized
INFO - 2021-04-20 17:53:12 --> Output Class Initialized
INFO - 2021-04-20 17:53:12 --> Security Class Initialized
DEBUG - 2021-04-20 17:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:53:12 --> Input Class Initialized
INFO - 2021-04-20 17:53:12 --> Language Class Initialized
INFO - 2021-04-20 17:53:12 --> Loader Class Initialized
INFO - 2021-04-20 17:53:12 --> Helper loaded: url_helper
INFO - 2021-04-20 17:53:12 --> Helper loaded: form_helper
INFO - 2021-04-20 17:53:12 --> Helper loaded: common_helper
INFO - 2021-04-20 17:53:12 --> Helper loaded: util_helper
INFO - 2021-04-20 17:53:12 --> Helper loaded: user_helper
INFO - 2021-04-20 17:53:12 --> Database Driver Class Initialized
DEBUG - 2021-04-20 17:53:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 17:53:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 17:53:12 --> Form Validation Class Initialized
INFO - 2021-04-20 17:53:12 --> Controller Class Initialized
INFO - 2021-04-20 17:53:12 --> Model Class Initialized
INFO - 2021-04-20 17:53:12 --> Model Class Initialized
INFO - 2021-04-20 17:53:12 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-20 17:53:12 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-20 17:53:12 --> Final output sent to browser
DEBUG - 2021-04-20 17:53:12 --> Total execution time: 0.0279
INFO - 2021-04-20 17:53:16 --> Config Class Initialized
INFO - 2021-04-20 17:53:16 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:53:16 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:53:16 --> Utf8 Class Initialized
INFO - 2021-04-20 17:53:16 --> URI Class Initialized
INFO - 2021-04-20 17:53:16 --> Router Class Initialized
INFO - 2021-04-20 17:53:16 --> Output Class Initialized
INFO - 2021-04-20 17:53:16 --> Security Class Initialized
DEBUG - 2021-04-20 17:53:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:53:16 --> Input Class Initialized
INFO - 2021-04-20 17:53:16 --> Language Class Initialized
INFO - 2021-04-20 17:53:16 --> Loader Class Initialized
INFO - 2021-04-20 17:53:16 --> Helper loaded: url_helper
INFO - 2021-04-20 17:53:16 --> Helper loaded: form_helper
INFO - 2021-04-20 17:53:16 --> Helper loaded: common_helper
INFO - 2021-04-20 17:53:16 --> Helper loaded: util_helper
INFO - 2021-04-20 17:53:16 --> Helper loaded: user_helper
INFO - 2021-04-20 17:53:16 --> Database Driver Class Initialized
DEBUG - 2021-04-20 17:53:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 17:53:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 17:53:16 --> Form Validation Class Initialized
INFO - 2021-04-20 17:53:16 --> Controller Class Initialized
INFO - 2021-04-20 17:53:16 --> Model Class Initialized
INFO - 2021-04-20 17:53:16 --> Model Class Initialized
INFO - 2021-04-20 17:53:16 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\register.php
INFO - 2021-04-20 17:53:16 --> Final output sent to browser
DEBUG - 2021-04-20 17:53:16 --> Total execution time: 0.0270
INFO - 2021-04-20 17:53:25 --> Config Class Initialized
INFO - 2021-04-20 17:53:25 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:53:25 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:53:25 --> Utf8 Class Initialized
INFO - 2021-04-20 17:53:25 --> URI Class Initialized
INFO - 2021-04-20 17:53:25 --> Router Class Initialized
INFO - 2021-04-20 17:53:25 --> Output Class Initialized
INFO - 2021-04-20 17:53:25 --> Security Class Initialized
DEBUG - 2021-04-20 17:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:53:25 --> Input Class Initialized
INFO - 2021-04-20 17:53:25 --> Language Class Initialized
INFO - 2021-04-20 17:53:25 --> Loader Class Initialized
INFO - 2021-04-20 17:53:25 --> Helper loaded: url_helper
INFO - 2021-04-20 17:53:25 --> Helper loaded: form_helper
INFO - 2021-04-20 17:53:25 --> Helper loaded: common_helper
INFO - 2021-04-20 17:53:25 --> Helper loaded: util_helper
INFO - 2021-04-20 17:53:25 --> Helper loaded: user_helper
INFO - 2021-04-20 17:53:25 --> Database Driver Class Initialized
DEBUG - 2021-04-20 17:53:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 17:53:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 17:53:25 --> Form Validation Class Initialized
INFO - 2021-04-20 17:53:25 --> Controller Class Initialized
INFO - 2021-04-20 17:53:25 --> Model Class Initialized
INFO - 2021-04-20 17:53:25 --> Model Class Initialized
INFO - 2021-04-20 17:53:25 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\register.php
INFO - 2021-04-20 17:53:25 --> Final output sent to browser
DEBUG - 2021-04-20 17:53:25 --> Total execution time: 0.0268
INFO - 2021-04-20 17:53:25 --> Config Class Initialized
INFO - 2021-04-20 17:53:25 --> Config Class Initialized
INFO - 2021-04-20 17:53:25 --> Hooks Class Initialized
INFO - 2021-04-20 17:53:25 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:53:25 --> UTF-8 Support Enabled
DEBUG - 2021-04-20 17:53:25 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:53:25 --> Utf8 Class Initialized
INFO - 2021-04-20 17:53:25 --> Utf8 Class Initialized
INFO - 2021-04-20 17:53:25 --> URI Class Initialized
INFO - 2021-04-20 17:53:25 --> URI Class Initialized
INFO - 2021-04-20 17:53:25 --> Router Class Initialized
INFO - 2021-04-20 17:53:25 --> Router Class Initialized
INFO - 2021-04-20 17:53:25 --> Output Class Initialized
INFO - 2021-04-20 17:53:25 --> Output Class Initialized
INFO - 2021-04-20 17:53:25 --> Security Class Initialized
INFO - 2021-04-20 17:53:25 --> Security Class Initialized
DEBUG - 2021-04-20 17:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:53:25 --> Input Class Initialized
INFO - 2021-04-20 17:53:25 --> Language Class Initialized
DEBUG - 2021-04-20 17:53:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:53:25 --> Input Class Initialized
INFO - 2021-04-20 17:53:25 --> Language Class Initialized
ERROR - 2021-04-20 17:53:25 --> 404 Page Not Found: Fasset/img
ERROR - 2021-04-20 17:53:25 --> 404 Page Not Found: Fasset/img
INFO - 2021-04-20 17:53:31 --> Config Class Initialized
INFO - 2021-04-20 17:53:31 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:53:31 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:53:31 --> Utf8 Class Initialized
INFO - 2021-04-20 17:53:31 --> URI Class Initialized
DEBUG - 2021-04-20 17:53:31 --> No URI present. Default controller set.
INFO - 2021-04-20 17:53:31 --> Router Class Initialized
INFO - 2021-04-20 17:53:31 --> Output Class Initialized
INFO - 2021-04-20 17:53:31 --> Security Class Initialized
DEBUG - 2021-04-20 17:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:53:31 --> Input Class Initialized
INFO - 2021-04-20 17:53:31 --> Language Class Initialized
INFO - 2021-04-20 17:53:31 --> Loader Class Initialized
INFO - 2021-04-20 17:53:31 --> Helper loaded: url_helper
INFO - 2021-04-20 17:53:31 --> Helper loaded: form_helper
INFO - 2021-04-20 17:53:31 --> Helper loaded: common_helper
INFO - 2021-04-20 17:53:31 --> Helper loaded: util_helper
INFO - 2021-04-20 17:53:31 --> Helper loaded: user_helper
INFO - 2021-04-20 17:53:31 --> Database Driver Class Initialized
DEBUG - 2021-04-20 17:53:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 17:53:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 17:53:31 --> Form Validation Class Initialized
INFO - 2021-04-20 17:53:31 --> Controller Class Initialized
INFO - 2021-04-20 17:53:31 --> Model Class Initialized
INFO - 2021-04-20 17:53:31 --> Model Class Initialized
INFO - 2021-04-20 17:53:31 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-20 17:53:31 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-20 17:53:31 --> Final output sent to browser
DEBUG - 2021-04-20 17:53:31 --> Total execution time: 0.0277
INFO - 2021-04-20 17:55:29 --> Config Class Initialized
INFO - 2021-04-20 17:55:29 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:55:29 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:55:29 --> Utf8 Class Initialized
INFO - 2021-04-20 17:55:29 --> URI Class Initialized
DEBUG - 2021-04-20 17:55:29 --> No URI present. Default controller set.
INFO - 2021-04-20 17:55:29 --> Router Class Initialized
INFO - 2021-04-20 17:55:29 --> Output Class Initialized
INFO - 2021-04-20 17:55:29 --> Security Class Initialized
DEBUG - 2021-04-20 17:55:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:55:29 --> Input Class Initialized
INFO - 2021-04-20 17:55:29 --> Language Class Initialized
INFO - 2021-04-20 17:55:29 --> Loader Class Initialized
INFO - 2021-04-20 17:55:29 --> Helper loaded: url_helper
INFO - 2021-04-20 17:55:29 --> Helper loaded: form_helper
INFO - 2021-04-20 17:55:29 --> Helper loaded: common_helper
INFO - 2021-04-20 17:55:29 --> Helper loaded: util_helper
INFO - 2021-04-20 17:55:29 --> Helper loaded: user_helper
INFO - 2021-04-20 17:55:29 --> Database Driver Class Initialized
DEBUG - 2021-04-20 17:55:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 17:55:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 17:55:29 --> Form Validation Class Initialized
INFO - 2021-04-20 17:55:29 --> Controller Class Initialized
INFO - 2021-04-20 17:55:29 --> Model Class Initialized
INFO - 2021-04-20 17:55:29 --> Model Class Initialized
INFO - 2021-04-20 17:55:29 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-20 17:55:29 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-20 17:55:29 --> Final output sent to browser
DEBUG - 2021-04-20 17:55:29 --> Total execution time: 0.0277
INFO - 2021-04-20 17:55:43 --> Config Class Initialized
INFO - 2021-04-20 17:55:43 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:55:43 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:55:43 --> Utf8 Class Initialized
INFO - 2021-04-20 17:55:43 --> URI Class Initialized
DEBUG - 2021-04-20 17:55:43 --> No URI present. Default controller set.
INFO - 2021-04-20 17:55:43 --> Router Class Initialized
INFO - 2021-04-20 17:55:43 --> Output Class Initialized
INFO - 2021-04-20 17:55:43 --> Security Class Initialized
DEBUG - 2021-04-20 17:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:55:43 --> Input Class Initialized
INFO - 2021-04-20 17:55:43 --> Language Class Initialized
INFO - 2021-04-20 17:55:43 --> Loader Class Initialized
INFO - 2021-04-20 17:55:43 --> Helper loaded: url_helper
INFO - 2021-04-20 17:55:43 --> Helper loaded: form_helper
INFO - 2021-04-20 17:55:43 --> Helper loaded: common_helper
INFO - 2021-04-20 17:55:43 --> Helper loaded: util_helper
INFO - 2021-04-20 17:55:43 --> Helper loaded: user_helper
INFO - 2021-04-20 17:55:43 --> Database Driver Class Initialized
DEBUG - 2021-04-20 17:55:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 17:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 17:55:43 --> Form Validation Class Initialized
INFO - 2021-04-20 17:55:43 --> Controller Class Initialized
INFO - 2021-04-20 17:55:43 --> Model Class Initialized
INFO - 2021-04-20 17:55:43 --> Model Class Initialized
INFO - 2021-04-20 17:55:43 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-20 17:55:43 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-20 17:55:43 --> Final output sent to browser
DEBUG - 2021-04-20 17:55:43 --> Total execution time: 0.0369
INFO - 2021-04-20 17:56:25 --> Config Class Initialized
INFO - 2021-04-20 17:56:25 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:56:25 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:56:25 --> Utf8 Class Initialized
INFO - 2021-04-20 17:56:25 --> URI Class Initialized
DEBUG - 2021-04-20 17:56:25 --> No URI present. Default controller set.
INFO - 2021-04-20 17:56:25 --> Router Class Initialized
INFO - 2021-04-20 17:56:25 --> Output Class Initialized
INFO - 2021-04-20 17:56:25 --> Security Class Initialized
DEBUG - 2021-04-20 17:56:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:56:25 --> Input Class Initialized
INFO - 2021-04-20 17:56:25 --> Language Class Initialized
INFO - 2021-04-20 17:56:25 --> Loader Class Initialized
INFO - 2021-04-20 17:56:25 --> Helper loaded: url_helper
INFO - 2021-04-20 17:56:25 --> Helper loaded: form_helper
INFO - 2021-04-20 17:56:25 --> Helper loaded: common_helper
INFO - 2021-04-20 17:56:25 --> Helper loaded: util_helper
INFO - 2021-04-20 17:56:25 --> Helper loaded: user_helper
INFO - 2021-04-20 17:56:25 --> Database Driver Class Initialized
DEBUG - 2021-04-20 17:56:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 17:56:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 17:56:25 --> Form Validation Class Initialized
INFO - 2021-04-20 17:56:25 --> Controller Class Initialized
INFO - 2021-04-20 17:56:25 --> Model Class Initialized
INFO - 2021-04-20 17:56:25 --> Model Class Initialized
INFO - 2021-04-20 17:56:25 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-20 17:56:25 --> Final output sent to browser
DEBUG - 2021-04-20 17:56:25 --> Total execution time: 0.0274
INFO - 2021-04-20 17:56:34 --> Config Class Initialized
INFO - 2021-04-20 17:56:34 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:56:34 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:56:34 --> Utf8 Class Initialized
INFO - 2021-04-20 17:56:34 --> URI Class Initialized
DEBUG - 2021-04-20 17:56:34 --> No URI present. Default controller set.
INFO - 2021-04-20 17:56:34 --> Router Class Initialized
INFO - 2021-04-20 17:56:34 --> Output Class Initialized
INFO - 2021-04-20 17:56:34 --> Security Class Initialized
DEBUG - 2021-04-20 17:56:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:56:34 --> Input Class Initialized
INFO - 2021-04-20 17:56:34 --> Language Class Initialized
INFO - 2021-04-20 17:56:34 --> Loader Class Initialized
INFO - 2021-04-20 17:56:34 --> Helper loaded: url_helper
INFO - 2021-04-20 17:56:34 --> Helper loaded: form_helper
INFO - 2021-04-20 17:56:34 --> Helper loaded: common_helper
INFO - 2021-04-20 17:56:34 --> Helper loaded: util_helper
INFO - 2021-04-20 17:56:34 --> Helper loaded: user_helper
INFO - 2021-04-20 17:56:34 --> Database Driver Class Initialized
DEBUG - 2021-04-20 17:56:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 17:56:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 17:56:34 --> Form Validation Class Initialized
INFO - 2021-04-20 17:56:34 --> Controller Class Initialized
INFO - 2021-04-20 17:56:34 --> Model Class Initialized
INFO - 2021-04-20 17:56:34 --> Model Class Initialized
INFO - 2021-04-20 17:56:34 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-20 17:56:34 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-20 17:56:34 --> Final output sent to browser
DEBUG - 2021-04-20 17:56:34 --> Total execution time: 0.0269
INFO - 2021-04-20 17:56:53 --> Config Class Initialized
INFO - 2021-04-20 17:56:53 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:56:53 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:56:53 --> Utf8 Class Initialized
INFO - 2021-04-20 17:56:53 --> URI Class Initialized
DEBUG - 2021-04-20 17:56:53 --> No URI present. Default controller set.
INFO - 2021-04-20 17:56:53 --> Router Class Initialized
INFO - 2021-04-20 17:56:53 --> Output Class Initialized
INFO - 2021-04-20 17:56:53 --> Security Class Initialized
DEBUG - 2021-04-20 17:56:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:56:53 --> Input Class Initialized
INFO - 2021-04-20 17:56:53 --> Language Class Initialized
INFO - 2021-04-20 17:56:53 --> Loader Class Initialized
INFO - 2021-04-20 17:56:53 --> Helper loaded: url_helper
INFO - 2021-04-20 17:56:53 --> Helper loaded: form_helper
INFO - 2021-04-20 17:56:53 --> Helper loaded: common_helper
INFO - 2021-04-20 17:56:53 --> Helper loaded: util_helper
INFO - 2021-04-20 17:56:53 --> Helper loaded: user_helper
INFO - 2021-04-20 17:56:53 --> Database Driver Class Initialized
DEBUG - 2021-04-20 17:56:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 17:56:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 17:56:53 --> Form Validation Class Initialized
INFO - 2021-04-20 17:56:53 --> Controller Class Initialized
INFO - 2021-04-20 17:56:53 --> Model Class Initialized
INFO - 2021-04-20 17:56:53 --> Model Class Initialized
INFO - 2021-04-20 17:56:53 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-20 17:56:53 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-20 17:56:53 --> Final output sent to browser
DEBUG - 2021-04-20 17:56:53 --> Total execution time: 0.0284
INFO - 2021-04-20 17:58:11 --> Config Class Initialized
INFO - 2021-04-20 17:58:11 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:58:11 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:58:11 --> Utf8 Class Initialized
INFO - 2021-04-20 17:58:11 --> URI Class Initialized
DEBUG - 2021-04-20 17:58:11 --> No URI present. Default controller set.
INFO - 2021-04-20 17:58:11 --> Router Class Initialized
INFO - 2021-04-20 17:58:11 --> Output Class Initialized
INFO - 2021-04-20 17:58:11 --> Security Class Initialized
DEBUG - 2021-04-20 17:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:58:11 --> Input Class Initialized
INFO - 2021-04-20 17:58:11 --> Language Class Initialized
INFO - 2021-04-20 17:58:11 --> Loader Class Initialized
INFO - 2021-04-20 17:58:11 --> Helper loaded: url_helper
INFO - 2021-04-20 17:58:11 --> Helper loaded: form_helper
INFO - 2021-04-20 17:58:11 --> Helper loaded: common_helper
INFO - 2021-04-20 17:58:11 --> Helper loaded: util_helper
INFO - 2021-04-20 17:58:11 --> Helper loaded: user_helper
INFO - 2021-04-20 17:58:11 --> Database Driver Class Initialized
DEBUG - 2021-04-20 17:58:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 17:58:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 17:58:11 --> Form Validation Class Initialized
INFO - 2021-04-20 17:58:11 --> Controller Class Initialized
INFO - 2021-04-20 17:58:11 --> Model Class Initialized
INFO - 2021-04-20 17:58:11 --> Model Class Initialized
INFO - 2021-04-20 17:58:11 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-20 17:58:11 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-20 17:58:11 --> Final output sent to browser
DEBUG - 2021-04-20 17:58:11 --> Total execution time: 0.0377
INFO - 2021-04-20 17:58:28 --> Config Class Initialized
INFO - 2021-04-20 17:58:28 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:58:28 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:58:28 --> Utf8 Class Initialized
INFO - 2021-04-20 17:58:28 --> URI Class Initialized
INFO - 2021-04-20 17:58:28 --> Router Class Initialized
INFO - 2021-04-20 17:58:28 --> Output Class Initialized
INFO - 2021-04-20 17:58:28 --> Security Class Initialized
DEBUG - 2021-04-20 17:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:58:28 --> Input Class Initialized
INFO - 2021-04-20 17:58:28 --> Language Class Initialized
INFO - 2021-04-20 17:58:28 --> Loader Class Initialized
INFO - 2021-04-20 17:58:28 --> Helper loaded: url_helper
INFO - 2021-04-20 17:58:28 --> Helper loaded: form_helper
INFO - 2021-04-20 17:58:28 --> Helper loaded: common_helper
INFO - 2021-04-20 17:58:28 --> Helper loaded: util_helper
INFO - 2021-04-20 17:58:28 --> Helper loaded: user_helper
INFO - 2021-04-20 17:58:28 --> Database Driver Class Initialized
DEBUG - 2021-04-20 17:58:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 17:58:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 17:58:28 --> Form Validation Class Initialized
INFO - 2021-04-20 17:58:28 --> Controller Class Initialized
INFO - 2021-04-20 17:58:28 --> Model Class Initialized
INFO - 2021-04-20 17:58:28 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\viewaccount.php
INFO - 2021-04-20 17:58:28 --> Final output sent to browser
DEBUG - 2021-04-20 17:58:28 --> Total execution time: 0.0280
INFO - 2021-04-20 17:58:28 --> Config Class Initialized
INFO - 2021-04-20 17:58:28 --> Hooks Class Initialized
INFO - 2021-04-20 17:58:28 --> Config Class Initialized
INFO - 2021-04-20 17:58:28 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:58:28 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:58:28 --> Utf8 Class Initialized
INFO - 2021-04-20 17:58:28 --> URI Class Initialized
DEBUG - 2021-04-20 17:58:28 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:58:28 --> Utf8 Class Initialized
INFO - 2021-04-20 17:58:28 --> Router Class Initialized
INFO - 2021-04-20 17:58:28 --> URI Class Initialized
INFO - 2021-04-20 17:58:28 --> Output Class Initialized
INFO - 2021-04-20 17:58:28 --> Router Class Initialized
INFO - 2021-04-20 17:58:28 --> Security Class Initialized
INFO - 2021-04-20 17:58:28 --> Output Class Initialized
DEBUG - 2021-04-20 17:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:58:28 --> Input Class Initialized
INFO - 2021-04-20 17:58:28 --> Security Class Initialized
INFO - 2021-04-20 17:58:28 --> Language Class Initialized
DEBUG - 2021-04-20 17:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:58:28 --> Input Class Initialized
INFO - 2021-04-20 17:58:28 --> Language Class Initialized
ERROR - 2021-04-20 17:58:28 --> 404 Page Not Found: Assets/plugins
ERROR - 2021-04-20 17:58:28 --> 404 Page Not Found: Assets/plugins
INFO - 2021-04-20 17:58:28 --> Config Class Initialized
INFO - 2021-04-20 17:58:28 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:58:28 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:58:28 --> Utf8 Class Initialized
INFO - 2021-04-20 17:58:28 --> URI Class Initialized
INFO - 2021-04-20 17:58:28 --> Router Class Initialized
INFO - 2021-04-20 17:58:28 --> Output Class Initialized
INFO - 2021-04-20 17:58:28 --> Security Class Initialized
DEBUG - 2021-04-20 17:58:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:58:28 --> Input Class Initialized
INFO - 2021-04-20 17:58:28 --> Language Class Initialized
ERROR - 2021-04-20 17:58:28 --> 404 Page Not Found: Assets/plugins
INFO - 2021-04-20 17:58:30 --> Config Class Initialized
INFO - 2021-04-20 17:58:30 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:58:30 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:58:30 --> Utf8 Class Initialized
INFO - 2021-04-20 17:58:30 --> URI Class Initialized
INFO - 2021-04-20 17:58:30 --> Router Class Initialized
INFO - 2021-04-20 17:58:30 --> Output Class Initialized
INFO - 2021-04-20 17:58:30 --> Security Class Initialized
DEBUG - 2021-04-20 17:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:58:30 --> Input Class Initialized
INFO - 2021-04-20 17:58:30 --> Language Class Initialized
INFO - 2021-04-20 17:58:30 --> Loader Class Initialized
INFO - 2021-04-20 17:58:30 --> Helper loaded: url_helper
INFO - 2021-04-20 17:58:30 --> Helper loaded: form_helper
INFO - 2021-04-20 17:58:30 --> Helper loaded: common_helper
INFO - 2021-04-20 17:58:30 --> Helper loaded: util_helper
INFO - 2021-04-20 17:58:30 --> Helper loaded: user_helper
INFO - 2021-04-20 17:58:30 --> Database Driver Class Initialized
DEBUG - 2021-04-20 17:58:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 17:58:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 17:58:30 --> Form Validation Class Initialized
INFO - 2021-04-20 17:58:30 --> Controller Class Initialized
INFO - 2021-04-20 17:58:30 --> Model Class Initialized
INFO - 2021-04-20 17:58:30 --> Model Class Initialized
INFO - 2021-04-20 17:58:30 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\register.php
INFO - 2021-04-20 17:58:30 --> Final output sent to browser
DEBUG - 2021-04-20 17:58:30 --> Total execution time: 0.0272
INFO - 2021-04-20 17:58:30 --> Config Class Initialized
INFO - 2021-04-20 17:58:30 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:58:30 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:58:30 --> Utf8 Class Initialized
INFO - 2021-04-20 17:58:30 --> URI Class Initialized
INFO - 2021-04-20 17:58:30 --> Config Class Initialized
INFO - 2021-04-20 17:58:30 --> Router Class Initialized
INFO - 2021-04-20 17:58:30 --> Hooks Class Initialized
INFO - 2021-04-20 17:58:30 --> Output Class Initialized
DEBUG - 2021-04-20 17:58:30 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:58:30 --> Utf8 Class Initialized
INFO - 2021-04-20 17:58:30 --> Security Class Initialized
INFO - 2021-04-20 17:58:30 --> URI Class Initialized
DEBUG - 2021-04-20 17:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:58:30 --> Input Class Initialized
INFO - 2021-04-20 17:58:30 --> Router Class Initialized
INFO - 2021-04-20 17:58:30 --> Language Class Initialized
INFO - 2021-04-20 17:58:30 --> Output Class Initialized
ERROR - 2021-04-20 17:58:30 --> 404 Page Not Found: Fasset/img
INFO - 2021-04-20 17:58:30 --> Security Class Initialized
DEBUG - 2021-04-20 17:58:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:58:30 --> Input Class Initialized
INFO - 2021-04-20 17:58:30 --> Language Class Initialized
ERROR - 2021-04-20 17:58:30 --> 404 Page Not Found: Fasset/img
INFO - 2021-04-20 17:58:32 --> Config Class Initialized
INFO - 2021-04-20 17:58:32 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:58:32 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:58:32 --> Utf8 Class Initialized
INFO - 2021-04-20 17:58:32 --> URI Class Initialized
INFO - 2021-04-20 17:58:32 --> Router Class Initialized
INFO - 2021-04-20 17:58:32 --> Output Class Initialized
INFO - 2021-04-20 17:58:32 --> Security Class Initialized
DEBUG - 2021-04-20 17:58:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:58:32 --> Input Class Initialized
INFO - 2021-04-20 17:58:32 --> Language Class Initialized
INFO - 2021-04-20 17:58:32 --> Loader Class Initialized
INFO - 2021-04-20 17:58:32 --> Helper loaded: url_helper
INFO - 2021-04-20 17:58:32 --> Helper loaded: form_helper
INFO - 2021-04-20 17:58:32 --> Helper loaded: common_helper
INFO - 2021-04-20 17:58:32 --> Helper loaded: util_helper
INFO - 2021-04-20 17:58:32 --> Helper loaded: user_helper
INFO - 2021-04-20 17:58:32 --> Database Driver Class Initialized
DEBUG - 2021-04-20 17:58:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 17:58:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 17:58:32 --> Form Validation Class Initialized
INFO - 2021-04-20 17:58:32 --> Controller Class Initialized
INFO - 2021-04-20 17:58:32 --> Model Class Initialized
INFO - 2021-04-20 17:58:32 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\viewaccount.php
INFO - 2021-04-20 17:58:32 --> Final output sent to browser
DEBUG - 2021-04-20 17:58:32 --> Total execution time: 0.0285
INFO - 2021-04-20 17:58:34 --> Config Class Initialized
INFO - 2021-04-20 17:58:34 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:58:34 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:58:34 --> Utf8 Class Initialized
INFO - 2021-04-20 17:58:34 --> URI Class Initialized
INFO - 2021-04-20 17:58:34 --> Router Class Initialized
INFO - 2021-04-20 17:58:34 --> Output Class Initialized
INFO - 2021-04-20 17:58:34 --> Security Class Initialized
DEBUG - 2021-04-20 17:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:58:34 --> Input Class Initialized
INFO - 2021-04-20 17:58:34 --> Language Class Initialized
INFO - 2021-04-20 17:58:34 --> Loader Class Initialized
INFO - 2021-04-20 17:58:34 --> Helper loaded: url_helper
INFO - 2021-04-20 17:58:34 --> Helper loaded: form_helper
INFO - 2021-04-20 17:58:34 --> Helper loaded: common_helper
INFO - 2021-04-20 17:58:34 --> Helper loaded: util_helper
INFO - 2021-04-20 17:58:34 --> Helper loaded: user_helper
INFO - 2021-04-20 17:58:34 --> Database Driver Class Initialized
DEBUG - 2021-04-20 17:58:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 17:58:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 17:58:34 --> Form Validation Class Initialized
INFO - 2021-04-20 17:58:34 --> Controller Class Initialized
INFO - 2021-04-20 17:58:34 --> Model Class Initialized
INFO - 2021-04-20 17:58:34 --> Model Class Initialized
INFO - 2021-04-20 17:58:34 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\register.php
INFO - 2021-04-20 17:58:34 --> Final output sent to browser
DEBUG - 2021-04-20 17:58:34 --> Total execution time: 0.0262
INFO - 2021-04-20 17:58:39 --> Config Class Initialized
INFO - 2021-04-20 17:58:39 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:58:39 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:58:39 --> Utf8 Class Initialized
INFO - 2021-04-20 17:58:39 --> URI Class Initialized
INFO - 2021-04-20 17:58:39 --> Router Class Initialized
INFO - 2021-04-20 17:58:39 --> Output Class Initialized
INFO - 2021-04-20 17:58:39 --> Security Class Initialized
DEBUG - 2021-04-20 17:58:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:58:39 --> Input Class Initialized
INFO - 2021-04-20 17:58:39 --> Language Class Initialized
INFO - 2021-04-20 17:58:39 --> Loader Class Initialized
INFO - 2021-04-20 17:58:39 --> Helper loaded: url_helper
INFO - 2021-04-20 17:58:39 --> Helper loaded: form_helper
INFO - 2021-04-20 17:58:39 --> Helper loaded: common_helper
INFO - 2021-04-20 17:58:39 --> Helper loaded: util_helper
INFO - 2021-04-20 17:58:39 --> Helper loaded: user_helper
INFO - 2021-04-20 17:58:39 --> Database Driver Class Initialized
DEBUG - 2021-04-20 17:58:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 17:58:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 17:58:39 --> Form Validation Class Initialized
INFO - 2021-04-20 17:58:39 --> Controller Class Initialized
INFO - 2021-04-20 17:58:39 --> Model Class Initialized
INFO - 2021-04-20 17:58:39 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\viewaccount.php
INFO - 2021-04-20 17:58:39 --> Final output sent to browser
DEBUG - 2021-04-20 17:58:39 --> Total execution time: 0.0289
INFO - 2021-04-20 17:59:04 --> Config Class Initialized
INFO - 2021-04-20 17:59:04 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:59:04 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:59:04 --> Utf8 Class Initialized
INFO - 2021-04-20 17:59:04 --> URI Class Initialized
INFO - 2021-04-20 17:59:04 --> Router Class Initialized
INFO - 2021-04-20 17:59:04 --> Output Class Initialized
INFO - 2021-04-20 17:59:04 --> Security Class Initialized
DEBUG - 2021-04-20 17:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:59:04 --> Input Class Initialized
INFO - 2021-04-20 17:59:04 --> Language Class Initialized
INFO - 2021-04-20 17:59:04 --> Loader Class Initialized
INFO - 2021-04-20 17:59:04 --> Helper loaded: url_helper
INFO - 2021-04-20 17:59:04 --> Helper loaded: form_helper
INFO - 2021-04-20 17:59:04 --> Helper loaded: common_helper
INFO - 2021-04-20 17:59:04 --> Helper loaded: util_helper
INFO - 2021-04-20 17:59:04 --> Helper loaded: user_helper
INFO - 2021-04-20 17:59:04 --> Database Driver Class Initialized
DEBUG - 2021-04-20 17:59:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 17:59:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 17:59:04 --> Form Validation Class Initialized
INFO - 2021-04-20 17:59:04 --> Controller Class Initialized
INFO - 2021-04-20 17:59:04 --> Model Class Initialized
INFO - 2021-04-20 17:59:04 --> Model Class Initialized
INFO - 2021-04-20 17:59:04 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\register.php
INFO - 2021-04-20 17:59:04 --> Final output sent to browser
DEBUG - 2021-04-20 17:59:04 --> Total execution time: 0.0273
INFO - 2021-04-20 17:59:04 --> Config Class Initialized
INFO - 2021-04-20 17:59:04 --> Hooks Class Initialized
INFO - 2021-04-20 17:59:04 --> Config Class Initialized
INFO - 2021-04-20 17:59:04 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:59:04 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:59:04 --> Utf8 Class Initialized
INFO - 2021-04-20 17:59:04 --> URI Class Initialized
INFO - 2021-04-20 17:59:04 --> Router Class Initialized
DEBUG - 2021-04-20 17:59:04 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:59:04 --> Utf8 Class Initialized
INFO - 2021-04-20 17:59:04 --> URI Class Initialized
INFO - 2021-04-20 17:59:04 --> Output Class Initialized
INFO - 2021-04-20 17:59:04 --> Router Class Initialized
INFO - 2021-04-20 17:59:04 --> Security Class Initialized
DEBUG - 2021-04-20 17:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:59:04 --> Output Class Initialized
INFO - 2021-04-20 17:59:04 --> Input Class Initialized
INFO - 2021-04-20 17:59:04 --> Language Class Initialized
INFO - 2021-04-20 17:59:04 --> Security Class Initialized
ERROR - 2021-04-20 17:59:04 --> 404 Page Not Found: Fasset/img
DEBUG - 2021-04-20 17:59:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:59:04 --> Input Class Initialized
INFO - 2021-04-20 17:59:04 --> Language Class Initialized
ERROR - 2021-04-20 17:59:04 --> 404 Page Not Found: Fasset/img
INFO - 2021-04-20 17:59:08 --> Config Class Initialized
INFO - 2021-04-20 17:59:08 --> Hooks Class Initialized
DEBUG - 2021-04-20 17:59:08 --> UTF-8 Support Enabled
INFO - 2021-04-20 17:59:08 --> Utf8 Class Initialized
INFO - 2021-04-20 17:59:08 --> URI Class Initialized
INFO - 2021-04-20 17:59:08 --> Router Class Initialized
INFO - 2021-04-20 17:59:08 --> Output Class Initialized
INFO - 2021-04-20 17:59:08 --> Security Class Initialized
DEBUG - 2021-04-20 17:59:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 17:59:08 --> Input Class Initialized
INFO - 2021-04-20 17:59:08 --> Language Class Initialized
INFO - 2021-04-20 17:59:08 --> Loader Class Initialized
INFO - 2021-04-20 17:59:08 --> Helper loaded: url_helper
INFO - 2021-04-20 17:59:08 --> Helper loaded: form_helper
INFO - 2021-04-20 17:59:08 --> Helper loaded: common_helper
INFO - 2021-04-20 17:59:08 --> Helper loaded: util_helper
INFO - 2021-04-20 17:59:08 --> Helper loaded: user_helper
INFO - 2021-04-20 17:59:08 --> Database Driver Class Initialized
DEBUG - 2021-04-20 17:59:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 17:59:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 17:59:08 --> Form Validation Class Initialized
INFO - 2021-04-20 17:59:08 --> Controller Class Initialized
INFO - 2021-04-20 17:59:08 --> Model Class Initialized
INFO - 2021-04-20 17:59:08 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\viewaccount.php
INFO - 2021-04-20 17:59:08 --> Final output sent to browser
DEBUG - 2021-04-20 17:59:08 --> Total execution time: 0.0277
INFO - 2021-04-20 18:10:33 --> Config Class Initialized
INFO - 2021-04-20 18:10:33 --> Hooks Class Initialized
DEBUG - 2021-04-20 18:10:33 --> UTF-8 Support Enabled
INFO - 2021-04-20 18:10:33 --> Utf8 Class Initialized
INFO - 2021-04-20 18:10:33 --> URI Class Initialized
INFO - 2021-04-20 18:10:33 --> Router Class Initialized
INFO - 2021-04-20 18:10:33 --> Output Class Initialized
INFO - 2021-04-20 18:10:33 --> Security Class Initialized
DEBUG - 2021-04-20 18:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 18:10:33 --> Input Class Initialized
INFO - 2021-04-20 18:10:33 --> Language Class Initialized
INFO - 2021-04-20 18:10:33 --> Loader Class Initialized
INFO - 2021-04-20 18:10:33 --> Helper loaded: url_helper
INFO - 2021-04-20 18:10:33 --> Helper loaded: form_helper
INFO - 2021-04-20 18:10:33 --> Helper loaded: common_helper
INFO - 2021-04-20 18:10:33 --> Helper loaded: util_helper
INFO - 2021-04-20 18:10:33 --> Helper loaded: user_helper
INFO - 2021-04-20 18:10:33 --> Database Driver Class Initialized
DEBUG - 2021-04-20 18:10:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 18:10:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 18:10:33 --> Form Validation Class Initialized
INFO - 2021-04-20 18:10:33 --> Controller Class Initialized
INFO - 2021-04-20 18:10:33 --> Model Class Initialized
INFO - 2021-04-20 18:10:33 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\viewaccount.php
INFO - 2021-04-20 18:10:33 --> Final output sent to browser
DEBUG - 2021-04-20 18:10:33 --> Total execution time: 0.0288
INFO - 2021-04-20 18:10:33 --> Config Class Initialized
INFO - 2021-04-20 18:10:33 --> Hooks Class Initialized
INFO - 2021-04-20 18:10:33 --> Config Class Initialized
INFO - 2021-04-20 18:10:33 --> Hooks Class Initialized
DEBUG - 2021-04-20 18:10:33 --> UTF-8 Support Enabled
INFO - 2021-04-20 18:10:33 --> Utf8 Class Initialized
INFO - 2021-04-20 18:10:33 --> URI Class Initialized
DEBUG - 2021-04-20 18:10:33 --> UTF-8 Support Enabled
INFO - 2021-04-20 18:10:33 --> Utf8 Class Initialized
INFO - 2021-04-20 18:10:33 --> Router Class Initialized
INFO - 2021-04-20 18:10:33 --> URI Class Initialized
INFO - 2021-04-20 18:10:33 --> Router Class Initialized
INFO - 2021-04-20 18:10:33 --> Output Class Initialized
INFO - 2021-04-20 18:10:33 --> Security Class Initialized
INFO - 2021-04-20 18:10:33 --> Output Class Initialized
DEBUG - 2021-04-20 18:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 18:10:33 --> Security Class Initialized
INFO - 2021-04-20 18:10:33 --> Input Class Initialized
INFO - 2021-04-20 18:10:33 --> Language Class Initialized
DEBUG - 2021-04-20 18:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 18:10:33 --> Input Class Initialized
INFO - 2021-04-20 18:10:33 --> Language Class Initialized
ERROR - 2021-04-20 18:10:33 --> 404 Page Not Found: Assets/plugins
ERROR - 2021-04-20 18:10:33 --> 404 Page Not Found: Assets/plugins
INFO - 2021-04-20 18:10:33 --> Config Class Initialized
INFO - 2021-04-20 18:10:33 --> Hooks Class Initialized
DEBUG - 2021-04-20 18:10:33 --> UTF-8 Support Enabled
INFO - 2021-04-20 18:10:33 --> Utf8 Class Initialized
INFO - 2021-04-20 18:10:33 --> URI Class Initialized
INFO - 2021-04-20 18:10:33 --> Router Class Initialized
INFO - 2021-04-20 18:10:33 --> Output Class Initialized
INFO - 2021-04-20 18:10:33 --> Security Class Initialized
DEBUG - 2021-04-20 18:10:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 18:10:33 --> Input Class Initialized
INFO - 2021-04-20 18:10:33 --> Language Class Initialized
ERROR - 2021-04-20 18:10:33 --> 404 Page Not Found: Assets/plugins
INFO - 2021-04-20 18:10:39 --> Config Class Initialized
INFO - 2021-04-20 18:10:39 --> Hooks Class Initialized
DEBUG - 2021-04-20 18:10:39 --> UTF-8 Support Enabled
INFO - 2021-04-20 18:10:39 --> Utf8 Class Initialized
INFO - 2021-04-20 18:10:39 --> URI Class Initialized
INFO - 2021-04-20 18:10:39 --> Router Class Initialized
INFO - 2021-04-20 18:10:39 --> Output Class Initialized
INFO - 2021-04-20 18:10:39 --> Security Class Initialized
DEBUG - 2021-04-20 18:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 18:10:39 --> Input Class Initialized
INFO - 2021-04-20 18:10:39 --> Language Class Initialized
INFO - 2021-04-20 18:10:39 --> Loader Class Initialized
INFO - 2021-04-20 18:10:39 --> Helper loaded: url_helper
INFO - 2021-04-20 18:10:39 --> Helper loaded: form_helper
INFO - 2021-04-20 18:10:39 --> Helper loaded: common_helper
INFO - 2021-04-20 18:10:39 --> Helper loaded: util_helper
INFO - 2021-04-20 18:10:39 --> Helper loaded: user_helper
INFO - 2021-04-20 18:10:39 --> Database Driver Class Initialized
DEBUG - 2021-04-20 18:10:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 18:10:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 18:10:39 --> Form Validation Class Initialized
INFO - 2021-04-20 18:10:39 --> Controller Class Initialized
INFO - 2021-04-20 18:10:39 --> Model Class Initialized
INFO - 2021-04-20 18:10:39 --> Model Class Initialized
INFO - 2021-04-20 18:10:39 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\register.php
INFO - 2021-04-20 18:10:39 --> Final output sent to browser
DEBUG - 2021-04-20 18:10:39 --> Total execution time: 0.0392
INFO - 2021-04-20 18:10:39 --> Config Class Initialized
INFO - 2021-04-20 18:10:39 --> Hooks Class Initialized
DEBUG - 2021-04-20 18:10:39 --> UTF-8 Support Enabled
INFO - 2021-04-20 18:10:39 --> Utf8 Class Initialized
INFO - 2021-04-20 18:10:39 --> URI Class Initialized
INFO - 2021-04-20 18:10:39 --> Config Class Initialized
INFO - 2021-04-20 18:10:39 --> Hooks Class Initialized
INFO - 2021-04-20 18:10:39 --> Router Class Initialized
DEBUG - 2021-04-20 18:10:39 --> UTF-8 Support Enabled
INFO - 2021-04-20 18:10:39 --> Output Class Initialized
INFO - 2021-04-20 18:10:39 --> Utf8 Class Initialized
INFO - 2021-04-20 18:10:39 --> URI Class Initialized
INFO - 2021-04-20 18:10:39 --> Security Class Initialized
DEBUG - 2021-04-20 18:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 18:10:39 --> Input Class Initialized
INFO - 2021-04-20 18:10:39 --> Language Class Initialized
INFO - 2021-04-20 18:10:39 --> Router Class Initialized
ERROR - 2021-04-20 18:10:39 --> 404 Page Not Found: Fasset/img
INFO - 2021-04-20 18:10:39 --> Output Class Initialized
INFO - 2021-04-20 18:10:39 --> Security Class Initialized
DEBUG - 2021-04-20 18:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 18:10:39 --> Input Class Initialized
INFO - 2021-04-20 18:10:39 --> Language Class Initialized
ERROR - 2021-04-20 18:10:39 --> 404 Page Not Found: Fasset/img
INFO - 2021-04-20 18:10:40 --> Config Class Initialized
INFO - 2021-04-20 18:10:40 --> Hooks Class Initialized
DEBUG - 2021-04-20 18:10:40 --> UTF-8 Support Enabled
INFO - 2021-04-20 18:10:40 --> Utf8 Class Initialized
INFO - 2021-04-20 18:10:40 --> URI Class Initialized
INFO - 2021-04-20 18:10:40 --> Router Class Initialized
INFO - 2021-04-20 18:10:40 --> Output Class Initialized
INFO - 2021-04-20 18:10:40 --> Security Class Initialized
DEBUG - 2021-04-20 18:10:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 18:10:40 --> Input Class Initialized
INFO - 2021-04-20 18:10:40 --> Language Class Initialized
INFO - 2021-04-20 18:10:40 --> Loader Class Initialized
INFO - 2021-04-20 18:10:40 --> Helper loaded: url_helper
INFO - 2021-04-20 18:10:40 --> Helper loaded: form_helper
INFO - 2021-04-20 18:10:40 --> Helper loaded: common_helper
INFO - 2021-04-20 18:10:40 --> Helper loaded: util_helper
INFO - 2021-04-20 18:10:40 --> Helper loaded: user_helper
INFO - 2021-04-20 18:10:40 --> Database Driver Class Initialized
DEBUG - 2021-04-20 18:10:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 18:10:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 18:10:40 --> Form Validation Class Initialized
INFO - 2021-04-20 18:10:40 --> Controller Class Initialized
INFO - 2021-04-20 18:10:40 --> Model Class Initialized
INFO - 2021-04-20 18:10:40 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\viewaccount.php
INFO - 2021-04-20 18:10:40 --> Final output sent to browser
DEBUG - 2021-04-20 18:10:40 --> Total execution time: 0.0295
INFO - 2021-04-20 19:25:17 --> Config Class Initialized
INFO - 2021-04-20 19:25:17 --> Hooks Class Initialized
DEBUG - 2021-04-20 19:25:17 --> UTF-8 Support Enabled
INFO - 2021-04-20 19:25:17 --> Utf8 Class Initialized
INFO - 2021-04-20 19:25:17 --> URI Class Initialized
DEBUG - 2021-04-20 19:25:17 --> No URI present. Default controller set.
INFO - 2021-04-20 19:25:17 --> Router Class Initialized
INFO - 2021-04-20 19:25:17 --> Output Class Initialized
INFO - 2021-04-20 19:25:17 --> Security Class Initialized
DEBUG - 2021-04-20 19:25:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 19:25:17 --> Input Class Initialized
INFO - 2021-04-20 19:25:17 --> Language Class Initialized
INFO - 2021-04-20 19:25:17 --> Loader Class Initialized
INFO - 2021-04-20 19:25:17 --> Helper loaded: url_helper
INFO - 2021-04-20 19:25:17 --> Helper loaded: form_helper
INFO - 2021-04-20 19:25:17 --> Helper loaded: common_helper
INFO - 2021-04-20 19:25:17 --> Helper loaded: util_helper
INFO - 2021-04-20 19:25:17 --> Helper loaded: user_helper
INFO - 2021-04-20 19:25:17 --> Database Driver Class Initialized
DEBUG - 2021-04-20 19:25:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 19:25:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 19:25:17 --> Form Validation Class Initialized
INFO - 2021-04-20 19:25:17 --> Controller Class Initialized
INFO - 2021-04-20 19:25:17 --> Model Class Initialized
INFO - 2021-04-20 19:25:17 --> Model Class Initialized
INFO - 2021-04-20 19:25:17 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-20 19:25:17 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-20 19:25:17 --> Final output sent to browser
DEBUG - 2021-04-20 19:25:17 --> Total execution time: 0.0490
INFO - 2021-04-20 19:25:19 --> Config Class Initialized
INFO - 2021-04-20 19:25:19 --> Hooks Class Initialized
DEBUG - 2021-04-20 19:25:19 --> UTF-8 Support Enabled
INFO - 2021-04-20 19:25:19 --> Utf8 Class Initialized
INFO - 2021-04-20 19:25:19 --> URI Class Initialized
DEBUG - 2021-04-20 19:25:19 --> No URI present. Default controller set.
INFO - 2021-04-20 19:25:19 --> Router Class Initialized
INFO - 2021-04-20 19:25:19 --> Output Class Initialized
INFO - 2021-04-20 19:25:19 --> Security Class Initialized
DEBUG - 2021-04-20 19:25:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 19:25:19 --> Input Class Initialized
INFO - 2021-04-20 19:25:19 --> Language Class Initialized
INFO - 2021-04-20 19:25:19 --> Loader Class Initialized
INFO - 2021-04-20 19:25:19 --> Helper loaded: url_helper
INFO - 2021-04-20 19:25:19 --> Helper loaded: form_helper
INFO - 2021-04-20 19:25:19 --> Helper loaded: common_helper
INFO - 2021-04-20 19:25:19 --> Helper loaded: util_helper
INFO - 2021-04-20 19:25:19 --> Helper loaded: user_helper
INFO - 2021-04-20 19:25:19 --> Database Driver Class Initialized
DEBUG - 2021-04-20 19:25:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 19:25:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 19:25:19 --> Form Validation Class Initialized
INFO - 2021-04-20 19:25:19 --> Controller Class Initialized
INFO - 2021-04-20 19:25:19 --> Model Class Initialized
INFO - 2021-04-20 19:25:19 --> Model Class Initialized
INFO - 2021-04-20 19:25:19 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-20 19:25:19 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-20 19:25:19 --> Final output sent to browser
DEBUG - 2021-04-20 19:25:19 --> Total execution time: 0.0275
INFO - 2021-04-20 19:25:23 --> Config Class Initialized
INFO - 2021-04-20 19:25:23 --> Hooks Class Initialized
DEBUG - 2021-04-20 19:25:23 --> UTF-8 Support Enabled
INFO - 2021-04-20 19:25:23 --> Utf8 Class Initialized
INFO - 2021-04-20 19:25:23 --> URI Class Initialized
DEBUG - 2021-04-20 19:25:23 --> No URI present. Default controller set.
INFO - 2021-04-20 19:25:23 --> Router Class Initialized
INFO - 2021-04-20 19:25:23 --> Output Class Initialized
INFO - 2021-04-20 19:25:23 --> Security Class Initialized
DEBUG - 2021-04-20 19:25:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 19:25:23 --> Input Class Initialized
INFO - 2021-04-20 19:25:23 --> Language Class Initialized
INFO - 2021-04-20 19:25:23 --> Loader Class Initialized
INFO - 2021-04-20 19:25:23 --> Helper loaded: url_helper
INFO - 2021-04-20 19:25:23 --> Helper loaded: form_helper
INFO - 2021-04-20 19:25:23 --> Helper loaded: common_helper
INFO - 2021-04-20 19:25:23 --> Helper loaded: util_helper
INFO - 2021-04-20 19:25:23 --> Helper loaded: user_helper
INFO - 2021-04-20 19:25:23 --> Database Driver Class Initialized
DEBUG - 2021-04-20 19:25:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 19:25:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 19:25:23 --> Form Validation Class Initialized
INFO - 2021-04-20 19:25:23 --> Controller Class Initialized
INFO - 2021-04-20 19:25:23 --> Model Class Initialized
INFO - 2021-04-20 19:25:23 --> Model Class Initialized
INFO - 2021-04-20 19:25:23 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-20 19:25:23 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-20 19:25:23 --> Final output sent to browser
DEBUG - 2021-04-20 19:25:23 --> Total execution time: 0.0267
INFO - 2021-04-20 19:26:18 --> Config Class Initialized
INFO - 2021-04-20 19:26:18 --> Hooks Class Initialized
DEBUG - 2021-04-20 19:26:18 --> UTF-8 Support Enabled
INFO - 2021-04-20 19:26:18 --> Utf8 Class Initialized
INFO - 2021-04-20 19:26:18 --> URI Class Initialized
DEBUG - 2021-04-20 19:26:18 --> No URI present. Default controller set.
INFO - 2021-04-20 19:26:18 --> Router Class Initialized
INFO - 2021-04-20 19:26:18 --> Output Class Initialized
INFO - 2021-04-20 19:26:18 --> Security Class Initialized
DEBUG - 2021-04-20 19:26:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 19:26:18 --> Input Class Initialized
INFO - 2021-04-20 19:26:18 --> Language Class Initialized
INFO - 2021-04-20 19:26:18 --> Loader Class Initialized
INFO - 2021-04-20 19:26:18 --> Helper loaded: url_helper
INFO - 2021-04-20 19:26:18 --> Helper loaded: form_helper
INFO - 2021-04-20 19:26:18 --> Helper loaded: common_helper
INFO - 2021-04-20 19:26:18 --> Helper loaded: util_helper
INFO - 2021-04-20 19:26:18 --> Helper loaded: user_helper
INFO - 2021-04-20 19:26:18 --> Database Driver Class Initialized
DEBUG - 2021-04-20 19:26:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 19:26:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 19:26:18 --> Form Validation Class Initialized
INFO - 2021-04-20 19:26:18 --> Controller Class Initialized
INFO - 2021-04-20 19:26:18 --> Model Class Initialized
INFO - 2021-04-20 19:26:18 --> Model Class Initialized
INFO - 2021-04-20 19:26:18 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-20 19:26:18 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-20 19:26:18 --> Final output sent to browser
DEBUG - 2021-04-20 19:26:18 --> Total execution time: 0.0380
INFO - 2021-04-20 19:26:44 --> Config Class Initialized
INFO - 2021-04-20 19:26:44 --> Hooks Class Initialized
DEBUG - 2021-04-20 19:26:44 --> UTF-8 Support Enabled
INFO - 2021-04-20 19:26:44 --> Utf8 Class Initialized
INFO - 2021-04-20 19:26:44 --> URI Class Initialized
DEBUG - 2021-04-20 19:26:44 --> No URI present. Default controller set.
INFO - 2021-04-20 19:26:44 --> Router Class Initialized
INFO - 2021-04-20 19:26:44 --> Output Class Initialized
INFO - 2021-04-20 19:26:44 --> Security Class Initialized
DEBUG - 2021-04-20 19:26:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 19:26:44 --> Input Class Initialized
INFO - 2021-04-20 19:26:44 --> Language Class Initialized
INFO - 2021-04-20 19:26:44 --> Loader Class Initialized
INFO - 2021-04-20 19:26:44 --> Helper loaded: url_helper
INFO - 2021-04-20 19:26:44 --> Helper loaded: form_helper
INFO - 2021-04-20 19:26:44 --> Helper loaded: common_helper
INFO - 2021-04-20 19:26:44 --> Helper loaded: util_helper
INFO - 2021-04-20 19:26:44 --> Helper loaded: user_helper
INFO - 2021-04-20 19:26:44 --> Database Driver Class Initialized
DEBUG - 2021-04-20 19:26:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 19:26:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 19:26:44 --> Form Validation Class Initialized
INFO - 2021-04-20 19:26:44 --> Controller Class Initialized
INFO - 2021-04-20 19:26:44 --> Model Class Initialized
INFO - 2021-04-20 19:26:44 --> Model Class Initialized
INFO - 2021-04-20 19:26:44 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-20 19:26:44 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-20 19:26:44 --> Final output sent to browser
DEBUG - 2021-04-20 19:26:44 --> Total execution time: 0.0327
INFO - 2021-04-20 21:17:40 --> Config Class Initialized
INFO - 2021-04-20 21:17:40 --> Hooks Class Initialized
DEBUG - 2021-04-20 21:17:40 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:17:40 --> Utf8 Class Initialized
INFO - 2021-04-20 21:17:40 --> URI Class Initialized
DEBUG - 2021-04-20 21:17:40 --> No URI present. Default controller set.
INFO - 2021-04-20 21:17:40 --> Router Class Initialized
INFO - 2021-04-20 21:17:40 --> Output Class Initialized
INFO - 2021-04-20 21:17:40 --> Security Class Initialized
DEBUG - 2021-04-20 21:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:17:40 --> Input Class Initialized
INFO - 2021-04-20 21:17:40 --> Language Class Initialized
INFO - 2021-04-20 21:17:40 --> Loader Class Initialized
INFO - 2021-04-20 21:17:40 --> Helper loaded: url_helper
INFO - 2021-04-20 21:17:40 --> Helper loaded: form_helper
INFO - 2021-04-20 21:17:40 --> Helper loaded: common_helper
INFO - 2021-04-20 21:17:40 --> Helper loaded: util_helper
INFO - 2021-04-20 21:17:40 --> Helper loaded: user_helper
INFO - 2021-04-20 21:17:40 --> Database Driver Class Initialized
DEBUG - 2021-04-20 21:17:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 21:17:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 21:17:40 --> Form Validation Class Initialized
INFO - 2021-04-20 21:17:40 --> Controller Class Initialized
INFO - 2021-04-20 21:17:40 --> Model Class Initialized
INFO - 2021-04-20 21:17:40 --> Model Class Initialized
INFO - 2021-04-20 21:17:40 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-20 21:17:40 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-20 21:17:40 --> Final output sent to browser
DEBUG - 2021-04-20 21:17:40 --> Total execution time: 0.0406
INFO - 2021-04-20 21:17:40 --> Config Class Initialized
INFO - 2021-04-20 21:17:40 --> Hooks Class Initialized
DEBUG - 2021-04-20 21:17:40 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:17:40 --> Utf8 Class Initialized
INFO - 2021-04-20 21:17:40 --> URI Class Initialized
INFO - 2021-04-20 21:17:40 --> Router Class Initialized
INFO - 2021-04-20 21:17:40 --> Output Class Initialized
INFO - 2021-04-20 21:17:40 --> Security Class Initialized
DEBUG - 2021-04-20 21:17:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:17:40 --> Input Class Initialized
INFO - 2021-04-20 21:17:40 --> Language Class Initialized
ERROR - 2021-04-20 21:17:40 --> 404 Page Not Found: Fassets/img
INFO - 2021-04-20 21:35:41 --> Config Class Initialized
INFO - 2021-04-20 21:35:41 --> Hooks Class Initialized
DEBUG - 2021-04-20 21:35:41 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:35:41 --> Utf8 Class Initialized
INFO - 2021-04-20 21:35:41 --> URI Class Initialized
DEBUG - 2021-04-20 21:35:41 --> No URI present. Default controller set.
INFO - 2021-04-20 21:35:41 --> Router Class Initialized
INFO - 2021-04-20 21:35:41 --> Output Class Initialized
INFO - 2021-04-20 21:35:41 --> Security Class Initialized
DEBUG - 2021-04-20 21:35:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:35:41 --> Input Class Initialized
INFO - 2021-04-20 21:35:41 --> Language Class Initialized
INFO - 2021-04-20 21:35:41 --> Loader Class Initialized
INFO - 2021-04-20 21:35:41 --> Helper loaded: url_helper
INFO - 2021-04-20 21:35:41 --> Helper loaded: form_helper
INFO - 2021-04-20 21:35:41 --> Helper loaded: common_helper
INFO - 2021-04-20 21:35:41 --> Helper loaded: util_helper
INFO - 2021-04-20 21:35:41 --> Helper loaded: user_helper
INFO - 2021-04-20 21:35:41 --> Database Driver Class Initialized
DEBUG - 2021-04-20 21:35:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 21:35:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 21:35:41 --> Form Validation Class Initialized
INFO - 2021-04-20 21:35:41 --> Controller Class Initialized
INFO - 2021-04-20 21:35:41 --> Model Class Initialized
INFO - 2021-04-20 21:35:41 --> Model Class Initialized
INFO - 2021-04-20 21:35:41 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-20 21:35:41 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-20 21:35:41 --> Final output sent to browser
DEBUG - 2021-04-20 21:35:41 --> Total execution time: 0.0402
INFO - 2021-04-20 21:35:53 --> Config Class Initialized
INFO - 2021-04-20 21:35:53 --> Hooks Class Initialized
DEBUG - 2021-04-20 21:35:53 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:35:53 --> Utf8 Class Initialized
INFO - 2021-04-20 21:35:53 --> URI Class Initialized
INFO - 2021-04-20 21:35:53 --> Router Class Initialized
INFO - 2021-04-20 21:35:53 --> Output Class Initialized
INFO - 2021-04-20 21:35:53 --> Security Class Initialized
DEBUG - 2021-04-20 21:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:35:53 --> Input Class Initialized
INFO - 2021-04-20 21:35:53 --> Language Class Initialized
INFO - 2021-04-20 21:35:53 --> Loader Class Initialized
INFO - 2021-04-20 21:35:53 --> Helper loaded: url_helper
INFO - 2021-04-20 21:35:53 --> Helper loaded: form_helper
INFO - 2021-04-20 21:35:53 --> Helper loaded: common_helper
INFO - 2021-04-20 21:35:53 --> Helper loaded: util_helper
INFO - 2021-04-20 21:35:53 --> Helper loaded: user_helper
INFO - 2021-04-20 21:35:53 --> Database Driver Class Initialized
DEBUG - 2021-04-20 21:35:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 21:35:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 21:35:53 --> Form Validation Class Initialized
INFO - 2021-04-20 21:35:53 --> Controller Class Initialized
INFO - 2021-04-20 21:35:53 --> Model Class Initialized
INFO - 2021-04-20 21:35:53 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\viewaccount.php
INFO - 2021-04-20 21:35:53 --> Final output sent to browser
DEBUG - 2021-04-20 21:35:53 --> Total execution time: 0.0293
INFO - 2021-04-20 21:35:53 --> Config Class Initialized
INFO - 2021-04-20 21:35:53 --> Hooks Class Initialized
INFO - 2021-04-20 21:35:53 --> Config Class Initialized
INFO - 2021-04-20 21:35:53 --> Hooks Class Initialized
DEBUG - 2021-04-20 21:35:53 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:35:53 --> Utf8 Class Initialized
INFO - 2021-04-20 21:35:53 --> URI Class Initialized
DEBUG - 2021-04-20 21:35:53 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:35:53 --> Utf8 Class Initialized
INFO - 2021-04-20 21:35:53 --> Router Class Initialized
INFO - 2021-04-20 21:35:53 --> URI Class Initialized
INFO - 2021-04-20 21:35:53 --> Output Class Initialized
INFO - 2021-04-20 21:35:53 --> Router Class Initialized
INFO - 2021-04-20 21:35:53 --> Security Class Initialized
DEBUG - 2021-04-20 21:35:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:35:53 --> Output Class Initialized
INFO - 2021-04-20 21:35:53 --> Input Class Initialized
INFO - 2021-04-20 21:35:53 --> Language Class Initialized
INFO - 2021-04-20 21:35:53 --> Security Class Initialized
ERROR - 2021-04-20 21:35:54 --> 404 Page Not Found: Assets/plugins
DEBUG - 2021-04-20 21:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:35:54 --> Input Class Initialized
INFO - 2021-04-20 21:35:54 --> Language Class Initialized
ERROR - 2021-04-20 21:35:54 --> 404 Page Not Found: Assets/plugins
INFO - 2021-04-20 21:35:54 --> Config Class Initialized
INFO - 2021-04-20 21:35:54 --> Hooks Class Initialized
DEBUG - 2021-04-20 21:35:54 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:35:54 --> Utf8 Class Initialized
INFO - 2021-04-20 21:35:54 --> URI Class Initialized
INFO - 2021-04-20 21:35:54 --> Router Class Initialized
INFO - 2021-04-20 21:35:54 --> Output Class Initialized
INFO - 2021-04-20 21:35:54 --> Security Class Initialized
DEBUG - 2021-04-20 21:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:35:54 --> Input Class Initialized
INFO - 2021-04-20 21:35:54 --> Language Class Initialized
ERROR - 2021-04-20 21:35:54 --> 404 Page Not Found: Assets/plugins
INFO - 2021-04-20 21:35:59 --> Config Class Initialized
INFO - 2021-04-20 21:35:59 --> Hooks Class Initialized
DEBUG - 2021-04-20 21:35:59 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:35:59 --> Utf8 Class Initialized
INFO - 2021-04-20 21:35:59 --> URI Class Initialized
INFO - 2021-04-20 21:35:59 --> Router Class Initialized
INFO - 2021-04-20 21:35:59 --> Output Class Initialized
INFO - 2021-04-20 21:35:59 --> Security Class Initialized
DEBUG - 2021-04-20 21:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:35:59 --> Input Class Initialized
INFO - 2021-04-20 21:35:59 --> Language Class Initialized
INFO - 2021-04-20 21:35:59 --> Loader Class Initialized
INFO - 2021-04-20 21:35:59 --> Helper loaded: url_helper
INFO - 2021-04-20 21:35:59 --> Helper loaded: form_helper
INFO - 2021-04-20 21:35:59 --> Helper loaded: common_helper
INFO - 2021-04-20 21:35:59 --> Helper loaded: util_helper
INFO - 2021-04-20 21:35:59 --> Helper loaded: user_helper
INFO - 2021-04-20 21:35:59 --> Database Driver Class Initialized
DEBUG - 2021-04-20 21:35:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 21:35:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 21:35:59 --> Form Validation Class Initialized
INFO - 2021-04-20 21:35:59 --> Controller Class Initialized
INFO - 2021-04-20 21:35:59 --> Model Class Initialized
INFO - 2021-04-20 21:35:59 --> Model Class Initialized
INFO - 2021-04-20 21:35:59 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\register.php
INFO - 2021-04-20 21:35:59 --> Final output sent to browser
DEBUG - 2021-04-20 21:35:59 --> Total execution time: 0.0372
INFO - 2021-04-20 21:35:59 --> Config Class Initialized
INFO - 2021-04-20 21:35:59 --> Config Class Initialized
INFO - 2021-04-20 21:35:59 --> Hooks Class Initialized
INFO - 2021-04-20 21:35:59 --> Hooks Class Initialized
DEBUG - 2021-04-20 21:35:59 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:35:59 --> Utf8 Class Initialized
DEBUG - 2021-04-20 21:35:59 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:35:59 --> Utf8 Class Initialized
INFO - 2021-04-20 21:35:59 --> URI Class Initialized
INFO - 2021-04-20 21:35:59 --> URI Class Initialized
INFO - 2021-04-20 21:35:59 --> Router Class Initialized
INFO - 2021-04-20 21:35:59 --> Router Class Initialized
INFO - 2021-04-20 21:35:59 --> Output Class Initialized
INFO - 2021-04-20 21:35:59 --> Output Class Initialized
INFO - 2021-04-20 21:35:59 --> Security Class Initialized
INFO - 2021-04-20 21:35:59 --> Security Class Initialized
DEBUG - 2021-04-20 21:35:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-20 21:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:35:59 --> Input Class Initialized
INFO - 2021-04-20 21:35:59 --> Input Class Initialized
INFO - 2021-04-20 21:35:59 --> Language Class Initialized
INFO - 2021-04-20 21:35:59 --> Language Class Initialized
ERROR - 2021-04-20 21:35:59 --> 404 Page Not Found: Fasset/img
ERROR - 2021-04-20 21:35:59 --> 404 Page Not Found: Fasset/img
INFO - 2021-04-20 21:36:01 --> Config Class Initialized
INFO - 2021-04-20 21:36:01 --> Hooks Class Initialized
DEBUG - 2021-04-20 21:36:01 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:36:01 --> Utf8 Class Initialized
INFO - 2021-04-20 21:36:01 --> URI Class Initialized
INFO - 2021-04-20 21:36:01 --> Router Class Initialized
INFO - 2021-04-20 21:36:01 --> Output Class Initialized
INFO - 2021-04-20 21:36:01 --> Security Class Initialized
DEBUG - 2021-04-20 21:36:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:36:01 --> Input Class Initialized
INFO - 2021-04-20 21:36:01 --> Language Class Initialized
INFO - 2021-04-20 21:36:01 --> Loader Class Initialized
INFO - 2021-04-20 21:36:01 --> Helper loaded: url_helper
INFO - 2021-04-20 21:36:01 --> Helper loaded: form_helper
INFO - 2021-04-20 21:36:01 --> Helper loaded: common_helper
INFO - 2021-04-20 21:36:01 --> Helper loaded: util_helper
INFO - 2021-04-20 21:36:01 --> Helper loaded: user_helper
INFO - 2021-04-20 21:36:01 --> Database Driver Class Initialized
DEBUG - 2021-04-20 21:36:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 21:36:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 21:36:01 --> Form Validation Class Initialized
INFO - 2021-04-20 21:36:01 --> Controller Class Initialized
INFO - 2021-04-20 21:36:01 --> Model Class Initialized
INFO - 2021-04-20 21:36:01 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\viewaccount.php
INFO - 2021-04-20 21:36:01 --> Final output sent to browser
DEBUG - 2021-04-20 21:36:01 --> Total execution time: 0.0394
INFO - 2021-04-20 21:38:57 --> Config Class Initialized
INFO - 2021-04-20 21:38:57 --> Hooks Class Initialized
DEBUG - 2021-04-20 21:38:57 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:38:57 --> Utf8 Class Initialized
INFO - 2021-04-20 21:38:57 --> URI Class Initialized
INFO - 2021-04-20 21:38:57 --> Router Class Initialized
INFO - 2021-04-20 21:38:57 --> Output Class Initialized
INFO - 2021-04-20 21:38:57 --> Security Class Initialized
DEBUG - 2021-04-20 21:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:38:57 --> Input Class Initialized
INFO - 2021-04-20 21:38:57 --> Language Class Initialized
INFO - 2021-04-20 21:38:57 --> Loader Class Initialized
INFO - 2021-04-20 21:38:57 --> Helper loaded: url_helper
INFO - 2021-04-20 21:38:57 --> Helper loaded: form_helper
INFO - 2021-04-20 21:38:57 --> Helper loaded: common_helper
INFO - 2021-04-20 21:38:57 --> Helper loaded: util_helper
INFO - 2021-04-20 21:38:57 --> Helper loaded: user_helper
INFO - 2021-04-20 21:38:57 --> Database Driver Class Initialized
DEBUG - 2021-04-20 21:38:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 21:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 21:38:57 --> Form Validation Class Initialized
INFO - 2021-04-20 21:38:57 --> Controller Class Initialized
INFO - 2021-04-20 21:38:57 --> Model Class Initialized
INFO - 2021-04-20 21:38:57 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\viewaccount.php
INFO - 2021-04-20 21:38:57 --> Final output sent to browser
DEBUG - 2021-04-20 21:38:57 --> Total execution time: 0.0425
INFO - 2021-04-20 21:38:57 --> Config Class Initialized
INFO - 2021-04-20 21:38:57 --> Hooks Class Initialized
INFO - 2021-04-20 21:38:57 --> Config Class Initialized
INFO - 2021-04-20 21:38:57 --> Hooks Class Initialized
DEBUG - 2021-04-20 21:38:57 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:38:57 --> Utf8 Class Initialized
INFO - 2021-04-20 21:38:57 --> URI Class Initialized
DEBUG - 2021-04-20 21:38:57 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:38:57 --> Utf8 Class Initialized
INFO - 2021-04-20 21:38:57 --> URI Class Initialized
INFO - 2021-04-20 21:38:57 --> Router Class Initialized
INFO - 2021-04-20 21:38:57 --> Router Class Initialized
INFO - 2021-04-20 21:38:57 --> Output Class Initialized
INFO - 2021-04-20 21:38:57 --> Output Class Initialized
INFO - 2021-04-20 21:38:57 --> Security Class Initialized
INFO - 2021-04-20 21:38:57 --> Security Class Initialized
DEBUG - 2021-04-20 21:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:38:57 --> Input Class Initialized
INFO - 2021-04-20 21:38:57 --> Language Class Initialized
DEBUG - 2021-04-20 21:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:38:57 --> Input Class Initialized
INFO - 2021-04-20 21:38:57 --> Language Class Initialized
ERROR - 2021-04-20 21:38:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2021-04-20 21:38:57 --> 404 Page Not Found: Assets/plugins
INFO - 2021-04-20 21:42:00 --> Config Class Initialized
INFO - 2021-04-20 21:42:00 --> Hooks Class Initialized
DEBUG - 2021-04-20 21:42:00 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:42:00 --> Utf8 Class Initialized
INFO - 2021-04-20 21:42:00 --> URI Class Initialized
INFO - 2021-04-20 21:42:00 --> Router Class Initialized
INFO - 2021-04-20 21:42:00 --> Output Class Initialized
INFO - 2021-04-20 21:42:00 --> Security Class Initialized
DEBUG - 2021-04-20 21:42:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:42:00 --> Input Class Initialized
INFO - 2021-04-20 21:42:00 --> Language Class Initialized
INFO - 2021-04-20 21:42:00 --> Loader Class Initialized
INFO - 2021-04-20 21:42:00 --> Helper loaded: url_helper
INFO - 2021-04-20 21:42:00 --> Helper loaded: form_helper
INFO - 2021-04-20 21:42:00 --> Helper loaded: common_helper
INFO - 2021-04-20 21:42:00 --> Helper loaded: util_helper
INFO - 2021-04-20 21:42:00 --> Helper loaded: user_helper
INFO - 2021-04-20 21:42:00 --> Database Driver Class Initialized
DEBUG - 2021-04-20 21:42:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 21:42:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 21:42:00 --> Form Validation Class Initialized
INFO - 2021-04-20 21:42:01 --> Controller Class Initialized
INFO - 2021-04-20 21:42:01 --> Model Class Initialized
INFO - 2021-04-20 21:42:01 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\viewaccount.php
INFO - 2021-04-20 21:42:01 --> Final output sent to browser
DEBUG - 2021-04-20 21:42:01 --> Total execution time: 0.0400
INFO - 2021-04-20 21:42:01 --> Config Class Initialized
INFO - 2021-04-20 21:42:01 --> Hooks Class Initialized
INFO - 2021-04-20 21:42:01 --> Config Class Initialized
INFO - 2021-04-20 21:42:01 --> Hooks Class Initialized
DEBUG - 2021-04-20 21:42:01 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:42:01 --> Utf8 Class Initialized
DEBUG - 2021-04-20 21:42:01 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:42:01 --> Utf8 Class Initialized
INFO - 2021-04-20 21:42:01 --> URI Class Initialized
INFO - 2021-04-20 21:42:01 --> URI Class Initialized
INFO - 2021-04-20 21:42:01 --> Router Class Initialized
INFO - 2021-04-20 21:42:01 --> Router Class Initialized
INFO - 2021-04-20 21:42:01 --> Output Class Initialized
INFO - 2021-04-20 21:42:01 --> Output Class Initialized
INFO - 2021-04-20 21:42:01 --> Security Class Initialized
INFO - 2021-04-20 21:42:01 --> Security Class Initialized
DEBUG - 2021-04-20 21:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:42:01 --> Input Class Initialized
INFO - 2021-04-20 21:42:01 --> Language Class Initialized
DEBUG - 2021-04-20 21:42:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:42:01 --> Input Class Initialized
INFO - 2021-04-20 21:42:01 --> Language Class Initialized
ERROR - 2021-04-20 21:42:01 --> 404 Page Not Found: Assets/plugins
ERROR - 2021-04-20 21:42:01 --> 404 Page Not Found: Assets/plugins
INFO - 2021-04-20 21:42:03 --> Config Class Initialized
INFO - 2021-04-20 21:42:03 --> Hooks Class Initialized
DEBUG - 2021-04-20 21:42:03 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:42:03 --> Utf8 Class Initialized
INFO - 2021-04-20 21:42:03 --> URI Class Initialized
INFO - 2021-04-20 21:42:03 --> Router Class Initialized
INFO - 2021-04-20 21:42:03 --> Output Class Initialized
INFO - 2021-04-20 21:42:03 --> Security Class Initialized
DEBUG - 2021-04-20 21:42:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:42:03 --> Input Class Initialized
INFO - 2021-04-20 21:42:03 --> Language Class Initialized
ERROR - 2021-04-20 21:42:03 --> 404 Page Not Found: AdminController/edit
INFO - 2021-04-20 21:42:04 --> Config Class Initialized
INFO - 2021-04-20 21:42:04 --> Hooks Class Initialized
DEBUG - 2021-04-20 21:42:04 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:42:04 --> Utf8 Class Initialized
INFO - 2021-04-20 21:42:04 --> URI Class Initialized
INFO - 2021-04-20 21:42:04 --> Router Class Initialized
INFO - 2021-04-20 21:42:04 --> Output Class Initialized
INFO - 2021-04-20 21:42:04 --> Security Class Initialized
DEBUG - 2021-04-20 21:42:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:42:04 --> Input Class Initialized
INFO - 2021-04-20 21:42:04 --> Language Class Initialized
INFO - 2021-04-20 21:42:04 --> Loader Class Initialized
INFO - 2021-04-20 21:42:04 --> Helper loaded: url_helper
INFO - 2021-04-20 21:42:04 --> Helper loaded: form_helper
INFO - 2021-04-20 21:42:04 --> Helper loaded: common_helper
INFO - 2021-04-20 21:42:04 --> Helper loaded: util_helper
INFO - 2021-04-20 21:42:04 --> Helper loaded: user_helper
INFO - 2021-04-20 21:42:04 --> Database Driver Class Initialized
DEBUG - 2021-04-20 21:42:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 21:42:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 21:42:04 --> Form Validation Class Initialized
INFO - 2021-04-20 21:42:04 --> Controller Class Initialized
INFO - 2021-04-20 21:42:04 --> Model Class Initialized
INFO - 2021-04-20 21:42:04 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\viewaccount.php
INFO - 2021-04-20 21:42:04 --> Final output sent to browser
DEBUG - 2021-04-20 21:42:04 --> Total execution time: 0.0307
INFO - 2021-04-20 21:42:08 --> Config Class Initialized
INFO - 2021-04-20 21:42:08 --> Hooks Class Initialized
DEBUG - 2021-04-20 21:42:08 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:42:08 --> Utf8 Class Initialized
INFO - 2021-04-20 21:42:08 --> URI Class Initialized
INFO - 2021-04-20 21:42:08 --> Router Class Initialized
INFO - 2021-04-20 21:42:08 --> Output Class Initialized
INFO - 2021-04-20 21:42:08 --> Security Class Initialized
DEBUG - 2021-04-20 21:42:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:42:08 --> Input Class Initialized
INFO - 2021-04-20 21:42:08 --> Language Class Initialized
ERROR - 2021-04-20 21:42:08 --> 404 Page Not Found: AdminController/delete_row
INFO - 2021-04-20 21:42:10 --> Config Class Initialized
INFO - 2021-04-20 21:42:10 --> Hooks Class Initialized
DEBUG - 2021-04-20 21:42:10 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:42:10 --> Utf8 Class Initialized
INFO - 2021-04-20 21:42:10 --> URI Class Initialized
INFO - 2021-04-20 21:42:10 --> Router Class Initialized
INFO - 2021-04-20 21:42:10 --> Output Class Initialized
INFO - 2021-04-20 21:42:10 --> Security Class Initialized
DEBUG - 2021-04-20 21:42:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:42:10 --> Input Class Initialized
INFO - 2021-04-20 21:42:10 --> Language Class Initialized
INFO - 2021-04-20 21:42:10 --> Loader Class Initialized
INFO - 2021-04-20 21:42:10 --> Helper loaded: url_helper
INFO - 2021-04-20 21:42:10 --> Helper loaded: form_helper
INFO - 2021-04-20 21:42:10 --> Helper loaded: common_helper
INFO - 2021-04-20 21:42:10 --> Helper loaded: util_helper
INFO - 2021-04-20 21:42:10 --> Helper loaded: user_helper
INFO - 2021-04-20 21:42:10 --> Database Driver Class Initialized
DEBUG - 2021-04-20 21:42:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 21:42:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 21:42:10 --> Form Validation Class Initialized
INFO - 2021-04-20 21:42:10 --> Controller Class Initialized
INFO - 2021-04-20 21:42:10 --> Model Class Initialized
INFO - 2021-04-20 21:42:10 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\viewaccount.php
INFO - 2021-04-20 21:42:10 --> Final output sent to browser
DEBUG - 2021-04-20 21:42:10 --> Total execution time: 0.0291
INFO - 2021-04-20 21:42:11 --> Config Class Initialized
INFO - 2021-04-20 21:42:11 --> Hooks Class Initialized
DEBUG - 2021-04-20 21:42:11 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:42:11 --> Utf8 Class Initialized
INFO - 2021-04-20 21:42:11 --> URI Class Initialized
INFO - 2021-04-20 21:42:11 --> Router Class Initialized
INFO - 2021-04-20 21:42:11 --> Output Class Initialized
INFO - 2021-04-20 21:42:11 --> Security Class Initialized
DEBUG - 2021-04-20 21:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:42:11 --> Input Class Initialized
INFO - 2021-04-20 21:42:11 --> Language Class Initialized
INFO - 2021-04-20 21:42:11 --> Loader Class Initialized
INFO - 2021-04-20 21:42:11 --> Helper loaded: url_helper
INFO - 2021-04-20 21:42:11 --> Helper loaded: form_helper
INFO - 2021-04-20 21:42:11 --> Helper loaded: common_helper
INFO - 2021-04-20 21:42:11 --> Helper loaded: util_helper
INFO - 2021-04-20 21:42:11 --> Helper loaded: user_helper
INFO - 2021-04-20 21:42:11 --> Database Driver Class Initialized
DEBUG - 2021-04-20 21:42:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 21:42:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 21:42:11 --> Form Validation Class Initialized
INFO - 2021-04-20 21:42:11 --> Controller Class Initialized
INFO - 2021-04-20 21:42:11 --> Model Class Initialized
INFO - 2021-04-20 21:42:11 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\viewaccount.php
INFO - 2021-04-20 21:42:11 --> Final output sent to browser
DEBUG - 2021-04-20 21:42:11 --> Total execution time: 0.0316
INFO - 2021-04-20 21:42:11 --> Config Class Initialized
INFO - 2021-04-20 21:42:11 --> Config Class Initialized
INFO - 2021-04-20 21:42:11 --> Hooks Class Initialized
INFO - 2021-04-20 21:42:11 --> Hooks Class Initialized
DEBUG - 2021-04-20 21:42:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-20 21:42:11 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:42:11 --> Utf8 Class Initialized
INFO - 2021-04-20 21:42:11 --> Utf8 Class Initialized
INFO - 2021-04-20 21:42:11 --> URI Class Initialized
INFO - 2021-04-20 21:42:11 --> URI Class Initialized
INFO - 2021-04-20 21:42:11 --> Router Class Initialized
INFO - 2021-04-20 21:42:11 --> Router Class Initialized
INFO - 2021-04-20 21:42:11 --> Output Class Initialized
INFO - 2021-04-20 21:42:11 --> Output Class Initialized
INFO - 2021-04-20 21:42:11 --> Security Class Initialized
DEBUG - 2021-04-20 21:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:42:11 --> Input Class Initialized
INFO - 2021-04-20 21:42:11 --> Security Class Initialized
INFO - 2021-04-20 21:42:11 --> Language Class Initialized
DEBUG - 2021-04-20 21:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:42:11 --> Input Class Initialized
ERROR - 2021-04-20 21:42:11 --> 404 Page Not Found: Assets/plugins
INFO - 2021-04-20 21:42:11 --> Language Class Initialized
ERROR - 2021-04-20 21:42:11 --> 404 Page Not Found: Assets/plugins
INFO - 2021-04-20 21:42:11 --> Config Class Initialized
INFO - 2021-04-20 21:42:11 --> Hooks Class Initialized
DEBUG - 2021-04-20 21:42:11 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:42:11 --> Utf8 Class Initialized
INFO - 2021-04-20 21:42:11 --> URI Class Initialized
INFO - 2021-04-20 21:42:11 --> Router Class Initialized
INFO - 2021-04-20 21:42:11 --> Output Class Initialized
INFO - 2021-04-20 21:42:11 --> Security Class Initialized
DEBUG - 2021-04-20 21:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:42:11 --> Input Class Initialized
INFO - 2021-04-20 21:42:11 --> Language Class Initialized
ERROR - 2021-04-20 21:42:11 --> 404 Page Not Found: Assets/plugins
INFO - 2021-04-20 21:42:14 --> Config Class Initialized
INFO - 2021-04-20 21:42:14 --> Hooks Class Initialized
DEBUG - 2021-04-20 21:42:14 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:42:14 --> Utf8 Class Initialized
INFO - 2021-04-20 21:42:14 --> URI Class Initialized
INFO - 2021-04-20 21:42:14 --> Router Class Initialized
INFO - 2021-04-20 21:42:14 --> Output Class Initialized
INFO - 2021-04-20 21:42:14 --> Security Class Initialized
DEBUG - 2021-04-20 21:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:42:14 --> Input Class Initialized
INFO - 2021-04-20 21:42:14 --> Language Class Initialized
INFO - 2021-04-20 21:42:14 --> Loader Class Initialized
INFO - 2021-04-20 21:42:14 --> Helper loaded: url_helper
INFO - 2021-04-20 21:42:14 --> Helper loaded: form_helper
INFO - 2021-04-20 21:42:14 --> Helper loaded: common_helper
INFO - 2021-04-20 21:42:14 --> Helper loaded: util_helper
INFO - 2021-04-20 21:42:14 --> Helper loaded: user_helper
INFO - 2021-04-20 21:42:14 --> Database Driver Class Initialized
DEBUG - 2021-04-20 21:42:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 21:42:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 21:42:14 --> Form Validation Class Initialized
INFO - 2021-04-20 21:42:14 --> Controller Class Initialized
INFO - 2021-04-20 21:42:14 --> Model Class Initialized
INFO - 2021-04-20 21:42:14 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\viewaccount.php
INFO - 2021-04-20 21:42:14 --> Final output sent to browser
DEBUG - 2021-04-20 21:42:14 --> Total execution time: 0.0277
INFO - 2021-04-20 21:42:14 --> Config Class Initialized
INFO - 2021-04-20 21:42:14 --> Hooks Class Initialized
INFO - 2021-04-20 21:42:14 --> Config Class Initialized
INFO - 2021-04-20 21:42:14 --> Hooks Class Initialized
DEBUG - 2021-04-20 21:42:14 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:42:14 --> Utf8 Class Initialized
DEBUG - 2021-04-20 21:42:14 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:42:14 --> Utf8 Class Initialized
INFO - 2021-04-20 21:42:14 --> URI Class Initialized
INFO - 2021-04-20 21:42:14 --> URI Class Initialized
INFO - 2021-04-20 21:42:14 --> Router Class Initialized
INFO - 2021-04-20 21:42:14 --> Router Class Initialized
INFO - 2021-04-20 21:42:14 --> Output Class Initialized
INFO - 2021-04-20 21:42:14 --> Output Class Initialized
INFO - 2021-04-20 21:42:14 --> Security Class Initialized
INFO - 2021-04-20 21:42:14 --> Security Class Initialized
DEBUG - 2021-04-20 21:42:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-20 21:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:42:14 --> Input Class Initialized
INFO - 2021-04-20 21:42:14 --> Input Class Initialized
INFO - 2021-04-20 21:42:14 --> Language Class Initialized
INFO - 2021-04-20 21:42:14 --> Language Class Initialized
ERROR - 2021-04-20 21:42:14 --> 404 Page Not Found: Assets/plugins
ERROR - 2021-04-20 21:42:14 --> 404 Page Not Found: Assets/plugins
INFO - 2021-04-20 21:42:14 --> Config Class Initialized
INFO - 2021-04-20 21:42:14 --> Hooks Class Initialized
DEBUG - 2021-04-20 21:42:14 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:42:14 --> Utf8 Class Initialized
INFO - 2021-04-20 21:42:14 --> URI Class Initialized
INFO - 2021-04-20 21:42:14 --> Router Class Initialized
INFO - 2021-04-20 21:42:14 --> Output Class Initialized
INFO - 2021-04-20 21:42:14 --> Security Class Initialized
DEBUG - 2021-04-20 21:42:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:42:14 --> Input Class Initialized
INFO - 2021-04-20 21:42:14 --> Language Class Initialized
ERROR - 2021-04-20 21:42:14 --> 404 Page Not Found: Assets/plugins
INFO - 2021-04-20 21:47:42 --> Config Class Initialized
INFO - 2021-04-20 21:47:42 --> Hooks Class Initialized
DEBUG - 2021-04-20 21:47:42 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:47:42 --> Utf8 Class Initialized
INFO - 2021-04-20 21:47:42 --> URI Class Initialized
INFO - 2021-04-20 21:47:42 --> Router Class Initialized
INFO - 2021-04-20 21:47:42 --> Output Class Initialized
INFO - 2021-04-20 21:47:42 --> Security Class Initialized
DEBUG - 2021-04-20 21:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:47:42 --> Input Class Initialized
INFO - 2021-04-20 21:47:42 --> Language Class Initialized
INFO - 2021-04-20 21:47:42 --> Loader Class Initialized
INFO - 2021-04-20 21:47:42 --> Helper loaded: url_helper
INFO - 2021-04-20 21:47:42 --> Helper loaded: form_helper
INFO - 2021-04-20 21:47:42 --> Helper loaded: common_helper
INFO - 2021-04-20 21:47:42 --> Helper loaded: util_helper
INFO - 2021-04-20 21:47:42 --> Helper loaded: user_helper
INFO - 2021-04-20 21:47:42 --> Database Driver Class Initialized
DEBUG - 2021-04-20 21:47:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 21:47:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 21:47:42 --> Form Validation Class Initialized
INFO - 2021-04-20 21:47:42 --> Controller Class Initialized
INFO - 2021-04-20 21:47:42 --> Model Class Initialized
INFO - 2021-04-20 21:47:42 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\ckeditor/samples/index.php
INFO - 2021-04-20 21:47:42 --> Final output sent to browser
DEBUG - 2021-04-20 21:47:42 --> Total execution time: 0.0298
INFO - 2021-04-20 21:47:42 --> Config Class Initialized
INFO - 2021-04-20 21:47:42 --> Hooks Class Initialized
INFO - 2021-04-20 21:47:42 --> Config Class Initialized
INFO - 2021-04-20 21:47:42 --> Hooks Class Initialized
DEBUG - 2021-04-20 21:47:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-20 21:47:42 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:47:42 --> Utf8 Class Initialized
INFO - 2021-04-20 21:47:42 --> Utf8 Class Initialized
INFO - 2021-04-20 21:47:42 --> URI Class Initialized
INFO - 2021-04-20 21:47:42 --> URI Class Initialized
INFO - 2021-04-20 21:47:42 --> Router Class Initialized
INFO - 2021-04-20 21:47:42 --> Output Class Initialized
INFO - 2021-04-20 21:47:42 --> Router Class Initialized
INFO - 2021-04-20 21:47:42 --> Config Class Initialized
INFO - 2021-04-20 21:47:42 --> Security Class Initialized
INFO - 2021-04-20 21:47:42 --> Hooks Class Initialized
INFO - 2021-04-20 21:47:42 --> Output Class Initialized
DEBUG - 2021-04-20 21:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:47:42 --> Input Class Initialized
INFO - 2021-04-20 21:47:42 --> Config Class Initialized
INFO - 2021-04-20 21:47:42 --> Language Class Initialized
INFO - 2021-04-20 21:47:42 --> Security Class Initialized
INFO - 2021-04-20 21:47:42 --> Hooks Class Initialized
DEBUG - 2021-04-20 21:47:42 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:47:42 --> Utf8 Class Initialized
DEBUG - 2021-04-20 21:47:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-20 21:47:42 --> 404 Page Not Found: administrator/Js/sample.js
INFO - 2021-04-20 21:47:42 --> Input Class Initialized
INFO - 2021-04-20 21:47:42 --> URI Class Initialized
DEBUG - 2021-04-20 21:47:42 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:47:42 --> Utf8 Class Initialized
INFO - 2021-04-20 21:47:42 --> Language Class Initialized
INFO - 2021-04-20 21:47:42 --> Router Class Initialized
INFO - 2021-04-20 21:47:42 --> URI Class Initialized
ERROR - 2021-04-20 21:47:42 --> 404 Page Not Found: Ckeditorjs/index
INFO - 2021-04-20 21:47:42 --> Output Class Initialized
INFO - 2021-04-20 21:47:42 --> Router Class Initialized
INFO - 2021-04-20 21:47:42 --> Security Class Initialized
INFO - 2021-04-20 21:47:42 --> Output Class Initialized
DEBUG - 2021-04-20 21:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:47:42 --> Security Class Initialized
INFO - 2021-04-20 21:47:42 --> Input Class Initialized
INFO - 2021-04-20 21:47:42 --> Language Class Initialized
DEBUG - 2021-04-20 21:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:47:42 --> Input Class Initialized
INFO - 2021-04-20 21:47:42 --> Language Class Initialized
ERROR - 2021-04-20 21:47:42 --> 404 Page Not Found: administrator/Toolbarconfigurator/lib
ERROR - 2021-04-20 21:47:42 --> 404 Page Not Found: administrator/Css/samples.css
INFO - 2021-04-20 21:47:42 --> Config Class Initialized
INFO - 2021-04-20 21:47:42 --> Hooks Class Initialized
DEBUG - 2021-04-20 21:47:42 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:47:42 --> Utf8 Class Initialized
INFO - 2021-04-20 21:47:42 --> URI Class Initialized
INFO - 2021-04-20 21:47:42 --> Router Class Initialized
INFO - 2021-04-20 21:47:42 --> Output Class Initialized
INFO - 2021-04-20 21:47:42 --> Security Class Initialized
INFO - 2021-04-20 21:47:42 --> Config Class Initialized
DEBUG - 2021-04-20 21:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:47:42 --> Hooks Class Initialized
INFO - 2021-04-20 21:47:42 --> Input Class Initialized
INFO - 2021-04-20 21:47:42 --> Language Class Initialized
DEBUG - 2021-04-20 21:47:42 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:47:42 --> Utf8 Class Initialized
ERROR - 2021-04-20 21:47:42 --> 404 Page Not Found: administrator/Js/sample.js
INFO - 2021-04-20 21:47:42 --> URI Class Initialized
INFO - 2021-04-20 21:47:42 --> Router Class Initialized
INFO - 2021-04-20 21:47:42 --> Output Class Initialized
INFO - 2021-04-20 21:47:42 --> Security Class Initialized
DEBUG - 2021-04-20 21:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:47:42 --> Input Class Initialized
INFO - 2021-04-20 21:47:42 --> Language Class Initialized
ERROR - 2021-04-20 21:47:42 --> 404 Page Not Found: administrator/Img/logo.svg
INFO - 2021-04-20 21:47:42 --> Config Class Initialized
INFO - 2021-04-20 21:47:42 --> Hooks Class Initialized
INFO - 2021-04-20 21:47:42 --> Config Class Initialized
INFO - 2021-04-20 21:47:42 --> Hooks Class Initialized
DEBUG - 2021-04-20 21:47:42 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:47:42 --> Utf8 Class Initialized
DEBUG - 2021-04-20 21:47:42 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:47:42 --> Utf8 Class Initialized
INFO - 2021-04-20 21:47:42 --> URI Class Initialized
INFO - 2021-04-20 21:47:42 --> URI Class Initialized
INFO - 2021-04-20 21:47:42 --> Router Class Initialized
INFO - 2021-04-20 21:47:42 --> Router Class Initialized
INFO - 2021-04-20 21:47:42 --> Output Class Initialized
INFO - 2021-04-20 21:47:42 --> Output Class Initialized
INFO - 2021-04-20 21:47:42 --> Security Class Initialized
DEBUG - 2021-04-20 21:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:47:42 --> Input Class Initialized
INFO - 2021-04-20 21:47:42 --> Security Class Initialized
INFO - 2021-04-20 21:47:42 --> Language Class Initialized
INFO - 2021-04-20 21:47:42 --> Config Class Initialized
DEBUG - 2021-04-20 21:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:47:42 --> Hooks Class Initialized
INFO - 2021-04-20 21:47:42 --> Input Class Initialized
ERROR - 2021-04-20 21:47:42 --> 404 Page Not Found: administrator/Css/samples.css
INFO - 2021-04-20 21:47:42 --> Language Class Initialized
DEBUG - 2021-04-20 21:47:42 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:47:42 --> Utf8 Class Initialized
ERROR - 2021-04-20 21:47:42 --> 404 Page Not Found: administrator/Toolbarconfigurator/lib
INFO - 2021-04-20 21:47:42 --> URI Class Initialized
INFO - 2021-04-20 21:47:42 --> Router Class Initialized
INFO - 2021-04-20 21:47:42 --> Output Class Initialized
INFO - 2021-04-20 21:47:42 --> Security Class Initialized
DEBUG - 2021-04-20 21:47:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:47:42 --> Input Class Initialized
INFO - 2021-04-20 21:47:42 --> Language Class Initialized
ERROR - 2021-04-20 21:47:42 --> 404 Page Not Found: administrator/Img/logo.png
INFO - 2021-04-20 21:48:50 --> Config Class Initialized
INFO - 2021-04-20 21:48:50 --> Hooks Class Initialized
DEBUG - 2021-04-20 21:48:50 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:48:50 --> Utf8 Class Initialized
INFO - 2021-04-20 21:48:50 --> URI Class Initialized
INFO - 2021-04-20 21:48:50 --> Router Class Initialized
INFO - 2021-04-20 21:48:50 --> Output Class Initialized
INFO - 2021-04-20 21:48:50 --> Security Class Initialized
DEBUG - 2021-04-20 21:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:48:50 --> Input Class Initialized
INFO - 2021-04-20 21:48:50 --> Language Class Initialized
INFO - 2021-04-20 21:48:50 --> Loader Class Initialized
INFO - 2021-04-20 21:48:50 --> Helper loaded: url_helper
INFO - 2021-04-20 21:48:50 --> Helper loaded: form_helper
INFO - 2021-04-20 21:48:50 --> Helper loaded: common_helper
INFO - 2021-04-20 21:48:50 --> Helper loaded: util_helper
INFO - 2021-04-20 21:48:50 --> Helper loaded: user_helper
INFO - 2021-04-20 21:48:50 --> Database Driver Class Initialized
DEBUG - 2021-04-20 21:48:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 21:48:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 21:48:50 --> Form Validation Class Initialized
INFO - 2021-04-20 21:48:50 --> Controller Class Initialized
INFO - 2021-04-20 21:48:50 --> Model Class Initialized
INFO - 2021-04-20 21:48:50 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\ckeditor/samples/index.php
INFO - 2021-04-20 21:48:50 --> Final output sent to browser
DEBUG - 2021-04-20 21:48:50 --> Total execution time: 0.0295
INFO - 2021-04-20 21:48:50 --> Config Class Initialized
INFO - 2021-04-20 21:48:50 --> Hooks Class Initialized
INFO - 2021-04-20 21:48:50 --> Config Class Initialized
INFO - 2021-04-20 21:48:50 --> Hooks Class Initialized
DEBUG - 2021-04-20 21:48:50 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:48:50 --> Utf8 Class Initialized
INFO - 2021-04-20 21:48:50 --> URI Class Initialized
INFO - 2021-04-20 21:48:50 --> Config Class Initialized
INFO - 2021-04-20 21:48:50 --> Hooks Class Initialized
INFO - 2021-04-20 21:48:50 --> Config Class Initialized
INFO - 2021-04-20 21:48:50 --> Router Class Initialized
INFO - 2021-04-20 21:48:50 --> Hooks Class Initialized
INFO - 2021-04-20 21:48:50 --> Output Class Initialized
DEBUG - 2021-04-20 21:48:50 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:48:50 --> Utf8 Class Initialized
DEBUG - 2021-04-20 21:48:50 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:48:50 --> Security Class Initialized
INFO - 2021-04-20 21:48:50 --> Utf8 Class Initialized
INFO - 2021-04-20 21:48:50 --> URI Class Initialized
DEBUG - 2021-04-20 21:48:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-20 21:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:48:50 --> URI Class Initialized
INFO - 2021-04-20 21:48:50 --> Input Class Initialized
INFO - 2021-04-20 21:48:50 --> Utf8 Class Initialized
INFO - 2021-04-20 21:48:50 --> Language Class Initialized
INFO - 2021-04-20 21:48:50 --> Router Class Initialized
INFO - 2021-04-20 21:48:50 --> URI Class Initialized
INFO - 2021-04-20 21:48:50 --> Router Class Initialized
ERROR - 2021-04-20 21:48:50 --> 404 Page Not Found: administrator/Js/sample.js
INFO - 2021-04-20 21:48:50 --> Router Class Initialized
INFO - 2021-04-20 21:48:50 --> Output Class Initialized
INFO - 2021-04-20 21:48:50 --> Output Class Initialized
INFO - 2021-04-20 21:48:50 --> Security Class Initialized
INFO - 2021-04-20 21:48:50 --> Output Class Initialized
INFO - 2021-04-20 21:48:50 --> Security Class Initialized
DEBUG - 2021-04-20 21:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:48:50 --> Security Class Initialized
DEBUG - 2021-04-20 21:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:48:50 --> Input Class Initialized
INFO - 2021-04-20 21:48:50 --> Input Class Initialized
INFO - 2021-04-20 21:48:50 --> Language Class Initialized
INFO - 2021-04-20 21:48:50 --> Language Class Initialized
DEBUG - 2021-04-20 21:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:48:50 --> Input Class Initialized
INFO - 2021-04-20 21:48:50 --> Language Class Initialized
ERROR - 2021-04-20 21:48:50 --> 404 Page Not Found: administrator/Css/samples.css
ERROR - 2021-04-20 21:48:50 --> 404 Page Not Found: administrator/Toolbarconfigurator/lib
ERROR - 2021-04-20 21:48:50 --> 404 Page Not Found: Ckeditorjs/index
INFO - 2021-04-20 21:48:50 --> Config Class Initialized
INFO - 2021-04-20 21:48:50 --> Hooks Class Initialized
INFO - 2021-04-20 21:48:50 --> Config Class Initialized
INFO - 2021-04-20 21:48:50 --> Hooks Class Initialized
DEBUG - 2021-04-20 21:48:50 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:48:50 --> Utf8 Class Initialized
INFO - 2021-04-20 21:48:50 --> URI Class Initialized
DEBUG - 2021-04-20 21:48:50 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:48:50 --> Utf8 Class Initialized
INFO - 2021-04-20 21:48:50 --> Router Class Initialized
INFO - 2021-04-20 21:48:50 --> URI Class Initialized
INFO - 2021-04-20 21:48:50 --> Router Class Initialized
INFO - 2021-04-20 21:48:50 --> Output Class Initialized
INFO - 2021-04-20 21:48:50 --> Security Class Initialized
INFO - 2021-04-20 21:48:50 --> Output Class Initialized
DEBUG - 2021-04-20 21:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:48:50 --> Security Class Initialized
INFO - 2021-04-20 21:48:50 --> Input Class Initialized
INFO - 2021-04-20 21:48:50 --> Language Class Initialized
DEBUG - 2021-04-20 21:48:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:48:50 --> Input Class Initialized
INFO - 2021-04-20 21:48:50 --> Language Class Initialized
ERROR - 2021-04-20 21:48:50 --> 404 Page Not Found: administrator/Img/logo.svg
ERROR - 2021-04-20 21:48:50 --> 404 Page Not Found: administrator/Js/sample.js
INFO - 2021-04-20 21:48:51 --> Config Class Initialized
INFO - 2021-04-20 21:48:51 --> Hooks Class Initialized
INFO - 2021-04-20 21:48:51 --> Config Class Initialized
INFO - 2021-04-20 21:48:51 --> Hooks Class Initialized
INFO - 2021-04-20 21:48:51 --> Config Class Initialized
INFO - 2021-04-20 21:48:51 --> Hooks Class Initialized
DEBUG - 2021-04-20 21:48:51 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:48:51 --> Utf8 Class Initialized
INFO - 2021-04-20 21:48:51 --> URI Class Initialized
DEBUG - 2021-04-20 21:48:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-20 21:48:51 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:48:51 --> Utf8 Class Initialized
INFO - 2021-04-20 21:48:51 --> Utf8 Class Initialized
INFO - 2021-04-20 21:48:51 --> Router Class Initialized
INFO - 2021-04-20 21:48:51 --> URI Class Initialized
INFO - 2021-04-20 21:48:51 --> URI Class Initialized
INFO - 2021-04-20 21:48:51 --> Router Class Initialized
INFO - 2021-04-20 21:48:51 --> Output Class Initialized
INFO - 2021-04-20 21:48:51 --> Router Class Initialized
INFO - 2021-04-20 21:48:51 --> Output Class Initialized
INFO - 2021-04-20 21:48:51 --> Security Class Initialized
INFO - 2021-04-20 21:48:51 --> Security Class Initialized
INFO - 2021-04-20 21:48:51 --> Output Class Initialized
DEBUG - 2021-04-20 21:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:48:51 --> Input Class Initialized
DEBUG - 2021-04-20 21:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:48:51 --> Input Class Initialized
INFO - 2021-04-20 21:48:51 --> Security Class Initialized
INFO - 2021-04-20 21:48:51 --> Language Class Initialized
INFO - 2021-04-20 21:48:51 --> Language Class Initialized
DEBUG - 2021-04-20 21:48:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:48:51 --> Input Class Initialized
ERROR - 2021-04-20 21:48:51 --> 404 Page Not Found: administrator/Img/logo.png
ERROR - 2021-04-20 21:48:51 --> 404 Page Not Found: administrator/Css/samples.css
INFO - 2021-04-20 21:48:51 --> Language Class Initialized
ERROR - 2021-04-20 21:48:51 --> 404 Page Not Found: administrator/Toolbarconfigurator/lib
INFO - 2021-04-20 21:52:19 --> Config Class Initialized
INFO - 2021-04-20 21:52:19 --> Hooks Class Initialized
DEBUG - 2021-04-20 21:52:19 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:52:19 --> Utf8 Class Initialized
INFO - 2021-04-20 21:52:19 --> URI Class Initialized
INFO - 2021-04-20 21:52:19 --> Router Class Initialized
INFO - 2021-04-20 21:52:19 --> Output Class Initialized
INFO - 2021-04-20 21:52:19 --> Security Class Initialized
DEBUG - 2021-04-20 21:52:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:52:19 --> Input Class Initialized
INFO - 2021-04-20 21:52:19 --> Language Class Initialized
ERROR - 2021-04-20 21:52:19 --> 404 Page Not Found: administrator/Indexhtml/index
INFO - 2021-04-20 21:52:21 --> Config Class Initialized
INFO - 2021-04-20 21:52:21 --> Hooks Class Initialized
DEBUG - 2021-04-20 21:52:21 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:52:21 --> Utf8 Class Initialized
INFO - 2021-04-20 21:52:21 --> URI Class Initialized
INFO - 2021-04-20 21:52:21 --> Router Class Initialized
INFO - 2021-04-20 21:52:21 --> Output Class Initialized
INFO - 2021-04-20 21:52:21 --> Security Class Initialized
DEBUG - 2021-04-20 21:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:52:21 --> Input Class Initialized
INFO - 2021-04-20 21:52:21 --> Language Class Initialized
INFO - 2021-04-20 21:52:21 --> Loader Class Initialized
INFO - 2021-04-20 21:52:21 --> Helper loaded: url_helper
INFO - 2021-04-20 21:52:21 --> Helper loaded: form_helper
INFO - 2021-04-20 21:52:21 --> Helper loaded: common_helper
INFO - 2021-04-20 21:52:21 --> Helper loaded: util_helper
INFO - 2021-04-20 21:52:21 --> Helper loaded: user_helper
INFO - 2021-04-20 21:52:21 --> Database Driver Class Initialized
DEBUG - 2021-04-20 21:52:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 21:52:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 21:52:21 --> Form Validation Class Initialized
INFO - 2021-04-20 21:52:21 --> Controller Class Initialized
INFO - 2021-04-20 21:52:21 --> Model Class Initialized
INFO - 2021-04-20 21:52:21 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\ckeditor/samples/index.php
INFO - 2021-04-20 21:52:21 --> Final output sent to browser
DEBUG - 2021-04-20 21:52:21 --> Total execution time: 0.0398
INFO - 2021-04-20 21:52:21 --> Config Class Initialized
INFO - 2021-04-20 21:52:21 --> Hooks Class Initialized
DEBUG - 2021-04-20 21:52:21 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:52:21 --> Utf8 Class Initialized
INFO - 2021-04-20 21:52:21 --> URI Class Initialized
INFO - 2021-04-20 21:52:21 --> Router Class Initialized
INFO - 2021-04-20 21:52:21 --> Output Class Initialized
INFO - 2021-04-20 21:52:21 --> Security Class Initialized
DEBUG - 2021-04-20 21:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:52:21 --> Input Class Initialized
INFO - 2021-04-20 21:52:21 --> Language Class Initialized
ERROR - 2021-04-20 21:52:21 --> 404 Page Not Found: Ckeditorjs/index
INFO - 2021-04-20 21:52:21 --> Config Class Initialized
INFO - 2021-04-20 21:52:21 --> Hooks Class Initialized
DEBUG - 2021-04-20 21:52:21 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:52:21 --> Utf8 Class Initialized
INFO - 2021-04-20 21:52:21 --> URI Class Initialized
INFO - 2021-04-20 21:52:21 --> Router Class Initialized
INFO - 2021-04-20 21:52:21 --> Output Class Initialized
INFO - 2021-04-20 21:52:21 --> Security Class Initialized
DEBUG - 2021-04-20 21:52:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:52:21 --> Input Class Initialized
INFO - 2021-04-20 21:52:21 --> Language Class Initialized
ERROR - 2021-04-20 21:52:21 --> 404 Page Not Found: administrator/Img/logo.png
INFO - 2021-04-20 21:55:25 --> Config Class Initialized
INFO - 2021-04-20 21:55:25 --> Hooks Class Initialized
DEBUG - 2021-04-20 21:55:25 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:55:25 --> Utf8 Class Initialized
INFO - 2021-04-20 21:55:25 --> URI Class Initialized
INFO - 2021-04-20 21:55:25 --> Router Class Initialized
INFO - 2021-04-20 21:55:25 --> Output Class Initialized
INFO - 2021-04-20 21:55:25 --> Security Class Initialized
DEBUG - 2021-04-20 21:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:55:25 --> Input Class Initialized
INFO - 2021-04-20 21:55:25 --> Language Class Initialized
INFO - 2021-04-20 21:55:25 --> Loader Class Initialized
INFO - 2021-04-20 21:55:25 --> Helper loaded: url_helper
INFO - 2021-04-20 21:55:25 --> Helper loaded: form_helper
INFO - 2021-04-20 21:55:25 --> Helper loaded: common_helper
INFO - 2021-04-20 21:55:25 --> Helper loaded: util_helper
INFO - 2021-04-20 21:55:25 --> Helper loaded: user_helper
INFO - 2021-04-20 21:55:25 --> Database Driver Class Initialized
DEBUG - 2021-04-20 21:55:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 21:55:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 21:55:25 --> Form Validation Class Initialized
INFO - 2021-04-20 21:55:25 --> Controller Class Initialized
INFO - 2021-04-20 21:55:25 --> Model Class Initialized
INFO - 2021-04-20 21:55:25 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\ckeditor/samples/index.php
INFO - 2021-04-20 21:55:25 --> Final output sent to browser
DEBUG - 2021-04-20 21:55:25 --> Total execution time: 0.0395
INFO - 2021-04-20 21:55:25 --> Config Class Initialized
INFO - 2021-04-20 21:55:25 --> Hooks Class Initialized
INFO - 2021-04-20 21:55:25 --> Config Class Initialized
DEBUG - 2021-04-20 21:55:25 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:55:25 --> Hooks Class Initialized
INFO - 2021-04-20 21:55:25 --> Utf8 Class Initialized
INFO - 2021-04-20 21:55:25 --> Config Class Initialized
INFO - 2021-04-20 21:55:25 --> Hooks Class Initialized
INFO - 2021-04-20 21:55:25 --> URI Class Initialized
INFO - 2021-04-20 21:55:25 --> Config Class Initialized
INFO - 2021-04-20 21:55:25 --> Hooks Class Initialized
INFO - 2021-04-20 21:55:25 --> Router Class Initialized
DEBUG - 2021-04-20 21:55:25 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:55:25 --> Utf8 Class Initialized
DEBUG - 2021-04-20 21:55:25 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:55:25 --> Utf8 Class Initialized
INFO - 2021-04-20 21:55:25 --> URI Class Initialized
INFO - 2021-04-20 21:55:25 --> Output Class Initialized
INFO - 2021-04-20 21:55:25 --> URI Class Initialized
INFO - 2021-04-20 21:55:25 --> Router Class Initialized
INFO - 2021-04-20 21:55:25 --> Security Class Initialized
DEBUG - 2021-04-20 21:55:25 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:55:25 --> Utf8 Class Initialized
INFO - 2021-04-20 21:55:25 --> Router Class Initialized
DEBUG - 2021-04-20 21:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:55:25 --> Output Class Initialized
INFO - 2021-04-20 21:55:25 --> Input Class Initialized
INFO - 2021-04-20 21:55:25 --> URI Class Initialized
INFO - 2021-04-20 21:55:25 --> Output Class Initialized
INFO - 2021-04-20 21:55:25 --> Language Class Initialized
INFO - 2021-04-20 21:55:25 --> Security Class Initialized
INFO - 2021-04-20 21:55:25 --> Security Class Initialized
INFO - 2021-04-20 21:55:25 --> Router Class Initialized
ERROR - 2021-04-20 21:55:25 --> 404 Page Not Found: administrator/Js/sample.js
DEBUG - 2021-04-20 21:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:55:25 --> Input Class Initialized
DEBUG - 2021-04-20 21:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:55:25 --> Output Class Initialized
INFO - 2021-04-20 21:55:25 --> Input Class Initialized
INFO - 2021-04-20 21:55:25 --> Language Class Initialized
INFO - 2021-04-20 21:55:25 --> Language Class Initialized
INFO - 2021-04-20 21:55:25 --> Security Class Initialized
ERROR - 2021-04-20 21:55:25 --> 404 Page Not Found: Ckeditorjs/index
DEBUG - 2021-04-20 21:55:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-20 21:55:25 --> 404 Page Not Found: administrator/Css/samples.css
INFO - 2021-04-20 21:55:25 --> Input Class Initialized
INFO - 2021-04-20 21:55:25 --> Language Class Initialized
ERROR - 2021-04-20 21:55:25 --> 404 Page Not Found: administrator/Toolbarconfigurator/lib
INFO - 2021-04-20 21:55:25 --> Config Class Initialized
INFO - 2021-04-20 21:55:25 --> Hooks Class Initialized
DEBUG - 2021-04-20 21:55:25 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:55:25 --> Utf8 Class Initialized
INFO - 2021-04-20 21:55:25 --> Config Class Initialized
INFO - 2021-04-20 21:55:25 --> URI Class Initialized
INFO - 2021-04-20 21:55:25 --> Hooks Class Initialized
INFO - 2021-04-20 21:55:25 --> Router Class Initialized
DEBUG - 2021-04-20 21:55:25 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:55:25 --> Utf8 Class Initialized
INFO - 2021-04-20 21:55:25 --> Output Class Initialized
INFO - 2021-04-20 21:55:25 --> URI Class Initialized
INFO - 2021-04-20 21:55:25 --> Security Class Initialized
INFO - 2021-04-20 21:55:25 --> Router Class Initialized
DEBUG - 2021-04-20 21:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:55:25 --> Input Class Initialized
INFO - 2021-04-20 21:55:25 --> Language Class Initialized
INFO - 2021-04-20 21:55:25 --> Output Class Initialized
INFO - 2021-04-20 21:55:25 --> Security Class Initialized
ERROR - 2021-04-20 21:55:25 --> 404 Page Not Found: administrator/Js/sample.js
DEBUG - 2021-04-20 21:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:55:25 --> Input Class Initialized
INFO - 2021-04-20 21:55:25 --> Language Class Initialized
ERROR - 2021-04-20 21:55:25 --> 404 Page Not Found: administrator/Img/logo.svg
INFO - 2021-04-20 21:55:25 --> Config Class Initialized
INFO - 2021-04-20 21:55:25 --> Hooks Class Initialized
INFO - 2021-04-20 21:55:25 --> Config Class Initialized
INFO - 2021-04-20 21:55:25 --> Hooks Class Initialized
DEBUG - 2021-04-20 21:55:25 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:55:25 --> Utf8 Class Initialized
DEBUG - 2021-04-20 21:55:25 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:55:25 --> Utf8 Class Initialized
INFO - 2021-04-20 21:55:25 --> URI Class Initialized
INFO - 2021-04-20 21:55:25 --> URI Class Initialized
INFO - 2021-04-20 21:55:25 --> Router Class Initialized
INFO - 2021-04-20 21:55:25 --> Router Class Initialized
INFO - 2021-04-20 21:55:25 --> Config Class Initialized
INFO - 2021-04-20 21:55:25 --> Output Class Initialized
INFO - 2021-04-20 21:55:25 --> Hooks Class Initialized
INFO - 2021-04-20 21:55:25 --> Output Class Initialized
INFO - 2021-04-20 21:55:25 --> Security Class Initialized
INFO - 2021-04-20 21:55:25 --> Security Class Initialized
DEBUG - 2021-04-20 21:55:25 --> UTF-8 Support Enabled
DEBUG - 2021-04-20 21:55:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-20 21:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:55:25 --> Utf8 Class Initialized
INFO - 2021-04-20 21:55:25 --> Input Class Initialized
INFO - 2021-04-20 21:55:25 --> Input Class Initialized
INFO - 2021-04-20 21:55:25 --> Language Class Initialized
INFO - 2021-04-20 21:55:25 --> Language Class Initialized
INFO - 2021-04-20 21:55:25 --> URI Class Initialized
ERROR - 2021-04-20 21:55:25 --> 404 Page Not Found: administrator/Toolbarconfigurator/lib
ERROR - 2021-04-20 21:55:25 --> 404 Page Not Found: administrator/Css/samples.css
INFO - 2021-04-20 21:55:25 --> Router Class Initialized
INFO - 2021-04-20 21:55:25 --> Output Class Initialized
INFO - 2021-04-20 21:55:25 --> Security Class Initialized
DEBUG - 2021-04-20 21:55:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:55:25 --> Input Class Initialized
INFO - 2021-04-20 21:55:25 --> Language Class Initialized
ERROR - 2021-04-20 21:55:25 --> 404 Page Not Found: administrator/Img/logo.png
INFO - 2021-04-20 21:55:26 --> Config Class Initialized
INFO - 2021-04-20 21:55:26 --> Hooks Class Initialized
DEBUG - 2021-04-20 21:55:26 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:55:26 --> Utf8 Class Initialized
INFO - 2021-04-20 21:55:26 --> URI Class Initialized
INFO - 2021-04-20 21:55:26 --> Router Class Initialized
INFO - 2021-04-20 21:55:26 --> Output Class Initialized
INFO - 2021-04-20 21:55:26 --> Security Class Initialized
DEBUG - 2021-04-20 21:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:55:26 --> Input Class Initialized
INFO - 2021-04-20 21:55:26 --> Language Class Initialized
INFO - 2021-04-20 21:55:26 --> Loader Class Initialized
INFO - 2021-04-20 21:55:26 --> Helper loaded: url_helper
INFO - 2021-04-20 21:55:26 --> Helper loaded: form_helper
INFO - 2021-04-20 21:55:26 --> Helper loaded: common_helper
INFO - 2021-04-20 21:55:26 --> Helper loaded: util_helper
INFO - 2021-04-20 21:55:26 --> Helper loaded: user_helper
INFO - 2021-04-20 21:55:26 --> Database Driver Class Initialized
DEBUG - 2021-04-20 21:55:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 21:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 21:55:26 --> Form Validation Class Initialized
INFO - 2021-04-20 21:55:26 --> Controller Class Initialized
INFO - 2021-04-20 21:55:26 --> Model Class Initialized
INFO - 2021-04-20 21:55:26 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\ckeditor/samples/index.php
INFO - 2021-04-20 21:55:26 --> Final output sent to browser
DEBUG - 2021-04-20 21:55:26 --> Total execution time: 0.0301
INFO - 2021-04-20 21:55:26 --> Config Class Initialized
INFO - 2021-04-20 21:55:26 --> Hooks Class Initialized
INFO - 2021-04-20 21:55:26 --> Config Class Initialized
INFO - 2021-04-20 21:55:26 --> Hooks Class Initialized
INFO - 2021-04-20 21:55:26 --> Config Class Initialized
INFO - 2021-04-20 21:55:26 --> Config Class Initialized
DEBUG - 2021-04-20 21:55:26 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:55:26 --> Hooks Class Initialized
INFO - 2021-04-20 21:55:26 --> Hooks Class Initialized
INFO - 2021-04-20 21:55:26 --> Utf8 Class Initialized
INFO - 2021-04-20 21:55:26 --> URI Class Initialized
DEBUG - 2021-04-20 21:55:26 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:55:26 --> Utf8 Class Initialized
DEBUG - 2021-04-20 21:55:26 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:55:26 --> Router Class Initialized
INFO - 2021-04-20 21:55:26 --> URI Class Initialized
INFO - 2021-04-20 21:55:26 --> Utf8 Class Initialized
DEBUG - 2021-04-20 21:55:26 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:55:26 --> Utf8 Class Initialized
INFO - 2021-04-20 21:55:26 --> URI Class Initialized
INFO - 2021-04-20 21:55:26 --> URI Class Initialized
INFO - 2021-04-20 21:55:26 --> Output Class Initialized
INFO - 2021-04-20 21:55:26 --> Router Class Initialized
INFO - 2021-04-20 21:55:26 --> Security Class Initialized
INFO - 2021-04-20 21:55:26 --> Router Class Initialized
INFO - 2021-04-20 21:55:26 --> Router Class Initialized
INFO - 2021-04-20 21:55:26 --> Output Class Initialized
DEBUG - 2021-04-20 21:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:55:26 --> Input Class Initialized
INFO - 2021-04-20 21:55:26 --> Output Class Initialized
INFO - 2021-04-20 21:55:26 --> Output Class Initialized
INFO - 2021-04-20 21:55:26 --> Language Class Initialized
INFO - 2021-04-20 21:55:26 --> Security Class Initialized
INFO - 2021-04-20 21:55:26 --> Security Class Initialized
INFO - 2021-04-20 21:55:26 --> Security Class Initialized
DEBUG - 2021-04-20 21:55:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-20 21:55:26 --> 404 Page Not Found: Ckeditorjs/index
INFO - 2021-04-20 21:55:26 --> Input Class Initialized
INFO - 2021-04-20 21:55:26 --> Language Class Initialized
DEBUG - 2021-04-20 21:55:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-20 21:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:55:26 --> Input Class Initialized
INFO - 2021-04-20 21:55:26 --> Input Class Initialized
INFO - 2021-04-20 21:55:26 --> Language Class Initialized
INFO - 2021-04-20 21:55:26 --> Language Class Initialized
ERROR - 2021-04-20 21:55:26 --> 404 Page Not Found: administrator/Js/sample.js
ERROR - 2021-04-20 21:55:26 --> 404 Page Not Found: administrator/Css/samples.css
ERROR - 2021-04-20 21:55:26 --> 404 Page Not Found: administrator/Toolbarconfigurator/lib
INFO - 2021-04-20 21:55:26 --> Config Class Initialized
INFO - 2021-04-20 21:55:26 --> Hooks Class Initialized
DEBUG - 2021-04-20 21:55:26 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:55:26 --> Utf8 Class Initialized
INFO - 2021-04-20 21:55:26 --> URI Class Initialized
INFO - 2021-04-20 21:55:26 --> Router Class Initialized
INFO - 2021-04-20 21:55:26 --> Output Class Initialized
INFO - 2021-04-20 21:55:26 --> Security Class Initialized
DEBUG - 2021-04-20 21:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:55:26 --> Input Class Initialized
INFO - 2021-04-20 21:55:26 --> Language Class Initialized
ERROR - 2021-04-20 21:55:26 --> 404 Page Not Found: administrator/Img/logo.svg
INFO - 2021-04-20 21:55:26 --> Config Class Initialized
INFO - 2021-04-20 21:55:26 --> Hooks Class Initialized
DEBUG - 2021-04-20 21:55:26 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:55:26 --> Utf8 Class Initialized
INFO - 2021-04-20 21:55:26 --> URI Class Initialized
INFO - 2021-04-20 21:55:26 --> Router Class Initialized
INFO - 2021-04-20 21:55:26 --> Output Class Initialized
INFO - 2021-04-20 21:55:26 --> Security Class Initialized
DEBUG - 2021-04-20 21:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:55:26 --> Input Class Initialized
INFO - 2021-04-20 21:55:26 --> Language Class Initialized
ERROR - 2021-04-20 21:55:26 --> 404 Page Not Found: administrator/Img/logo.png
INFO - 2021-04-20 21:55:27 --> Config Class Initialized
INFO - 2021-04-20 21:55:27 --> Hooks Class Initialized
DEBUG - 2021-04-20 21:55:27 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:55:27 --> Utf8 Class Initialized
INFO - 2021-04-20 21:55:27 --> URI Class Initialized
INFO - 2021-04-20 21:55:27 --> Router Class Initialized
INFO - 2021-04-20 21:55:27 --> Output Class Initialized
INFO - 2021-04-20 21:55:27 --> Security Class Initialized
DEBUG - 2021-04-20 21:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:55:27 --> Input Class Initialized
INFO - 2021-04-20 21:55:27 --> Language Class Initialized
INFO - 2021-04-20 21:55:27 --> Loader Class Initialized
INFO - 2021-04-20 21:55:27 --> Helper loaded: url_helper
INFO - 2021-04-20 21:55:27 --> Helper loaded: form_helper
INFO - 2021-04-20 21:55:27 --> Helper loaded: common_helper
INFO - 2021-04-20 21:55:27 --> Helper loaded: util_helper
INFO - 2021-04-20 21:55:27 --> Helper loaded: user_helper
INFO - 2021-04-20 21:55:27 --> Database Driver Class Initialized
DEBUG - 2021-04-20 21:55:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 21:55:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 21:55:27 --> Form Validation Class Initialized
INFO - 2021-04-20 21:55:27 --> Controller Class Initialized
INFO - 2021-04-20 21:55:27 --> Model Class Initialized
INFO - 2021-04-20 21:55:27 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\ckeditor/samples/index.php
INFO - 2021-04-20 21:55:27 --> Final output sent to browser
DEBUG - 2021-04-20 21:55:27 --> Total execution time: 0.0310
INFO - 2021-04-20 21:55:27 --> Config Class Initialized
INFO - 2021-04-20 21:55:27 --> Hooks Class Initialized
INFO - 2021-04-20 21:55:27 --> Config Class Initialized
INFO - 2021-04-20 21:55:27 --> Hooks Class Initialized
INFO - 2021-04-20 21:55:27 --> Config Class Initialized
INFO - 2021-04-20 21:55:27 --> Hooks Class Initialized
DEBUG - 2021-04-20 21:55:27 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:55:27 --> Config Class Initialized
INFO - 2021-04-20 21:55:27 --> Utf8 Class Initialized
INFO - 2021-04-20 21:55:27 --> Hooks Class Initialized
DEBUG - 2021-04-20 21:55:27 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:55:27 --> Utf8 Class Initialized
INFO - 2021-04-20 21:55:27 --> URI Class Initialized
DEBUG - 2021-04-20 21:55:27 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:55:27 --> Utf8 Class Initialized
INFO - 2021-04-20 21:55:27 --> URI Class Initialized
DEBUG - 2021-04-20 21:55:27 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:55:27 --> Router Class Initialized
INFO - 2021-04-20 21:55:27 --> Utf8 Class Initialized
INFO - 2021-04-20 21:55:27 --> URI Class Initialized
INFO - 2021-04-20 21:55:27 --> Router Class Initialized
INFO - 2021-04-20 21:55:27 --> URI Class Initialized
INFO - 2021-04-20 21:55:27 --> Output Class Initialized
INFO - 2021-04-20 21:55:27 --> Router Class Initialized
INFO - 2021-04-20 21:55:27 --> Router Class Initialized
INFO - 2021-04-20 21:55:27 --> Output Class Initialized
INFO - 2021-04-20 21:55:27 --> Security Class Initialized
INFO - 2021-04-20 21:55:27 --> Output Class Initialized
INFO - 2021-04-20 21:55:27 --> Security Class Initialized
INFO - 2021-04-20 21:55:27 --> Output Class Initialized
DEBUG - 2021-04-20 21:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:55:27 --> Security Class Initialized
INFO - 2021-04-20 21:55:27 --> Input Class Initialized
DEBUG - 2021-04-20 21:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:55:27 --> Input Class Initialized
INFO - 2021-04-20 21:55:27 --> Security Class Initialized
DEBUG - 2021-04-20 21:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:55:27 --> Language Class Initialized
INFO - 2021-04-20 21:55:27 --> Input Class Initialized
INFO - 2021-04-20 21:55:27 --> Language Class Initialized
INFO - 2021-04-20 21:55:27 --> Language Class Initialized
DEBUG - 2021-04-20 21:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:55:27 --> Input Class Initialized
ERROR - 2021-04-20 21:55:27 --> 404 Page Not Found: administrator/Js/sample.js
ERROR - 2021-04-20 21:55:27 --> 404 Page Not Found: administrator/Toolbarconfigurator/lib
INFO - 2021-04-20 21:55:27 --> Language Class Initialized
ERROR - 2021-04-20 21:55:27 --> 404 Page Not Found: Ckeditorjs/index
ERROR - 2021-04-20 21:55:27 --> 404 Page Not Found: administrator/Css/samples.css
INFO - 2021-04-20 21:55:27 --> Config Class Initialized
INFO - 2021-04-20 21:55:27 --> Hooks Class Initialized
INFO - 2021-04-20 21:55:27 --> Config Class Initialized
INFO - 2021-04-20 21:55:27 --> Hooks Class Initialized
DEBUG - 2021-04-20 21:55:27 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:55:27 --> Utf8 Class Initialized
DEBUG - 2021-04-20 21:55:27 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:55:27 --> Utf8 Class Initialized
INFO - 2021-04-20 21:55:27 --> URI Class Initialized
INFO - 2021-04-20 21:55:27 --> URI Class Initialized
INFO - 2021-04-20 21:55:27 --> Router Class Initialized
INFO - 2021-04-20 21:55:27 --> Router Class Initialized
INFO - 2021-04-20 21:55:27 --> Output Class Initialized
INFO - 2021-04-20 21:55:27 --> Output Class Initialized
INFO - 2021-04-20 21:55:27 --> Security Class Initialized
DEBUG - 2021-04-20 21:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:55:27 --> Input Class Initialized
INFO - 2021-04-20 21:55:27 --> Security Class Initialized
INFO - 2021-04-20 21:55:27 --> Language Class Initialized
DEBUG - 2021-04-20 21:55:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:55:27 --> Input Class Initialized
INFO - 2021-04-20 21:55:27 --> Language Class Initialized
ERROR - 2021-04-20 21:55:27 --> 404 Page Not Found: administrator/Js/sample.js
ERROR - 2021-04-20 21:55:27 --> 404 Page Not Found: administrator/Img/logo.svg
INFO - 2021-04-20 21:55:28 --> Config Class Initialized
INFO - 2021-04-20 21:55:28 --> Hooks Class Initialized
INFO - 2021-04-20 21:55:28 --> Config Class Initialized
INFO - 2021-04-20 21:55:28 --> Hooks Class Initialized
INFO - 2021-04-20 21:55:28 --> Config Class Initialized
DEBUG - 2021-04-20 21:55:28 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:55:28 --> Hooks Class Initialized
INFO - 2021-04-20 21:55:28 --> Utf8 Class Initialized
INFO - 2021-04-20 21:55:28 --> URI Class Initialized
DEBUG - 2021-04-20 21:55:28 --> UTF-8 Support Enabled
DEBUG - 2021-04-20 21:55:28 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:55:28 --> Utf8 Class Initialized
INFO - 2021-04-20 21:55:28 --> Router Class Initialized
INFO - 2021-04-20 21:55:28 --> Utf8 Class Initialized
INFO - 2021-04-20 21:55:28 --> URI Class Initialized
INFO - 2021-04-20 21:55:28 --> URI Class Initialized
INFO - 2021-04-20 21:55:28 --> Output Class Initialized
INFO - 2021-04-20 21:55:28 --> Router Class Initialized
INFO - 2021-04-20 21:55:28 --> Security Class Initialized
INFO - 2021-04-20 21:55:28 --> Router Class Initialized
INFO - 2021-04-20 21:55:28 --> Output Class Initialized
DEBUG - 2021-04-20 21:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:55:28 --> Input Class Initialized
INFO - 2021-04-20 21:55:28 --> Output Class Initialized
INFO - 2021-04-20 21:55:28 --> Language Class Initialized
INFO - 2021-04-20 21:55:28 --> Security Class Initialized
INFO - 2021-04-20 21:55:28 --> Security Class Initialized
DEBUG - 2021-04-20 21:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:55:28 --> Input Class Initialized
ERROR - 2021-04-20 21:55:28 --> 404 Page Not Found: administrator/Css/samples.css
INFO - 2021-04-20 21:55:28 --> Language Class Initialized
DEBUG - 2021-04-20 21:55:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:55:28 --> Input Class Initialized
ERROR - 2021-04-20 21:55:28 --> 404 Page Not Found: administrator/Img/logo.png
INFO - 2021-04-20 21:55:28 --> Language Class Initialized
ERROR - 2021-04-20 21:55:28 --> 404 Page Not Found: administrator/Toolbarconfigurator/lib
INFO - 2021-04-20 21:59:05 --> Config Class Initialized
INFO - 2021-04-20 21:59:05 --> Hooks Class Initialized
DEBUG - 2021-04-20 21:59:05 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:59:05 --> Utf8 Class Initialized
INFO - 2021-04-20 21:59:05 --> URI Class Initialized
INFO - 2021-04-20 21:59:05 --> Router Class Initialized
INFO - 2021-04-20 21:59:05 --> Output Class Initialized
INFO - 2021-04-20 21:59:05 --> Security Class Initialized
DEBUG - 2021-04-20 21:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:59:05 --> Input Class Initialized
INFO - 2021-04-20 21:59:05 --> Language Class Initialized
INFO - 2021-04-20 21:59:05 --> Loader Class Initialized
INFO - 2021-04-20 21:59:05 --> Helper loaded: url_helper
INFO - 2021-04-20 21:59:05 --> Helper loaded: form_helper
INFO - 2021-04-20 21:59:05 --> Helper loaded: common_helper
INFO - 2021-04-20 21:59:05 --> Helper loaded: util_helper
INFO - 2021-04-20 21:59:05 --> Helper loaded: user_helper
INFO - 2021-04-20 21:59:05 --> Database Driver Class Initialized
DEBUG - 2021-04-20 21:59:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 21:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 21:59:05 --> Form Validation Class Initialized
INFO - 2021-04-20 21:59:05 --> Controller Class Initialized
INFO - 2021-04-20 21:59:05 --> Model Class Initialized
INFO - 2021-04-20 21:59:05 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\ckeditor/samples/index.php
INFO - 2021-04-20 21:59:05 --> Final output sent to browser
DEBUG - 2021-04-20 21:59:05 --> Total execution time: 0.0432
INFO - 2021-04-20 21:59:05 --> Config Class Initialized
INFO - 2021-04-20 21:59:05 --> Config Class Initialized
INFO - 2021-04-20 21:59:05 --> Hooks Class Initialized
INFO - 2021-04-20 21:59:05 --> Hooks Class Initialized
DEBUG - 2021-04-20 21:59:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-20 21:59:05 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:59:05 --> Utf8 Class Initialized
INFO - 2021-04-20 21:59:05 --> Utf8 Class Initialized
INFO - 2021-04-20 21:59:05 --> URI Class Initialized
INFO - 2021-04-20 21:59:05 --> URI Class Initialized
INFO - 2021-04-20 21:59:05 --> Router Class Initialized
INFO - 2021-04-20 21:59:05 --> Router Class Initialized
INFO - 2021-04-20 21:59:05 --> Output Class Initialized
INFO - 2021-04-20 21:59:05 --> Output Class Initialized
INFO - 2021-04-20 21:59:05 --> Security Class Initialized
INFO - 2021-04-20 21:59:05 --> Security Class Initialized
DEBUG - 2021-04-20 21:59:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-20 21:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:59:05 --> Input Class Initialized
INFO - 2021-04-20 21:59:05 --> Input Class Initialized
INFO - 2021-04-20 21:59:05 --> Language Class Initialized
INFO - 2021-04-20 21:59:05 --> Language Class Initialized
ERROR - 2021-04-20 21:59:05 --> 404 Page Not Found: Ckeditorjs/index
ERROR - 2021-04-20 21:59:05 --> 404 Page Not Found: administrator/Js/sample.js
INFO - 2021-04-20 21:59:05 --> Config Class Initialized
INFO - 2021-04-20 21:59:05 --> Hooks Class Initialized
INFO - 2021-04-20 21:59:05 --> Config Class Initialized
INFO - 2021-04-20 21:59:05 --> Hooks Class Initialized
DEBUG - 2021-04-20 21:59:05 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:59:05 --> Utf8 Class Initialized
INFO - 2021-04-20 21:59:05 --> URI Class Initialized
DEBUG - 2021-04-20 21:59:05 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:59:05 --> Utf8 Class Initialized
INFO - 2021-04-20 21:59:05 --> Config Class Initialized
INFO - 2021-04-20 21:59:05 --> Hooks Class Initialized
INFO - 2021-04-20 21:59:05 --> Router Class Initialized
INFO - 2021-04-20 21:59:05 --> URI Class Initialized
DEBUG - 2021-04-20 21:59:05 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:59:05 --> Utf8 Class Initialized
INFO - 2021-04-20 21:59:05 --> Output Class Initialized
INFO - 2021-04-20 21:59:05 --> Router Class Initialized
INFO - 2021-04-20 21:59:05 --> URI Class Initialized
INFO - 2021-04-20 21:59:05 --> Security Class Initialized
INFO - 2021-04-20 21:59:05 --> Output Class Initialized
INFO - 2021-04-20 21:59:05 --> Router Class Initialized
DEBUG - 2021-04-20 21:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:59:05 --> Input Class Initialized
INFO - 2021-04-20 21:59:05 --> Security Class Initialized
INFO - 2021-04-20 21:59:05 --> Output Class Initialized
INFO - 2021-04-20 21:59:05 --> Language Class Initialized
DEBUG - 2021-04-20 21:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:59:05 --> Security Class Initialized
INFO - 2021-04-20 21:59:05 --> Input Class Initialized
ERROR - 2021-04-20 21:59:05 --> 404 Page Not Found: administrator/Css/samples.css
DEBUG - 2021-04-20 21:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:59:05 --> Language Class Initialized
INFO - 2021-04-20 21:59:05 --> Input Class Initialized
INFO - 2021-04-20 21:59:05 --> Language Class Initialized
ERROR - 2021-04-20 21:59:05 --> 404 Page Not Found: administrator/Toolbarconfigurator/lib
ERROR - 2021-04-20 21:59:05 --> 404 Page Not Found: administrator/Js/sample.js
INFO - 2021-04-20 21:59:05 --> Config Class Initialized
INFO - 2021-04-20 21:59:05 --> Hooks Class Initialized
INFO - 2021-04-20 21:59:05 --> Config Class Initialized
INFO - 2021-04-20 21:59:05 --> Hooks Class Initialized
INFO - 2021-04-20 21:59:05 --> Config Class Initialized
INFO - 2021-04-20 21:59:05 --> Hooks Class Initialized
DEBUG - 2021-04-20 21:59:05 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:59:05 --> Utf8 Class Initialized
DEBUG - 2021-04-20 21:59:05 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:59:05 --> Utf8 Class Initialized
INFO - 2021-04-20 21:59:05 --> URI Class Initialized
DEBUG - 2021-04-20 21:59:05 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:59:05 --> Utf8 Class Initialized
INFO - 2021-04-20 21:59:05 --> URI Class Initialized
INFO - 2021-04-20 21:59:05 --> URI Class Initialized
INFO - 2021-04-20 21:59:05 --> Router Class Initialized
INFO - 2021-04-20 21:59:05 --> Router Class Initialized
INFO - 2021-04-20 21:59:05 --> Router Class Initialized
INFO - 2021-04-20 21:59:05 --> Output Class Initialized
INFO - 2021-04-20 21:59:05 --> Output Class Initialized
INFO - 2021-04-20 21:59:05 --> Security Class Initialized
INFO - 2021-04-20 21:59:05 --> Output Class Initialized
INFO - 2021-04-20 21:59:05 --> Security Class Initialized
DEBUG - 2021-04-20 21:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:59:05 --> Security Class Initialized
INFO - 2021-04-20 21:59:05 --> Input Class Initialized
DEBUG - 2021-04-20 21:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:59:05 --> Input Class Initialized
INFO - 2021-04-20 21:59:05 --> Language Class Initialized
DEBUG - 2021-04-20 21:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:59:05 --> Input Class Initialized
INFO - 2021-04-20 21:59:05 --> Language Class Initialized
INFO - 2021-04-20 21:59:05 --> Language Class Initialized
ERROR - 2021-04-20 21:59:05 --> 404 Page Not Found: administrator/Css/samples.css
ERROR - 2021-04-20 21:59:05 --> 404 Page Not Found: administrator/Img/logo.svg
ERROR - 2021-04-20 21:59:05 --> 404 Page Not Found: administrator/Toolbarconfigurator/lib
INFO - 2021-04-20 21:59:05 --> Config Class Initialized
INFO - 2021-04-20 21:59:05 --> Hooks Class Initialized
DEBUG - 2021-04-20 21:59:05 --> UTF-8 Support Enabled
INFO - 2021-04-20 21:59:05 --> Utf8 Class Initialized
INFO - 2021-04-20 21:59:05 --> URI Class Initialized
INFO - 2021-04-20 21:59:05 --> Router Class Initialized
INFO - 2021-04-20 21:59:05 --> Output Class Initialized
INFO - 2021-04-20 21:59:05 --> Security Class Initialized
DEBUG - 2021-04-20 21:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 21:59:05 --> Input Class Initialized
INFO - 2021-04-20 21:59:05 --> Language Class Initialized
ERROR - 2021-04-20 21:59:05 --> 404 Page Not Found: administrator/Img/logo.png
INFO - 2021-04-20 22:07:49 --> Config Class Initialized
INFO - 2021-04-20 22:07:49 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:07:49 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:07:49 --> Utf8 Class Initialized
INFO - 2021-04-20 22:07:49 --> URI Class Initialized
INFO - 2021-04-20 22:07:49 --> Router Class Initialized
INFO - 2021-04-20 22:07:49 --> Output Class Initialized
INFO - 2021-04-20 22:07:49 --> Security Class Initialized
DEBUG - 2021-04-20 22:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:07:49 --> Input Class Initialized
INFO - 2021-04-20 22:07:49 --> Language Class Initialized
INFO - 2021-04-20 22:07:49 --> Loader Class Initialized
INFO - 2021-04-20 22:07:49 --> Helper loaded: url_helper
INFO - 2021-04-20 22:07:49 --> Helper loaded: form_helper
INFO - 2021-04-20 22:07:49 --> Helper loaded: common_helper
INFO - 2021-04-20 22:07:49 --> Helper loaded: util_helper
INFO - 2021-04-20 22:07:49 --> Helper loaded: user_helper
INFO - 2021-04-20 22:07:49 --> Database Driver Class Initialized
DEBUG - 2021-04-20 22:07:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 22:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 22:07:49 --> Form Validation Class Initialized
INFO - 2021-04-20 22:07:49 --> Controller Class Initialized
INFO - 2021-04-20 22:07:49 --> Model Class Initialized
INFO - 2021-04-20 22:07:49 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\ckeditor/samples/index.php
INFO - 2021-04-20 22:07:49 --> Final output sent to browser
DEBUG - 2021-04-20 22:07:49 --> Total execution time: 0.0401
INFO - 2021-04-20 22:07:49 --> Config Class Initialized
INFO - 2021-04-20 22:07:49 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:07:49 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:07:49 --> Utf8 Class Initialized
INFO - 2021-04-20 22:07:49 --> URI Class Initialized
INFO - 2021-04-20 22:07:49 --> Router Class Initialized
INFO - 2021-04-20 22:07:49 --> Output Class Initialized
INFO - 2021-04-20 22:07:49 --> Security Class Initialized
DEBUG - 2021-04-20 22:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:07:49 --> Input Class Initialized
INFO - 2021-04-20 22:07:49 --> Language Class Initialized
ERROR - 2021-04-20 22:07:49 --> 404 Page Not Found: Ckeditorjs/index
INFO - 2021-04-20 22:07:49 --> Config Class Initialized
INFO - 2021-04-20 22:07:49 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:07:49 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:07:49 --> Utf8 Class Initialized
INFO - 2021-04-20 22:07:49 --> URI Class Initialized
INFO - 2021-04-20 22:07:49 --> Router Class Initialized
INFO - 2021-04-20 22:07:49 --> Output Class Initialized
INFO - 2021-04-20 22:07:49 --> Security Class Initialized
DEBUG - 2021-04-20 22:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:07:49 --> Input Class Initialized
INFO - 2021-04-20 22:07:49 --> Language Class Initialized
ERROR - 2021-04-20 22:07:49 --> 404 Page Not Found: administrator/Img/logo.svg
INFO - 2021-04-20 22:07:49 --> Config Class Initialized
INFO - 2021-04-20 22:07:49 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:07:49 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:07:49 --> Utf8 Class Initialized
INFO - 2021-04-20 22:07:49 --> URI Class Initialized
INFO - 2021-04-20 22:07:49 --> Router Class Initialized
INFO - 2021-04-20 22:07:49 --> Output Class Initialized
INFO - 2021-04-20 22:07:49 --> Security Class Initialized
DEBUG - 2021-04-20 22:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:07:49 --> Input Class Initialized
INFO - 2021-04-20 22:07:49 --> Language Class Initialized
ERROR - 2021-04-20 22:07:49 --> 404 Page Not Found: administrator/Img/logo.png
INFO - 2021-04-20 22:09:48 --> Config Class Initialized
INFO - 2021-04-20 22:09:48 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:09:48 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:09:48 --> Utf8 Class Initialized
INFO - 2021-04-20 22:09:48 --> URI Class Initialized
INFO - 2021-04-20 22:09:48 --> Router Class Initialized
INFO - 2021-04-20 22:09:48 --> Output Class Initialized
INFO - 2021-04-20 22:09:48 --> Security Class Initialized
DEBUG - 2021-04-20 22:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:09:48 --> Input Class Initialized
INFO - 2021-04-20 22:09:48 --> Language Class Initialized
INFO - 2021-04-20 22:09:48 --> Loader Class Initialized
INFO - 2021-04-20 22:09:48 --> Helper loaded: url_helper
INFO - 2021-04-20 22:09:48 --> Helper loaded: form_helper
INFO - 2021-04-20 22:09:48 --> Helper loaded: common_helper
INFO - 2021-04-20 22:09:48 --> Helper loaded: util_helper
INFO - 2021-04-20 22:09:48 --> Helper loaded: user_helper
INFO - 2021-04-20 22:09:48 --> Database Driver Class Initialized
DEBUG - 2021-04-20 22:09:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 22:09:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 22:09:48 --> Form Validation Class Initialized
INFO - 2021-04-20 22:09:48 --> Controller Class Initialized
INFO - 2021-04-20 22:09:48 --> Model Class Initialized
INFO - 2021-04-20 22:09:48 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\ckeditor/samples/index.php
INFO - 2021-04-20 22:09:48 --> Final output sent to browser
DEBUG - 2021-04-20 22:09:48 --> Total execution time: 0.0281
INFO - 2021-04-20 22:09:48 --> Config Class Initialized
INFO - 2021-04-20 22:09:48 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:09:48 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:09:48 --> Utf8 Class Initialized
INFO - 2021-04-20 22:09:48 --> URI Class Initialized
INFO - 2021-04-20 22:09:48 --> Router Class Initialized
INFO - 2021-04-20 22:09:48 --> Output Class Initialized
INFO - 2021-04-20 22:09:48 --> Security Class Initialized
DEBUG - 2021-04-20 22:09:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:09:48 --> Input Class Initialized
INFO - 2021-04-20 22:09:48 --> Language Class Initialized
ERROR - 2021-04-20 22:09:48 --> 404 Page Not Found: Ckeditorjs/index
INFO - 2021-04-20 22:20:52 --> Config Class Initialized
INFO - 2021-04-20 22:20:52 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:20:52 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:20:52 --> Utf8 Class Initialized
INFO - 2021-04-20 22:20:52 --> URI Class Initialized
INFO - 2021-04-20 22:20:52 --> Router Class Initialized
INFO - 2021-04-20 22:20:52 --> Output Class Initialized
INFO - 2021-04-20 22:20:52 --> Security Class Initialized
DEBUG - 2021-04-20 22:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:20:52 --> Input Class Initialized
INFO - 2021-04-20 22:20:52 --> Language Class Initialized
INFO - 2021-04-20 22:20:52 --> Loader Class Initialized
INFO - 2021-04-20 22:20:52 --> Helper loaded: url_helper
INFO - 2021-04-20 22:20:52 --> Helper loaded: form_helper
INFO - 2021-04-20 22:20:52 --> Helper loaded: common_helper
INFO - 2021-04-20 22:20:52 --> Helper loaded: util_helper
INFO - 2021-04-20 22:20:52 --> Helper loaded: user_helper
INFO - 2021-04-20 22:20:52 --> Database Driver Class Initialized
DEBUG - 2021-04-20 22:20:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 22:20:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 22:20:52 --> Form Validation Class Initialized
INFO - 2021-04-20 22:20:52 --> Controller Class Initialized
INFO - 2021-04-20 22:20:52 --> Model Class Initialized
INFO - 2021-04-20 22:20:52 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\ckeditor/samples/index.php
INFO - 2021-04-20 22:20:52 --> Final output sent to browser
DEBUG - 2021-04-20 22:20:52 --> Total execution time: 0.0307
INFO - 2021-04-20 22:20:52 --> Config Class Initialized
INFO - 2021-04-20 22:20:52 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:20:52 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:20:52 --> Utf8 Class Initialized
INFO - 2021-04-20 22:20:52 --> URI Class Initialized
INFO - 2021-04-20 22:20:52 --> Router Class Initialized
INFO - 2021-04-20 22:20:52 --> Output Class Initialized
INFO - 2021-04-20 22:20:52 --> Security Class Initialized
DEBUG - 2021-04-20 22:20:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:20:52 --> Input Class Initialized
INFO - 2021-04-20 22:20:52 --> Language Class Initialized
ERROR - 2021-04-20 22:20:52 --> 404 Page Not Found: Ckeditorjs/index
INFO - 2021-04-20 22:22:55 --> Config Class Initialized
INFO - 2021-04-20 22:22:55 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:22:55 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:22:55 --> Utf8 Class Initialized
INFO - 2021-04-20 22:22:55 --> URI Class Initialized
INFO - 2021-04-20 22:22:55 --> Router Class Initialized
INFO - 2021-04-20 22:22:55 --> Output Class Initialized
INFO - 2021-04-20 22:22:55 --> Security Class Initialized
DEBUG - 2021-04-20 22:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:22:55 --> Input Class Initialized
INFO - 2021-04-20 22:22:55 --> Language Class Initialized
INFO - 2021-04-20 22:22:55 --> Loader Class Initialized
INFO - 2021-04-20 22:22:55 --> Helper loaded: url_helper
INFO - 2021-04-20 22:22:55 --> Helper loaded: form_helper
INFO - 2021-04-20 22:22:55 --> Helper loaded: common_helper
INFO - 2021-04-20 22:22:55 --> Helper loaded: util_helper
INFO - 2021-04-20 22:22:55 --> Helper loaded: user_helper
INFO - 2021-04-20 22:22:55 --> Database Driver Class Initialized
DEBUG - 2021-04-20 22:22:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 22:22:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 22:22:55 --> Form Validation Class Initialized
INFO - 2021-04-20 22:22:55 --> Controller Class Initialized
INFO - 2021-04-20 22:22:55 --> Model Class Initialized
INFO - 2021-04-20 22:22:55 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\ckeditor/samples/index.php
INFO - 2021-04-20 22:22:55 --> Final output sent to browser
DEBUG - 2021-04-20 22:22:55 --> Total execution time: 0.0297
INFO - 2021-04-20 22:22:55 --> Config Class Initialized
INFO - 2021-04-20 22:22:55 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:22:55 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:22:55 --> Utf8 Class Initialized
INFO - 2021-04-20 22:22:55 --> URI Class Initialized
INFO - 2021-04-20 22:22:55 --> Router Class Initialized
INFO - 2021-04-20 22:22:55 --> Output Class Initialized
INFO - 2021-04-20 22:22:55 --> Security Class Initialized
DEBUG - 2021-04-20 22:22:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:22:55 --> Input Class Initialized
INFO - 2021-04-20 22:22:55 --> Language Class Initialized
ERROR - 2021-04-20 22:22:55 --> 404 Page Not Found: Ckeditorjs/index
INFO - 2021-04-20 22:29:14 --> Config Class Initialized
INFO - 2021-04-20 22:29:14 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:29:14 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:29:14 --> Utf8 Class Initialized
INFO - 2021-04-20 22:29:14 --> URI Class Initialized
INFO - 2021-04-20 22:29:14 --> Router Class Initialized
INFO - 2021-04-20 22:29:14 --> Output Class Initialized
INFO - 2021-04-20 22:29:14 --> Security Class Initialized
DEBUG - 2021-04-20 22:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:29:14 --> Input Class Initialized
INFO - 2021-04-20 22:29:14 --> Language Class Initialized
INFO - 2021-04-20 22:29:14 --> Loader Class Initialized
INFO - 2021-04-20 22:29:14 --> Helper loaded: url_helper
INFO - 2021-04-20 22:29:14 --> Helper loaded: form_helper
INFO - 2021-04-20 22:29:14 --> Helper loaded: common_helper
INFO - 2021-04-20 22:29:14 --> Helper loaded: util_helper
INFO - 2021-04-20 22:29:14 --> Helper loaded: user_helper
INFO - 2021-04-20 22:29:14 --> Database Driver Class Initialized
DEBUG - 2021-04-20 22:29:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 22:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 22:29:14 --> Form Validation Class Initialized
INFO - 2021-04-20 22:29:14 --> Controller Class Initialized
INFO - 2021-04-20 22:29:14 --> Model Class Initialized
INFO - 2021-04-20 22:29:14 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\ckeditor/samples/index.php
INFO - 2021-04-20 22:29:14 --> Final output sent to browser
DEBUG - 2021-04-20 22:29:14 --> Total execution time: 0.0306
INFO - 2021-04-20 22:29:14 --> Config Class Initialized
INFO - 2021-04-20 22:29:14 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:29:14 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:29:14 --> Utf8 Class Initialized
INFO - 2021-04-20 22:29:14 --> URI Class Initialized
INFO - 2021-04-20 22:29:14 --> Router Class Initialized
INFO - 2021-04-20 22:29:14 --> Output Class Initialized
INFO - 2021-04-20 22:29:14 --> Security Class Initialized
DEBUG - 2021-04-20 22:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:29:14 --> Input Class Initialized
INFO - 2021-04-20 22:29:14 --> Language Class Initialized
ERROR - 2021-04-20 22:29:14 --> 404 Page Not Found: Ckeditorjs/index
INFO - 2021-04-20 22:29:18 --> Config Class Initialized
INFO - 2021-04-20 22:29:18 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:29:18 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:29:18 --> Utf8 Class Initialized
INFO - 2021-04-20 22:29:18 --> URI Class Initialized
INFO - 2021-04-20 22:29:18 --> Router Class Initialized
INFO - 2021-04-20 22:29:18 --> Output Class Initialized
INFO - 2021-04-20 22:29:18 --> Security Class Initialized
DEBUG - 2021-04-20 22:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:29:18 --> Input Class Initialized
INFO - 2021-04-20 22:29:18 --> Language Class Initialized
INFO - 2021-04-20 22:29:18 --> Loader Class Initialized
INFO - 2021-04-20 22:29:18 --> Helper loaded: url_helper
INFO - 2021-04-20 22:29:18 --> Helper loaded: form_helper
INFO - 2021-04-20 22:29:18 --> Helper loaded: common_helper
INFO - 2021-04-20 22:29:18 --> Helper loaded: util_helper
INFO - 2021-04-20 22:29:18 --> Helper loaded: user_helper
INFO - 2021-04-20 22:29:18 --> Database Driver Class Initialized
DEBUG - 2021-04-20 22:29:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 22:29:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 22:29:18 --> Form Validation Class Initialized
INFO - 2021-04-20 22:29:18 --> Controller Class Initialized
INFO - 2021-04-20 22:29:18 --> Model Class Initialized
INFO - 2021-04-20 22:29:18 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\ckeditor/samples/index.php
INFO - 2021-04-20 22:29:18 --> Final output sent to browser
DEBUG - 2021-04-20 22:29:18 --> Total execution time: 0.0379
INFO - 2021-04-20 22:29:18 --> Config Class Initialized
INFO - 2021-04-20 22:29:18 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:29:18 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:29:18 --> Utf8 Class Initialized
INFO - 2021-04-20 22:29:18 --> URI Class Initialized
INFO - 2021-04-20 22:29:18 --> Router Class Initialized
INFO - 2021-04-20 22:29:18 --> Output Class Initialized
INFO - 2021-04-20 22:29:18 --> Security Class Initialized
DEBUG - 2021-04-20 22:29:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:29:18 --> Input Class Initialized
INFO - 2021-04-20 22:29:18 --> Language Class Initialized
ERROR - 2021-04-20 22:29:18 --> 404 Page Not Found: Ckeditorjs/index
INFO - 2021-04-20 22:31:12 --> Config Class Initialized
INFO - 2021-04-20 22:31:12 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:31:12 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:31:12 --> Utf8 Class Initialized
INFO - 2021-04-20 22:31:12 --> URI Class Initialized
DEBUG - 2021-04-20 22:31:12 --> No URI present. Default controller set.
INFO - 2021-04-20 22:31:12 --> Router Class Initialized
INFO - 2021-04-20 22:31:12 --> Output Class Initialized
INFO - 2021-04-20 22:31:12 --> Security Class Initialized
DEBUG - 2021-04-20 22:31:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:31:12 --> Input Class Initialized
INFO - 2021-04-20 22:31:12 --> Language Class Initialized
INFO - 2021-04-20 22:31:12 --> Loader Class Initialized
INFO - 2021-04-20 22:31:12 --> Helper loaded: url_helper
INFO - 2021-04-20 22:31:12 --> Helper loaded: form_helper
INFO - 2021-04-20 22:31:12 --> Helper loaded: common_helper
INFO - 2021-04-20 22:31:12 --> Helper loaded: util_helper
INFO - 2021-04-20 22:31:12 --> Helper loaded: user_helper
INFO - 2021-04-20 22:31:12 --> Database Driver Class Initialized
DEBUG - 2021-04-20 22:31:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 22:31:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 22:31:12 --> Form Validation Class Initialized
INFO - 2021-04-20 22:31:12 --> Controller Class Initialized
INFO - 2021-04-20 22:31:12 --> Model Class Initialized
INFO - 2021-04-20 22:31:12 --> Model Class Initialized
INFO - 2021-04-20 22:31:12 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-20 22:31:12 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-20 22:31:12 --> Final output sent to browser
DEBUG - 2021-04-20 22:31:12 --> Total execution time: 0.0896
INFO - 2021-04-20 22:31:24 --> Config Class Initialized
INFO - 2021-04-20 22:31:24 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:31:24 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:31:24 --> Utf8 Class Initialized
INFO - 2021-04-20 22:31:24 --> URI Class Initialized
INFO - 2021-04-20 22:31:24 --> Router Class Initialized
INFO - 2021-04-20 22:31:24 --> Output Class Initialized
INFO - 2021-04-20 22:31:24 --> Security Class Initialized
DEBUG - 2021-04-20 22:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:31:24 --> Input Class Initialized
INFO - 2021-04-20 22:31:24 --> Language Class Initialized
INFO - 2021-04-20 22:31:24 --> Loader Class Initialized
INFO - 2021-04-20 22:31:24 --> Helper loaded: url_helper
INFO - 2021-04-20 22:31:24 --> Helper loaded: form_helper
INFO - 2021-04-20 22:31:24 --> Helper loaded: common_helper
INFO - 2021-04-20 22:31:24 --> Helper loaded: util_helper
INFO - 2021-04-20 22:31:24 --> Helper loaded: user_helper
INFO - 2021-04-20 22:31:24 --> Database Driver Class Initialized
DEBUG - 2021-04-20 22:31:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 22:31:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 22:31:24 --> Form Validation Class Initialized
INFO - 2021-04-20 22:31:24 --> Controller Class Initialized
INFO - 2021-04-20 22:31:24 --> Model Class Initialized
INFO - 2021-04-20 22:31:24 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\ckeditor/samples/index.php
INFO - 2021-04-20 22:31:24 --> Final output sent to browser
DEBUG - 2021-04-20 22:31:24 --> Total execution time: 0.0391
INFO - 2021-04-20 22:31:24 --> Config Class Initialized
INFO - 2021-04-20 22:31:24 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:31:24 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:31:24 --> Utf8 Class Initialized
INFO - 2021-04-20 22:31:24 --> URI Class Initialized
INFO - 2021-04-20 22:31:24 --> Router Class Initialized
INFO - 2021-04-20 22:31:24 --> Output Class Initialized
INFO - 2021-04-20 22:31:24 --> Security Class Initialized
DEBUG - 2021-04-20 22:31:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:31:24 --> Input Class Initialized
INFO - 2021-04-20 22:31:24 --> Language Class Initialized
ERROR - 2021-04-20 22:31:24 --> 404 Page Not Found: Ckeditorjs/index
INFO - 2021-04-20 22:32:05 --> Config Class Initialized
INFO - 2021-04-20 22:32:05 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:32:05 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:32:05 --> Utf8 Class Initialized
INFO - 2021-04-20 22:32:05 --> URI Class Initialized
INFO - 2021-04-20 22:32:05 --> Router Class Initialized
INFO - 2021-04-20 22:32:05 --> Output Class Initialized
INFO - 2021-04-20 22:32:05 --> Security Class Initialized
DEBUG - 2021-04-20 22:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:32:05 --> Input Class Initialized
INFO - 2021-04-20 22:32:05 --> Language Class Initialized
INFO - 2021-04-20 22:32:05 --> Loader Class Initialized
INFO - 2021-04-20 22:32:05 --> Helper loaded: url_helper
INFO - 2021-04-20 22:32:05 --> Helper loaded: form_helper
INFO - 2021-04-20 22:32:05 --> Helper loaded: common_helper
INFO - 2021-04-20 22:32:05 --> Helper loaded: util_helper
INFO - 2021-04-20 22:32:05 --> Helper loaded: user_helper
INFO - 2021-04-20 22:32:05 --> Database Driver Class Initialized
DEBUG - 2021-04-20 22:32:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 22:32:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 22:32:05 --> Form Validation Class Initialized
INFO - 2021-04-20 22:32:05 --> Controller Class Initialized
INFO - 2021-04-20 22:32:05 --> Model Class Initialized
INFO - 2021-04-20 22:32:05 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\ckeditor/samples/index.php
INFO - 2021-04-20 22:32:05 --> Final output sent to browser
DEBUG - 2021-04-20 22:32:05 --> Total execution time: 0.0398
INFO - 2021-04-20 22:32:05 --> Config Class Initialized
INFO - 2021-04-20 22:32:05 --> Hooks Class Initialized
INFO - 2021-04-20 22:32:05 --> Config Class Initialized
INFO - 2021-04-20 22:32:05 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:32:05 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:32:05 --> Utf8 Class Initialized
DEBUG - 2021-04-20 22:32:05 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:32:05 --> Utf8 Class Initialized
INFO - 2021-04-20 22:32:05 --> URI Class Initialized
INFO - 2021-04-20 22:32:05 --> URI Class Initialized
INFO - 2021-04-20 22:32:05 --> Router Class Initialized
INFO - 2021-04-20 22:32:05 --> Router Class Initialized
INFO - 2021-04-20 22:32:05 --> Output Class Initialized
INFO - 2021-04-20 22:32:05 --> Output Class Initialized
INFO - 2021-04-20 22:32:05 --> Security Class Initialized
INFO - 2021-04-20 22:32:05 --> Security Class Initialized
DEBUG - 2021-04-20 22:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:32:05 --> Input Class Initialized
INFO - 2021-04-20 22:32:05 --> Language Class Initialized
DEBUG - 2021-04-20 22:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:32:05 --> Input Class Initialized
INFO - 2021-04-20 22:32:05 --> Language Class Initialized
ERROR - 2021-04-20 22:32:05 --> 404 Page Not Found: Plugins/scayt
ERROR - 2021-04-20 22:32:05 --> 404 Page Not Found: Plugins/scayt
INFO - 2021-04-20 22:32:05 --> Config Class Initialized
INFO - 2021-04-20 22:32:05 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:32:05 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:32:05 --> Utf8 Class Initialized
INFO - 2021-04-20 22:32:05 --> URI Class Initialized
INFO - 2021-04-20 22:32:05 --> Router Class Initialized
INFO - 2021-04-20 22:32:05 --> Output Class Initialized
INFO - 2021-04-20 22:32:05 --> Security Class Initialized
INFO - 2021-04-20 22:32:05 --> Config Class Initialized
INFO - 2021-04-20 22:32:05 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:32:05 --> Input Class Initialized
INFO - 2021-04-20 22:32:05 --> Language Class Initialized
DEBUG - 2021-04-20 22:32:05 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:32:05 --> Utf8 Class Initialized
ERROR - 2021-04-20 22:32:05 --> 404 Page Not Found: Plugins/tableselection
INFO - 2021-04-20 22:32:05 --> URI Class Initialized
INFO - 2021-04-20 22:32:05 --> Router Class Initialized
INFO - 2021-04-20 22:32:05 --> Output Class Initialized
INFO - 2021-04-20 22:32:05 --> Security Class Initialized
DEBUG - 2021-04-20 22:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:32:05 --> Input Class Initialized
INFO - 2021-04-20 22:32:05 --> Language Class Initialized
ERROR - 2021-04-20 22:32:05 --> 404 Page Not Found: Plugins/dialog
INFO - 2021-04-20 22:32:05 --> Config Class Initialized
INFO - 2021-04-20 22:32:05 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:32:05 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:32:05 --> Utf8 Class Initialized
INFO - 2021-04-20 22:32:05 --> URI Class Initialized
INFO - 2021-04-20 22:32:05 --> Router Class Initialized
INFO - 2021-04-20 22:32:05 --> Output Class Initialized
INFO - 2021-04-20 22:32:05 --> Security Class Initialized
DEBUG - 2021-04-20 22:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:32:05 --> Input Class Initialized
INFO - 2021-04-20 22:32:05 --> Language Class Initialized
ERROR - 2021-04-20 22:32:05 --> 404 Page Not Found: Plugins/tableselection
INFO - 2021-04-20 22:33:02 --> Config Class Initialized
INFO - 2021-04-20 22:33:02 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:33:02 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:33:02 --> Utf8 Class Initialized
INFO - 2021-04-20 22:33:02 --> URI Class Initialized
INFO - 2021-04-20 22:33:02 --> Router Class Initialized
INFO - 2021-04-20 22:33:02 --> Output Class Initialized
INFO - 2021-04-20 22:33:02 --> Security Class Initialized
DEBUG - 2021-04-20 22:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:33:02 --> Input Class Initialized
INFO - 2021-04-20 22:33:02 --> Language Class Initialized
INFO - 2021-04-20 22:33:02 --> Loader Class Initialized
INFO - 2021-04-20 22:33:02 --> Helper loaded: url_helper
INFO - 2021-04-20 22:33:02 --> Helper loaded: form_helper
INFO - 2021-04-20 22:33:02 --> Helper loaded: common_helper
INFO - 2021-04-20 22:33:02 --> Helper loaded: util_helper
INFO - 2021-04-20 22:33:02 --> Helper loaded: user_helper
INFO - 2021-04-20 22:33:02 --> Database Driver Class Initialized
DEBUG - 2021-04-20 22:33:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 22:33:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 22:33:02 --> Form Validation Class Initialized
INFO - 2021-04-20 22:33:02 --> Controller Class Initialized
INFO - 2021-04-20 22:33:02 --> Model Class Initialized
INFO - 2021-04-20 22:33:02 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\ckeditor/samples/index.php
INFO - 2021-04-20 22:33:02 --> Final output sent to browser
DEBUG - 2021-04-20 22:33:02 --> Total execution time: 0.0301
INFO - 2021-04-20 22:33:02 --> Config Class Initialized
INFO - 2021-04-20 22:33:02 --> Hooks Class Initialized
INFO - 2021-04-20 22:33:02 --> Config Class Initialized
INFO - 2021-04-20 22:33:02 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:33:02 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:33:02 --> Utf8 Class Initialized
INFO - 2021-04-20 22:33:02 --> URI Class Initialized
DEBUG - 2021-04-20 22:33:02 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:33:02 --> Router Class Initialized
INFO - 2021-04-20 22:33:02 --> Utf8 Class Initialized
INFO - 2021-04-20 22:33:02 --> URI Class Initialized
INFO - 2021-04-20 22:33:02 --> Output Class Initialized
INFO - 2021-04-20 22:33:02 --> Router Class Initialized
INFO - 2021-04-20 22:33:02 --> Security Class Initialized
DEBUG - 2021-04-20 22:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:33:02 --> Input Class Initialized
INFO - 2021-04-20 22:33:02 --> Config Class Initialized
INFO - 2021-04-20 22:33:02 --> Output Class Initialized
INFO - 2021-04-20 22:33:02 --> Language Class Initialized
INFO - 2021-04-20 22:33:02 --> Hooks Class Initialized
ERROR - 2021-04-20 22:33:02 --> 404 Page Not Found: Plugins/scayt
INFO - 2021-04-20 22:33:02 --> Security Class Initialized
DEBUG - 2021-04-20 22:33:02 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:33:02 --> Utf8 Class Initialized
DEBUG - 2021-04-20 22:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:33:02 --> URI Class Initialized
INFO - 2021-04-20 22:33:02 --> Input Class Initialized
INFO - 2021-04-20 22:33:02 --> Language Class Initialized
INFO - 2021-04-20 22:33:02 --> Router Class Initialized
ERROR - 2021-04-20 22:33:02 --> 404 Page Not Found: Plugins/tableselection
INFO - 2021-04-20 22:33:02 --> Output Class Initialized
INFO - 2021-04-20 22:33:02 --> Security Class Initialized
DEBUG - 2021-04-20 22:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:33:02 --> Input Class Initialized
INFO - 2021-04-20 22:33:02 --> Language Class Initialized
ERROR - 2021-04-20 22:33:02 --> 404 Page Not Found: Plugins/scayt
INFO - 2021-04-20 22:33:02 --> Config Class Initialized
INFO - 2021-04-20 22:33:02 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:33:02 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:33:02 --> Utf8 Class Initialized
INFO - 2021-04-20 22:33:02 --> URI Class Initialized
INFO - 2021-04-20 22:33:02 --> Router Class Initialized
INFO - 2021-04-20 22:33:02 --> Output Class Initialized
INFO - 2021-04-20 22:33:02 --> Security Class Initialized
DEBUG - 2021-04-20 22:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:33:02 --> Input Class Initialized
INFO - 2021-04-20 22:33:02 --> Language Class Initialized
ERROR - 2021-04-20 22:33:02 --> 404 Page Not Found: Plugins/dialog
INFO - 2021-04-20 22:33:02 --> Config Class Initialized
INFO - 2021-04-20 22:33:02 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:33:02 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:33:02 --> Utf8 Class Initialized
INFO - 2021-04-20 22:33:02 --> URI Class Initialized
INFO - 2021-04-20 22:33:02 --> Router Class Initialized
INFO - 2021-04-20 22:33:02 --> Output Class Initialized
INFO - 2021-04-20 22:33:02 --> Security Class Initialized
DEBUG - 2021-04-20 22:33:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:33:02 --> Input Class Initialized
INFO - 2021-04-20 22:33:02 --> Language Class Initialized
ERROR - 2021-04-20 22:33:02 --> 404 Page Not Found: Plugins/tableselection
INFO - 2021-04-20 22:40:25 --> Config Class Initialized
INFO - 2021-04-20 22:40:25 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:40:25 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:40:25 --> Utf8 Class Initialized
INFO - 2021-04-20 22:40:25 --> URI Class Initialized
DEBUG - 2021-04-20 22:40:25 --> No URI present. Default controller set.
INFO - 2021-04-20 22:40:25 --> Router Class Initialized
INFO - 2021-04-20 22:40:25 --> Output Class Initialized
INFO - 2021-04-20 22:40:25 --> Security Class Initialized
DEBUG - 2021-04-20 22:40:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:40:25 --> Input Class Initialized
INFO - 2021-04-20 22:40:25 --> Language Class Initialized
INFO - 2021-04-20 22:40:25 --> Loader Class Initialized
INFO - 2021-04-20 22:40:25 --> Helper loaded: url_helper
INFO - 2021-04-20 22:40:25 --> Helper loaded: form_helper
INFO - 2021-04-20 22:40:25 --> Helper loaded: common_helper
INFO - 2021-04-20 22:40:25 --> Helper loaded: util_helper
INFO - 2021-04-20 22:40:25 --> Helper loaded: user_helper
INFO - 2021-04-20 22:40:25 --> Database Driver Class Initialized
DEBUG - 2021-04-20 22:40:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 22:40:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 22:40:25 --> Form Validation Class Initialized
INFO - 2021-04-20 22:40:25 --> Controller Class Initialized
INFO - 2021-04-20 22:40:25 --> Model Class Initialized
INFO - 2021-04-20 22:40:25 --> Model Class Initialized
INFO - 2021-04-20 22:40:25 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-20 22:40:25 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-20 22:40:25 --> Final output sent to browser
DEBUG - 2021-04-20 22:40:25 --> Total execution time: 0.0409
INFO - 2021-04-20 22:40:27 --> Config Class Initialized
INFO - 2021-04-20 22:40:27 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:40:27 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:40:27 --> Utf8 Class Initialized
INFO - 2021-04-20 22:40:27 --> URI Class Initialized
DEBUG - 2021-04-20 22:40:27 --> No URI present. Default controller set.
INFO - 2021-04-20 22:40:27 --> Router Class Initialized
INFO - 2021-04-20 22:40:27 --> Output Class Initialized
INFO - 2021-04-20 22:40:27 --> Security Class Initialized
DEBUG - 2021-04-20 22:40:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:40:27 --> Input Class Initialized
INFO - 2021-04-20 22:40:27 --> Language Class Initialized
INFO - 2021-04-20 22:40:27 --> Loader Class Initialized
INFO - 2021-04-20 22:40:27 --> Helper loaded: url_helper
INFO - 2021-04-20 22:40:27 --> Helper loaded: form_helper
INFO - 2021-04-20 22:40:27 --> Helper loaded: common_helper
INFO - 2021-04-20 22:40:27 --> Helper loaded: util_helper
INFO - 2021-04-20 22:40:27 --> Helper loaded: user_helper
INFO - 2021-04-20 22:40:27 --> Database Driver Class Initialized
DEBUG - 2021-04-20 22:40:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 22:40:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 22:40:27 --> Form Validation Class Initialized
INFO - 2021-04-20 22:40:27 --> Controller Class Initialized
INFO - 2021-04-20 22:40:27 --> Model Class Initialized
INFO - 2021-04-20 22:40:27 --> Model Class Initialized
INFO - 2021-04-20 22:40:27 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-20 22:40:27 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-20 22:40:27 --> Final output sent to browser
DEBUG - 2021-04-20 22:40:27 --> Total execution time: 0.0275
INFO - 2021-04-20 22:40:29 --> Config Class Initialized
INFO - 2021-04-20 22:40:29 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:40:29 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:40:29 --> Utf8 Class Initialized
INFO - 2021-04-20 22:40:29 --> URI Class Initialized
INFO - 2021-04-20 22:40:29 --> Router Class Initialized
INFO - 2021-04-20 22:40:29 --> Output Class Initialized
INFO - 2021-04-20 22:40:29 --> Security Class Initialized
DEBUG - 2021-04-20 22:40:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:40:29 --> Input Class Initialized
INFO - 2021-04-20 22:40:29 --> Language Class Initialized
ERROR - 2021-04-20 22:40:29 --> 404 Page Not Found: Cms/index
INFO - 2021-04-20 22:40:37 --> Config Class Initialized
INFO - 2021-04-20 22:40:37 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:40:37 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:40:37 --> Utf8 Class Initialized
INFO - 2021-04-20 22:40:37 --> URI Class Initialized
DEBUG - 2021-04-20 22:40:37 --> No URI present. Default controller set.
INFO - 2021-04-20 22:40:37 --> Router Class Initialized
INFO - 2021-04-20 22:40:37 --> Output Class Initialized
INFO - 2021-04-20 22:40:37 --> Security Class Initialized
DEBUG - 2021-04-20 22:40:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:40:37 --> Input Class Initialized
INFO - 2021-04-20 22:40:37 --> Language Class Initialized
INFO - 2021-04-20 22:40:37 --> Loader Class Initialized
INFO - 2021-04-20 22:40:37 --> Helper loaded: url_helper
INFO - 2021-04-20 22:40:37 --> Helper loaded: form_helper
INFO - 2021-04-20 22:40:37 --> Helper loaded: common_helper
INFO - 2021-04-20 22:40:37 --> Helper loaded: util_helper
INFO - 2021-04-20 22:40:37 --> Helper loaded: user_helper
INFO - 2021-04-20 22:40:37 --> Database Driver Class Initialized
DEBUG - 2021-04-20 22:40:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 22:40:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 22:40:37 --> Form Validation Class Initialized
INFO - 2021-04-20 22:40:37 --> Controller Class Initialized
INFO - 2021-04-20 22:40:37 --> Model Class Initialized
INFO - 2021-04-20 22:40:37 --> Model Class Initialized
INFO - 2021-04-20 22:40:37 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-20 22:40:37 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-20 22:40:37 --> Final output sent to browser
DEBUG - 2021-04-20 22:40:37 --> Total execution time: 0.0300
INFO - 2021-04-20 22:41:01 --> Config Class Initialized
INFO - 2021-04-20 22:41:01 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:41:01 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:41:01 --> Utf8 Class Initialized
INFO - 2021-04-20 22:41:01 --> URI Class Initialized
DEBUG - 2021-04-20 22:41:01 --> No URI present. Default controller set.
INFO - 2021-04-20 22:41:01 --> Router Class Initialized
INFO - 2021-04-20 22:41:01 --> Output Class Initialized
INFO - 2021-04-20 22:41:01 --> Security Class Initialized
DEBUG - 2021-04-20 22:41:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:41:01 --> Input Class Initialized
INFO - 2021-04-20 22:41:01 --> Language Class Initialized
INFO - 2021-04-20 22:41:01 --> Loader Class Initialized
INFO - 2021-04-20 22:41:01 --> Helper loaded: url_helper
INFO - 2021-04-20 22:41:01 --> Helper loaded: form_helper
INFO - 2021-04-20 22:41:01 --> Helper loaded: common_helper
INFO - 2021-04-20 22:41:01 --> Helper loaded: util_helper
INFO - 2021-04-20 22:41:01 --> Helper loaded: user_helper
INFO - 2021-04-20 22:41:01 --> Database Driver Class Initialized
DEBUG - 2021-04-20 22:41:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 22:41:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 22:41:01 --> Form Validation Class Initialized
INFO - 2021-04-20 22:41:01 --> Controller Class Initialized
INFO - 2021-04-20 22:41:01 --> Model Class Initialized
INFO - 2021-04-20 22:41:01 --> Model Class Initialized
INFO - 2021-04-20 22:41:01 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-20 22:41:01 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-20 22:41:01 --> Final output sent to browser
DEBUG - 2021-04-20 22:41:01 --> Total execution time: 0.0374
INFO - 2021-04-20 22:41:02 --> Config Class Initialized
INFO - 2021-04-20 22:41:02 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:41:02 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:41:02 --> Utf8 Class Initialized
INFO - 2021-04-20 22:41:02 --> URI Class Initialized
INFO - 2021-04-20 22:41:02 --> Router Class Initialized
INFO - 2021-04-20 22:41:02 --> Output Class Initialized
INFO - 2021-04-20 22:41:02 --> Security Class Initialized
DEBUG - 2021-04-20 22:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:41:02 --> Input Class Initialized
INFO - 2021-04-20 22:41:02 --> Language Class Initialized
INFO - 2021-04-20 22:41:02 --> Loader Class Initialized
INFO - 2021-04-20 22:41:02 --> Helper loaded: url_helper
INFO - 2021-04-20 22:41:02 --> Helper loaded: form_helper
INFO - 2021-04-20 22:41:02 --> Helper loaded: common_helper
INFO - 2021-04-20 22:41:02 --> Helper loaded: util_helper
INFO - 2021-04-20 22:41:02 --> Helper loaded: user_helper
INFO - 2021-04-20 22:41:02 --> Database Driver Class Initialized
DEBUG - 2021-04-20 22:41:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 22:41:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 22:41:02 --> Form Validation Class Initialized
INFO - 2021-04-20 22:41:02 --> Controller Class Initialized
INFO - 2021-04-20 22:41:02 --> Model Class Initialized
INFO - 2021-04-20 22:41:02 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\viewaccount.php
INFO - 2021-04-20 22:41:02 --> Final output sent to browser
DEBUG - 2021-04-20 22:41:02 --> Total execution time: 0.0305
INFO - 2021-04-20 22:41:02 --> Config Class Initialized
INFO - 2021-04-20 22:41:02 --> Config Class Initialized
INFO - 2021-04-20 22:41:02 --> Hooks Class Initialized
INFO - 2021-04-20 22:41:02 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:41:02 --> UTF-8 Support Enabled
DEBUG - 2021-04-20 22:41:02 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:41:02 --> Utf8 Class Initialized
INFO - 2021-04-20 22:41:02 --> Utf8 Class Initialized
INFO - 2021-04-20 22:41:02 --> URI Class Initialized
INFO - 2021-04-20 22:41:02 --> URI Class Initialized
INFO - 2021-04-20 22:41:02 --> Router Class Initialized
INFO - 2021-04-20 22:41:02 --> Router Class Initialized
INFO - 2021-04-20 22:41:02 --> Output Class Initialized
INFO - 2021-04-20 22:41:02 --> Output Class Initialized
INFO - 2021-04-20 22:41:02 --> Security Class Initialized
INFO - 2021-04-20 22:41:02 --> Security Class Initialized
DEBUG - 2021-04-20 22:41:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-20 22:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:41:02 --> Input Class Initialized
INFO - 2021-04-20 22:41:02 --> Input Class Initialized
INFO - 2021-04-20 22:41:02 --> Language Class Initialized
INFO - 2021-04-20 22:41:02 --> Language Class Initialized
ERROR - 2021-04-20 22:41:02 --> 404 Page Not Found: Assets/plugins
ERROR - 2021-04-20 22:41:02 --> 404 Page Not Found: Assets/plugins
INFO - 2021-04-20 22:41:02 --> Config Class Initialized
INFO - 2021-04-20 22:41:02 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:41:02 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:41:02 --> Utf8 Class Initialized
INFO - 2021-04-20 22:41:02 --> URI Class Initialized
INFO - 2021-04-20 22:41:02 --> Router Class Initialized
INFO - 2021-04-20 22:41:02 --> Output Class Initialized
INFO - 2021-04-20 22:41:02 --> Security Class Initialized
DEBUG - 2021-04-20 22:41:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:41:02 --> Input Class Initialized
INFO - 2021-04-20 22:41:02 --> Language Class Initialized
ERROR - 2021-04-20 22:41:02 --> 404 Page Not Found: Assets/plugins
INFO - 2021-04-20 22:41:10 --> Config Class Initialized
INFO - 2021-04-20 22:41:10 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:41:10 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:41:10 --> Utf8 Class Initialized
INFO - 2021-04-20 22:41:10 --> URI Class Initialized
DEBUG - 2021-04-20 22:41:10 --> No URI present. Default controller set.
INFO - 2021-04-20 22:41:10 --> Router Class Initialized
INFO - 2021-04-20 22:41:10 --> Output Class Initialized
INFO - 2021-04-20 22:41:10 --> Security Class Initialized
DEBUG - 2021-04-20 22:41:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:41:10 --> Input Class Initialized
INFO - 2021-04-20 22:41:10 --> Language Class Initialized
INFO - 2021-04-20 22:41:10 --> Loader Class Initialized
INFO - 2021-04-20 22:41:10 --> Helper loaded: url_helper
INFO - 2021-04-20 22:41:10 --> Helper loaded: form_helper
INFO - 2021-04-20 22:41:10 --> Helper loaded: common_helper
INFO - 2021-04-20 22:41:10 --> Helper loaded: util_helper
INFO - 2021-04-20 22:41:10 --> Helper loaded: user_helper
INFO - 2021-04-20 22:41:10 --> Database Driver Class Initialized
DEBUG - 2021-04-20 22:41:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 22:41:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 22:41:10 --> Form Validation Class Initialized
INFO - 2021-04-20 22:41:10 --> Controller Class Initialized
INFO - 2021-04-20 22:41:10 --> Model Class Initialized
INFO - 2021-04-20 22:41:10 --> Model Class Initialized
INFO - 2021-04-20 22:41:10 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-20 22:41:10 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-20 22:41:10 --> Final output sent to browser
DEBUG - 2021-04-20 22:41:10 --> Total execution time: 0.0294
INFO - 2021-04-20 22:42:11 --> Config Class Initialized
INFO - 2021-04-20 22:42:11 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:42:11 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:42:11 --> Utf8 Class Initialized
INFO - 2021-04-20 22:42:11 --> URI Class Initialized
DEBUG - 2021-04-20 22:42:11 --> No URI present. Default controller set.
INFO - 2021-04-20 22:42:11 --> Router Class Initialized
INFO - 2021-04-20 22:42:11 --> Output Class Initialized
INFO - 2021-04-20 22:42:11 --> Security Class Initialized
DEBUG - 2021-04-20 22:42:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:42:11 --> Input Class Initialized
INFO - 2021-04-20 22:42:11 --> Language Class Initialized
INFO - 2021-04-20 22:42:11 --> Loader Class Initialized
INFO - 2021-04-20 22:42:11 --> Helper loaded: url_helper
INFO - 2021-04-20 22:42:11 --> Helper loaded: form_helper
INFO - 2021-04-20 22:42:11 --> Helper loaded: common_helper
INFO - 2021-04-20 22:42:11 --> Helper loaded: util_helper
INFO - 2021-04-20 22:42:11 --> Helper loaded: user_helper
INFO - 2021-04-20 22:42:11 --> Database Driver Class Initialized
DEBUG - 2021-04-20 22:42:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 22:42:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 22:42:11 --> Form Validation Class Initialized
INFO - 2021-04-20 22:42:11 --> Controller Class Initialized
INFO - 2021-04-20 22:42:11 --> Model Class Initialized
INFO - 2021-04-20 22:42:11 --> Model Class Initialized
INFO - 2021-04-20 22:42:11 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-20 22:42:11 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-20 22:42:11 --> Final output sent to browser
DEBUG - 2021-04-20 22:42:11 --> Total execution time: 0.0295
INFO - 2021-04-20 22:42:12 --> Config Class Initialized
INFO - 2021-04-20 22:42:12 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:42:12 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:42:12 --> Utf8 Class Initialized
INFO - 2021-04-20 22:42:12 --> URI Class Initialized
DEBUG - 2021-04-20 22:42:12 --> No URI present. Default controller set.
INFO - 2021-04-20 22:42:12 --> Router Class Initialized
INFO - 2021-04-20 22:42:12 --> Output Class Initialized
INFO - 2021-04-20 22:42:12 --> Security Class Initialized
DEBUG - 2021-04-20 22:42:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:42:12 --> Input Class Initialized
INFO - 2021-04-20 22:42:12 --> Language Class Initialized
INFO - 2021-04-20 22:42:12 --> Loader Class Initialized
INFO - 2021-04-20 22:42:12 --> Helper loaded: url_helper
INFO - 2021-04-20 22:42:12 --> Helper loaded: form_helper
INFO - 2021-04-20 22:42:12 --> Helper loaded: common_helper
INFO - 2021-04-20 22:42:12 --> Helper loaded: util_helper
INFO - 2021-04-20 22:42:12 --> Helper loaded: user_helper
INFO - 2021-04-20 22:42:12 --> Database Driver Class Initialized
DEBUG - 2021-04-20 22:42:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 22:42:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 22:42:12 --> Form Validation Class Initialized
INFO - 2021-04-20 22:42:12 --> Controller Class Initialized
INFO - 2021-04-20 22:42:12 --> Model Class Initialized
INFO - 2021-04-20 22:42:12 --> Model Class Initialized
INFO - 2021-04-20 22:42:12 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-20 22:42:12 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-20 22:42:12 --> Final output sent to browser
DEBUG - 2021-04-20 22:42:12 --> Total execution time: 0.0312
INFO - 2021-04-20 22:42:13 --> Config Class Initialized
INFO - 2021-04-20 22:42:13 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:42:13 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:42:13 --> Utf8 Class Initialized
INFO - 2021-04-20 22:42:13 --> URI Class Initialized
INFO - 2021-04-20 22:42:13 --> Router Class Initialized
INFO - 2021-04-20 22:42:13 --> Output Class Initialized
INFO - 2021-04-20 22:42:13 --> Security Class Initialized
DEBUG - 2021-04-20 22:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:42:13 --> Input Class Initialized
INFO - 2021-04-20 22:42:13 --> Language Class Initialized
INFO - 2021-04-20 22:42:13 --> Loader Class Initialized
INFO - 2021-04-20 22:42:13 --> Helper loaded: url_helper
INFO - 2021-04-20 22:42:13 --> Helper loaded: form_helper
INFO - 2021-04-20 22:42:13 --> Helper loaded: common_helper
INFO - 2021-04-20 22:42:13 --> Helper loaded: util_helper
INFO - 2021-04-20 22:42:13 --> Helper loaded: user_helper
INFO - 2021-04-20 22:42:13 --> Database Driver Class Initialized
DEBUG - 2021-04-20 22:42:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 22:42:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 22:42:13 --> Form Validation Class Initialized
INFO - 2021-04-20 22:42:13 --> Controller Class Initialized
INFO - 2021-04-20 22:42:13 --> Model Class Initialized
INFO - 2021-04-20 22:42:13 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\ckeditor/samples/index.php
INFO - 2021-04-20 22:42:13 --> Final output sent to browser
DEBUG - 2021-04-20 22:42:13 --> Total execution time: 0.0289
INFO - 2021-04-20 22:42:13 --> Config Class Initialized
INFO - 2021-04-20 22:42:13 --> Hooks Class Initialized
INFO - 2021-04-20 22:42:13 --> Config Class Initialized
INFO - 2021-04-20 22:42:13 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:42:13 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:42:13 --> Utf8 Class Initialized
DEBUG - 2021-04-20 22:42:13 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:42:13 --> Utf8 Class Initialized
INFO - 2021-04-20 22:42:13 --> URI Class Initialized
INFO - 2021-04-20 22:42:13 --> URI Class Initialized
INFO - 2021-04-20 22:42:13 --> Router Class Initialized
INFO - 2021-04-20 22:42:13 --> Router Class Initialized
INFO - 2021-04-20 22:42:13 --> Output Class Initialized
INFO - 2021-04-20 22:42:13 --> Output Class Initialized
INFO - 2021-04-20 22:42:13 --> Security Class Initialized
INFO - 2021-04-20 22:42:13 --> Security Class Initialized
DEBUG - 2021-04-20 22:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:42:13 --> Input Class Initialized
DEBUG - 2021-04-20 22:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:42:13 --> Language Class Initialized
INFO - 2021-04-20 22:42:13 --> Input Class Initialized
INFO - 2021-04-20 22:42:13 --> Language Class Initialized
ERROR - 2021-04-20 22:42:13 --> 404 Page Not Found: Plugins/scayt
ERROR - 2021-04-20 22:42:13 --> 404 Page Not Found: Plugins/scayt
INFO - 2021-04-20 22:42:13 --> Config Class Initialized
INFO - 2021-04-20 22:42:13 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:42:13 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:42:13 --> Utf8 Class Initialized
INFO - 2021-04-20 22:42:13 --> URI Class Initialized
INFO - 2021-04-20 22:42:13 --> Router Class Initialized
INFO - 2021-04-20 22:42:13 --> Config Class Initialized
INFO - 2021-04-20 22:42:13 --> Hooks Class Initialized
INFO - 2021-04-20 22:42:13 --> Output Class Initialized
DEBUG - 2021-04-20 22:42:13 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:42:13 --> Security Class Initialized
INFO - 2021-04-20 22:42:13 --> Utf8 Class Initialized
DEBUG - 2021-04-20 22:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:42:13 --> Input Class Initialized
INFO - 2021-04-20 22:42:13 --> URI Class Initialized
INFO - 2021-04-20 22:42:13 --> Language Class Initialized
INFO - 2021-04-20 22:42:13 --> Router Class Initialized
ERROR - 2021-04-20 22:42:13 --> 404 Page Not Found: Plugins/tableselection
INFO - 2021-04-20 22:42:13 --> Output Class Initialized
INFO - 2021-04-20 22:42:13 --> Security Class Initialized
DEBUG - 2021-04-20 22:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:42:13 --> Input Class Initialized
INFO - 2021-04-20 22:42:13 --> Language Class Initialized
ERROR - 2021-04-20 22:42:13 --> 404 Page Not Found: Plugins/dialog
INFO - 2021-04-20 22:42:13 --> Config Class Initialized
INFO - 2021-04-20 22:42:13 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:42:13 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:42:13 --> Utf8 Class Initialized
INFO - 2021-04-20 22:42:13 --> URI Class Initialized
INFO - 2021-04-20 22:42:13 --> Router Class Initialized
INFO - 2021-04-20 22:42:13 --> Output Class Initialized
INFO - 2021-04-20 22:42:13 --> Security Class Initialized
DEBUG - 2021-04-20 22:42:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:42:13 --> Input Class Initialized
INFO - 2021-04-20 22:42:13 --> Language Class Initialized
ERROR - 2021-04-20 22:42:13 --> 404 Page Not Found: Plugins/tableselection
INFO - 2021-04-20 22:42:18 --> Config Class Initialized
INFO - 2021-04-20 22:42:18 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:42:18 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:42:18 --> Utf8 Class Initialized
INFO - 2021-04-20 22:42:18 --> URI Class Initialized
DEBUG - 2021-04-20 22:42:18 --> No URI present. Default controller set.
INFO - 2021-04-20 22:42:18 --> Router Class Initialized
INFO - 2021-04-20 22:42:18 --> Output Class Initialized
INFO - 2021-04-20 22:42:18 --> Security Class Initialized
DEBUG - 2021-04-20 22:42:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:42:18 --> Input Class Initialized
INFO - 2021-04-20 22:42:18 --> Language Class Initialized
INFO - 2021-04-20 22:42:18 --> Loader Class Initialized
INFO - 2021-04-20 22:42:18 --> Helper loaded: url_helper
INFO - 2021-04-20 22:42:18 --> Helper loaded: form_helper
INFO - 2021-04-20 22:42:18 --> Helper loaded: common_helper
INFO - 2021-04-20 22:42:18 --> Helper loaded: util_helper
INFO - 2021-04-20 22:42:18 --> Helper loaded: user_helper
INFO - 2021-04-20 22:42:18 --> Database Driver Class Initialized
DEBUG - 2021-04-20 22:42:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 22:42:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 22:42:18 --> Form Validation Class Initialized
INFO - 2021-04-20 22:42:18 --> Controller Class Initialized
INFO - 2021-04-20 22:42:18 --> Model Class Initialized
INFO - 2021-04-20 22:42:18 --> Model Class Initialized
INFO - 2021-04-20 22:42:18 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-20 22:42:18 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-20 22:42:18 --> Final output sent to browser
DEBUG - 2021-04-20 22:42:18 --> Total execution time: 0.0288
INFO - 2021-04-20 22:51:12 --> Config Class Initialized
INFO - 2021-04-20 22:51:12 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:51:12 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:51:12 --> Utf8 Class Initialized
INFO - 2021-04-20 22:51:12 --> URI Class Initialized
DEBUG - 2021-04-20 22:51:12 --> No URI present. Default controller set.
INFO - 2021-04-20 22:51:12 --> Router Class Initialized
INFO - 2021-04-20 22:51:12 --> Output Class Initialized
INFO - 2021-04-20 22:51:12 --> Security Class Initialized
DEBUG - 2021-04-20 22:51:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:51:12 --> Input Class Initialized
INFO - 2021-04-20 22:51:12 --> Language Class Initialized
INFO - 2021-04-20 22:51:12 --> Loader Class Initialized
INFO - 2021-04-20 22:51:12 --> Helper loaded: url_helper
INFO - 2021-04-20 22:51:12 --> Helper loaded: form_helper
INFO - 2021-04-20 22:51:12 --> Helper loaded: common_helper
INFO - 2021-04-20 22:51:12 --> Helper loaded: util_helper
INFO - 2021-04-20 22:51:12 --> Helper loaded: user_helper
INFO - 2021-04-20 22:51:12 --> Database Driver Class Initialized
DEBUG - 2021-04-20 22:51:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 22:51:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 22:51:12 --> Form Validation Class Initialized
INFO - 2021-04-20 22:51:12 --> Controller Class Initialized
INFO - 2021-04-20 22:51:12 --> Model Class Initialized
INFO - 2021-04-20 22:51:12 --> Model Class Initialized
INFO - 2021-04-20 22:51:12 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-20 22:51:12 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-20 22:51:12 --> Final output sent to browser
DEBUG - 2021-04-20 22:51:12 --> Total execution time: 0.0389
INFO - 2021-04-20 22:51:16 --> Config Class Initialized
INFO - 2021-04-20 22:51:16 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:51:16 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:51:16 --> Utf8 Class Initialized
INFO - 2021-04-20 22:51:16 --> URI Class Initialized
INFO - 2021-04-20 22:51:16 --> Router Class Initialized
INFO - 2021-04-20 22:51:16 --> Output Class Initialized
INFO - 2021-04-20 22:51:16 --> Security Class Initialized
DEBUG - 2021-04-20 22:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:51:16 --> Input Class Initialized
INFO - 2021-04-20 22:51:16 --> Language Class Initialized
INFO - 2021-04-20 22:51:16 --> Loader Class Initialized
INFO - 2021-04-20 22:51:16 --> Helper loaded: url_helper
INFO - 2021-04-20 22:51:16 --> Helper loaded: form_helper
INFO - 2021-04-20 22:51:16 --> Helper loaded: common_helper
INFO - 2021-04-20 22:51:16 --> Helper loaded: util_helper
INFO - 2021-04-20 22:51:16 --> Helper loaded: user_helper
INFO - 2021-04-20 22:51:16 --> Database Driver Class Initialized
DEBUG - 2021-04-20 22:51:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 22:51:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 22:51:16 --> Form Validation Class Initialized
INFO - 2021-04-20 22:51:16 --> Controller Class Initialized
INFO - 2021-04-20 22:51:16 --> Model Class Initialized
INFO - 2021-04-20 22:51:16 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\viewaccount.php
INFO - 2021-04-20 22:51:16 --> Final output sent to browser
DEBUG - 2021-04-20 22:51:16 --> Total execution time: 0.0294
INFO - 2021-04-20 22:51:16 --> Config Class Initialized
INFO - 2021-04-20 22:51:16 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:51:16 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:51:16 --> Utf8 Class Initialized
INFO - 2021-04-20 22:51:16 --> Config Class Initialized
INFO - 2021-04-20 22:51:16 --> URI Class Initialized
INFO - 2021-04-20 22:51:16 --> Hooks Class Initialized
INFO - 2021-04-20 22:51:16 --> Router Class Initialized
DEBUG - 2021-04-20 22:51:16 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:51:16 --> Utf8 Class Initialized
INFO - 2021-04-20 22:51:16 --> Output Class Initialized
INFO - 2021-04-20 22:51:16 --> URI Class Initialized
INFO - 2021-04-20 22:51:16 --> Security Class Initialized
INFO - 2021-04-20 22:51:16 --> Router Class Initialized
DEBUG - 2021-04-20 22:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:51:16 --> Input Class Initialized
INFO - 2021-04-20 22:51:16 --> Language Class Initialized
INFO - 2021-04-20 22:51:16 --> Output Class Initialized
INFO - 2021-04-20 22:51:16 --> Security Class Initialized
ERROR - 2021-04-20 22:51:16 --> 404 Page Not Found: Assets/plugins
DEBUG - 2021-04-20 22:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:51:16 --> Input Class Initialized
INFO - 2021-04-20 22:51:16 --> Language Class Initialized
ERROR - 2021-04-20 22:51:16 --> 404 Page Not Found: Assets/plugins
INFO - 2021-04-20 22:51:16 --> Config Class Initialized
INFO - 2021-04-20 22:51:16 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:51:16 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:51:16 --> Utf8 Class Initialized
INFO - 2021-04-20 22:51:16 --> URI Class Initialized
INFO - 2021-04-20 22:51:16 --> Router Class Initialized
INFO - 2021-04-20 22:51:16 --> Output Class Initialized
INFO - 2021-04-20 22:51:16 --> Security Class Initialized
DEBUG - 2021-04-20 22:51:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:51:16 --> Input Class Initialized
INFO - 2021-04-20 22:51:16 --> Language Class Initialized
ERROR - 2021-04-20 22:51:16 --> 404 Page Not Found: Assets/plugins
INFO - 2021-04-20 22:51:18 --> Config Class Initialized
INFO - 2021-04-20 22:51:18 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:51:18 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:51:18 --> Utf8 Class Initialized
INFO - 2021-04-20 22:51:18 --> URI Class Initialized
INFO - 2021-04-20 22:51:18 --> Router Class Initialized
INFO - 2021-04-20 22:51:18 --> Output Class Initialized
INFO - 2021-04-20 22:51:18 --> Security Class Initialized
DEBUG - 2021-04-20 22:51:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:51:18 --> Input Class Initialized
INFO - 2021-04-20 22:51:18 --> Language Class Initialized
ERROR - 2021-04-20 22:51:18 --> 404 Page Not Found: AdminController/edit
INFO - 2021-04-20 22:51:22 --> Config Class Initialized
INFO - 2021-04-20 22:51:22 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:51:22 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:51:22 --> Utf8 Class Initialized
INFO - 2021-04-20 22:51:22 --> URI Class Initialized
INFO - 2021-04-20 22:51:22 --> Router Class Initialized
INFO - 2021-04-20 22:51:22 --> Output Class Initialized
INFO - 2021-04-20 22:51:22 --> Security Class Initialized
DEBUG - 2021-04-20 22:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:51:22 --> Input Class Initialized
INFO - 2021-04-20 22:51:22 --> Language Class Initialized
INFO - 2021-04-20 22:51:22 --> Loader Class Initialized
INFO - 2021-04-20 22:51:22 --> Helper loaded: url_helper
INFO - 2021-04-20 22:51:22 --> Helper loaded: form_helper
INFO - 2021-04-20 22:51:22 --> Helper loaded: common_helper
INFO - 2021-04-20 22:51:22 --> Helper loaded: util_helper
INFO - 2021-04-20 22:51:22 --> Helper loaded: user_helper
INFO - 2021-04-20 22:51:22 --> Database Driver Class Initialized
DEBUG - 2021-04-20 22:51:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 22:51:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 22:51:22 --> Form Validation Class Initialized
INFO - 2021-04-20 22:51:22 --> Controller Class Initialized
INFO - 2021-04-20 22:51:22 --> Model Class Initialized
INFO - 2021-04-20 22:51:22 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\viewaccount.php
INFO - 2021-04-20 22:51:22 --> Final output sent to browser
DEBUG - 2021-04-20 22:51:22 --> Total execution time: 0.0294
INFO - 2021-04-20 22:53:27 --> Config Class Initialized
INFO - 2021-04-20 22:53:27 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:53:27 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:53:27 --> Utf8 Class Initialized
INFO - 2021-04-20 22:53:27 --> URI Class Initialized
INFO - 2021-04-20 22:53:27 --> Router Class Initialized
INFO - 2021-04-20 22:53:27 --> Output Class Initialized
INFO - 2021-04-20 22:53:27 --> Security Class Initialized
DEBUG - 2021-04-20 22:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:53:27 --> Input Class Initialized
INFO - 2021-04-20 22:53:27 --> Language Class Initialized
INFO - 2021-04-20 22:53:27 --> Loader Class Initialized
INFO - 2021-04-20 22:53:27 --> Helper loaded: url_helper
INFO - 2021-04-20 22:53:27 --> Helper loaded: form_helper
INFO - 2021-04-20 22:53:27 --> Helper loaded: common_helper
INFO - 2021-04-20 22:53:27 --> Helper loaded: util_helper
INFO - 2021-04-20 22:53:27 --> Helper loaded: user_helper
INFO - 2021-04-20 22:53:27 --> Database Driver Class Initialized
DEBUG - 2021-04-20 22:53:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 22:53:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 22:53:27 --> Form Validation Class Initialized
INFO - 2021-04-20 22:53:27 --> Controller Class Initialized
INFO - 2021-04-20 22:53:27 --> Model Class Initialized
INFO - 2021-04-20 22:53:27 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\viewaccount.php
INFO - 2021-04-20 22:53:27 --> Final output sent to browser
DEBUG - 2021-04-20 22:53:27 --> Total execution time: 0.0296
INFO - 2021-04-20 22:53:27 --> Config Class Initialized
INFO - 2021-04-20 22:53:27 --> Hooks Class Initialized
INFO - 2021-04-20 22:53:27 --> Config Class Initialized
INFO - 2021-04-20 22:53:27 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:53:27 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:53:27 --> Utf8 Class Initialized
INFO - 2021-04-20 22:53:27 --> URI Class Initialized
DEBUG - 2021-04-20 22:53:27 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:53:27 --> Utf8 Class Initialized
INFO - 2021-04-20 22:53:27 --> Router Class Initialized
INFO - 2021-04-20 22:53:27 --> URI Class Initialized
INFO - 2021-04-20 22:53:27 --> Output Class Initialized
INFO - 2021-04-20 22:53:27 --> Router Class Initialized
INFO - 2021-04-20 22:53:27 --> Security Class Initialized
INFO - 2021-04-20 22:53:27 --> Output Class Initialized
DEBUG - 2021-04-20 22:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:53:27 --> Input Class Initialized
INFO - 2021-04-20 22:53:27 --> Language Class Initialized
INFO - 2021-04-20 22:53:27 --> Security Class Initialized
DEBUG - 2021-04-20 22:53:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:53:27 --> Input Class Initialized
ERROR - 2021-04-20 22:53:27 --> 404 Page Not Found: Assets/plugins
INFO - 2021-04-20 22:53:27 --> Language Class Initialized
ERROR - 2021-04-20 22:53:27 --> 404 Page Not Found: Assets/plugins
INFO - 2021-04-20 22:53:28 --> Config Class Initialized
INFO - 2021-04-20 22:53:28 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:53:28 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:53:28 --> Utf8 Class Initialized
INFO - 2021-04-20 22:53:28 --> URI Class Initialized
INFO - 2021-04-20 22:53:28 --> Router Class Initialized
INFO - 2021-04-20 22:53:28 --> Output Class Initialized
INFO - 2021-04-20 22:53:28 --> Security Class Initialized
DEBUG - 2021-04-20 22:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:53:28 --> Input Class Initialized
INFO - 2021-04-20 22:53:28 --> Language Class Initialized
INFO - 2021-04-20 22:53:28 --> Loader Class Initialized
INFO - 2021-04-20 22:53:28 --> Helper loaded: url_helper
INFO - 2021-04-20 22:53:28 --> Helper loaded: form_helper
INFO - 2021-04-20 22:53:28 --> Helper loaded: common_helper
INFO - 2021-04-20 22:53:28 --> Helper loaded: util_helper
INFO - 2021-04-20 22:53:28 --> Helper loaded: user_helper
INFO - 2021-04-20 22:53:28 --> Database Driver Class Initialized
DEBUG - 2021-04-20 22:53:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 22:53:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 22:53:28 --> Form Validation Class Initialized
INFO - 2021-04-20 22:53:28 --> Controller Class Initialized
INFO - 2021-04-20 22:53:28 --> Model Class Initialized
INFO - 2021-04-20 22:53:28 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\viewaccount.php
INFO - 2021-04-20 22:53:28 --> Final output sent to browser
DEBUG - 2021-04-20 22:53:28 --> Total execution time: 0.0285
INFO - 2021-04-20 22:53:28 --> Config Class Initialized
INFO - 2021-04-20 22:53:28 --> Config Class Initialized
INFO - 2021-04-20 22:53:28 --> Hooks Class Initialized
INFO - 2021-04-20 22:53:28 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:53:28 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:53:28 --> Utf8 Class Initialized
DEBUG - 2021-04-20 22:53:28 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:53:28 --> Utf8 Class Initialized
INFO - 2021-04-20 22:53:28 --> URI Class Initialized
INFO - 2021-04-20 22:53:28 --> URI Class Initialized
INFO - 2021-04-20 22:53:28 --> Router Class Initialized
INFO - 2021-04-20 22:53:28 --> Router Class Initialized
INFO - 2021-04-20 22:53:28 --> Output Class Initialized
INFO - 2021-04-20 22:53:28 --> Security Class Initialized
INFO - 2021-04-20 22:53:28 --> Output Class Initialized
DEBUG - 2021-04-20 22:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:53:28 --> Input Class Initialized
INFO - 2021-04-20 22:53:28 --> Security Class Initialized
INFO - 2021-04-20 22:53:28 --> Language Class Initialized
DEBUG - 2021-04-20 22:53:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:53:28 --> Input Class Initialized
ERROR - 2021-04-20 22:53:28 --> 404 Page Not Found: Assets/plugins
INFO - 2021-04-20 22:53:28 --> Language Class Initialized
ERROR - 2021-04-20 22:53:28 --> 404 Page Not Found: Assets/plugins
INFO - 2021-04-20 22:53:30 --> Config Class Initialized
INFO - 2021-04-20 22:53:30 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:53:30 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:53:30 --> Utf8 Class Initialized
INFO - 2021-04-20 22:53:30 --> URI Class Initialized
INFO - 2021-04-20 22:53:30 --> Router Class Initialized
INFO - 2021-04-20 22:53:30 --> Output Class Initialized
INFO - 2021-04-20 22:53:30 --> Security Class Initialized
DEBUG - 2021-04-20 22:53:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:53:30 --> Input Class Initialized
INFO - 2021-04-20 22:53:30 --> Language Class Initialized
ERROR - 2021-04-20 22:53:30 --> 404 Page Not Found: AdminController/edit
INFO - 2021-04-20 22:53:34 --> Config Class Initialized
INFO - 2021-04-20 22:53:34 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:53:34 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:53:34 --> Utf8 Class Initialized
INFO - 2021-04-20 22:53:34 --> URI Class Initialized
INFO - 2021-04-20 22:53:34 --> Router Class Initialized
INFO - 2021-04-20 22:53:34 --> Output Class Initialized
INFO - 2021-04-20 22:53:34 --> Security Class Initialized
DEBUG - 2021-04-20 22:53:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:53:34 --> Input Class Initialized
INFO - 2021-04-20 22:53:34 --> Language Class Initialized
INFO - 2021-04-20 22:53:34 --> Loader Class Initialized
INFO - 2021-04-20 22:53:34 --> Helper loaded: url_helper
INFO - 2021-04-20 22:53:34 --> Helper loaded: form_helper
INFO - 2021-04-20 22:53:34 --> Helper loaded: common_helper
INFO - 2021-04-20 22:53:34 --> Helper loaded: util_helper
INFO - 2021-04-20 22:53:34 --> Helper loaded: user_helper
INFO - 2021-04-20 22:53:34 --> Database Driver Class Initialized
DEBUG - 2021-04-20 22:53:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 22:53:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 22:53:34 --> Form Validation Class Initialized
INFO - 2021-04-20 22:53:34 --> Controller Class Initialized
INFO - 2021-04-20 22:53:34 --> Model Class Initialized
INFO - 2021-04-20 22:53:34 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\viewaccount.php
INFO - 2021-04-20 22:53:34 --> Final output sent to browser
DEBUG - 2021-04-20 22:53:34 --> Total execution time: 0.0289
INFO - 2021-04-20 22:53:43 --> Config Class Initialized
INFO - 2021-04-20 22:53:43 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:53:43 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:53:43 --> Utf8 Class Initialized
INFO - 2021-04-20 22:53:43 --> URI Class Initialized
INFO - 2021-04-20 22:53:43 --> Router Class Initialized
INFO - 2021-04-20 22:53:43 --> Output Class Initialized
INFO - 2021-04-20 22:53:43 --> Security Class Initialized
DEBUG - 2021-04-20 22:53:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:53:43 --> Input Class Initialized
INFO - 2021-04-20 22:53:43 --> Language Class Initialized
INFO - 2021-04-20 22:53:43 --> Loader Class Initialized
INFO - 2021-04-20 22:53:43 --> Helper loaded: url_helper
INFO - 2021-04-20 22:53:43 --> Helper loaded: form_helper
INFO - 2021-04-20 22:53:43 --> Helper loaded: common_helper
INFO - 2021-04-20 22:53:43 --> Helper loaded: util_helper
INFO - 2021-04-20 22:53:43 --> Helper loaded: user_helper
INFO - 2021-04-20 22:53:43 --> Database Driver Class Initialized
DEBUG - 2021-04-20 22:53:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 22:53:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 22:53:43 --> Form Validation Class Initialized
INFO - 2021-04-20 22:53:43 --> Controller Class Initialized
INFO - 2021-04-20 22:53:43 --> Model Class Initialized
INFO - 2021-04-20 22:53:43 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\viewaccount.php
INFO - 2021-04-20 22:53:43 --> Final output sent to browser
DEBUG - 2021-04-20 22:53:43 --> Total execution time: 0.0300
INFO - 2021-04-20 22:53:52 --> Config Class Initialized
INFO - 2021-04-20 22:53:52 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:53:52 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:53:52 --> Utf8 Class Initialized
INFO - 2021-04-20 22:53:52 --> URI Class Initialized
INFO - 2021-04-20 22:53:52 --> Router Class Initialized
INFO - 2021-04-20 22:53:52 --> Output Class Initialized
INFO - 2021-04-20 22:53:52 --> Security Class Initialized
DEBUG - 2021-04-20 22:53:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:53:52 --> Input Class Initialized
INFO - 2021-04-20 22:53:52 --> Language Class Initialized
INFO - 2021-04-20 22:53:52 --> Loader Class Initialized
INFO - 2021-04-20 22:53:52 --> Helper loaded: url_helper
INFO - 2021-04-20 22:53:52 --> Helper loaded: form_helper
INFO - 2021-04-20 22:53:52 --> Helper loaded: common_helper
INFO - 2021-04-20 22:53:52 --> Helper loaded: util_helper
INFO - 2021-04-20 22:53:52 --> Helper loaded: user_helper
INFO - 2021-04-20 22:53:52 --> Database Driver Class Initialized
DEBUG - 2021-04-20 22:53:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 22:53:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 22:53:52 --> Form Validation Class Initialized
INFO - 2021-04-20 22:53:52 --> Controller Class Initialized
INFO - 2021-04-20 22:53:52 --> Model Class Initialized
INFO - 2021-04-20 22:53:52 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\viewaccount.php
INFO - 2021-04-20 22:53:52 --> Final output sent to browser
DEBUG - 2021-04-20 22:53:52 --> Total execution time: 0.0299
INFO - 2021-04-20 22:56:29 --> Config Class Initialized
INFO - 2021-04-20 22:56:29 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:56:29 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:56:29 --> Utf8 Class Initialized
INFO - 2021-04-20 22:56:29 --> URI Class Initialized
INFO - 2021-04-20 22:56:29 --> Router Class Initialized
INFO - 2021-04-20 22:56:29 --> Output Class Initialized
INFO - 2021-04-20 22:56:29 --> Security Class Initialized
DEBUG - 2021-04-20 22:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:56:29 --> Input Class Initialized
INFO - 2021-04-20 22:56:29 --> Language Class Initialized
INFO - 2021-04-20 22:56:29 --> Loader Class Initialized
INFO - 2021-04-20 22:56:29 --> Helper loaded: url_helper
INFO - 2021-04-20 22:56:29 --> Helper loaded: form_helper
INFO - 2021-04-20 22:56:29 --> Helper loaded: common_helper
INFO - 2021-04-20 22:56:29 --> Helper loaded: util_helper
INFO - 2021-04-20 22:56:29 --> Helper loaded: user_helper
INFO - 2021-04-20 22:56:29 --> Database Driver Class Initialized
DEBUG - 2021-04-20 22:56:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 22:56:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 22:56:29 --> Form Validation Class Initialized
INFO - 2021-04-20 22:56:29 --> Controller Class Initialized
INFO - 2021-04-20 22:56:29 --> Model Class Initialized
INFO - 2021-04-20 22:56:29 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\viewaccount.php
INFO - 2021-04-20 22:56:29 --> Final output sent to browser
DEBUG - 2021-04-20 22:56:29 --> Total execution time: 0.0476
INFO - 2021-04-20 22:56:29 --> Config Class Initialized
INFO - 2021-04-20 22:56:29 --> Hooks Class Initialized
INFO - 2021-04-20 22:56:29 --> Config Class Initialized
INFO - 2021-04-20 22:56:29 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:56:29 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:56:29 --> Utf8 Class Initialized
DEBUG - 2021-04-20 22:56:29 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:56:29 --> Utf8 Class Initialized
INFO - 2021-04-20 22:56:29 --> URI Class Initialized
INFO - 2021-04-20 22:56:29 --> URI Class Initialized
INFO - 2021-04-20 22:56:29 --> Router Class Initialized
INFO - 2021-04-20 22:56:29 --> Router Class Initialized
INFO - 2021-04-20 22:56:29 --> Output Class Initialized
INFO - 2021-04-20 22:56:29 --> Output Class Initialized
INFO - 2021-04-20 22:56:29 --> Security Class Initialized
INFO - 2021-04-20 22:56:29 --> Security Class Initialized
DEBUG - 2021-04-20 22:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:56:29 --> Input Class Initialized
DEBUG - 2021-04-20 22:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:56:29 --> Input Class Initialized
INFO - 2021-04-20 22:56:29 --> Language Class Initialized
INFO - 2021-04-20 22:56:29 --> Language Class Initialized
ERROR - 2021-04-20 22:56:29 --> 404 Page Not Found: Assets/plugins
ERROR - 2021-04-20 22:56:29 --> 404 Page Not Found: Assets/plugins
INFO - 2021-04-20 22:56:29 --> Config Class Initialized
INFO - 2021-04-20 22:56:29 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:56:29 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:56:29 --> Utf8 Class Initialized
INFO - 2021-04-20 22:56:29 --> URI Class Initialized
INFO - 2021-04-20 22:56:29 --> Router Class Initialized
INFO - 2021-04-20 22:56:29 --> Output Class Initialized
INFO - 2021-04-20 22:56:29 --> Security Class Initialized
DEBUG - 2021-04-20 22:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:56:29 --> Input Class Initialized
INFO - 2021-04-20 22:56:29 --> Language Class Initialized
ERROR - 2021-04-20 22:56:29 --> 404 Page Not Found: Assets/plugins
INFO - 2021-04-20 22:56:31 --> Config Class Initialized
INFO - 2021-04-20 22:56:31 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:56:31 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:56:31 --> Utf8 Class Initialized
INFO - 2021-04-20 22:56:31 --> URI Class Initialized
INFO - 2021-04-20 22:56:31 --> Router Class Initialized
INFO - 2021-04-20 22:56:31 --> Output Class Initialized
INFO - 2021-04-20 22:56:31 --> Security Class Initialized
DEBUG - 2021-04-20 22:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:56:31 --> Input Class Initialized
INFO - 2021-04-20 22:56:31 --> Language Class Initialized
INFO - 2021-04-20 22:56:31 --> Loader Class Initialized
INFO - 2021-04-20 22:56:31 --> Helper loaded: url_helper
INFO - 2021-04-20 22:56:31 --> Helper loaded: form_helper
INFO - 2021-04-20 22:56:31 --> Helper loaded: common_helper
INFO - 2021-04-20 22:56:31 --> Helper loaded: util_helper
INFO - 2021-04-20 22:56:31 --> Helper loaded: user_helper
INFO - 2021-04-20 22:56:31 --> Database Driver Class Initialized
DEBUG - 2021-04-20 22:56:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 22:56:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 22:56:31 --> Form Validation Class Initialized
INFO - 2021-04-20 22:56:31 --> Controller Class Initialized
INFO - 2021-04-20 22:56:31 --> Model Class Initialized
INFO - 2021-04-20 22:56:31 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\ckeditor/samples/index.php
INFO - 2021-04-20 22:56:31 --> Final output sent to browser
DEBUG - 2021-04-20 22:56:31 --> Total execution time: 0.0291
INFO - 2021-04-20 22:56:31 --> Config Class Initialized
INFO - 2021-04-20 22:56:31 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:56:31 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:56:31 --> Utf8 Class Initialized
INFO - 2021-04-20 22:56:31 --> URI Class Initialized
INFO - 2021-04-20 22:56:31 --> Router Class Initialized
INFO - 2021-04-20 22:56:31 --> Output Class Initialized
INFO - 2021-04-20 22:56:31 --> Security Class Initialized
DEBUG - 2021-04-20 22:56:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:56:31 --> Input Class Initialized
INFO - 2021-04-20 22:56:31 --> Language Class Initialized
ERROR - 2021-04-20 22:56:31 --> 404 Page Not Found: administrator/Cms/ckeditor.js
INFO - 2021-04-20 22:57:38 --> Config Class Initialized
INFO - 2021-04-20 22:57:38 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:57:38 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:57:38 --> Utf8 Class Initialized
INFO - 2021-04-20 22:57:38 --> URI Class Initialized
INFO - 2021-04-20 22:57:38 --> Router Class Initialized
INFO - 2021-04-20 22:57:38 --> Output Class Initialized
INFO - 2021-04-20 22:57:38 --> Security Class Initialized
DEBUG - 2021-04-20 22:57:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:57:38 --> Input Class Initialized
INFO - 2021-04-20 22:57:38 --> Language Class Initialized
INFO - 2021-04-20 22:57:38 --> Loader Class Initialized
INFO - 2021-04-20 22:57:38 --> Helper loaded: url_helper
INFO - 2021-04-20 22:57:38 --> Helper loaded: form_helper
INFO - 2021-04-20 22:57:38 --> Helper loaded: common_helper
INFO - 2021-04-20 22:57:38 --> Helper loaded: util_helper
INFO - 2021-04-20 22:57:38 --> Helper loaded: user_helper
INFO - 2021-04-20 22:57:38 --> Database Driver Class Initialized
DEBUG - 2021-04-20 22:57:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 22:57:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 22:57:38 --> Form Validation Class Initialized
INFO - 2021-04-20 22:57:38 --> Controller Class Initialized
INFO - 2021-04-20 22:57:38 --> Model Class Initialized
INFO - 2021-04-20 22:57:38 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\viewaccount.php
INFO - 2021-04-20 22:57:38 --> Final output sent to browser
DEBUG - 2021-04-20 22:57:38 --> Total execution time: 0.0295
INFO - 2021-04-20 22:57:41 --> Config Class Initialized
INFO - 2021-04-20 22:57:41 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:57:41 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:57:41 --> Utf8 Class Initialized
INFO - 2021-04-20 22:57:41 --> URI Class Initialized
DEBUG - 2021-04-20 22:57:41 --> No URI present. Default controller set.
INFO - 2021-04-20 22:57:41 --> Router Class Initialized
INFO - 2021-04-20 22:57:41 --> Output Class Initialized
INFO - 2021-04-20 22:57:41 --> Security Class Initialized
DEBUG - 2021-04-20 22:57:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:57:41 --> Input Class Initialized
INFO - 2021-04-20 22:57:41 --> Language Class Initialized
INFO - 2021-04-20 22:57:41 --> Loader Class Initialized
INFO - 2021-04-20 22:57:41 --> Helper loaded: url_helper
INFO - 2021-04-20 22:57:41 --> Helper loaded: form_helper
INFO - 2021-04-20 22:57:41 --> Helper loaded: common_helper
INFO - 2021-04-20 22:57:41 --> Helper loaded: util_helper
INFO - 2021-04-20 22:57:41 --> Helper loaded: user_helper
INFO - 2021-04-20 22:57:41 --> Database Driver Class Initialized
DEBUG - 2021-04-20 22:57:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 22:57:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 22:57:41 --> Form Validation Class Initialized
INFO - 2021-04-20 22:57:41 --> Controller Class Initialized
INFO - 2021-04-20 22:57:41 --> Model Class Initialized
INFO - 2021-04-20 22:57:41 --> Model Class Initialized
INFO - 2021-04-20 22:57:41 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-20 22:57:41 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-20 22:57:41 --> Final output sent to browser
DEBUG - 2021-04-20 22:57:41 --> Total execution time: 0.0309
INFO - 2021-04-20 22:57:43 --> Config Class Initialized
INFO - 2021-04-20 22:57:43 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:57:43 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:57:43 --> Utf8 Class Initialized
INFO - 2021-04-20 22:57:43 --> URI Class Initialized
INFO - 2021-04-20 22:57:43 --> Router Class Initialized
INFO - 2021-04-20 22:57:44 --> Output Class Initialized
INFO - 2021-04-20 22:57:44 --> Security Class Initialized
DEBUG - 2021-04-20 22:57:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:57:44 --> Input Class Initialized
INFO - 2021-04-20 22:57:44 --> Language Class Initialized
INFO - 2021-04-20 22:57:44 --> Loader Class Initialized
INFO - 2021-04-20 22:57:44 --> Helper loaded: url_helper
INFO - 2021-04-20 22:57:44 --> Helper loaded: form_helper
INFO - 2021-04-20 22:57:44 --> Helper loaded: common_helper
INFO - 2021-04-20 22:57:44 --> Helper loaded: util_helper
INFO - 2021-04-20 22:57:44 --> Helper loaded: user_helper
INFO - 2021-04-20 22:57:44 --> Database Driver Class Initialized
DEBUG - 2021-04-20 22:57:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 22:57:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 22:57:44 --> Form Validation Class Initialized
INFO - 2021-04-20 22:57:44 --> Controller Class Initialized
INFO - 2021-04-20 22:57:44 --> Model Class Initialized
INFO - 2021-04-20 22:57:44 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\viewaccount.php
INFO - 2021-04-20 22:57:44 --> Final output sent to browser
DEBUG - 2021-04-20 22:57:44 --> Total execution time: 0.0382
INFO - 2021-04-20 22:57:44 --> Config Class Initialized
INFO - 2021-04-20 22:57:44 --> Hooks Class Initialized
INFO - 2021-04-20 22:57:44 --> Config Class Initialized
INFO - 2021-04-20 22:57:44 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:57:44 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:57:44 --> Utf8 Class Initialized
DEBUG - 2021-04-20 22:57:44 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:57:44 --> Utf8 Class Initialized
INFO - 2021-04-20 22:57:44 --> URI Class Initialized
INFO - 2021-04-20 22:57:44 --> URI Class Initialized
INFO - 2021-04-20 22:57:44 --> Router Class Initialized
INFO - 2021-04-20 22:57:44 --> Router Class Initialized
INFO - 2021-04-20 22:57:44 --> Output Class Initialized
INFO - 2021-04-20 22:57:44 --> Output Class Initialized
INFO - 2021-04-20 22:57:44 --> Security Class Initialized
INFO - 2021-04-20 22:57:44 --> Security Class Initialized
DEBUG - 2021-04-20 22:57:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-20 22:57:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:57:44 --> Input Class Initialized
INFO - 2021-04-20 22:57:44 --> Input Class Initialized
INFO - 2021-04-20 22:57:44 --> Language Class Initialized
INFO - 2021-04-20 22:57:44 --> Language Class Initialized
ERROR - 2021-04-20 22:57:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2021-04-20 22:57:44 --> 404 Page Not Found: Assets/plugins
INFO - 2021-04-20 22:57:44 --> Config Class Initialized
INFO - 2021-04-20 22:57:44 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:57:44 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:57:44 --> Utf8 Class Initialized
INFO - 2021-04-20 22:57:44 --> URI Class Initialized
INFO - 2021-04-20 22:57:44 --> Router Class Initialized
INFO - 2021-04-20 22:57:44 --> Output Class Initialized
INFO - 2021-04-20 22:57:44 --> Security Class Initialized
DEBUG - 2021-04-20 22:57:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:57:44 --> Input Class Initialized
INFO - 2021-04-20 22:57:44 --> Language Class Initialized
ERROR - 2021-04-20 22:57:44 --> 404 Page Not Found: Assets/plugins
INFO - 2021-04-20 22:57:45 --> Config Class Initialized
INFO - 2021-04-20 22:57:45 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:57:45 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:57:45 --> Utf8 Class Initialized
INFO - 2021-04-20 22:57:45 --> URI Class Initialized
DEBUG - 2021-04-20 22:57:45 --> No URI present. Default controller set.
INFO - 2021-04-20 22:57:45 --> Router Class Initialized
INFO - 2021-04-20 22:57:45 --> Output Class Initialized
INFO - 2021-04-20 22:57:45 --> Security Class Initialized
DEBUG - 2021-04-20 22:57:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:57:45 --> Input Class Initialized
INFO - 2021-04-20 22:57:45 --> Language Class Initialized
INFO - 2021-04-20 22:57:45 --> Loader Class Initialized
INFO - 2021-04-20 22:57:45 --> Helper loaded: url_helper
INFO - 2021-04-20 22:57:45 --> Helper loaded: form_helper
INFO - 2021-04-20 22:57:45 --> Helper loaded: common_helper
INFO - 2021-04-20 22:57:45 --> Helper loaded: util_helper
INFO - 2021-04-20 22:57:45 --> Helper loaded: user_helper
INFO - 2021-04-20 22:57:45 --> Database Driver Class Initialized
DEBUG - 2021-04-20 22:57:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 22:57:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 22:57:45 --> Form Validation Class Initialized
INFO - 2021-04-20 22:57:45 --> Controller Class Initialized
INFO - 2021-04-20 22:57:45 --> Model Class Initialized
INFO - 2021-04-20 22:57:45 --> Model Class Initialized
INFO - 2021-04-20 22:57:45 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-20 22:57:45 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-20 22:57:45 --> Final output sent to browser
DEBUG - 2021-04-20 22:57:45 --> Total execution time: 0.0326
INFO - 2021-04-20 22:58:11 --> Config Class Initialized
INFO - 2021-04-20 22:58:11 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:58:11 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:58:11 --> Utf8 Class Initialized
INFO - 2021-04-20 22:58:11 --> URI Class Initialized
INFO - 2021-04-20 22:58:11 --> Router Class Initialized
INFO - 2021-04-20 22:58:11 --> Output Class Initialized
INFO - 2021-04-20 22:58:11 --> Security Class Initialized
DEBUG - 2021-04-20 22:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:58:11 --> Input Class Initialized
INFO - 2021-04-20 22:58:11 --> Language Class Initialized
INFO - 2021-04-20 22:58:11 --> Loader Class Initialized
INFO - 2021-04-20 22:58:11 --> Helper loaded: url_helper
INFO - 2021-04-20 22:58:11 --> Helper loaded: form_helper
INFO - 2021-04-20 22:58:11 --> Helper loaded: common_helper
INFO - 2021-04-20 22:58:11 --> Helper loaded: util_helper
INFO - 2021-04-20 22:58:11 --> Helper loaded: user_helper
INFO - 2021-04-20 22:58:11 --> Database Driver Class Initialized
DEBUG - 2021-04-20 22:58:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 22:58:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 22:58:11 --> Form Validation Class Initialized
INFO - 2021-04-20 22:58:11 --> Controller Class Initialized
INFO - 2021-04-20 22:58:11 --> Model Class Initialized
INFO - 2021-04-20 22:58:11 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\ckeditor/samples/index.php
INFO - 2021-04-20 22:58:11 --> Final output sent to browser
DEBUG - 2021-04-20 22:58:11 --> Total execution time: 0.0293
INFO - 2021-04-20 22:58:11 --> Config Class Initialized
INFO - 2021-04-20 22:58:11 --> Hooks Class Initialized
INFO - 2021-04-20 22:58:11 --> Config Class Initialized
DEBUG - 2021-04-20 22:58:11 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:58:11 --> Utf8 Class Initialized
INFO - 2021-04-20 22:58:11 --> Hooks Class Initialized
INFO - 2021-04-20 22:58:11 --> URI Class Initialized
INFO - 2021-04-20 22:58:11 --> Router Class Initialized
INFO - 2021-04-20 22:58:11 --> Output Class Initialized
DEBUG - 2021-04-20 22:58:11 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:58:11 --> Security Class Initialized
INFO - 2021-04-20 22:58:11 --> Utf8 Class Initialized
DEBUG - 2021-04-20 22:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:58:11 --> Input Class Initialized
INFO - 2021-04-20 22:58:11 --> URI Class Initialized
INFO - 2021-04-20 22:58:11 --> Language Class Initialized
INFO - 2021-04-20 22:58:11 --> Router Class Initialized
ERROR - 2021-04-20 22:58:11 --> 404 Page Not Found: Plugins/scayt
INFO - 2021-04-20 22:58:12 --> Output Class Initialized
INFO - 2021-04-20 22:58:12 --> Security Class Initialized
DEBUG - 2021-04-20 22:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:58:12 --> Input Class Initialized
INFO - 2021-04-20 22:58:12 --> Config Class Initialized
INFO - 2021-04-20 22:58:12 --> Language Class Initialized
INFO - 2021-04-20 22:58:12 --> Hooks Class Initialized
ERROR - 2021-04-20 22:58:12 --> 404 Page Not Found: Plugins/scayt
INFO - 2021-04-20 22:58:12 --> Config Class Initialized
DEBUG - 2021-04-20 22:58:12 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:58:12 --> Hooks Class Initialized
INFO - 2021-04-20 22:58:12 --> Utf8 Class Initialized
INFO - 2021-04-20 22:58:12 --> URI Class Initialized
DEBUG - 2021-04-20 22:58:12 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:58:12 --> Router Class Initialized
INFO - 2021-04-20 22:58:12 --> Utf8 Class Initialized
INFO - 2021-04-20 22:58:12 --> URI Class Initialized
INFO - 2021-04-20 22:58:12 --> Output Class Initialized
INFO - 2021-04-20 22:58:12 --> Router Class Initialized
INFO - 2021-04-20 22:58:12 --> Security Class Initialized
DEBUG - 2021-04-20 22:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:58:12 --> Input Class Initialized
INFO - 2021-04-20 22:58:12 --> Output Class Initialized
INFO - 2021-04-20 22:58:12 --> Language Class Initialized
INFO - 2021-04-20 22:58:12 --> Security Class Initialized
ERROR - 2021-04-20 22:58:12 --> 404 Page Not Found: Plugins/dialog
DEBUG - 2021-04-20 22:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:58:12 --> Input Class Initialized
INFO - 2021-04-20 22:58:12 --> Language Class Initialized
ERROR - 2021-04-20 22:58:12 --> 404 Page Not Found: Plugins/tableselection
INFO - 2021-04-20 22:58:12 --> Config Class Initialized
INFO - 2021-04-20 22:58:12 --> Hooks Class Initialized
DEBUG - 2021-04-20 22:58:12 --> UTF-8 Support Enabled
INFO - 2021-04-20 22:58:12 --> Utf8 Class Initialized
INFO - 2021-04-20 22:58:12 --> URI Class Initialized
INFO - 2021-04-20 22:58:12 --> Router Class Initialized
INFO - 2021-04-20 22:58:12 --> Output Class Initialized
INFO - 2021-04-20 22:58:12 --> Security Class Initialized
DEBUG - 2021-04-20 22:58:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 22:58:12 --> Input Class Initialized
INFO - 2021-04-20 22:58:12 --> Language Class Initialized
ERROR - 2021-04-20 22:58:12 --> 404 Page Not Found: Plugins/tableselection
INFO - 2021-04-20 23:00:57 --> Config Class Initialized
INFO - 2021-04-20 23:00:57 --> Hooks Class Initialized
DEBUG - 2021-04-20 23:00:57 --> UTF-8 Support Enabled
INFO - 2021-04-20 23:00:57 --> Utf8 Class Initialized
INFO - 2021-04-20 23:00:57 --> URI Class Initialized
INFO - 2021-04-20 23:00:57 --> Router Class Initialized
INFO - 2021-04-20 23:00:57 --> Output Class Initialized
INFO - 2021-04-20 23:00:57 --> Security Class Initialized
DEBUG - 2021-04-20 23:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 23:00:57 --> Input Class Initialized
INFO - 2021-04-20 23:00:57 --> Language Class Initialized
INFO - 2021-04-20 23:00:57 --> Loader Class Initialized
INFO - 2021-04-20 23:00:57 --> Helper loaded: url_helper
INFO - 2021-04-20 23:00:57 --> Helper loaded: form_helper
INFO - 2021-04-20 23:00:57 --> Helper loaded: common_helper
INFO - 2021-04-20 23:00:57 --> Helper loaded: util_helper
INFO - 2021-04-20 23:00:57 --> Helper loaded: user_helper
INFO - 2021-04-20 23:00:57 --> Database Driver Class Initialized
DEBUG - 2021-04-20 23:00:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 23:00:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 23:00:57 --> Form Validation Class Initialized
INFO - 2021-04-20 23:00:57 --> Controller Class Initialized
INFO - 2021-04-20 23:00:57 --> Model Class Initialized
INFO - 2021-04-20 23:00:57 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\viewaccount.php
INFO - 2021-04-20 23:00:57 --> Final output sent to browser
DEBUG - 2021-04-20 23:00:57 --> Total execution time: 0.0422
INFO - 2021-04-20 23:00:57 --> Config Class Initialized
INFO - 2021-04-20 23:00:57 --> Hooks Class Initialized
INFO - 2021-04-20 23:00:57 --> Config Class Initialized
INFO - 2021-04-20 23:00:57 --> Hooks Class Initialized
DEBUG - 2021-04-20 23:00:57 --> UTF-8 Support Enabled
INFO - 2021-04-20 23:00:57 --> Utf8 Class Initialized
INFO - 2021-04-20 23:00:57 --> URI Class Initialized
DEBUG - 2021-04-20 23:00:57 --> UTF-8 Support Enabled
INFO - 2021-04-20 23:00:57 --> Router Class Initialized
INFO - 2021-04-20 23:00:57 --> Utf8 Class Initialized
INFO - 2021-04-20 23:00:57 --> URI Class Initialized
INFO - 2021-04-20 23:00:57 --> Output Class Initialized
INFO - 2021-04-20 23:00:57 --> Router Class Initialized
INFO - 2021-04-20 23:00:57 --> Security Class Initialized
INFO - 2021-04-20 23:00:57 --> Output Class Initialized
DEBUG - 2021-04-20 23:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 23:00:57 --> Security Class Initialized
INFO - 2021-04-20 23:00:57 --> Input Class Initialized
INFO - 2021-04-20 23:00:57 --> Language Class Initialized
DEBUG - 2021-04-20 23:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 23:00:57 --> Input Class Initialized
INFO - 2021-04-20 23:00:57 --> Language Class Initialized
ERROR - 2021-04-20 23:00:57 --> 404 Page Not Found: Assets/plugins
ERROR - 2021-04-20 23:00:57 --> 404 Page Not Found: Assets/plugins
INFO - 2021-04-20 23:00:57 --> Config Class Initialized
INFO - 2021-04-20 23:00:57 --> Hooks Class Initialized
DEBUG - 2021-04-20 23:00:57 --> UTF-8 Support Enabled
INFO - 2021-04-20 23:00:57 --> Utf8 Class Initialized
INFO - 2021-04-20 23:00:57 --> URI Class Initialized
INFO - 2021-04-20 23:00:57 --> Router Class Initialized
INFO - 2021-04-20 23:00:57 --> Output Class Initialized
INFO - 2021-04-20 23:00:57 --> Security Class Initialized
DEBUG - 2021-04-20 23:00:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 23:00:57 --> Input Class Initialized
INFO - 2021-04-20 23:00:57 --> Language Class Initialized
ERROR - 2021-04-20 23:00:57 --> 404 Page Not Found: Assets/plugins
INFO - 2021-04-20 23:01:00 --> Config Class Initialized
INFO - 2021-04-20 23:01:00 --> Hooks Class Initialized
DEBUG - 2021-04-20 23:01:00 --> UTF-8 Support Enabled
INFO - 2021-04-20 23:01:00 --> Utf8 Class Initialized
INFO - 2021-04-20 23:01:00 --> URI Class Initialized
INFO - 2021-04-20 23:01:00 --> Router Class Initialized
INFO - 2021-04-20 23:01:00 --> Output Class Initialized
INFO - 2021-04-20 23:01:00 --> Security Class Initialized
DEBUG - 2021-04-20 23:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 23:01:00 --> Input Class Initialized
INFO - 2021-04-20 23:01:00 --> Language Class Initialized
INFO - 2021-04-20 23:01:00 --> Loader Class Initialized
INFO - 2021-04-20 23:01:00 --> Helper loaded: url_helper
INFO - 2021-04-20 23:01:00 --> Helper loaded: form_helper
INFO - 2021-04-20 23:01:00 --> Helper loaded: common_helper
INFO - 2021-04-20 23:01:00 --> Helper loaded: util_helper
INFO - 2021-04-20 23:01:00 --> Helper loaded: user_helper
INFO - 2021-04-20 23:01:00 --> Database Driver Class Initialized
DEBUG - 2021-04-20 23:01:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 23:01:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 23:01:00 --> Form Validation Class Initialized
INFO - 2021-04-20 23:01:00 --> Controller Class Initialized
INFO - 2021-04-20 23:01:00 --> Model Class Initialized
INFO - 2021-04-20 23:01:00 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\ckeditor/samples/index.php
INFO - 2021-04-20 23:01:00 --> Final output sent to browser
DEBUG - 2021-04-20 23:01:00 --> Total execution time: 0.0283
INFO - 2021-04-20 23:01:00 --> Config Class Initialized
INFO - 2021-04-20 23:01:00 --> Hooks Class Initialized
DEBUG - 2021-04-20 23:01:00 --> UTF-8 Support Enabled
INFO - 2021-04-20 23:01:00 --> Utf8 Class Initialized
INFO - 2021-04-20 23:01:00 --> URI Class Initialized
INFO - 2021-04-20 23:01:00 --> Router Class Initialized
INFO - 2021-04-20 23:01:00 --> Output Class Initialized
INFO - 2021-04-20 23:01:00 --> Security Class Initialized
DEBUG - 2021-04-20 23:01:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 23:01:00 --> Input Class Initialized
INFO - 2021-04-20 23:01:00 --> Language Class Initialized
ERROR - 2021-04-20 23:01:00 --> 404 Page Not Found: administrator/Cms/ckeditor.js
INFO - 2021-04-20 23:01:38 --> Config Class Initialized
INFO - 2021-04-20 23:01:38 --> Hooks Class Initialized
DEBUG - 2021-04-20 23:01:38 --> UTF-8 Support Enabled
INFO - 2021-04-20 23:01:38 --> Utf8 Class Initialized
INFO - 2021-04-20 23:01:38 --> URI Class Initialized
INFO - 2021-04-20 23:01:38 --> Router Class Initialized
INFO - 2021-04-20 23:01:38 --> Output Class Initialized
INFO - 2021-04-20 23:01:38 --> Security Class Initialized
DEBUG - 2021-04-20 23:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 23:01:38 --> Input Class Initialized
INFO - 2021-04-20 23:01:38 --> Language Class Initialized
INFO - 2021-04-20 23:01:38 --> Loader Class Initialized
INFO - 2021-04-20 23:01:38 --> Helper loaded: url_helper
INFO - 2021-04-20 23:01:38 --> Helper loaded: form_helper
INFO - 2021-04-20 23:01:38 --> Helper loaded: common_helper
INFO - 2021-04-20 23:01:38 --> Helper loaded: util_helper
INFO - 2021-04-20 23:01:38 --> Helper loaded: user_helper
INFO - 2021-04-20 23:01:38 --> Database Driver Class Initialized
DEBUG - 2021-04-20 23:01:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 23:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 23:01:38 --> Form Validation Class Initialized
INFO - 2021-04-20 23:01:38 --> Controller Class Initialized
INFO - 2021-04-20 23:01:38 --> Model Class Initialized
INFO - 2021-04-20 23:01:38 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\ckeditor/samples/index.php
INFO - 2021-04-20 23:01:38 --> Final output sent to browser
DEBUG - 2021-04-20 23:01:38 --> Total execution time: 0.0369
INFO - 2021-04-20 23:01:45 --> Config Class Initialized
INFO - 2021-04-20 23:01:45 --> Hooks Class Initialized
DEBUG - 2021-04-20 23:01:45 --> UTF-8 Support Enabled
INFO - 2021-04-20 23:01:45 --> Utf8 Class Initialized
INFO - 2021-04-20 23:01:45 --> URI Class Initialized
INFO - 2021-04-20 23:01:45 --> Router Class Initialized
INFO - 2021-04-20 23:01:45 --> Output Class Initialized
INFO - 2021-04-20 23:01:45 --> Security Class Initialized
DEBUG - 2021-04-20 23:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 23:01:45 --> Input Class Initialized
INFO - 2021-04-20 23:01:45 --> Language Class Initialized
INFO - 2021-04-20 23:01:45 --> Loader Class Initialized
INFO - 2021-04-20 23:01:45 --> Helper loaded: url_helper
INFO - 2021-04-20 23:01:45 --> Helper loaded: form_helper
INFO - 2021-04-20 23:01:45 --> Helper loaded: common_helper
INFO - 2021-04-20 23:01:45 --> Helper loaded: util_helper
INFO - 2021-04-20 23:01:45 --> Helper loaded: user_helper
INFO - 2021-04-20 23:01:45 --> Database Driver Class Initialized
DEBUG - 2021-04-20 23:01:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 23:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 23:01:45 --> Form Validation Class Initialized
INFO - 2021-04-20 23:01:45 --> Controller Class Initialized
INFO - 2021-04-20 23:01:45 --> Model Class Initialized
INFO - 2021-04-20 23:01:45 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\viewaccount.php
INFO - 2021-04-20 23:01:45 --> Final output sent to browser
DEBUG - 2021-04-20 23:01:45 --> Total execution time: 0.0288
INFO - 2021-04-20 23:01:52 --> Config Class Initialized
INFO - 2021-04-20 23:01:52 --> Hooks Class Initialized
DEBUG - 2021-04-20 23:01:52 --> UTF-8 Support Enabled
INFO - 2021-04-20 23:01:52 --> Utf8 Class Initialized
INFO - 2021-04-20 23:01:52 --> URI Class Initialized
INFO - 2021-04-20 23:01:52 --> Router Class Initialized
INFO - 2021-04-20 23:01:52 --> Output Class Initialized
INFO - 2021-04-20 23:01:52 --> Security Class Initialized
DEBUG - 2021-04-20 23:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 23:01:52 --> Input Class Initialized
INFO - 2021-04-20 23:01:52 --> Language Class Initialized
INFO - 2021-04-20 23:01:52 --> Loader Class Initialized
INFO - 2021-04-20 23:01:52 --> Helper loaded: url_helper
INFO - 2021-04-20 23:01:52 --> Helper loaded: form_helper
INFO - 2021-04-20 23:01:52 --> Helper loaded: common_helper
INFO - 2021-04-20 23:01:52 --> Helper loaded: util_helper
INFO - 2021-04-20 23:01:52 --> Helper loaded: user_helper
INFO - 2021-04-20 23:01:52 --> Database Driver Class Initialized
DEBUG - 2021-04-20 23:01:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 23:01:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 23:01:52 --> Form Validation Class Initialized
INFO - 2021-04-20 23:01:52 --> Controller Class Initialized
INFO - 2021-04-20 23:01:52 --> Model Class Initialized
INFO - 2021-04-20 23:01:52 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\ckeditor/samples/index.php
INFO - 2021-04-20 23:01:52 --> Final output sent to browser
DEBUG - 2021-04-20 23:01:52 --> Total execution time: 0.0290
INFO - 2021-04-20 23:01:52 --> Config Class Initialized
INFO - 2021-04-20 23:01:52 --> Hooks Class Initialized
DEBUG - 2021-04-20 23:01:52 --> UTF-8 Support Enabled
INFO - 2021-04-20 23:01:52 --> Utf8 Class Initialized
INFO - 2021-04-20 23:01:52 --> URI Class Initialized
INFO - 2021-04-20 23:01:52 --> Router Class Initialized
INFO - 2021-04-20 23:01:52 --> Output Class Initialized
INFO - 2021-04-20 23:01:52 --> Security Class Initialized
DEBUG - 2021-04-20 23:01:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 23:01:52 --> Input Class Initialized
INFO - 2021-04-20 23:01:52 --> Language Class Initialized
ERROR - 2021-04-20 23:01:52 --> 404 Page Not Found: administrator/Cms/ckeditor.js
INFO - 2021-04-20 23:01:54 --> Config Class Initialized
INFO - 2021-04-20 23:01:54 --> Hooks Class Initialized
DEBUG - 2021-04-20 23:01:54 --> UTF-8 Support Enabled
INFO - 2021-04-20 23:01:54 --> Utf8 Class Initialized
INFO - 2021-04-20 23:01:54 --> URI Class Initialized
INFO - 2021-04-20 23:01:54 --> Router Class Initialized
INFO - 2021-04-20 23:01:54 --> Output Class Initialized
INFO - 2021-04-20 23:01:54 --> Security Class Initialized
DEBUG - 2021-04-20 23:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 23:01:54 --> Input Class Initialized
INFO - 2021-04-20 23:01:54 --> Language Class Initialized
INFO - 2021-04-20 23:01:54 --> Loader Class Initialized
INFO - 2021-04-20 23:01:54 --> Helper loaded: url_helper
INFO - 2021-04-20 23:01:54 --> Helper loaded: form_helper
INFO - 2021-04-20 23:01:54 --> Helper loaded: common_helper
INFO - 2021-04-20 23:01:54 --> Helper loaded: util_helper
INFO - 2021-04-20 23:01:54 --> Helper loaded: user_helper
INFO - 2021-04-20 23:01:54 --> Database Driver Class Initialized
DEBUG - 2021-04-20 23:01:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 23:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 23:01:54 --> Form Validation Class Initialized
INFO - 2021-04-20 23:01:54 --> Controller Class Initialized
INFO - 2021-04-20 23:01:54 --> Model Class Initialized
INFO - 2021-04-20 23:01:54 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\ckeditor/samples/index.php
INFO - 2021-04-20 23:01:54 --> Final output sent to browser
DEBUG - 2021-04-20 23:01:54 --> Total execution time: 0.0380
INFO - 2021-04-20 23:01:54 --> Config Class Initialized
INFO - 2021-04-20 23:01:54 --> Hooks Class Initialized
DEBUG - 2021-04-20 23:01:54 --> UTF-8 Support Enabled
INFO - 2021-04-20 23:01:54 --> Utf8 Class Initialized
INFO - 2021-04-20 23:01:54 --> URI Class Initialized
INFO - 2021-04-20 23:01:54 --> Router Class Initialized
INFO - 2021-04-20 23:01:54 --> Output Class Initialized
INFO - 2021-04-20 23:01:54 --> Security Class Initialized
DEBUG - 2021-04-20 23:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 23:01:54 --> Input Class Initialized
INFO - 2021-04-20 23:01:54 --> Language Class Initialized
INFO - 2021-04-20 23:01:54 --> Loader Class Initialized
INFO - 2021-04-20 23:01:54 --> Helper loaded: url_helper
INFO - 2021-04-20 23:01:54 --> Helper loaded: form_helper
INFO - 2021-04-20 23:01:54 --> Helper loaded: common_helper
INFO - 2021-04-20 23:01:54 --> Helper loaded: util_helper
INFO - 2021-04-20 23:01:54 --> Helper loaded: user_helper
INFO - 2021-04-20 23:01:54 --> Database Driver Class Initialized
DEBUG - 2021-04-20 23:01:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 23:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 23:01:54 --> Form Validation Class Initialized
INFO - 2021-04-20 23:01:54 --> Controller Class Initialized
INFO - 2021-04-20 23:01:54 --> Model Class Initialized
INFO - 2021-04-20 23:01:54 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\ckeditor/samples/index.php
INFO - 2021-04-20 23:01:54 --> Final output sent to browser
DEBUG - 2021-04-20 23:01:54 --> Total execution time: 0.0289
INFO - 2021-04-20 23:01:57 --> Config Class Initialized
INFO - 2021-04-20 23:01:57 --> Hooks Class Initialized
DEBUG - 2021-04-20 23:01:57 --> UTF-8 Support Enabled
INFO - 2021-04-20 23:01:57 --> Utf8 Class Initialized
INFO - 2021-04-20 23:01:57 --> URI Class Initialized
INFO - 2021-04-20 23:01:57 --> Router Class Initialized
INFO - 2021-04-20 23:01:57 --> Output Class Initialized
INFO - 2021-04-20 23:01:57 --> Security Class Initialized
DEBUG - 2021-04-20 23:01:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 23:01:57 --> Input Class Initialized
INFO - 2021-04-20 23:01:57 --> Language Class Initialized
INFO - 2021-04-20 23:01:57 --> Loader Class Initialized
INFO - 2021-04-20 23:01:57 --> Helper loaded: url_helper
INFO - 2021-04-20 23:01:57 --> Helper loaded: form_helper
INFO - 2021-04-20 23:01:57 --> Helper loaded: common_helper
INFO - 2021-04-20 23:01:57 --> Helper loaded: util_helper
INFO - 2021-04-20 23:01:57 --> Helper loaded: user_helper
INFO - 2021-04-20 23:01:57 --> Database Driver Class Initialized
DEBUG - 2021-04-20 23:01:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 23:01:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 23:01:57 --> Form Validation Class Initialized
INFO - 2021-04-20 23:01:57 --> Controller Class Initialized
INFO - 2021-04-20 23:01:57 --> Model Class Initialized
INFO - 2021-04-20 23:01:57 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\ckeditor/samples/index.php
INFO - 2021-04-20 23:01:57 --> Final output sent to browser
DEBUG - 2021-04-20 23:01:57 --> Total execution time: 0.0293
INFO - 2021-04-20 23:02:00 --> Config Class Initialized
INFO - 2021-04-20 23:02:00 --> Hooks Class Initialized
DEBUG - 2021-04-20 23:02:00 --> UTF-8 Support Enabled
INFO - 2021-04-20 23:02:00 --> Utf8 Class Initialized
INFO - 2021-04-20 23:02:00 --> URI Class Initialized
INFO - 2021-04-20 23:02:00 --> Router Class Initialized
INFO - 2021-04-20 23:02:00 --> Output Class Initialized
INFO - 2021-04-20 23:02:00 --> Security Class Initialized
DEBUG - 2021-04-20 23:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 23:02:00 --> Input Class Initialized
INFO - 2021-04-20 23:02:00 --> Language Class Initialized
INFO - 2021-04-20 23:02:00 --> Loader Class Initialized
INFO - 2021-04-20 23:02:00 --> Helper loaded: url_helper
INFO - 2021-04-20 23:02:00 --> Helper loaded: form_helper
INFO - 2021-04-20 23:02:00 --> Helper loaded: common_helper
INFO - 2021-04-20 23:02:00 --> Helper loaded: util_helper
INFO - 2021-04-20 23:02:00 --> Helper loaded: user_helper
INFO - 2021-04-20 23:02:00 --> Database Driver Class Initialized
DEBUG - 2021-04-20 23:02:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 23:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 23:02:00 --> Form Validation Class Initialized
INFO - 2021-04-20 23:02:00 --> Controller Class Initialized
INFO - 2021-04-20 23:02:00 --> Model Class Initialized
INFO - 2021-04-20 23:02:00 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\ckeditor/samples/index.php
INFO - 2021-04-20 23:02:00 --> Final output sent to browser
DEBUG - 2021-04-20 23:02:00 --> Total execution time: 0.0276
INFO - 2021-04-20 23:02:00 --> Config Class Initialized
INFO - 2021-04-20 23:02:00 --> Hooks Class Initialized
DEBUG - 2021-04-20 23:02:00 --> UTF-8 Support Enabled
INFO - 2021-04-20 23:02:00 --> Utf8 Class Initialized
INFO - 2021-04-20 23:02:00 --> URI Class Initialized
INFO - 2021-04-20 23:02:00 --> Router Class Initialized
INFO - 2021-04-20 23:02:00 --> Output Class Initialized
INFO - 2021-04-20 23:02:00 --> Security Class Initialized
DEBUG - 2021-04-20 23:02:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 23:02:00 --> Input Class Initialized
INFO - 2021-04-20 23:02:00 --> Language Class Initialized
INFO - 2021-04-20 23:02:00 --> Loader Class Initialized
INFO - 2021-04-20 23:02:00 --> Helper loaded: url_helper
INFO - 2021-04-20 23:02:00 --> Helper loaded: form_helper
INFO - 2021-04-20 23:02:00 --> Helper loaded: common_helper
INFO - 2021-04-20 23:02:00 --> Helper loaded: util_helper
INFO - 2021-04-20 23:02:00 --> Helper loaded: user_helper
INFO - 2021-04-20 23:02:00 --> Database Driver Class Initialized
DEBUG - 2021-04-20 23:02:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 23:02:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 23:02:00 --> Form Validation Class Initialized
INFO - 2021-04-20 23:02:00 --> Controller Class Initialized
INFO - 2021-04-20 23:02:00 --> Model Class Initialized
INFO - 2021-04-20 23:02:00 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\ckeditor/samples/index.php
INFO - 2021-04-20 23:02:00 --> Final output sent to browser
DEBUG - 2021-04-20 23:02:00 --> Total execution time: 0.0308
INFO - 2021-04-20 23:02:03 --> Config Class Initialized
INFO - 2021-04-20 23:02:03 --> Hooks Class Initialized
DEBUG - 2021-04-20 23:02:03 --> UTF-8 Support Enabled
INFO - 2021-04-20 23:02:03 --> Utf8 Class Initialized
INFO - 2021-04-20 23:02:03 --> URI Class Initialized
INFO - 2021-04-20 23:02:03 --> Router Class Initialized
INFO - 2021-04-20 23:02:03 --> Output Class Initialized
INFO - 2021-04-20 23:02:03 --> Security Class Initialized
DEBUG - 2021-04-20 23:02:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 23:02:03 --> Input Class Initialized
INFO - 2021-04-20 23:02:03 --> Language Class Initialized
INFO - 2021-04-20 23:02:03 --> Loader Class Initialized
INFO - 2021-04-20 23:02:03 --> Helper loaded: url_helper
INFO - 2021-04-20 23:02:03 --> Helper loaded: form_helper
INFO - 2021-04-20 23:02:03 --> Helper loaded: common_helper
INFO - 2021-04-20 23:02:03 --> Helper loaded: util_helper
INFO - 2021-04-20 23:02:03 --> Helper loaded: user_helper
INFO - 2021-04-20 23:02:03 --> Database Driver Class Initialized
DEBUG - 2021-04-20 23:02:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 23:02:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 23:02:03 --> Form Validation Class Initialized
INFO - 2021-04-20 23:02:03 --> Controller Class Initialized
INFO - 2021-04-20 23:02:03 --> Model Class Initialized
INFO - 2021-04-20 23:02:03 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\ckeditor/samples/index.php
INFO - 2021-04-20 23:02:03 --> Final output sent to browser
DEBUG - 2021-04-20 23:02:03 --> Total execution time: 0.0395
INFO - 2021-04-20 23:02:07 --> Config Class Initialized
INFO - 2021-04-20 23:02:07 --> Hooks Class Initialized
DEBUG - 2021-04-20 23:02:07 --> UTF-8 Support Enabled
INFO - 2021-04-20 23:02:07 --> Utf8 Class Initialized
INFO - 2021-04-20 23:02:07 --> URI Class Initialized
INFO - 2021-04-20 23:02:07 --> Router Class Initialized
INFO - 2021-04-20 23:02:07 --> Output Class Initialized
INFO - 2021-04-20 23:02:07 --> Security Class Initialized
DEBUG - 2021-04-20 23:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 23:02:07 --> Input Class Initialized
INFO - 2021-04-20 23:02:07 --> Language Class Initialized
INFO - 2021-04-20 23:02:07 --> Loader Class Initialized
INFO - 2021-04-20 23:02:07 --> Helper loaded: url_helper
INFO - 2021-04-20 23:02:07 --> Helper loaded: form_helper
INFO - 2021-04-20 23:02:07 --> Helper loaded: common_helper
INFO - 2021-04-20 23:02:07 --> Helper loaded: util_helper
INFO - 2021-04-20 23:02:07 --> Helper loaded: user_helper
INFO - 2021-04-20 23:02:07 --> Database Driver Class Initialized
DEBUG - 2021-04-20 23:02:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 23:02:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 23:02:07 --> Form Validation Class Initialized
INFO - 2021-04-20 23:02:07 --> Controller Class Initialized
INFO - 2021-04-20 23:02:07 --> Model Class Initialized
INFO - 2021-04-20 23:02:07 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\ckeditor/samples/index.php
INFO - 2021-04-20 23:02:07 --> Final output sent to browser
DEBUG - 2021-04-20 23:02:07 --> Total execution time: 0.0284
INFO - 2021-04-20 23:02:07 --> Config Class Initialized
INFO - 2021-04-20 23:02:07 --> Hooks Class Initialized
DEBUG - 2021-04-20 23:02:07 --> UTF-8 Support Enabled
INFO - 2021-04-20 23:02:07 --> Utf8 Class Initialized
INFO - 2021-04-20 23:02:07 --> URI Class Initialized
INFO - 2021-04-20 23:02:07 --> Router Class Initialized
INFO - 2021-04-20 23:02:07 --> Output Class Initialized
INFO - 2021-04-20 23:02:07 --> Security Class Initialized
DEBUG - 2021-04-20 23:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 23:02:07 --> Input Class Initialized
INFO - 2021-04-20 23:02:07 --> Language Class Initialized
ERROR - 2021-04-20 23:02:07 --> 404 Page Not Found: administrator/Cms/ckeditor.js
INFO - 2021-04-20 23:02:09 --> Config Class Initialized
INFO - 2021-04-20 23:02:09 --> Hooks Class Initialized
DEBUG - 2021-04-20 23:02:09 --> UTF-8 Support Enabled
INFO - 2021-04-20 23:02:09 --> Utf8 Class Initialized
INFO - 2021-04-20 23:02:09 --> URI Class Initialized
INFO - 2021-04-20 23:02:09 --> Router Class Initialized
INFO - 2021-04-20 23:02:09 --> Output Class Initialized
INFO - 2021-04-20 23:02:09 --> Security Class Initialized
DEBUG - 2021-04-20 23:02:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 23:02:09 --> Input Class Initialized
INFO - 2021-04-20 23:02:09 --> Language Class Initialized
INFO - 2021-04-20 23:02:09 --> Loader Class Initialized
INFO - 2021-04-20 23:02:09 --> Helper loaded: url_helper
INFO - 2021-04-20 23:02:09 --> Helper loaded: form_helper
INFO - 2021-04-20 23:02:09 --> Helper loaded: common_helper
INFO - 2021-04-20 23:02:09 --> Helper loaded: util_helper
INFO - 2021-04-20 23:02:09 --> Helper loaded: user_helper
INFO - 2021-04-20 23:02:09 --> Database Driver Class Initialized
DEBUG - 2021-04-20 23:02:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 23:02:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 23:02:09 --> Form Validation Class Initialized
INFO - 2021-04-20 23:02:09 --> Controller Class Initialized
INFO - 2021-04-20 23:02:09 --> Model Class Initialized
INFO - 2021-04-20 23:02:09 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\ckeditor/samples/index.php
INFO - 2021-04-20 23:02:09 --> Final output sent to browser
DEBUG - 2021-04-20 23:02:09 --> Total execution time: 0.0307
INFO - 2021-04-20 23:04:16 --> Config Class Initialized
INFO - 2021-04-20 23:04:16 --> Hooks Class Initialized
DEBUG - 2021-04-20 23:04:16 --> UTF-8 Support Enabled
INFO - 2021-04-20 23:04:16 --> Utf8 Class Initialized
INFO - 2021-04-20 23:04:16 --> URI Class Initialized
INFO - 2021-04-20 23:04:16 --> Router Class Initialized
INFO - 2021-04-20 23:04:16 --> Output Class Initialized
INFO - 2021-04-20 23:04:16 --> Security Class Initialized
DEBUG - 2021-04-20 23:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 23:04:16 --> Input Class Initialized
INFO - 2021-04-20 23:04:16 --> Language Class Initialized
INFO - 2021-04-20 23:04:16 --> Loader Class Initialized
INFO - 2021-04-20 23:04:16 --> Helper loaded: url_helper
INFO - 2021-04-20 23:04:16 --> Helper loaded: form_helper
INFO - 2021-04-20 23:04:16 --> Helper loaded: common_helper
INFO - 2021-04-20 23:04:16 --> Helper loaded: util_helper
INFO - 2021-04-20 23:04:16 --> Helper loaded: user_helper
INFO - 2021-04-20 23:04:16 --> Database Driver Class Initialized
DEBUG - 2021-04-20 23:04:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 23:04:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 23:04:16 --> Form Validation Class Initialized
INFO - 2021-04-20 23:04:16 --> Controller Class Initialized
INFO - 2021-04-20 23:04:16 --> Model Class Initialized
INFO - 2021-04-20 23:04:16 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\ckeditor/samples/index.php
INFO - 2021-04-20 23:04:16 --> Final output sent to browser
DEBUG - 2021-04-20 23:04:16 --> Total execution time: 0.0385
INFO - 2021-04-20 23:04:16 --> Config Class Initialized
INFO - 2021-04-20 23:04:16 --> Hooks Class Initialized
DEBUG - 2021-04-20 23:04:16 --> UTF-8 Support Enabled
INFO - 2021-04-20 23:04:16 --> Utf8 Class Initialized
INFO - 2021-04-20 23:04:16 --> URI Class Initialized
INFO - 2021-04-20 23:04:16 --> Router Class Initialized
INFO - 2021-04-20 23:04:16 --> Output Class Initialized
INFO - 2021-04-20 23:04:16 --> Security Class Initialized
DEBUG - 2021-04-20 23:04:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 23:04:16 --> Input Class Initialized
INFO - 2021-04-20 23:04:16 --> Language Class Initialized
ERROR - 2021-04-20 23:04:16 --> 404 Page Not Found: administrator/Cms/ckeditor.js
INFO - 2021-04-20 23:09:27 --> Config Class Initialized
INFO - 2021-04-20 23:09:27 --> Hooks Class Initialized
DEBUG - 2021-04-20 23:09:27 --> UTF-8 Support Enabled
INFO - 2021-04-20 23:09:27 --> Utf8 Class Initialized
INFO - 2021-04-20 23:09:27 --> URI Class Initialized
INFO - 2021-04-20 23:09:27 --> Router Class Initialized
INFO - 2021-04-20 23:09:27 --> Output Class Initialized
INFO - 2021-04-20 23:09:27 --> Security Class Initialized
DEBUG - 2021-04-20 23:09:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 23:09:27 --> Input Class Initialized
INFO - 2021-04-20 23:09:27 --> Language Class Initialized
INFO - 2021-04-20 23:09:27 --> Loader Class Initialized
INFO - 2021-04-20 23:09:27 --> Helper loaded: url_helper
INFO - 2021-04-20 23:09:27 --> Helper loaded: form_helper
INFO - 2021-04-20 23:09:27 --> Helper loaded: common_helper
INFO - 2021-04-20 23:09:27 --> Helper loaded: util_helper
INFO - 2021-04-20 23:09:27 --> Helper loaded: user_helper
INFO - 2021-04-20 23:09:27 --> Database Driver Class Initialized
DEBUG - 2021-04-20 23:09:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 23:09:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 23:09:27 --> Form Validation Class Initialized
INFO - 2021-04-20 23:09:27 --> Controller Class Initialized
INFO - 2021-04-20 23:09:27 --> Model Class Initialized
INFO - 2021-04-20 23:09:28 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\viewaccount.php
INFO - 2021-04-20 23:09:28 --> Final output sent to browser
DEBUG - 2021-04-20 23:09:28 --> Total execution time: 0.0410
INFO - 2021-04-20 23:09:30 --> Config Class Initialized
INFO - 2021-04-20 23:09:30 --> Hooks Class Initialized
DEBUG - 2021-04-20 23:09:30 --> UTF-8 Support Enabled
INFO - 2021-04-20 23:09:30 --> Utf8 Class Initialized
INFO - 2021-04-20 23:09:30 --> URI Class Initialized
INFO - 2021-04-20 23:09:30 --> Router Class Initialized
INFO - 2021-04-20 23:09:30 --> Output Class Initialized
INFO - 2021-04-20 23:09:30 --> Security Class Initialized
DEBUG - 2021-04-20 23:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 23:09:30 --> Input Class Initialized
INFO - 2021-04-20 23:09:30 --> Language Class Initialized
INFO - 2021-04-20 23:09:30 --> Loader Class Initialized
INFO - 2021-04-20 23:09:30 --> Helper loaded: url_helper
INFO - 2021-04-20 23:09:30 --> Helper loaded: form_helper
INFO - 2021-04-20 23:09:30 --> Helper loaded: common_helper
INFO - 2021-04-20 23:09:30 --> Helper loaded: util_helper
INFO - 2021-04-20 23:09:30 --> Helper loaded: user_helper
INFO - 2021-04-20 23:09:30 --> Database Driver Class Initialized
DEBUG - 2021-04-20 23:09:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 23:09:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 23:09:30 --> Form Validation Class Initialized
INFO - 2021-04-20 23:09:30 --> Controller Class Initialized
INFO - 2021-04-20 23:09:30 --> Model Class Initialized
INFO - 2021-04-20 23:09:30 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\viewaccount.php
INFO - 2021-04-20 23:09:30 --> Final output sent to browser
DEBUG - 2021-04-20 23:09:30 --> Total execution time: 0.0288
INFO - 2021-04-20 23:09:30 --> Config Class Initialized
INFO - 2021-04-20 23:09:30 --> Hooks Class Initialized
INFO - 2021-04-20 23:09:30 --> Config Class Initialized
INFO - 2021-04-20 23:09:30 --> Hooks Class Initialized
DEBUG - 2021-04-20 23:09:30 --> UTF-8 Support Enabled
INFO - 2021-04-20 23:09:30 --> Utf8 Class Initialized
DEBUG - 2021-04-20 23:09:30 --> UTF-8 Support Enabled
INFO - 2021-04-20 23:09:30 --> Utf8 Class Initialized
INFO - 2021-04-20 23:09:30 --> URI Class Initialized
INFO - 2021-04-20 23:09:30 --> URI Class Initialized
INFO - 2021-04-20 23:09:30 --> Router Class Initialized
INFO - 2021-04-20 23:09:30 --> Router Class Initialized
INFO - 2021-04-20 23:09:30 --> Output Class Initialized
INFO - 2021-04-20 23:09:30 --> Output Class Initialized
INFO - 2021-04-20 23:09:30 --> Security Class Initialized
INFO - 2021-04-20 23:09:30 --> Security Class Initialized
DEBUG - 2021-04-20 23:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 23:09:30 --> Input Class Initialized
INFO - 2021-04-20 23:09:30 --> Language Class Initialized
DEBUG - 2021-04-20 23:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 23:09:30 --> Input Class Initialized
INFO - 2021-04-20 23:09:30 --> Language Class Initialized
ERROR - 2021-04-20 23:09:30 --> 404 Page Not Found: Assets/plugins
ERROR - 2021-04-20 23:09:30 --> 404 Page Not Found: Assets/plugins
INFO - 2021-04-20 23:09:30 --> Config Class Initialized
INFO - 2021-04-20 23:09:30 --> Hooks Class Initialized
DEBUG - 2021-04-20 23:09:30 --> UTF-8 Support Enabled
INFO - 2021-04-20 23:09:30 --> Utf8 Class Initialized
INFO - 2021-04-20 23:09:30 --> URI Class Initialized
INFO - 2021-04-20 23:09:30 --> Router Class Initialized
INFO - 2021-04-20 23:09:30 --> Output Class Initialized
INFO - 2021-04-20 23:09:30 --> Security Class Initialized
DEBUG - 2021-04-20 23:09:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 23:09:30 --> Input Class Initialized
INFO - 2021-04-20 23:09:30 --> Language Class Initialized
ERROR - 2021-04-20 23:09:30 --> 404 Page Not Found: Assets/plugins
INFO - 2021-04-20 23:09:33 --> Config Class Initialized
INFO - 2021-04-20 23:09:33 --> Hooks Class Initialized
DEBUG - 2021-04-20 23:09:33 --> UTF-8 Support Enabled
INFO - 2021-04-20 23:09:33 --> Utf8 Class Initialized
INFO - 2021-04-20 23:09:33 --> URI Class Initialized
INFO - 2021-04-20 23:09:33 --> Router Class Initialized
INFO - 2021-04-20 23:09:33 --> Output Class Initialized
INFO - 2021-04-20 23:09:33 --> Security Class Initialized
DEBUG - 2021-04-20 23:09:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 23:09:33 --> Input Class Initialized
INFO - 2021-04-20 23:09:33 --> Language Class Initialized
ERROR - 2021-04-20 23:09:33 --> 404 Page Not Found: administrator/Cms/delete_row
INFO - 2021-04-20 23:09:34 --> Config Class Initialized
INFO - 2021-04-20 23:09:34 --> Hooks Class Initialized
DEBUG - 2021-04-20 23:09:34 --> UTF-8 Support Enabled
INFO - 2021-04-20 23:09:34 --> Utf8 Class Initialized
INFO - 2021-04-20 23:09:34 --> URI Class Initialized
INFO - 2021-04-20 23:09:34 --> Router Class Initialized
INFO - 2021-04-20 23:09:34 --> Output Class Initialized
INFO - 2021-04-20 23:09:34 --> Security Class Initialized
DEBUG - 2021-04-20 23:09:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 23:09:34 --> Input Class Initialized
INFO - 2021-04-20 23:09:34 --> Language Class Initialized
INFO - 2021-04-20 23:09:34 --> Loader Class Initialized
INFO - 2021-04-20 23:09:34 --> Helper loaded: url_helper
INFO - 2021-04-20 23:09:34 --> Helper loaded: form_helper
INFO - 2021-04-20 23:09:34 --> Helper loaded: common_helper
INFO - 2021-04-20 23:09:34 --> Helper loaded: util_helper
INFO - 2021-04-20 23:09:34 --> Helper loaded: user_helper
INFO - 2021-04-20 23:09:34 --> Database Driver Class Initialized
DEBUG - 2021-04-20 23:09:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 23:09:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 23:09:34 --> Form Validation Class Initialized
INFO - 2021-04-20 23:09:34 --> Controller Class Initialized
INFO - 2021-04-20 23:09:34 --> Model Class Initialized
INFO - 2021-04-20 23:09:34 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\viewaccount.php
INFO - 2021-04-20 23:09:34 --> Final output sent to browser
DEBUG - 2021-04-20 23:09:34 --> Total execution time: 0.0293
INFO - 2021-04-20 23:09:36 --> Config Class Initialized
INFO - 2021-04-20 23:09:36 --> Hooks Class Initialized
DEBUG - 2021-04-20 23:09:36 --> UTF-8 Support Enabled
INFO - 2021-04-20 23:09:36 --> Utf8 Class Initialized
INFO - 2021-04-20 23:09:36 --> URI Class Initialized
INFO - 2021-04-20 23:09:36 --> Router Class Initialized
INFO - 2021-04-20 23:09:36 --> Output Class Initialized
INFO - 2021-04-20 23:09:36 --> Security Class Initialized
DEBUG - 2021-04-20 23:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 23:09:36 --> Input Class Initialized
INFO - 2021-04-20 23:09:36 --> Language Class Initialized
INFO - 2021-04-20 23:09:36 --> Loader Class Initialized
INFO - 2021-04-20 23:09:36 --> Helper loaded: url_helper
INFO - 2021-04-20 23:09:36 --> Helper loaded: form_helper
INFO - 2021-04-20 23:09:36 --> Helper loaded: common_helper
INFO - 2021-04-20 23:09:36 --> Helper loaded: util_helper
INFO - 2021-04-20 23:09:36 --> Helper loaded: user_helper
INFO - 2021-04-20 23:09:36 --> Database Driver Class Initialized
DEBUG - 2021-04-20 23:09:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 23:09:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 23:09:36 --> Form Validation Class Initialized
INFO - 2021-04-20 23:09:36 --> Controller Class Initialized
INFO - 2021-04-20 23:09:36 --> Model Class Initialized
INFO - 2021-04-20 23:09:36 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\viewaccount.php
INFO - 2021-04-20 23:09:36 --> Final output sent to browser
DEBUG - 2021-04-20 23:09:36 --> Total execution time: 0.0424
INFO - 2021-04-20 23:09:36 --> Config Class Initialized
INFO - 2021-04-20 23:09:36 --> Hooks Class Initialized
INFO - 2021-04-20 23:09:36 --> Config Class Initialized
INFO - 2021-04-20 23:09:36 --> Hooks Class Initialized
DEBUG - 2021-04-20 23:09:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-20 23:09:36 --> UTF-8 Support Enabled
INFO - 2021-04-20 23:09:36 --> Utf8 Class Initialized
INFO - 2021-04-20 23:09:36 --> Utf8 Class Initialized
INFO - 2021-04-20 23:09:36 --> URI Class Initialized
INFO - 2021-04-20 23:09:36 --> URI Class Initialized
INFO - 2021-04-20 23:09:36 --> Router Class Initialized
INFO - 2021-04-20 23:09:36 --> Router Class Initialized
INFO - 2021-04-20 23:09:36 --> Output Class Initialized
INFO - 2021-04-20 23:09:36 --> Output Class Initialized
INFO - 2021-04-20 23:09:36 --> Security Class Initialized
INFO - 2021-04-20 23:09:36 --> Security Class Initialized
DEBUG - 2021-04-20 23:09:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-20 23:09:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 23:09:36 --> Input Class Initialized
INFO - 2021-04-20 23:09:36 --> Input Class Initialized
INFO - 2021-04-20 23:09:36 --> Language Class Initialized
INFO - 2021-04-20 23:09:36 --> Language Class Initialized
ERROR - 2021-04-20 23:09:36 --> 404 Page Not Found: Assets/plugins
ERROR - 2021-04-20 23:09:36 --> 404 Page Not Found: Assets/plugins
INFO - 2021-04-20 23:09:38 --> Config Class Initialized
INFO - 2021-04-20 23:09:38 --> Hooks Class Initialized
DEBUG - 2021-04-20 23:09:38 --> UTF-8 Support Enabled
INFO - 2021-04-20 23:09:38 --> Utf8 Class Initialized
INFO - 2021-04-20 23:09:38 --> URI Class Initialized
INFO - 2021-04-20 23:09:38 --> Router Class Initialized
INFO - 2021-04-20 23:09:38 --> Output Class Initialized
INFO - 2021-04-20 23:09:38 --> Security Class Initialized
DEBUG - 2021-04-20 23:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 23:09:38 --> Input Class Initialized
INFO - 2021-04-20 23:09:38 --> Language Class Initialized
INFO - 2021-04-20 23:09:38 --> Loader Class Initialized
INFO - 2021-04-20 23:09:38 --> Helper loaded: url_helper
INFO - 2021-04-20 23:09:38 --> Helper loaded: form_helper
INFO - 2021-04-20 23:09:38 --> Helper loaded: common_helper
INFO - 2021-04-20 23:09:38 --> Helper loaded: util_helper
INFO - 2021-04-20 23:09:38 --> Helper loaded: user_helper
INFO - 2021-04-20 23:09:38 --> Database Driver Class Initialized
DEBUG - 2021-04-20 23:09:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 23:09:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 23:09:38 --> Form Validation Class Initialized
INFO - 2021-04-20 23:09:38 --> Controller Class Initialized
INFO - 2021-04-20 23:09:38 --> Model Class Initialized
INFO - 2021-04-20 23:09:38 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\ckeditor/samples/index.php
INFO - 2021-04-20 23:09:38 --> Final output sent to browser
DEBUG - 2021-04-20 23:09:38 --> Total execution time: 0.0287
INFO - 2021-04-20 23:09:38 --> Config Class Initialized
INFO - 2021-04-20 23:09:38 --> Hooks Class Initialized
DEBUG - 2021-04-20 23:09:38 --> UTF-8 Support Enabled
INFO - 2021-04-20 23:09:38 --> Utf8 Class Initialized
INFO - 2021-04-20 23:09:38 --> URI Class Initialized
INFO - 2021-04-20 23:09:38 --> Router Class Initialized
INFO - 2021-04-20 23:09:38 --> Output Class Initialized
INFO - 2021-04-20 23:09:38 --> Security Class Initialized
DEBUG - 2021-04-20 23:09:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 23:09:38 --> Input Class Initialized
INFO - 2021-04-20 23:09:38 --> Language Class Initialized
ERROR - 2021-04-20 23:09:38 --> 404 Page Not Found: administrator/Cms/ckeditor.js
INFO - 2021-04-20 23:09:40 --> Config Class Initialized
INFO - 2021-04-20 23:09:40 --> Hooks Class Initialized
DEBUG - 2021-04-20 23:09:40 --> UTF-8 Support Enabled
INFO - 2021-04-20 23:09:40 --> Utf8 Class Initialized
INFO - 2021-04-20 23:09:40 --> URI Class Initialized
INFO - 2021-04-20 23:09:40 --> Router Class Initialized
INFO - 2021-04-20 23:09:40 --> Output Class Initialized
INFO - 2021-04-20 23:09:40 --> Security Class Initialized
DEBUG - 2021-04-20 23:09:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 23:09:40 --> Input Class Initialized
INFO - 2021-04-20 23:09:40 --> Language Class Initialized
INFO - 2021-04-20 23:09:40 --> Loader Class Initialized
INFO - 2021-04-20 23:09:40 --> Helper loaded: url_helper
INFO - 2021-04-20 23:09:40 --> Helper loaded: form_helper
INFO - 2021-04-20 23:09:40 --> Helper loaded: common_helper
INFO - 2021-04-20 23:09:40 --> Helper loaded: util_helper
INFO - 2021-04-20 23:09:40 --> Helper loaded: user_helper
INFO - 2021-04-20 23:09:40 --> Database Driver Class Initialized
DEBUG - 2021-04-20 23:09:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 23:09:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 23:09:40 --> Form Validation Class Initialized
INFO - 2021-04-20 23:09:40 --> Controller Class Initialized
INFO - 2021-04-20 23:09:40 --> Model Class Initialized
INFO - 2021-04-20 23:09:40 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\viewaccount.php
INFO - 2021-04-20 23:09:40 --> Final output sent to browser
DEBUG - 2021-04-20 23:09:40 --> Total execution time: 0.0300
INFO - 2021-04-20 23:10:35 --> Config Class Initialized
INFO - 2021-04-20 23:10:35 --> Hooks Class Initialized
DEBUG - 2021-04-20 23:10:35 --> UTF-8 Support Enabled
INFO - 2021-04-20 23:10:35 --> Utf8 Class Initialized
INFO - 2021-04-20 23:10:35 --> URI Class Initialized
INFO - 2021-04-20 23:10:35 --> Router Class Initialized
INFO - 2021-04-20 23:10:35 --> Output Class Initialized
INFO - 2021-04-20 23:10:35 --> Security Class Initialized
DEBUG - 2021-04-20 23:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 23:10:35 --> Input Class Initialized
INFO - 2021-04-20 23:10:35 --> Language Class Initialized
INFO - 2021-04-20 23:10:35 --> Loader Class Initialized
INFO - 2021-04-20 23:10:35 --> Helper loaded: url_helper
INFO - 2021-04-20 23:10:35 --> Helper loaded: form_helper
INFO - 2021-04-20 23:10:35 --> Helper loaded: common_helper
INFO - 2021-04-20 23:10:35 --> Helper loaded: util_helper
INFO - 2021-04-20 23:10:35 --> Helper loaded: user_helper
INFO - 2021-04-20 23:10:35 --> Database Driver Class Initialized
DEBUG - 2021-04-20 23:10:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 23:10:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 23:10:35 --> Form Validation Class Initialized
INFO - 2021-04-20 23:10:35 --> Controller Class Initialized
INFO - 2021-04-20 23:10:35 --> Model Class Initialized
INFO - 2021-04-20 23:10:35 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\viewaccount.php
INFO - 2021-04-20 23:10:35 --> Final output sent to browser
DEBUG - 2021-04-20 23:10:35 --> Total execution time: 0.0294
INFO - 2021-04-20 23:10:35 --> Config Class Initialized
INFO - 2021-04-20 23:10:35 --> Hooks Class Initialized
INFO - 2021-04-20 23:10:35 --> Config Class Initialized
INFO - 2021-04-20 23:10:35 --> Hooks Class Initialized
DEBUG - 2021-04-20 23:10:35 --> UTF-8 Support Enabled
INFO - 2021-04-20 23:10:35 --> Utf8 Class Initialized
DEBUG - 2021-04-20 23:10:35 --> UTF-8 Support Enabled
INFO - 2021-04-20 23:10:35 --> Utf8 Class Initialized
INFO - 2021-04-20 23:10:35 --> URI Class Initialized
INFO - 2021-04-20 23:10:35 --> URI Class Initialized
INFO - 2021-04-20 23:10:35 --> Router Class Initialized
INFO - 2021-04-20 23:10:35 --> Router Class Initialized
INFO - 2021-04-20 23:10:35 --> Output Class Initialized
INFO - 2021-04-20 23:10:35 --> Output Class Initialized
INFO - 2021-04-20 23:10:35 --> Security Class Initialized
INFO - 2021-04-20 23:10:35 --> Security Class Initialized
DEBUG - 2021-04-20 23:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 23:10:35 --> Input Class Initialized
INFO - 2021-04-20 23:10:35 --> Language Class Initialized
DEBUG - 2021-04-20 23:10:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 23:10:35 --> Input Class Initialized
INFO - 2021-04-20 23:10:35 --> Language Class Initialized
ERROR - 2021-04-20 23:10:35 --> 404 Page Not Found: Assets/plugins
ERROR - 2021-04-20 23:10:35 --> 404 Page Not Found: Assets/plugins
INFO - 2021-04-20 23:10:37 --> Config Class Initialized
INFO - 2021-04-20 23:10:37 --> Hooks Class Initialized
DEBUG - 2021-04-20 23:10:37 --> UTF-8 Support Enabled
INFO - 2021-04-20 23:10:37 --> Utf8 Class Initialized
INFO - 2021-04-20 23:10:37 --> URI Class Initialized
INFO - 2021-04-20 23:10:37 --> Router Class Initialized
INFO - 2021-04-20 23:10:37 --> Output Class Initialized
INFO - 2021-04-20 23:10:37 --> Security Class Initialized
DEBUG - 2021-04-20 23:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 23:10:37 --> Input Class Initialized
INFO - 2021-04-20 23:10:37 --> Language Class Initialized
INFO - 2021-04-20 23:10:37 --> Loader Class Initialized
INFO - 2021-04-20 23:10:37 --> Helper loaded: url_helper
INFO - 2021-04-20 23:10:37 --> Helper loaded: form_helper
INFO - 2021-04-20 23:10:37 --> Helper loaded: common_helper
INFO - 2021-04-20 23:10:37 --> Helper loaded: util_helper
INFO - 2021-04-20 23:10:37 --> Helper loaded: user_helper
INFO - 2021-04-20 23:10:37 --> Database Driver Class Initialized
DEBUG - 2021-04-20 23:10:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 23:10:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 23:10:37 --> Form Validation Class Initialized
INFO - 2021-04-20 23:10:37 --> Controller Class Initialized
INFO - 2021-04-20 23:10:37 --> Model Class Initialized
INFO - 2021-04-20 23:10:37 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\ckeditor/samples/index.php
INFO - 2021-04-20 23:10:37 --> Final output sent to browser
DEBUG - 2021-04-20 23:10:37 --> Total execution time: 0.0288
INFO - 2021-04-20 23:10:37 --> Config Class Initialized
INFO - 2021-04-20 23:10:37 --> Hooks Class Initialized
DEBUG - 2021-04-20 23:10:37 --> UTF-8 Support Enabled
INFO - 2021-04-20 23:10:37 --> Utf8 Class Initialized
INFO - 2021-04-20 23:10:37 --> URI Class Initialized
INFO - 2021-04-20 23:10:37 --> Router Class Initialized
INFO - 2021-04-20 23:10:37 --> Output Class Initialized
INFO - 2021-04-20 23:10:37 --> Security Class Initialized
DEBUG - 2021-04-20 23:10:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 23:10:37 --> Input Class Initialized
INFO - 2021-04-20 23:10:37 --> Language Class Initialized
ERROR - 2021-04-20 23:10:37 --> 404 Page Not Found: administrator/Cms/ckeditor.js
INFO - 2021-04-20 23:10:39 --> Config Class Initialized
INFO - 2021-04-20 23:10:39 --> Hooks Class Initialized
DEBUG - 2021-04-20 23:10:39 --> UTF-8 Support Enabled
INFO - 2021-04-20 23:10:39 --> Utf8 Class Initialized
INFO - 2021-04-20 23:10:39 --> URI Class Initialized
INFO - 2021-04-20 23:10:39 --> Router Class Initialized
INFO - 2021-04-20 23:10:39 --> Output Class Initialized
INFO - 2021-04-20 23:10:39 --> Security Class Initialized
DEBUG - 2021-04-20 23:10:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 23:10:39 --> Input Class Initialized
INFO - 2021-04-20 23:10:39 --> Language Class Initialized
INFO - 2021-04-20 23:10:39 --> Loader Class Initialized
INFO - 2021-04-20 23:10:39 --> Helper loaded: url_helper
INFO - 2021-04-20 23:10:39 --> Helper loaded: form_helper
INFO - 2021-04-20 23:10:39 --> Helper loaded: common_helper
INFO - 2021-04-20 23:10:39 --> Helper loaded: util_helper
INFO - 2021-04-20 23:10:39 --> Helper loaded: user_helper
INFO - 2021-04-20 23:10:39 --> Database Driver Class Initialized
DEBUG - 2021-04-20 23:10:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 23:10:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 23:10:39 --> Form Validation Class Initialized
INFO - 2021-04-20 23:10:39 --> Controller Class Initialized
INFO - 2021-04-20 23:10:39 --> Model Class Initialized
INFO - 2021-04-20 23:10:39 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\viewaccount.php
INFO - 2021-04-20 23:10:39 --> Final output sent to browser
DEBUG - 2021-04-20 23:10:39 --> Total execution time: 0.0393
INFO - 2021-04-20 23:10:40 --> Config Class Initialized
INFO - 2021-04-20 23:10:40 --> Hooks Class Initialized
DEBUG - 2021-04-20 23:10:40 --> UTF-8 Support Enabled
INFO - 2021-04-20 23:10:40 --> Utf8 Class Initialized
INFO - 2021-04-20 23:10:40 --> URI Class Initialized
INFO - 2021-04-20 23:10:40 --> Router Class Initialized
INFO - 2021-04-20 23:10:40 --> Output Class Initialized
INFO - 2021-04-20 23:10:40 --> Security Class Initialized
DEBUG - 2021-04-20 23:10:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 23:10:40 --> Input Class Initialized
INFO - 2021-04-20 23:10:40 --> Language Class Initialized
INFO - 2021-04-20 23:10:40 --> Loader Class Initialized
INFO - 2021-04-20 23:10:40 --> Helper loaded: url_helper
INFO - 2021-04-20 23:10:40 --> Helper loaded: form_helper
INFO - 2021-04-20 23:10:40 --> Helper loaded: common_helper
INFO - 2021-04-20 23:10:40 --> Helper loaded: util_helper
INFO - 2021-04-20 23:10:40 --> Helper loaded: user_helper
INFO - 2021-04-20 23:10:41 --> Database Driver Class Initialized
DEBUG - 2021-04-20 23:10:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 23:10:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 23:10:41 --> Form Validation Class Initialized
INFO - 2021-04-20 23:10:41 --> Controller Class Initialized
INFO - 2021-04-20 23:10:41 --> Model Class Initialized
INFO - 2021-04-20 23:10:41 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\ckeditor/samples/index.php
INFO - 2021-04-20 23:10:41 --> Final output sent to browser
DEBUG - 2021-04-20 23:10:41 --> Total execution time: 0.0395
INFO - 2021-04-20 23:10:41 --> Config Class Initialized
INFO - 2021-04-20 23:10:41 --> Hooks Class Initialized
DEBUG - 2021-04-20 23:10:41 --> UTF-8 Support Enabled
INFO - 2021-04-20 23:10:41 --> Utf8 Class Initialized
INFO - 2021-04-20 23:10:41 --> URI Class Initialized
INFO - 2021-04-20 23:10:41 --> Router Class Initialized
INFO - 2021-04-20 23:10:41 --> Output Class Initialized
INFO - 2021-04-20 23:10:41 --> Security Class Initialized
DEBUG - 2021-04-20 23:10:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 23:10:41 --> Input Class Initialized
INFO - 2021-04-20 23:10:41 --> Language Class Initialized
ERROR - 2021-04-20 23:10:41 --> 404 Page Not Found: administrator/Cms/ckeditor.js
INFO - 2021-04-20 23:10:44 --> Config Class Initialized
INFO - 2021-04-20 23:10:44 --> Hooks Class Initialized
DEBUG - 2021-04-20 23:10:44 --> UTF-8 Support Enabled
INFO - 2021-04-20 23:10:44 --> Utf8 Class Initialized
INFO - 2021-04-20 23:10:44 --> URI Class Initialized
INFO - 2021-04-20 23:10:44 --> Router Class Initialized
INFO - 2021-04-20 23:10:44 --> Output Class Initialized
INFO - 2021-04-20 23:10:44 --> Security Class Initialized
DEBUG - 2021-04-20 23:10:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 23:10:44 --> Input Class Initialized
INFO - 2021-04-20 23:10:44 --> Language Class Initialized
INFO - 2021-04-20 23:10:44 --> Loader Class Initialized
INFO - 2021-04-20 23:10:44 --> Helper loaded: url_helper
INFO - 2021-04-20 23:10:44 --> Helper loaded: form_helper
INFO - 2021-04-20 23:10:44 --> Helper loaded: common_helper
INFO - 2021-04-20 23:10:44 --> Helper loaded: util_helper
INFO - 2021-04-20 23:10:44 --> Helper loaded: user_helper
INFO - 2021-04-20 23:10:44 --> Database Driver Class Initialized
DEBUG - 2021-04-20 23:10:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 23:10:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 23:10:44 --> Form Validation Class Initialized
INFO - 2021-04-20 23:10:44 --> Controller Class Initialized
INFO - 2021-04-20 23:10:44 --> Model Class Initialized
INFO - 2021-04-20 23:10:44 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\viewaccount.php
INFO - 2021-04-20 23:10:44 --> Final output sent to browser
DEBUG - 2021-04-20 23:10:44 --> Total execution time: 0.0280
INFO - 2021-04-20 23:19:44 --> Config Class Initialized
INFO - 2021-04-20 23:19:44 --> Hooks Class Initialized
DEBUG - 2021-04-20 23:19:44 --> UTF-8 Support Enabled
INFO - 2021-04-20 23:19:44 --> Utf8 Class Initialized
INFO - 2021-04-20 23:19:44 --> URI Class Initialized
INFO - 2021-04-20 23:19:44 --> Router Class Initialized
INFO - 2021-04-20 23:19:44 --> Output Class Initialized
INFO - 2021-04-20 23:19:44 --> Security Class Initialized
DEBUG - 2021-04-20 23:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 23:19:44 --> Input Class Initialized
INFO - 2021-04-20 23:19:44 --> Language Class Initialized
INFO - 2021-04-20 23:19:44 --> Loader Class Initialized
INFO - 2021-04-20 23:19:44 --> Helper loaded: url_helper
INFO - 2021-04-20 23:19:44 --> Helper loaded: form_helper
INFO - 2021-04-20 23:19:44 --> Helper loaded: common_helper
INFO - 2021-04-20 23:19:44 --> Helper loaded: util_helper
INFO - 2021-04-20 23:19:44 --> Helper loaded: user_helper
INFO - 2021-04-20 23:19:44 --> Database Driver Class Initialized
DEBUG - 2021-04-20 23:19:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 23:19:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 23:19:44 --> Form Validation Class Initialized
INFO - 2021-04-20 23:19:44 --> Controller Class Initialized
INFO - 2021-04-20 23:19:44 --> Model Class Initialized
INFO - 2021-04-20 23:19:44 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\viewaccount.php
INFO - 2021-04-20 23:19:44 --> Final output sent to browser
DEBUG - 2021-04-20 23:19:44 --> Total execution time: 0.0304
INFO - 2021-04-20 23:19:44 --> Config Class Initialized
INFO - 2021-04-20 23:19:44 --> Hooks Class Initialized
INFO - 2021-04-20 23:19:44 --> Config Class Initialized
INFO - 2021-04-20 23:19:44 --> Hooks Class Initialized
DEBUG - 2021-04-20 23:19:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-20 23:19:44 --> UTF-8 Support Enabled
INFO - 2021-04-20 23:19:44 --> Utf8 Class Initialized
INFO - 2021-04-20 23:19:44 --> Utf8 Class Initialized
INFO - 2021-04-20 23:19:44 --> URI Class Initialized
INFO - 2021-04-20 23:19:44 --> URI Class Initialized
INFO - 2021-04-20 23:19:44 --> Router Class Initialized
INFO - 2021-04-20 23:19:44 --> Router Class Initialized
INFO - 2021-04-20 23:19:44 --> Output Class Initialized
INFO - 2021-04-20 23:19:44 --> Output Class Initialized
INFO - 2021-04-20 23:19:44 --> Security Class Initialized
INFO - 2021-04-20 23:19:44 --> Security Class Initialized
DEBUG - 2021-04-20 23:19:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-20 23:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 23:19:44 --> Input Class Initialized
INFO - 2021-04-20 23:19:44 --> Input Class Initialized
INFO - 2021-04-20 23:19:44 --> Language Class Initialized
INFO - 2021-04-20 23:19:44 --> Language Class Initialized
ERROR - 2021-04-20 23:19:44 --> 404 Page Not Found: Assets/plugins
ERROR - 2021-04-20 23:19:44 --> 404 Page Not Found: Assets/plugins
INFO - 2021-04-20 23:19:44 --> Config Class Initialized
INFO - 2021-04-20 23:19:44 --> Hooks Class Initialized
DEBUG - 2021-04-20 23:19:44 --> UTF-8 Support Enabled
INFO - 2021-04-20 23:19:44 --> Utf8 Class Initialized
INFO - 2021-04-20 23:19:44 --> URI Class Initialized
INFO - 2021-04-20 23:19:44 --> Router Class Initialized
INFO - 2021-04-20 23:19:44 --> Output Class Initialized
INFO - 2021-04-20 23:19:44 --> Security Class Initialized
DEBUG - 2021-04-20 23:19:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 23:19:44 --> Input Class Initialized
INFO - 2021-04-20 23:19:44 --> Language Class Initialized
ERROR - 2021-04-20 23:19:44 --> 404 Page Not Found: Assets/plugins
INFO - 2021-04-20 23:19:46 --> Config Class Initialized
INFO - 2021-04-20 23:19:46 --> Hooks Class Initialized
DEBUG - 2021-04-20 23:19:46 --> UTF-8 Support Enabled
INFO - 2021-04-20 23:19:46 --> Utf8 Class Initialized
INFO - 2021-04-20 23:19:46 --> URI Class Initialized
INFO - 2021-04-20 23:19:46 --> Router Class Initialized
INFO - 2021-04-20 23:19:46 --> Output Class Initialized
INFO - 2021-04-20 23:19:46 --> Security Class Initialized
DEBUG - 2021-04-20 23:19:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 23:19:46 --> Input Class Initialized
INFO - 2021-04-20 23:19:46 --> Language Class Initialized
INFO - 2021-04-20 23:19:46 --> Loader Class Initialized
INFO - 2021-04-20 23:19:46 --> Helper loaded: url_helper
INFO - 2021-04-20 23:19:46 --> Helper loaded: form_helper
INFO - 2021-04-20 23:19:46 --> Helper loaded: common_helper
INFO - 2021-04-20 23:19:46 --> Helper loaded: util_helper
INFO - 2021-04-20 23:19:46 --> Helper loaded: user_helper
INFO - 2021-04-20 23:19:46 --> Database Driver Class Initialized
DEBUG - 2021-04-20 23:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 23:19:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 23:19:46 --> Form Validation Class Initialized
INFO - 2021-04-20 23:19:46 --> Controller Class Initialized
INFO - 2021-04-20 23:19:46 --> Model Class Initialized
INFO - 2021-04-20 23:19:46 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\ckeditor/samples/updateData.php
INFO - 2021-04-20 23:19:46 --> Final output sent to browser
DEBUG - 2021-04-20 23:19:46 --> Total execution time: 0.0311
INFO - 2021-04-20 23:19:51 --> Config Class Initialized
INFO - 2021-04-20 23:19:51 --> Hooks Class Initialized
DEBUG - 2021-04-20 23:19:51 --> UTF-8 Support Enabled
INFO - 2021-04-20 23:19:51 --> Utf8 Class Initialized
INFO - 2021-04-20 23:19:51 --> URI Class Initialized
INFO - 2021-04-20 23:19:51 --> Router Class Initialized
INFO - 2021-04-20 23:19:51 --> Output Class Initialized
INFO - 2021-04-20 23:19:51 --> Security Class Initialized
DEBUG - 2021-04-20 23:19:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 23:19:51 --> Input Class Initialized
INFO - 2021-04-20 23:19:51 --> Language Class Initialized
ERROR - 2021-04-20 23:19:51 --> 404 Page Not Found: administrator/Cms/updateData
INFO - 2021-04-20 23:19:54 --> Config Class Initialized
INFO - 2021-04-20 23:19:54 --> Hooks Class Initialized
DEBUG - 2021-04-20 23:19:54 --> UTF-8 Support Enabled
INFO - 2021-04-20 23:19:54 --> Utf8 Class Initialized
INFO - 2021-04-20 23:19:54 --> URI Class Initialized
INFO - 2021-04-20 23:19:54 --> Router Class Initialized
INFO - 2021-04-20 23:19:54 --> Output Class Initialized
INFO - 2021-04-20 23:19:54 --> Security Class Initialized
DEBUG - 2021-04-20 23:19:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 23:19:54 --> Input Class Initialized
INFO - 2021-04-20 23:19:54 --> Language Class Initialized
INFO - 2021-04-20 23:19:54 --> Loader Class Initialized
INFO - 2021-04-20 23:19:54 --> Helper loaded: url_helper
INFO - 2021-04-20 23:19:54 --> Helper loaded: form_helper
INFO - 2021-04-20 23:19:54 --> Helper loaded: common_helper
INFO - 2021-04-20 23:19:54 --> Helper loaded: util_helper
INFO - 2021-04-20 23:19:54 --> Helper loaded: user_helper
INFO - 2021-04-20 23:19:54 --> Database Driver Class Initialized
DEBUG - 2021-04-20 23:19:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 23:19:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 23:19:54 --> Form Validation Class Initialized
INFO - 2021-04-20 23:19:54 --> Controller Class Initialized
INFO - 2021-04-20 23:19:54 --> Model Class Initialized
INFO - 2021-04-20 23:19:54 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\ckeditor/samples/updateData.php
INFO - 2021-04-20 23:19:54 --> Final output sent to browser
DEBUG - 2021-04-20 23:19:54 --> Total execution time: 0.0293
INFO - 2021-04-20 23:19:55 --> Config Class Initialized
INFO - 2021-04-20 23:19:55 --> Hooks Class Initialized
DEBUG - 2021-04-20 23:19:55 --> UTF-8 Support Enabled
INFO - 2021-04-20 23:19:55 --> Utf8 Class Initialized
INFO - 2021-04-20 23:19:55 --> URI Class Initialized
INFO - 2021-04-20 23:19:55 --> Router Class Initialized
INFO - 2021-04-20 23:19:55 --> Output Class Initialized
INFO - 2021-04-20 23:19:55 --> Security Class Initialized
DEBUG - 2021-04-20 23:19:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 23:19:55 --> Input Class Initialized
INFO - 2021-04-20 23:19:55 --> Language Class Initialized
INFO - 2021-04-20 23:19:55 --> Loader Class Initialized
INFO - 2021-04-20 23:19:55 --> Helper loaded: url_helper
INFO - 2021-04-20 23:19:55 --> Helper loaded: form_helper
INFO - 2021-04-20 23:19:55 --> Helper loaded: common_helper
INFO - 2021-04-20 23:19:55 --> Helper loaded: util_helper
INFO - 2021-04-20 23:19:55 --> Helper loaded: user_helper
INFO - 2021-04-20 23:19:55 --> Database Driver Class Initialized
DEBUG - 2021-04-20 23:19:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 23:19:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 23:19:55 --> Form Validation Class Initialized
INFO - 2021-04-20 23:19:55 --> Controller Class Initialized
INFO - 2021-04-20 23:19:55 --> Model Class Initialized
INFO - 2021-04-20 23:19:55 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\viewaccount.php
INFO - 2021-04-20 23:19:55 --> Final output sent to browser
DEBUG - 2021-04-20 23:19:55 --> Total execution time: 0.0316
INFO - 2021-04-20 23:19:57 --> Config Class Initialized
INFO - 2021-04-20 23:19:57 --> Hooks Class Initialized
DEBUG - 2021-04-20 23:19:57 --> UTF-8 Support Enabled
INFO - 2021-04-20 23:19:57 --> Utf8 Class Initialized
INFO - 2021-04-20 23:19:57 --> URI Class Initialized
INFO - 2021-04-20 23:19:57 --> Router Class Initialized
INFO - 2021-04-20 23:19:57 --> Output Class Initialized
INFO - 2021-04-20 23:19:57 --> Security Class Initialized
DEBUG - 2021-04-20 23:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 23:19:57 --> Input Class Initialized
INFO - 2021-04-20 23:19:57 --> Language Class Initialized
INFO - 2021-04-20 23:19:57 --> Loader Class Initialized
INFO - 2021-04-20 23:19:57 --> Helper loaded: url_helper
INFO - 2021-04-20 23:19:57 --> Helper loaded: form_helper
INFO - 2021-04-20 23:19:57 --> Helper loaded: common_helper
INFO - 2021-04-20 23:19:57 --> Helper loaded: util_helper
INFO - 2021-04-20 23:19:57 --> Helper loaded: user_helper
INFO - 2021-04-20 23:19:57 --> Database Driver Class Initialized
DEBUG - 2021-04-20 23:19:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 23:19:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 23:19:57 --> Form Validation Class Initialized
INFO - 2021-04-20 23:19:57 --> Controller Class Initialized
INFO - 2021-04-20 23:19:57 --> Model Class Initialized
INFO - 2021-04-20 23:19:57 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\ckeditor/samples/updateData.php
INFO - 2021-04-20 23:19:57 --> Final output sent to browser
DEBUG - 2021-04-20 23:19:57 --> Total execution time: 0.0308
INFO - 2021-04-20 23:19:59 --> Config Class Initialized
INFO - 2021-04-20 23:19:59 --> Hooks Class Initialized
DEBUG - 2021-04-20 23:19:59 --> UTF-8 Support Enabled
INFO - 2021-04-20 23:19:59 --> Utf8 Class Initialized
INFO - 2021-04-20 23:19:59 --> URI Class Initialized
INFO - 2021-04-20 23:19:59 --> Router Class Initialized
INFO - 2021-04-20 23:19:59 --> Output Class Initialized
INFO - 2021-04-20 23:19:59 --> Security Class Initialized
DEBUG - 2021-04-20 23:19:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 23:19:59 --> Input Class Initialized
INFO - 2021-04-20 23:19:59 --> Language Class Initialized
INFO - 2021-04-20 23:19:59 --> Loader Class Initialized
INFO - 2021-04-20 23:19:59 --> Helper loaded: url_helper
INFO - 2021-04-20 23:19:59 --> Helper loaded: form_helper
INFO - 2021-04-20 23:19:59 --> Helper loaded: common_helper
INFO - 2021-04-20 23:19:59 --> Helper loaded: util_helper
INFO - 2021-04-20 23:19:59 --> Helper loaded: user_helper
INFO - 2021-04-20 23:19:59 --> Database Driver Class Initialized
DEBUG - 2021-04-20 23:19:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 23:19:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 23:19:59 --> Form Validation Class Initialized
INFO - 2021-04-20 23:19:59 --> Controller Class Initialized
INFO - 2021-04-20 23:19:59 --> Model Class Initialized
INFO - 2021-04-20 23:19:59 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\viewaccount.php
INFO - 2021-04-20 23:19:59 --> Final output sent to browser
DEBUG - 2021-04-20 23:19:59 --> Total execution time: 0.0292
INFO - 2021-04-20 23:20:13 --> Config Class Initialized
INFO - 2021-04-20 23:20:13 --> Hooks Class Initialized
DEBUG - 2021-04-20 23:20:13 --> UTF-8 Support Enabled
INFO - 2021-04-20 23:20:13 --> Utf8 Class Initialized
INFO - 2021-04-20 23:20:13 --> URI Class Initialized
INFO - 2021-04-20 23:20:13 --> Router Class Initialized
INFO - 2021-04-20 23:20:13 --> Output Class Initialized
INFO - 2021-04-20 23:20:13 --> Security Class Initialized
DEBUG - 2021-04-20 23:20:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 23:20:13 --> Input Class Initialized
INFO - 2021-04-20 23:20:13 --> Language Class Initialized
INFO - 2021-04-20 23:20:13 --> Loader Class Initialized
INFO - 2021-04-20 23:20:13 --> Helper loaded: url_helper
INFO - 2021-04-20 23:20:13 --> Helper loaded: form_helper
INFO - 2021-04-20 23:20:13 --> Helper loaded: common_helper
INFO - 2021-04-20 23:20:13 --> Helper loaded: util_helper
INFO - 2021-04-20 23:20:13 --> Helper loaded: user_helper
INFO - 2021-04-20 23:20:13 --> Database Driver Class Initialized
DEBUG - 2021-04-20 23:20:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 23:20:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 23:20:13 --> Form Validation Class Initialized
INFO - 2021-04-20 23:20:13 --> Controller Class Initialized
INFO - 2021-04-20 23:20:13 --> Model Class Initialized
INFO - 2021-04-20 23:20:13 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\ckeditor/samples/updateData.php
INFO - 2021-04-20 23:20:13 --> Final output sent to browser
DEBUG - 2021-04-20 23:20:13 --> Total execution time: 0.0286
INFO - 2021-04-20 23:20:14 --> Config Class Initialized
INFO - 2021-04-20 23:20:14 --> Hooks Class Initialized
DEBUG - 2021-04-20 23:20:14 --> UTF-8 Support Enabled
INFO - 2021-04-20 23:20:14 --> Utf8 Class Initialized
INFO - 2021-04-20 23:20:14 --> URI Class Initialized
INFO - 2021-04-20 23:20:14 --> Router Class Initialized
INFO - 2021-04-20 23:20:14 --> Output Class Initialized
INFO - 2021-04-20 23:20:14 --> Security Class Initialized
DEBUG - 2021-04-20 23:20:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 23:20:14 --> Input Class Initialized
INFO - 2021-04-20 23:20:14 --> Language Class Initialized
INFO - 2021-04-20 23:20:14 --> Loader Class Initialized
INFO - 2021-04-20 23:20:14 --> Helper loaded: url_helper
INFO - 2021-04-20 23:20:14 --> Helper loaded: form_helper
INFO - 2021-04-20 23:20:14 --> Helper loaded: common_helper
INFO - 2021-04-20 23:20:14 --> Helper loaded: util_helper
INFO - 2021-04-20 23:20:14 --> Helper loaded: user_helper
INFO - 2021-04-20 23:20:14 --> Database Driver Class Initialized
DEBUG - 2021-04-20 23:20:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 23:20:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 23:20:14 --> Form Validation Class Initialized
INFO - 2021-04-20 23:20:14 --> Controller Class Initialized
INFO - 2021-04-20 23:20:14 --> Model Class Initialized
INFO - 2021-04-20 23:20:14 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\viewaccount.php
INFO - 2021-04-20 23:20:14 --> Final output sent to browser
DEBUG - 2021-04-20 23:20:14 --> Total execution time: 0.0433
INFO - 2021-04-20 23:23:34 --> Config Class Initialized
INFO - 2021-04-20 23:23:34 --> Hooks Class Initialized
DEBUG - 2021-04-20 23:23:34 --> UTF-8 Support Enabled
INFO - 2021-04-20 23:23:34 --> Utf8 Class Initialized
INFO - 2021-04-20 23:23:34 --> URI Class Initialized
INFO - 2021-04-20 23:23:34 --> Router Class Initialized
INFO - 2021-04-20 23:23:34 --> Output Class Initialized
INFO - 2021-04-20 23:23:34 --> Security Class Initialized
DEBUG - 2021-04-20 23:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 23:23:34 --> Input Class Initialized
INFO - 2021-04-20 23:23:34 --> Language Class Initialized
INFO - 2021-04-20 23:23:34 --> Loader Class Initialized
INFO - 2021-04-20 23:23:34 --> Helper loaded: url_helper
INFO - 2021-04-20 23:23:34 --> Helper loaded: form_helper
INFO - 2021-04-20 23:23:34 --> Helper loaded: common_helper
INFO - 2021-04-20 23:23:34 --> Helper loaded: util_helper
INFO - 2021-04-20 23:23:34 --> Helper loaded: user_helper
INFO - 2021-04-20 23:23:34 --> Database Driver Class Initialized
DEBUG - 2021-04-20 23:23:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 23:23:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 23:23:34 --> Form Validation Class Initialized
INFO - 2021-04-20 23:23:34 --> Controller Class Initialized
INFO - 2021-04-20 23:23:34 --> Model Class Initialized
INFO - 2021-04-20 23:23:34 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\viewaccount.php
INFO - 2021-04-20 23:23:34 --> Final output sent to browser
DEBUG - 2021-04-20 23:23:34 --> Total execution time: 0.0384
INFO - 2021-04-20 23:23:34 --> Config Class Initialized
INFO - 2021-04-20 23:23:34 --> Hooks Class Initialized
INFO - 2021-04-20 23:23:34 --> Config Class Initialized
INFO - 2021-04-20 23:23:34 --> Hooks Class Initialized
DEBUG - 2021-04-20 23:23:34 --> UTF-8 Support Enabled
INFO - 2021-04-20 23:23:34 --> Utf8 Class Initialized
DEBUG - 2021-04-20 23:23:34 --> UTF-8 Support Enabled
INFO - 2021-04-20 23:23:34 --> Utf8 Class Initialized
INFO - 2021-04-20 23:23:34 --> URI Class Initialized
INFO - 2021-04-20 23:23:34 --> URI Class Initialized
INFO - 2021-04-20 23:23:34 --> Router Class Initialized
INFO - 2021-04-20 23:23:34 --> Router Class Initialized
INFO - 2021-04-20 23:23:34 --> Output Class Initialized
INFO - 2021-04-20 23:23:34 --> Output Class Initialized
INFO - 2021-04-20 23:23:34 --> Security Class Initialized
INFO - 2021-04-20 23:23:34 --> Security Class Initialized
DEBUG - 2021-04-20 23:23:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-20 23:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 23:23:34 --> Input Class Initialized
INFO - 2021-04-20 23:23:34 --> Input Class Initialized
INFO - 2021-04-20 23:23:34 --> Language Class Initialized
INFO - 2021-04-20 23:23:34 --> Language Class Initialized
ERROR - 2021-04-20 23:23:34 --> 404 Page Not Found: Assets/plugins
ERROR - 2021-04-20 23:23:34 --> 404 Page Not Found: Assets/plugins
INFO - 2021-04-20 23:23:34 --> Config Class Initialized
INFO - 2021-04-20 23:23:34 --> Hooks Class Initialized
DEBUG - 2021-04-20 23:23:34 --> UTF-8 Support Enabled
INFO - 2021-04-20 23:23:34 --> Utf8 Class Initialized
INFO - 2021-04-20 23:23:34 --> URI Class Initialized
INFO - 2021-04-20 23:23:34 --> Router Class Initialized
INFO - 2021-04-20 23:23:34 --> Output Class Initialized
INFO - 2021-04-20 23:23:34 --> Security Class Initialized
DEBUG - 2021-04-20 23:23:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 23:23:34 --> Input Class Initialized
INFO - 2021-04-20 23:23:34 --> Language Class Initialized
ERROR - 2021-04-20 23:23:34 --> 404 Page Not Found: Assets/plugins
INFO - 2021-04-20 23:23:35 --> Config Class Initialized
INFO - 2021-04-20 23:23:35 --> Hooks Class Initialized
DEBUG - 2021-04-20 23:23:35 --> UTF-8 Support Enabled
INFO - 2021-04-20 23:23:35 --> Utf8 Class Initialized
INFO - 2021-04-20 23:23:35 --> URI Class Initialized
INFO - 2021-04-20 23:23:35 --> Router Class Initialized
INFO - 2021-04-20 23:23:35 --> Output Class Initialized
INFO - 2021-04-20 23:23:35 --> Security Class Initialized
DEBUG - 2021-04-20 23:23:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 23:23:35 --> Input Class Initialized
INFO - 2021-04-20 23:23:35 --> Language Class Initialized
INFO - 2021-04-20 23:23:35 --> Loader Class Initialized
INFO - 2021-04-20 23:23:35 --> Helper loaded: url_helper
INFO - 2021-04-20 23:23:35 --> Helper loaded: form_helper
INFO - 2021-04-20 23:23:35 --> Helper loaded: common_helper
INFO - 2021-04-20 23:23:35 --> Helper loaded: util_helper
INFO - 2021-04-20 23:23:35 --> Helper loaded: user_helper
INFO - 2021-04-20 23:23:35 --> Database Driver Class Initialized
DEBUG - 2021-04-20 23:23:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 23:23:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 23:23:35 --> Form Validation Class Initialized
INFO - 2021-04-20 23:23:35 --> Controller Class Initialized
INFO - 2021-04-20 23:23:35 --> Model Class Initialized
INFO - 2021-04-20 23:23:35 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\ckeditor/samples/updateData.php
INFO - 2021-04-20 23:23:35 --> Final output sent to browser
DEBUG - 2021-04-20 23:23:35 --> Total execution time: 0.0286
INFO - 2021-04-20 23:23:39 --> Config Class Initialized
INFO - 2021-04-20 23:23:39 --> Hooks Class Initialized
DEBUG - 2021-04-20 23:23:39 --> UTF-8 Support Enabled
INFO - 2021-04-20 23:23:39 --> Utf8 Class Initialized
INFO - 2021-04-20 23:23:39 --> URI Class Initialized
INFO - 2021-04-20 23:23:39 --> Router Class Initialized
INFO - 2021-04-20 23:23:39 --> Output Class Initialized
INFO - 2021-04-20 23:23:39 --> Security Class Initialized
DEBUG - 2021-04-20 23:23:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-20 23:23:39 --> Input Class Initialized
INFO - 2021-04-20 23:23:39 --> Language Class Initialized
INFO - 2021-04-20 23:23:39 --> Loader Class Initialized
INFO - 2021-04-20 23:23:39 --> Helper loaded: url_helper
INFO - 2021-04-20 23:23:39 --> Helper loaded: form_helper
INFO - 2021-04-20 23:23:39 --> Helper loaded: common_helper
INFO - 2021-04-20 23:23:39 --> Helper loaded: util_helper
INFO - 2021-04-20 23:23:39 --> Helper loaded: user_helper
INFO - 2021-04-20 23:23:39 --> Database Driver Class Initialized
DEBUG - 2021-04-20 23:23:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-20 23:23:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-20 23:23:39 --> Form Validation Class Initialized
INFO - 2021-04-20 23:23:39 --> Controller Class Initialized
INFO - 2021-04-20 23:23:39 --> Model Class Initialized
INFO - 2021-04-20 23:23:39 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\viewaccount.php
INFO - 2021-04-20 23:23:39 --> Final output sent to browser
DEBUG - 2021-04-20 23:23:39 --> Total execution time: 0.0296
