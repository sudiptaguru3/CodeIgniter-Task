INFO - 2021-03-24 21:03:09 --> Config Class Initialized
INFO - 2021-03-24 21:03:09 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:03:09 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:03:09 --> Utf8 Class Initialized
INFO - 2021-03-24 21:03:09 --> URI Class Initialized
INFO - 2021-03-24 21:03:09 --> Router Class Initialized
INFO - 2021-03-24 21:03:09 --> Output Class Initialized
INFO - 2021-03-24 21:03:09 --> Security Class Initialized
DEBUG - 2021-03-24 21:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:03:09 --> Input Class Initialized
INFO - 2021-03-24 21:03:09 --> Language Class Initialized
INFO - 2021-03-24 21:03:09 --> Loader Class Initialized
INFO - 2021-03-24 21:03:09 --> Helper loaded: url_helper
INFO - 2021-03-24 21:03:09 --> Helper loaded: form_helper
INFO - 2021-03-24 21:03:09 --> Helper loaded: common_helper
INFO - 2021-03-24 21:03:09 --> Helper loaded: util_helper
INFO - 2021-03-24 21:03:09 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:03:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:03:09 --> Form Validation Class Initialized
INFO - 2021-03-24 21:03:09 --> Controller Class Initialized
INFO - 2021-03-24 21:03:09 --> Model Class Initialized
INFO - 2021-03-24 21:03:09 --> Model Class Initialized
INFO - 2021-03-24 21:03:09 --> Model Class Initialized
INFO - 2021-03-24 21:03:09 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:03:09 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
ERROR - 2021-03-24 21:03:09 --> Severity: error --> Exception: syntax error, unexpected '>' C:\xampp\htdocs\robust\php\application\views\admin\user\edit.php 56
INFO - 2021-03-24 21:03:09 --> Config Class Initialized
INFO - 2021-03-24 21:03:09 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:03:09 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:03:09 --> Utf8 Class Initialized
INFO - 2021-03-24 21:03:09 --> URI Class Initialized
INFO - 2021-03-24 21:03:09 --> Router Class Initialized
INFO - 2021-03-24 21:03:09 --> Output Class Initialized
INFO - 2021-03-24 21:03:09 --> Security Class Initialized
DEBUG - 2021-03-24 21:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:03:09 --> Input Class Initialized
INFO - 2021-03-24 21:03:09 --> Language Class Initialized
INFO - 2021-03-24 21:03:09 --> Config Class Initialized
INFO - 2021-03-24 21:03:09 --> Hooks Class Initialized
INFO - 2021-03-24 21:03:09 --> Loader Class Initialized
INFO - 2021-03-24 21:03:09 --> Helper loaded: url_helper
DEBUG - 2021-03-24 21:03:09 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:03:09 --> Utf8 Class Initialized
INFO - 2021-03-24 21:03:09 --> URI Class Initialized
INFO - 2021-03-24 21:03:09 --> Helper loaded: form_helper
INFO - 2021-03-24 21:03:09 --> Helper loaded: common_helper
INFO - 2021-03-24 21:03:09 --> Helper loaded: util_helper
INFO - 2021-03-24 21:03:09 --> Router Class Initialized
INFO - 2021-03-24 21:03:09 --> Output Class Initialized
INFO - 2021-03-24 21:03:09 --> Config Class Initialized
INFO - 2021-03-24 21:03:09 --> Hooks Class Initialized
INFO - 2021-03-24 21:03:09 --> Security Class Initialized
DEBUG - 2021-03-24 21:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:03:09 --> Database Driver Class Initialized
INFO - 2021-03-24 21:03:09 --> Input Class Initialized
DEBUG - 2021-03-24 21:03:09 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:03:09 --> Utf8 Class Initialized
INFO - 2021-03-24 21:03:09 --> Language Class Initialized
INFO - 2021-03-24 21:03:09 --> URI Class Initialized
DEBUG - 2021-03-24 21:03:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:03:09 --> Loader Class Initialized
INFO - 2021-03-24 21:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:03:09 --> Router Class Initialized
INFO - 2021-03-24 21:03:09 --> Helper loaded: url_helper
INFO - 2021-03-24 21:03:09 --> Output Class Initialized
INFO - 2021-03-24 21:03:09 --> Form Validation Class Initialized
INFO - 2021-03-24 21:03:09 --> Controller Class Initialized
INFO - 2021-03-24 21:03:09 --> Helper loaded: form_helper
INFO - 2021-03-24 21:03:09 --> Security Class Initialized
INFO - 2021-03-24 21:03:09 --> Helper loaded: common_helper
INFO - 2021-03-24 21:03:09 --> Model Class Initialized
INFO - 2021-03-24 21:03:09 --> Helper loaded: util_helper
DEBUG - 2021-03-24 21:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:03:09 --> Input Class Initialized
INFO - 2021-03-24 21:03:09 --> Model Class Initialized
INFO - 2021-03-24 21:03:09 --> Model Class Initialized
INFO - 2021-03-24 21:03:09 --> Language Class Initialized
INFO - 2021-03-24 21:03:09 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:03:09 --> Loader Class Initialized
INFO - 2021-03-24 21:03:09 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:03:09 --> Database Driver Class Initialized
INFO - 2021-03-24 21:03:09 --> Helper loaded: url_helper
ERROR - 2021-03-24 21:03:09 --> Severity: error --> Exception: syntax error, unexpected '>' C:\xampp\htdocs\robust\php\application\views\admin\user\edit.php 56
INFO - 2021-03-24 21:03:09 --> Helper loaded: form_helper
INFO - 2021-03-24 21:03:09 --> Helper loaded: common_helper
INFO - 2021-03-24 21:03:09 --> Helper loaded: util_helper
INFO - 2021-03-24 21:03:09 --> Config Class Initialized
DEBUG - 2021-03-24 21:03:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:03:09 --> Hooks Class Initialized
INFO - 2021-03-24 21:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:03:09 --> Form Validation Class Initialized
INFO - 2021-03-24 21:03:09 --> Controller Class Initialized
DEBUG - 2021-03-24 21:03:09 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:03:09 --> Utf8 Class Initialized
INFO - 2021-03-24 21:03:09 --> Model Class Initialized
INFO - 2021-03-24 21:03:09 --> URI Class Initialized
INFO - 2021-03-24 21:03:09 --> Model Class Initialized
INFO - 2021-03-24 21:03:09 --> Database Driver Class Initialized
INFO - 2021-03-24 21:03:09 --> Model Class Initialized
INFO - 2021-03-24 21:03:09 --> Router Class Initialized
INFO - 2021-03-24 21:03:09 --> Output Class Initialized
DEBUG - 2021-03-24 21:03:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:03:09 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:03:09 --> Security Class Initialized
INFO - 2021-03-24 21:03:09 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
DEBUG - 2021-03-24 21:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:03:09 --> Input Class Initialized
ERROR - 2021-03-24 21:03:09 --> Severity: error --> Exception: syntax error, unexpected '>' C:\xampp\htdocs\robust\php\application\views\admin\user\edit.php 56
INFO - 2021-03-24 21:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:03:09 --> Language Class Initialized
INFO - 2021-03-24 21:03:09 --> Form Validation Class Initialized
INFO - 2021-03-24 21:03:09 --> Controller Class Initialized
INFO - 2021-03-24 21:03:09 --> Model Class Initialized
INFO - 2021-03-24 21:03:09 --> Model Class Initialized
INFO - 2021-03-24 21:03:09 --> Model Class Initialized
INFO - 2021-03-24 21:03:09 --> Loader Class Initialized
INFO - 2021-03-24 21:03:09 --> Helper loaded: url_helper
INFO - 2021-03-24 21:03:09 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:03:09 --> Helper loaded: form_helper
INFO - 2021-03-24 21:03:09 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:03:09 --> Helper loaded: common_helper
ERROR - 2021-03-24 21:03:09 --> Severity: error --> Exception: syntax error, unexpected '>' C:\xampp\htdocs\robust\php\application\views\admin\user\edit.php 56
INFO - 2021-03-24 21:03:09 --> Helper loaded: util_helper
INFO - 2021-03-24 21:03:09 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:03:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:03:09 --> Form Validation Class Initialized
INFO - 2021-03-24 21:03:09 --> Controller Class Initialized
INFO - 2021-03-24 21:03:09 --> Model Class Initialized
INFO - 2021-03-24 21:03:09 --> Model Class Initialized
INFO - 2021-03-24 21:03:09 --> Model Class Initialized
INFO - 2021-03-24 21:03:09 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:03:09 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
ERROR - 2021-03-24 21:03:09 --> Severity: error --> Exception: syntax error, unexpected '>' C:\xampp\htdocs\robust\php\application\views\admin\user\edit.php 56
INFO - 2021-03-24 21:04:28 --> Config Class Initialized
INFO - 2021-03-24 21:04:28 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:04:28 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:04:28 --> Utf8 Class Initialized
INFO - 2021-03-24 21:04:28 --> URI Class Initialized
INFO - 2021-03-24 21:04:28 --> Router Class Initialized
INFO - 2021-03-24 21:04:28 --> Output Class Initialized
INFO - 2021-03-24 21:04:28 --> Security Class Initialized
DEBUG - 2021-03-24 21:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:04:28 --> Input Class Initialized
INFO - 2021-03-24 21:04:28 --> Language Class Initialized
INFO - 2021-03-24 21:04:28 --> Loader Class Initialized
INFO - 2021-03-24 21:04:28 --> Helper loaded: url_helper
INFO - 2021-03-24 21:04:28 --> Helper loaded: form_helper
INFO - 2021-03-24 21:04:28 --> Helper loaded: common_helper
INFO - 2021-03-24 21:04:28 --> Helper loaded: util_helper
INFO - 2021-03-24 21:04:28 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:04:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:04:28 --> Form Validation Class Initialized
INFO - 2021-03-24 21:04:28 --> Controller Class Initialized
INFO - 2021-03-24 21:04:28 --> Model Class Initialized
INFO - 2021-03-24 21:04:28 --> Model Class Initialized
INFO - 2021-03-24 21:04:28 --> Model Class Initialized
INFO - 2021-03-24 21:04:28 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:04:28 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:04:28 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:04:28 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:04:28 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:04:28 --> Final output sent to browser
DEBUG - 2021-03-24 21:04:28 --> Total execution time: 0.0461
INFO - 2021-03-24 21:04:28 --> Config Class Initialized
INFO - 2021-03-24 21:04:28 --> Hooks Class Initialized
INFO - 2021-03-24 21:04:28 --> Config Class Initialized
INFO - 2021-03-24 21:04:28 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:04:28 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:04:28 --> Utf8 Class Initialized
INFO - 2021-03-24 21:04:28 --> URI Class Initialized
INFO - 2021-03-24 21:04:28 --> Router Class Initialized
INFO - 2021-03-24 21:04:28 --> Output Class Initialized
INFO - 2021-03-24 21:04:28 --> Security Class Initialized
DEBUG - 2021-03-24 21:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:04:28 --> Input Class Initialized
INFO - 2021-03-24 21:04:28 --> Language Class Initialized
INFO - 2021-03-24 21:04:28 --> Loader Class Initialized
DEBUG - 2021-03-24 21:04:28 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:04:28 --> Utf8 Class Initialized
INFO - 2021-03-24 21:04:28 --> Helper loaded: url_helper
INFO - 2021-03-24 21:04:28 --> Helper loaded: form_helper
INFO - 2021-03-24 21:04:28 --> URI Class Initialized
INFO - 2021-03-24 21:04:28 --> Helper loaded: common_helper
INFO - 2021-03-24 21:04:28 --> Helper loaded: util_helper
INFO - 2021-03-24 21:04:28 --> Router Class Initialized
INFO - 2021-03-24 21:04:28 --> Output Class Initialized
INFO - 2021-03-24 21:04:28 --> Database Driver Class Initialized
INFO - 2021-03-24 21:04:28 --> Security Class Initialized
DEBUG - 2021-03-24 21:04:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:04:28 --> Session: Class initialized using 'files' driver.
DEBUG - 2021-03-24 21:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:04:28 --> Input Class Initialized
INFO - 2021-03-24 21:04:28 --> Form Validation Class Initialized
INFO - 2021-03-24 21:04:28 --> Controller Class Initialized
INFO - 2021-03-24 21:04:28 --> Language Class Initialized
INFO - 2021-03-24 21:04:28 --> Model Class Initialized
INFO - 2021-03-24 21:04:28 --> Model Class Initialized
INFO - 2021-03-24 21:04:28 --> Model Class Initialized
INFO - 2021-03-24 21:04:28 --> Config Class Initialized
INFO - 2021-03-24 21:04:28 --> Hooks Class Initialized
INFO - 2021-03-24 21:04:28 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:04:28 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:04:28 --> Loader Class Initialized
INFO - 2021-03-24 21:04:28 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:04:28 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:04:28 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:04:28 --> Helper loaded: url_helper
INFO - 2021-03-24 21:04:28 --> Final output sent to browser
DEBUG - 2021-03-24 21:04:28 --> Total execution time: 0.0535
INFO - 2021-03-24 21:04:28 --> Helper loaded: form_helper
DEBUG - 2021-03-24 21:04:28 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:04:28 --> Helper loaded: common_helper
INFO - 2021-03-24 21:04:28 --> Utf8 Class Initialized
INFO - 2021-03-24 21:04:28 --> Helper loaded: util_helper
INFO - 2021-03-24 21:04:28 --> URI Class Initialized
INFO - 2021-03-24 21:04:28 --> Router Class Initialized
INFO - 2021-03-24 21:04:28 --> Output Class Initialized
INFO - 2021-03-24 21:04:28 --> Security Class Initialized
INFO - 2021-03-24 21:04:28 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:04:28 --> Input Class Initialized
INFO - 2021-03-24 21:04:28 --> Language Class Initialized
DEBUG - 2021-03-24 21:04:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:04:28 --> Config Class Initialized
INFO - 2021-03-24 21:04:28 --> Hooks Class Initialized
INFO - 2021-03-24 21:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:04:28 --> Loader Class Initialized
INFO - 2021-03-24 21:04:28 --> Form Validation Class Initialized
INFO - 2021-03-24 21:04:28 --> Controller Class Initialized
DEBUG - 2021-03-24 21:04:28 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:04:28 --> Utf8 Class Initialized
INFO - 2021-03-24 21:04:28 --> URI Class Initialized
INFO - 2021-03-24 21:04:28 --> Model Class Initialized
INFO - 2021-03-24 21:04:28 --> Model Class Initialized
INFO - 2021-03-24 21:04:28 --> Model Class Initialized
INFO - 2021-03-24 21:04:28 --> Helper loaded: url_helper
INFO - 2021-03-24 21:04:28 --> Router Class Initialized
INFO - 2021-03-24 21:04:28 --> Helper loaded: form_helper
INFO - 2021-03-24 21:04:28 --> Output Class Initialized
INFO - 2021-03-24 21:04:28 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:04:28 --> Helper loaded: common_helper
INFO - 2021-03-24 21:04:28 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:04:28 --> Security Class Initialized
INFO - 2021-03-24 21:04:28 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:04:28 --> Helper loaded: util_helper
INFO - 2021-03-24 21:04:28 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:04:28 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
DEBUG - 2021-03-24 21:04:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:04:28 --> Input Class Initialized
INFO - 2021-03-24 21:04:28 --> Final output sent to browser
DEBUG - 2021-03-24 21:04:28 --> Total execution time: 0.0811
INFO - 2021-03-24 21:04:28 --> Language Class Initialized
INFO - 2021-03-24 21:04:28 --> Loader Class Initialized
INFO - 2021-03-24 21:04:28 --> Helper loaded: url_helper
INFO - 2021-03-24 21:04:28 --> Helper loaded: form_helper
INFO - 2021-03-24 21:04:28 --> Helper loaded: common_helper
INFO - 2021-03-24 21:04:28 --> Helper loaded: util_helper
INFO - 2021-03-24 21:04:28 --> Database Driver Class Initialized
INFO - 2021-03-24 21:04:28 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:04:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-03-24 21:04:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:04:28 --> Form Validation Class Initialized
INFO - 2021-03-24 21:04:28 --> Controller Class Initialized
INFO - 2021-03-24 21:04:28 --> Model Class Initialized
INFO - 2021-03-24 21:04:28 --> Model Class Initialized
INFO - 2021-03-24 21:04:28 --> Model Class Initialized
INFO - 2021-03-24 21:04:28 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:04:28 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:04:28 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:04:28 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:04:28 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:04:28 --> Final output sent to browser
DEBUG - 2021-03-24 21:04:28 --> Total execution time: 0.0742
INFO - 2021-03-24 21:04:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:04:28 --> Form Validation Class Initialized
INFO - 2021-03-24 21:04:28 --> Controller Class Initialized
INFO - 2021-03-24 21:04:28 --> Model Class Initialized
INFO - 2021-03-24 21:04:28 --> Model Class Initialized
INFO - 2021-03-24 21:04:28 --> Model Class Initialized
INFO - 2021-03-24 21:04:28 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:04:28 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:04:28 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:04:28 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:04:28 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:04:28 --> Final output sent to browser
DEBUG - 2021-03-24 21:04:28 --> Total execution time: 0.0660
INFO - 2021-03-24 21:04:38 --> Config Class Initialized
INFO - 2021-03-24 21:04:38 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:04:38 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:04:38 --> Utf8 Class Initialized
INFO - 2021-03-24 21:04:38 --> URI Class Initialized
INFO - 2021-03-24 21:04:38 --> Router Class Initialized
INFO - 2021-03-24 21:04:38 --> Output Class Initialized
INFO - 2021-03-24 21:04:38 --> Security Class Initialized
DEBUG - 2021-03-24 21:04:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:04:38 --> Input Class Initialized
INFO - 2021-03-24 21:04:38 --> Language Class Initialized
INFO - 2021-03-24 21:04:38 --> Loader Class Initialized
INFO - 2021-03-24 21:04:38 --> Helper loaded: url_helper
INFO - 2021-03-24 21:04:38 --> Helper loaded: form_helper
INFO - 2021-03-24 21:04:38 --> Helper loaded: common_helper
INFO - 2021-03-24 21:04:38 --> Helper loaded: util_helper
INFO - 2021-03-24 21:04:38 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:04:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:04:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:04:38 --> Form Validation Class Initialized
INFO - 2021-03-24 21:04:38 --> Controller Class Initialized
INFO - 2021-03-24 21:04:38 --> Model Class Initialized
INFO - 2021-03-24 21:04:38 --> Model Class Initialized
INFO - 2021-03-24 21:04:38 --> Model Class Initialized
INFO - 2021-03-24 21:04:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:04:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:04:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/list.php
INFO - 2021-03-24 21:04:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:04:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:04:38 --> Final output sent to browser
DEBUG - 2021-03-24 21:04:38 --> Total execution time: 0.0359
INFO - 2021-03-24 21:04:41 --> Config Class Initialized
INFO - 2021-03-24 21:04:41 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:04:41 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:04:41 --> Utf8 Class Initialized
INFO - 2021-03-24 21:04:41 --> URI Class Initialized
INFO - 2021-03-24 21:04:41 --> Router Class Initialized
INFO - 2021-03-24 21:04:41 --> Output Class Initialized
INFO - 2021-03-24 21:04:41 --> Security Class Initialized
DEBUG - 2021-03-24 21:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:04:41 --> Input Class Initialized
INFO - 2021-03-24 21:04:41 --> Language Class Initialized
INFO - 2021-03-24 21:04:41 --> Loader Class Initialized
INFO - 2021-03-24 21:04:41 --> Helper loaded: url_helper
INFO - 2021-03-24 21:04:41 --> Helper loaded: form_helper
INFO - 2021-03-24 21:04:41 --> Helper loaded: common_helper
INFO - 2021-03-24 21:04:41 --> Helper loaded: util_helper
INFO - 2021-03-24 21:04:41 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:04:41 --> Form Validation Class Initialized
INFO - 2021-03-24 21:04:41 --> Controller Class Initialized
INFO - 2021-03-24 21:04:41 --> Model Class Initialized
INFO - 2021-03-24 21:04:41 --> Model Class Initialized
INFO - 2021-03-24 21:04:41 --> Model Class Initialized
INFO - 2021-03-24 21:04:41 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:04:41 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:04:41 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:04:41 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:04:41 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:04:41 --> Final output sent to browser
DEBUG - 2021-03-24 21:04:41 --> Total execution time: 0.0469
INFO - 2021-03-24 21:04:41 --> Config Class Initialized
INFO - 2021-03-24 21:04:41 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:04:41 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:04:41 --> Config Class Initialized
INFO - 2021-03-24 21:04:41 --> Utf8 Class Initialized
INFO - 2021-03-24 21:04:41 --> Hooks Class Initialized
INFO - 2021-03-24 21:04:41 --> URI Class Initialized
INFO - 2021-03-24 21:04:41 --> Router Class Initialized
DEBUG - 2021-03-24 21:04:41 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:04:41 --> Utf8 Class Initialized
INFO - 2021-03-24 21:04:41 --> Output Class Initialized
INFO - 2021-03-24 21:04:41 --> URI Class Initialized
INFO - 2021-03-24 21:04:41 --> Security Class Initialized
INFO - 2021-03-24 21:04:41 --> Router Class Initialized
DEBUG - 2021-03-24 21:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:04:41 --> Input Class Initialized
INFO - 2021-03-24 21:04:41 --> Language Class Initialized
INFO - 2021-03-24 21:04:41 --> Output Class Initialized
INFO - 2021-03-24 21:04:41 --> Security Class Initialized
INFO - 2021-03-24 21:04:41 --> Loader Class Initialized
DEBUG - 2021-03-24 21:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:04:41 --> Input Class Initialized
INFO - 2021-03-24 21:04:41 --> Helper loaded: url_helper
INFO - 2021-03-24 21:04:41 --> Language Class Initialized
INFO - 2021-03-24 21:04:41 --> Config Class Initialized
INFO - 2021-03-24 21:04:41 --> Helper loaded: form_helper
INFO - 2021-03-24 21:04:41 --> Hooks Class Initialized
INFO - 2021-03-24 21:04:41 --> Helper loaded: common_helper
INFO - 2021-03-24 21:04:41 --> Helper loaded: util_helper
INFO - 2021-03-24 21:04:41 --> Loader Class Initialized
DEBUG - 2021-03-24 21:04:41 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:04:41 --> Utf8 Class Initialized
INFO - 2021-03-24 21:04:41 --> Helper loaded: url_helper
INFO - 2021-03-24 21:04:41 --> URI Class Initialized
INFO - 2021-03-24 21:04:41 --> Helper loaded: form_helper
INFO - 2021-03-24 21:04:41 --> Router Class Initialized
INFO - 2021-03-24 21:04:41 --> Helper loaded: common_helper
INFO - 2021-03-24 21:04:41 --> Helper loaded: util_helper
INFO - 2021-03-24 21:04:41 --> Output Class Initialized
INFO - 2021-03-24 21:04:41 --> Database Driver Class Initialized
INFO - 2021-03-24 21:04:41 --> Security Class Initialized
DEBUG - 2021-03-24 21:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:04:41 --> Input Class Initialized
INFO - 2021-03-24 21:04:41 --> Language Class Initialized
DEBUG - 2021-03-24 21:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:04:41 --> Loader Class Initialized
INFO - 2021-03-24 21:04:41 --> Form Validation Class Initialized
INFO - 2021-03-24 21:04:41 --> Controller Class Initialized
INFO - 2021-03-24 21:04:41 --> Helper loaded: url_helper
INFO - 2021-03-24 21:04:41 --> Model Class Initialized
INFO - 2021-03-24 21:04:41 --> Model Class Initialized
INFO - 2021-03-24 21:04:41 --> Model Class Initialized
INFO - 2021-03-24 21:04:41 --> Helper loaded: form_helper
INFO - 2021-03-24 21:04:41 --> Helper loaded: common_helper
INFO - 2021-03-24 21:04:41 --> Helper loaded: util_helper
INFO - 2021-03-24 21:04:41 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:04:41 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:04:41 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:04:41 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:04:41 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:04:41 --> Final output sent to browser
DEBUG - 2021-03-24 21:04:41 --> Total execution time: 0.0521
INFO - 2021-03-24 21:04:41 --> Database Driver Class Initialized
INFO - 2021-03-24 21:04:41 --> Config Class Initialized
INFO - 2021-03-24 21:04:41 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:04:41 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:04:41 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:04:41 --> Form Validation Class Initialized
INFO - 2021-03-24 21:04:41 --> Utf8 Class Initialized
INFO - 2021-03-24 21:04:41 --> Controller Class Initialized
INFO - 2021-03-24 21:04:41 --> URI Class Initialized
INFO - 2021-03-24 21:04:41 --> Model Class Initialized
INFO - 2021-03-24 21:04:41 --> Model Class Initialized
DEBUG - 2021-03-24 21:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:04:41 --> Model Class Initialized
INFO - 2021-03-24 21:04:41 --> Router Class Initialized
INFO - 2021-03-24 21:04:41 --> Output Class Initialized
INFO - 2021-03-24 21:04:41 --> Security Class Initialized
INFO - 2021-03-24 21:04:41 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:04:41 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
DEBUG - 2021-03-24 21:04:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:04:41 --> Input Class Initialized
INFO - 2021-03-24 21:04:41 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:04:41 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:04:41 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:04:41 --> Language Class Initialized
INFO - 2021-03-24 21:04:41 --> Final output sent to browser
DEBUG - 2021-03-24 21:04:41 --> Total execution time: 0.0528
INFO - 2021-03-24 21:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:04:41 --> Form Validation Class Initialized
INFO - 2021-03-24 21:04:41 --> Controller Class Initialized
INFO - 2021-03-24 21:04:41 --> Loader Class Initialized
INFO - 2021-03-24 21:04:41 --> Model Class Initialized
INFO - 2021-03-24 21:04:41 --> Helper loaded: url_helper
INFO - 2021-03-24 21:04:41 --> Model Class Initialized
INFO - 2021-03-24 21:04:41 --> Model Class Initialized
INFO - 2021-03-24 21:04:41 --> Helper loaded: form_helper
INFO - 2021-03-24 21:04:41 --> Helper loaded: common_helper
INFO - 2021-03-24 21:04:41 --> Helper loaded: util_helper
INFO - 2021-03-24 21:04:41 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:04:41 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:04:41 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:04:41 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:04:41 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:04:41 --> Final output sent to browser
DEBUG - 2021-03-24 21:04:41 --> Total execution time: 0.0873
INFO - 2021-03-24 21:04:41 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:04:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:04:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:04:41 --> Form Validation Class Initialized
INFO - 2021-03-24 21:04:41 --> Controller Class Initialized
INFO - 2021-03-24 21:04:41 --> Model Class Initialized
INFO - 2021-03-24 21:04:41 --> Model Class Initialized
INFO - 2021-03-24 21:04:41 --> Model Class Initialized
INFO - 2021-03-24 21:04:41 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:04:41 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:04:41 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:04:41 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:04:41 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:04:41 --> Final output sent to browser
DEBUG - 2021-03-24 21:04:41 --> Total execution time: 0.0627
INFO - 2021-03-24 21:04:49 --> Config Class Initialized
INFO - 2021-03-24 21:04:49 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:04:49 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:04:49 --> Utf8 Class Initialized
INFO - 2021-03-24 21:04:49 --> URI Class Initialized
INFO - 2021-03-24 21:04:49 --> Router Class Initialized
INFO - 2021-03-24 21:04:49 --> Output Class Initialized
INFO - 2021-03-24 21:04:49 --> Security Class Initialized
DEBUG - 2021-03-24 21:04:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:04:49 --> Input Class Initialized
INFO - 2021-03-24 21:04:49 --> Language Class Initialized
INFO - 2021-03-24 21:04:49 --> Loader Class Initialized
INFO - 2021-03-24 21:04:49 --> Helper loaded: url_helper
INFO - 2021-03-24 21:04:49 --> Helper loaded: form_helper
INFO - 2021-03-24 21:04:49 --> Helper loaded: common_helper
INFO - 2021-03-24 21:04:49 --> Helper loaded: util_helper
INFO - 2021-03-24 21:04:49 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:04:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:04:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:04:49 --> Form Validation Class Initialized
INFO - 2021-03-24 21:04:49 --> Controller Class Initialized
INFO - 2021-03-24 21:04:49 --> Model Class Initialized
INFO - 2021-03-24 21:04:49 --> Model Class Initialized
INFO - 2021-03-24 21:04:49 --> Model Class Initialized
INFO - 2021-03-24 21:04:49 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:04:49 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:04:49 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/list.php
INFO - 2021-03-24 21:04:49 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:04:49 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:04:49 --> Final output sent to browser
DEBUG - 2021-03-24 21:04:49 --> Total execution time: 0.0374
INFO - 2021-03-24 21:04:53 --> Config Class Initialized
INFO - 2021-03-24 21:04:53 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:04:53 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:04:53 --> Utf8 Class Initialized
INFO - 2021-03-24 21:04:53 --> URI Class Initialized
INFO - 2021-03-24 21:04:53 --> Router Class Initialized
INFO - 2021-03-24 21:04:53 --> Output Class Initialized
INFO - 2021-03-24 21:04:53 --> Security Class Initialized
DEBUG - 2021-03-24 21:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:04:53 --> Input Class Initialized
INFO - 2021-03-24 21:04:53 --> Language Class Initialized
INFO - 2021-03-24 21:04:53 --> Loader Class Initialized
INFO - 2021-03-24 21:04:53 --> Helper loaded: url_helper
INFO - 2021-03-24 21:04:53 --> Helper loaded: form_helper
INFO - 2021-03-24 21:04:53 --> Helper loaded: common_helper
INFO - 2021-03-24 21:04:53 --> Helper loaded: util_helper
INFO - 2021-03-24 21:04:53 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:04:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:04:53 --> Form Validation Class Initialized
INFO - 2021-03-24 21:04:53 --> Controller Class Initialized
INFO - 2021-03-24 21:04:53 --> Model Class Initialized
INFO - 2021-03-24 21:04:53 --> Model Class Initialized
INFO - 2021-03-24 21:04:53 --> Model Class Initialized
INFO - 2021-03-24 21:04:53 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:04:53 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:04:53 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:04:53 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:04:53 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:04:53 --> Final output sent to browser
DEBUG - 2021-03-24 21:04:53 --> Total execution time: 0.0456
INFO - 2021-03-24 21:04:53 --> Config Class Initialized
INFO - 2021-03-24 21:04:53 --> Hooks Class Initialized
INFO - 2021-03-24 21:04:53 --> Config Class Initialized
INFO - 2021-03-24 21:04:53 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:04:53 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:04:53 --> Utf8 Class Initialized
DEBUG - 2021-03-24 21:04:53 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:04:53 --> Utf8 Class Initialized
INFO - 2021-03-24 21:04:53 --> URI Class Initialized
INFO - 2021-03-24 21:04:53 --> URI Class Initialized
INFO - 2021-03-24 21:04:53 --> Router Class Initialized
INFO - 2021-03-24 21:04:53 --> Router Class Initialized
INFO - 2021-03-24 21:04:53 --> Output Class Initialized
INFO - 2021-03-24 21:04:53 --> Output Class Initialized
INFO - 2021-03-24 21:04:53 --> Security Class Initialized
INFO - 2021-03-24 21:04:53 --> Security Class Initialized
DEBUG - 2021-03-24 21:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:04:53 --> Input Class Initialized
INFO - 2021-03-24 21:04:53 --> Language Class Initialized
DEBUG - 2021-03-24 21:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:04:53 --> Input Class Initialized
INFO - 2021-03-24 21:04:53 --> Language Class Initialized
INFO - 2021-03-24 21:04:53 --> Loader Class Initialized
INFO - 2021-03-24 21:04:53 --> Helper loaded: url_helper
INFO - 2021-03-24 21:04:53 --> Helper loaded: form_helper
INFO - 2021-03-24 21:04:53 --> Helper loaded: common_helper
INFO - 2021-03-24 21:04:53 --> Helper loaded: util_helper
INFO - 2021-03-24 21:04:53 --> Loader Class Initialized
INFO - 2021-03-24 21:04:53 --> Helper loaded: url_helper
INFO - 2021-03-24 21:04:53 --> Helper loaded: form_helper
INFO - 2021-03-24 21:04:53 --> Database Driver Class Initialized
INFO - 2021-03-24 21:04:53 --> Helper loaded: common_helper
INFO - 2021-03-24 21:04:53 --> Helper loaded: util_helper
DEBUG - 2021-03-24 21:04:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:04:53 --> Config Class Initialized
INFO - 2021-03-24 21:04:53 --> Hooks Class Initialized
INFO - 2021-03-24 21:04:53 --> Form Validation Class Initialized
INFO - 2021-03-24 21:04:53 --> Controller Class Initialized
INFO - 2021-03-24 21:04:53 --> Model Class Initialized
INFO - 2021-03-24 21:04:53 --> Model Class Initialized
INFO - 2021-03-24 21:04:53 --> Model Class Initialized
DEBUG - 2021-03-24 21:04:53 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:04:53 --> Config Class Initialized
INFO - 2021-03-24 21:04:53 --> Utf8 Class Initialized
INFO - 2021-03-24 21:04:53 --> Hooks Class Initialized
INFO - 2021-03-24 21:04:53 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:04:53 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:04:53 --> URI Class Initialized
INFO - 2021-03-24 21:04:53 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
DEBUG - 2021-03-24 21:04:53 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:04:53 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:04:53 --> Utf8 Class Initialized
INFO - 2021-03-24 21:04:53 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:04:53 --> Router Class Initialized
INFO - 2021-03-24 21:04:53 --> Final output sent to browser
DEBUG - 2021-03-24 21:04:53 --> Total execution time: 0.0453
INFO - 2021-03-24 21:04:53 --> URI Class Initialized
INFO - 2021-03-24 21:04:53 --> Output Class Initialized
INFO - 2021-03-24 21:04:53 --> Router Class Initialized
INFO - 2021-03-24 21:04:53 --> Security Class Initialized
INFO - 2021-03-24 21:04:53 --> Output Class Initialized
DEBUG - 2021-03-24 21:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:04:53 --> Input Class Initialized
INFO - 2021-03-24 21:04:53 --> Language Class Initialized
INFO - 2021-03-24 21:04:53 --> Security Class Initialized
DEBUG - 2021-03-24 21:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:04:53 --> Input Class Initialized
INFO - 2021-03-24 21:04:53 --> Language Class Initialized
INFO - 2021-03-24 21:04:53 --> Loader Class Initialized
INFO - 2021-03-24 21:04:53 --> Helper loaded: url_helper
INFO - 2021-03-24 21:04:53 --> Loader Class Initialized
INFO - 2021-03-24 21:04:53 --> Helper loaded: form_helper
INFO - 2021-03-24 21:04:53 --> Helper loaded: url_helper
INFO - 2021-03-24 21:04:53 --> Database Driver Class Initialized
INFO - 2021-03-24 21:04:53 --> Helper loaded: common_helper
INFO - 2021-03-24 21:04:53 --> Helper loaded: util_helper
INFO - 2021-03-24 21:04:53 --> Helper loaded: form_helper
INFO - 2021-03-24 21:04:53 --> Helper loaded: common_helper
INFO - 2021-03-24 21:04:53 --> Helper loaded: util_helper
DEBUG - 2021-03-24 21:04:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:04:53 --> Form Validation Class Initialized
INFO - 2021-03-24 21:04:53 --> Database Driver Class Initialized
INFO - 2021-03-24 21:04:53 --> Controller Class Initialized
INFO - 2021-03-24 21:04:53 --> Model Class Initialized
INFO - 2021-03-24 21:04:53 --> Model Class Initialized
INFO - 2021-03-24 21:04:53 --> Database Driver Class Initialized
INFO - 2021-03-24 21:04:53 --> Model Class Initialized
DEBUG - 2021-03-24 21:04:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:04:53 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
DEBUG - 2021-03-24 21:04:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:04:53 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:04:53 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:04:53 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:04:53 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:04:53 --> Final output sent to browser
DEBUG - 2021-03-24 21:04:53 --> Total execution time: 0.0803
INFO - 2021-03-24 21:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:04:53 --> Form Validation Class Initialized
INFO - 2021-03-24 21:04:53 --> Controller Class Initialized
INFO - 2021-03-24 21:04:53 --> Model Class Initialized
INFO - 2021-03-24 21:04:53 --> Model Class Initialized
INFO - 2021-03-24 21:04:53 --> Model Class Initialized
INFO - 2021-03-24 21:04:53 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:04:53 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:04:53 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:04:53 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:04:53 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:04:53 --> Final output sent to browser
DEBUG - 2021-03-24 21:04:53 --> Total execution time: 0.0630
INFO - 2021-03-24 21:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:04:53 --> Form Validation Class Initialized
INFO - 2021-03-24 21:04:53 --> Controller Class Initialized
INFO - 2021-03-24 21:04:53 --> Model Class Initialized
INFO - 2021-03-24 21:04:53 --> Model Class Initialized
INFO - 2021-03-24 21:04:53 --> Model Class Initialized
INFO - 2021-03-24 21:04:53 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:04:53 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:04:53 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:04:53 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:04:53 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:04:53 --> Final output sent to browser
DEBUG - 2021-03-24 21:04:53 --> Total execution time: 0.0719
INFO - 2021-03-24 21:05:46 --> Config Class Initialized
INFO - 2021-03-24 21:05:46 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:05:46 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:05:46 --> Utf8 Class Initialized
INFO - 2021-03-24 21:05:46 --> URI Class Initialized
INFO - 2021-03-24 21:05:46 --> Router Class Initialized
INFO - 2021-03-24 21:05:46 --> Output Class Initialized
INFO - 2021-03-24 21:05:46 --> Security Class Initialized
DEBUG - 2021-03-24 21:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:05:46 --> Input Class Initialized
INFO - 2021-03-24 21:05:46 --> Language Class Initialized
INFO - 2021-03-24 21:05:46 --> Loader Class Initialized
INFO - 2021-03-24 21:05:46 --> Helper loaded: url_helper
INFO - 2021-03-24 21:05:46 --> Helper loaded: form_helper
INFO - 2021-03-24 21:05:46 --> Helper loaded: common_helper
INFO - 2021-03-24 21:05:46 --> Helper loaded: util_helper
INFO - 2021-03-24 21:05:46 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:05:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:05:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:05:46 --> Form Validation Class Initialized
INFO - 2021-03-24 21:05:46 --> Controller Class Initialized
INFO - 2021-03-24 21:05:46 --> Model Class Initialized
INFO - 2021-03-24 21:05:46 --> Model Class Initialized
INFO - 2021-03-24 21:05:46 --> Model Class Initialized
INFO - 2021-03-24 21:05:46 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:05:46 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:05:46 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:05:46 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:05:46 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:05:46 --> Final output sent to browser
DEBUG - 2021-03-24 21:05:46 --> Total execution time: 0.0384
INFO - 2021-03-24 21:05:46 --> Config Class Initialized
INFO - 2021-03-24 21:05:46 --> Config Class Initialized
INFO - 2021-03-24 21:05:46 --> Hooks Class Initialized
INFO - 2021-03-24 21:05:46 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:05:46 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:05:46 --> Utf8 Class Initialized
DEBUG - 2021-03-24 21:05:46 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:05:46 --> Utf8 Class Initialized
INFO - 2021-03-24 21:05:46 --> URI Class Initialized
INFO - 2021-03-24 21:05:46 --> Router Class Initialized
INFO - 2021-03-24 21:05:46 --> URI Class Initialized
INFO - 2021-03-24 21:05:46 --> Output Class Initialized
INFO - 2021-03-24 21:05:46 --> Router Class Initialized
INFO - 2021-03-24 21:05:46 --> Security Class Initialized
INFO - 2021-03-24 21:05:46 --> Output Class Initialized
DEBUG - 2021-03-24 21:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:05:46 --> Input Class Initialized
INFO - 2021-03-24 21:05:46 --> Security Class Initialized
INFO - 2021-03-24 21:05:46 --> Language Class Initialized
DEBUG - 2021-03-24 21:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:05:46 --> Input Class Initialized
INFO - 2021-03-24 21:05:46 --> Language Class Initialized
INFO - 2021-03-24 21:05:46 --> Loader Class Initialized
INFO - 2021-03-24 21:05:46 --> Helper loaded: url_helper
INFO - 2021-03-24 21:05:46 --> Helper loaded: form_helper
INFO - 2021-03-24 21:05:46 --> Loader Class Initialized
INFO - 2021-03-24 21:05:46 --> Helper loaded: common_helper
INFO - 2021-03-24 21:05:46 --> Helper loaded: url_helper
INFO - 2021-03-24 21:05:46 --> Helper loaded: util_helper
INFO - 2021-03-24 21:05:46 --> Helper loaded: form_helper
INFO - 2021-03-24 21:05:46 --> Helper loaded: common_helper
INFO - 2021-03-24 21:05:46 --> Helper loaded: util_helper
INFO - 2021-03-24 21:05:46 --> Config Class Initialized
INFO - 2021-03-24 21:05:46 --> Hooks Class Initialized
INFO - 2021-03-24 21:05:46 --> Config Class Initialized
INFO - 2021-03-24 21:05:46 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:05:46 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:05:46 --> Utf8 Class Initialized
DEBUG - 2021-03-24 21:05:46 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:05:46 --> Utf8 Class Initialized
INFO - 2021-03-24 21:05:46 --> URI Class Initialized
INFO - 2021-03-24 21:05:46 --> URI Class Initialized
INFO - 2021-03-24 21:05:46 --> Router Class Initialized
INFO - 2021-03-24 21:05:46 --> Router Class Initialized
INFO - 2021-03-24 21:05:46 --> Database Driver Class Initialized
INFO - 2021-03-24 21:05:46 --> Output Class Initialized
INFO - 2021-03-24 21:05:46 --> Output Class Initialized
INFO - 2021-03-24 21:05:46 --> Security Class Initialized
INFO - 2021-03-24 21:05:46 --> Security Class Initialized
DEBUG - 2021-03-24 21:05:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-24 21:05:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:05:46 --> Input Class Initialized
DEBUG - 2021-03-24 21:05:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:05:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:05:46 --> Input Class Initialized
INFO - 2021-03-24 21:05:46 --> Language Class Initialized
INFO - 2021-03-24 21:05:46 --> Language Class Initialized
INFO - 2021-03-24 21:05:46 --> Form Validation Class Initialized
INFO - 2021-03-24 21:05:46 --> Controller Class Initialized
INFO - 2021-03-24 21:05:46 --> Model Class Initialized
INFO - 2021-03-24 21:05:46 --> Model Class Initialized
INFO - 2021-03-24 21:05:46 --> Model Class Initialized
INFO - 2021-03-24 21:05:46 --> Loader Class Initialized
INFO - 2021-03-24 21:05:46 --> Loader Class Initialized
INFO - 2021-03-24 21:05:46 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:05:46 --> Helper loaded: url_helper
INFO - 2021-03-24 21:05:46 --> Helper loaded: url_helper
INFO - 2021-03-24 21:05:46 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:05:46 --> Database Driver Class Initialized
INFO - 2021-03-24 21:05:46 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:05:46 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:05:46 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:05:46 --> Helper loaded: form_helper
INFO - 2021-03-24 21:05:46 --> Helper loaded: form_helper
INFO - 2021-03-24 21:05:46 --> Final output sent to browser
DEBUG - 2021-03-24 21:05:46 --> Total execution time: 0.0637
INFO - 2021-03-24 21:05:46 --> Helper loaded: common_helper
INFO - 2021-03-24 21:05:46 --> Helper loaded: common_helper
INFO - 2021-03-24 21:05:46 --> Helper loaded: util_helper
INFO - 2021-03-24 21:05:46 --> Helper loaded: util_helper
INFO - 2021-03-24 21:05:46 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:05:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:05:46 --> Database Driver Class Initialized
INFO - 2021-03-24 21:05:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:05:46 --> Form Validation Class Initialized
INFO - 2021-03-24 21:05:46 --> Controller Class Initialized
DEBUG - 2021-03-24 21:05:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-03-24 21:05:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:05:46 --> Model Class Initialized
INFO - 2021-03-24 21:05:46 --> Model Class Initialized
INFO - 2021-03-24 21:05:46 --> Model Class Initialized
INFO - 2021-03-24 21:05:46 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:05:46 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:05:46 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:05:46 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:05:46 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:05:46 --> Final output sent to browser
DEBUG - 2021-03-24 21:05:46 --> Total execution time: 0.0842
INFO - 2021-03-24 21:05:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:05:46 --> Form Validation Class Initialized
INFO - 2021-03-24 21:05:46 --> Controller Class Initialized
INFO - 2021-03-24 21:05:46 --> Model Class Initialized
INFO - 2021-03-24 21:05:46 --> Model Class Initialized
INFO - 2021-03-24 21:05:46 --> Model Class Initialized
INFO - 2021-03-24 21:05:46 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:05:46 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:05:46 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:05:46 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:05:46 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:05:46 --> Final output sent to browser
DEBUG - 2021-03-24 21:05:46 --> Total execution time: 0.0610
INFO - 2021-03-24 21:05:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:05:46 --> Form Validation Class Initialized
INFO - 2021-03-24 21:05:46 --> Controller Class Initialized
INFO - 2021-03-24 21:05:46 --> Model Class Initialized
INFO - 2021-03-24 21:05:46 --> Model Class Initialized
INFO - 2021-03-24 21:05:46 --> Model Class Initialized
INFO - 2021-03-24 21:05:46 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:05:46 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:05:46 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:05:46 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:05:46 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:05:46 --> Final output sent to browser
DEBUG - 2021-03-24 21:05:46 --> Total execution time: 0.0763
INFO - 2021-03-24 21:24:12 --> Config Class Initialized
INFO - 2021-03-24 21:24:12 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:24:12 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:24:12 --> Utf8 Class Initialized
INFO - 2021-03-24 21:24:12 --> URI Class Initialized
INFO - 2021-03-24 21:24:12 --> Router Class Initialized
INFO - 2021-03-24 21:24:12 --> Output Class Initialized
INFO - 2021-03-24 21:24:12 --> Security Class Initialized
DEBUG - 2021-03-24 21:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:24:12 --> Input Class Initialized
INFO - 2021-03-24 21:24:12 --> Language Class Initialized
INFO - 2021-03-24 21:24:12 --> Loader Class Initialized
INFO - 2021-03-24 21:24:12 --> Helper loaded: url_helper
INFO - 2021-03-24 21:24:12 --> Helper loaded: form_helper
INFO - 2021-03-24 21:24:12 --> Helper loaded: common_helper
INFO - 2021-03-24 21:24:12 --> Helper loaded: util_helper
INFO - 2021-03-24 21:24:12 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:24:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:24:12 --> Form Validation Class Initialized
INFO - 2021-03-24 21:24:12 --> Controller Class Initialized
INFO - 2021-03-24 21:24:12 --> Model Class Initialized
INFO - 2021-03-24 21:24:12 --> Model Class Initialized
INFO - 2021-03-24 21:24:12 --> Model Class Initialized
INFO - 2021-03-24 21:24:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:24:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:24:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:24:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:24:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:24:12 --> Final output sent to browser
DEBUG - 2021-03-24 21:24:12 --> Total execution time: 0.0545
INFO - 2021-03-24 21:24:12 --> Config Class Initialized
INFO - 2021-03-24 21:24:12 --> Hooks Class Initialized
INFO - 2021-03-24 21:24:12 --> Config Class Initialized
INFO - 2021-03-24 21:24:12 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:24:12 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:24:12 --> Utf8 Class Initialized
INFO - 2021-03-24 21:24:12 --> URI Class Initialized
DEBUG - 2021-03-24 21:24:12 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:24:12 --> Utf8 Class Initialized
INFO - 2021-03-24 21:24:12 --> Router Class Initialized
INFO - 2021-03-24 21:24:12 --> Output Class Initialized
INFO - 2021-03-24 21:24:12 --> URI Class Initialized
INFO - 2021-03-24 21:24:12 --> Security Class Initialized
INFO - 2021-03-24 21:24:12 --> Router Class Initialized
DEBUG - 2021-03-24 21:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:24:12 --> Input Class Initialized
INFO - 2021-03-24 21:24:12 --> Output Class Initialized
INFO - 2021-03-24 21:24:12 --> Language Class Initialized
INFO - 2021-03-24 21:24:12 --> Security Class Initialized
DEBUG - 2021-03-24 21:24:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:24:12 --> Input Class Initialized
INFO - 2021-03-24 21:24:12 --> Language Class Initialized
INFO - 2021-03-24 21:24:12 --> Loader Class Initialized
INFO - 2021-03-24 21:24:12 --> Helper loaded: url_helper
INFO - 2021-03-24 21:24:12 --> Helper loaded: form_helper
INFO - 2021-03-24 21:24:12 --> Loader Class Initialized
INFO - 2021-03-24 21:24:12 --> Helper loaded: common_helper
INFO - 2021-03-24 21:24:12 --> Helper loaded: url_helper
INFO - 2021-03-24 21:24:12 --> Helper loaded: util_helper
INFO - 2021-03-24 21:24:12 --> Helper loaded: form_helper
INFO - 2021-03-24 21:24:12 --> Helper loaded: common_helper
INFO - 2021-03-24 21:24:12 --> Helper loaded: util_helper
INFO - 2021-03-24 21:24:12 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:24:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:24:12 --> Database Driver Class Initialized
INFO - 2021-03-24 21:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:24:12 --> Form Validation Class Initialized
INFO - 2021-03-24 21:24:12 --> Controller Class Initialized
DEBUG - 2021-03-24 21:24:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:24:12 --> Model Class Initialized
INFO - 2021-03-24 21:24:12 --> Model Class Initialized
INFO - 2021-03-24 21:24:12 --> Model Class Initialized
INFO - 2021-03-24 21:24:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:24:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:24:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:24:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:24:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:24:12 --> Final output sent to browser
DEBUG - 2021-03-24 21:24:12 --> Total execution time: 0.0489
INFO - 2021-03-24 21:24:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:24:12 --> Form Validation Class Initialized
INFO - 2021-03-24 21:24:12 --> Controller Class Initialized
INFO - 2021-03-24 21:24:12 --> Model Class Initialized
INFO - 2021-03-24 21:24:12 --> Model Class Initialized
INFO - 2021-03-24 21:24:12 --> Model Class Initialized
INFO - 2021-03-24 21:24:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:24:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:24:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:24:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:24:12 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:24:12 --> Final output sent to browser
DEBUG - 2021-03-24 21:24:12 --> Total execution time: 0.0669
INFO - 2021-03-24 21:24:12 --> Config Class Initialized
INFO - 2021-03-24 21:24:12 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:24:12 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:24:12 --> Utf8 Class Initialized
INFO - 2021-03-24 21:24:12 --> URI Class Initialized
INFO - 2021-03-24 21:24:12 --> Router Class Initialized
INFO - 2021-03-24 21:24:12 --> Output Class Initialized
INFO - 2021-03-24 21:24:12 --> Security Class Initialized
INFO - 2021-03-24 21:24:12 --> Config Class Initialized
INFO - 2021-03-24 21:24:12 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:24:13 --> Input Class Initialized
INFO - 2021-03-24 21:24:13 --> Language Class Initialized
DEBUG - 2021-03-24 21:24:13 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:24:13 --> Utf8 Class Initialized
INFO - 2021-03-24 21:24:13 --> URI Class Initialized
INFO - 2021-03-24 21:24:13 --> Loader Class Initialized
INFO - 2021-03-24 21:24:13 --> Router Class Initialized
INFO - 2021-03-24 21:24:13 --> Helper loaded: url_helper
INFO - 2021-03-24 21:24:13 --> Output Class Initialized
INFO - 2021-03-24 21:24:13 --> Helper loaded: form_helper
INFO - 2021-03-24 21:24:13 --> Security Class Initialized
INFO - 2021-03-24 21:24:13 --> Helper loaded: common_helper
INFO - 2021-03-24 21:24:13 --> Helper loaded: util_helper
DEBUG - 2021-03-24 21:24:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:24:13 --> Input Class Initialized
INFO - 2021-03-24 21:24:13 --> Language Class Initialized
INFO - 2021-03-24 21:24:13 --> Loader Class Initialized
INFO - 2021-03-24 21:24:13 --> Database Driver Class Initialized
INFO - 2021-03-24 21:24:13 --> Helper loaded: url_helper
INFO - 2021-03-24 21:24:13 --> Helper loaded: form_helper
INFO - 2021-03-24 21:24:13 --> Helper loaded: common_helper
DEBUG - 2021-03-24 21:24:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:24:13 --> Helper loaded: util_helper
INFO - 2021-03-24 21:24:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:24:13 --> Form Validation Class Initialized
INFO - 2021-03-24 21:24:13 --> Controller Class Initialized
INFO - 2021-03-24 21:24:13 --> Model Class Initialized
INFO - 2021-03-24 21:24:13 --> Model Class Initialized
INFO - 2021-03-24 21:24:13 --> Model Class Initialized
INFO - 2021-03-24 21:24:13 --> Database Driver Class Initialized
INFO - 2021-03-24 21:24:13 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
DEBUG - 2021-03-24 21:24:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:24:13 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:24:13 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:24:13 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:24:13 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:24:13 --> Final output sent to browser
DEBUG - 2021-03-24 21:24:13 --> Total execution time: 0.0519
INFO - 2021-03-24 21:24:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:24:13 --> Form Validation Class Initialized
INFO - 2021-03-24 21:24:13 --> Controller Class Initialized
INFO - 2021-03-24 21:24:13 --> Model Class Initialized
INFO - 2021-03-24 21:24:13 --> Model Class Initialized
INFO - 2021-03-24 21:24:13 --> Model Class Initialized
INFO - 2021-03-24 21:24:13 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:24:13 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:24:13 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:24:13 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:24:13 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:24:13 --> Final output sent to browser
DEBUG - 2021-03-24 21:24:13 --> Total execution time: 0.0544
INFO - 2021-03-24 21:24:31 --> Config Class Initialized
INFO - 2021-03-24 21:24:31 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:24:31 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:24:31 --> Utf8 Class Initialized
INFO - 2021-03-24 21:24:31 --> URI Class Initialized
INFO - 2021-03-24 21:24:31 --> Router Class Initialized
INFO - 2021-03-24 21:24:31 --> Output Class Initialized
INFO - 2021-03-24 21:24:31 --> Security Class Initialized
DEBUG - 2021-03-24 21:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:24:31 --> Input Class Initialized
INFO - 2021-03-24 21:24:31 --> Language Class Initialized
INFO - 2021-03-24 21:24:31 --> Loader Class Initialized
INFO - 2021-03-24 21:24:31 --> Helper loaded: url_helper
INFO - 2021-03-24 21:24:31 --> Helper loaded: form_helper
INFO - 2021-03-24 21:24:31 --> Helper loaded: common_helper
INFO - 2021-03-24 21:24:31 --> Helper loaded: util_helper
INFO - 2021-03-24 21:24:31 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:24:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:24:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:24:31 --> Form Validation Class Initialized
INFO - 2021-03-24 21:24:31 --> Controller Class Initialized
INFO - 2021-03-24 21:24:31 --> Model Class Initialized
INFO - 2021-03-24 21:24:31 --> Model Class Initialized
INFO - 2021-03-24 21:24:31 --> Model Class Initialized
INFO - 2021-03-24 21:24:31 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:24:31 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:24:31 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:24:31 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:24:31 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:24:31 --> Final output sent to browser
DEBUG - 2021-03-24 21:24:31 --> Total execution time: 0.0388
INFO - 2021-03-24 21:24:31 --> Config Class Initialized
INFO - 2021-03-24 21:24:31 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:24:31 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:24:31 --> Utf8 Class Initialized
INFO - 2021-03-24 21:24:31 --> Config Class Initialized
INFO - 2021-03-24 21:24:31 --> Hooks Class Initialized
INFO - 2021-03-24 21:24:31 --> URI Class Initialized
INFO - 2021-03-24 21:24:31 --> Router Class Initialized
DEBUG - 2021-03-24 21:24:31 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:24:31 --> Utf8 Class Initialized
INFO - 2021-03-24 21:24:31 --> URI Class Initialized
INFO - 2021-03-24 21:24:31 --> Output Class Initialized
INFO - 2021-03-24 21:24:31 --> Router Class Initialized
INFO - 2021-03-24 21:24:31 --> Security Class Initialized
DEBUG - 2021-03-24 21:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:24:31 --> Input Class Initialized
INFO - 2021-03-24 21:24:31 --> Output Class Initialized
INFO - 2021-03-24 21:24:31 --> Language Class Initialized
INFO - 2021-03-24 21:24:31 --> Security Class Initialized
DEBUG - 2021-03-24 21:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:24:31 --> Input Class Initialized
INFO - 2021-03-24 21:24:31 --> Language Class Initialized
INFO - 2021-03-24 21:24:31 --> Loader Class Initialized
INFO - 2021-03-24 21:24:31 --> Helper loaded: url_helper
INFO - 2021-03-24 21:24:31 --> Loader Class Initialized
INFO - 2021-03-24 21:24:31 --> Helper loaded: form_helper
INFO - 2021-03-24 21:24:31 --> Helper loaded: url_helper
INFO - 2021-03-24 21:24:31 --> Helper loaded: common_helper
INFO - 2021-03-24 21:24:31 --> Helper loaded: util_helper
INFO - 2021-03-24 21:24:31 --> Helper loaded: form_helper
INFO - 2021-03-24 21:24:31 --> Helper loaded: common_helper
INFO - 2021-03-24 21:24:31 --> Helper loaded: util_helper
INFO - 2021-03-24 21:24:31 --> Database Driver Class Initialized
INFO - 2021-03-24 21:24:31 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:24:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:24:31 --> Session: Class initialized using 'files' driver.
DEBUG - 2021-03-24 21:24:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:24:31 --> Form Validation Class Initialized
INFO - 2021-03-24 21:24:31 --> Controller Class Initialized
INFO - 2021-03-24 21:24:31 --> Model Class Initialized
INFO - 2021-03-24 21:24:31 --> Model Class Initialized
INFO - 2021-03-24 21:24:31 --> Model Class Initialized
INFO - 2021-03-24 21:24:31 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:24:31 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:24:31 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:24:31 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:24:31 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:24:31 --> Final output sent to browser
DEBUG - 2021-03-24 21:24:31 --> Total execution time: 0.0487
INFO - 2021-03-24 21:24:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:24:31 --> Form Validation Class Initialized
INFO - 2021-03-24 21:24:31 --> Controller Class Initialized
INFO - 2021-03-24 21:24:31 --> Model Class Initialized
INFO - 2021-03-24 21:24:31 --> Model Class Initialized
INFO - 2021-03-24 21:24:31 --> Model Class Initialized
INFO - 2021-03-24 21:24:31 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:24:31 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:24:31 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:24:31 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:24:31 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:24:31 --> Final output sent to browser
DEBUG - 2021-03-24 21:24:31 --> Total execution time: 0.0590
INFO - 2021-03-24 21:24:31 --> Config Class Initialized
INFO - 2021-03-24 21:24:31 --> Config Class Initialized
INFO - 2021-03-24 21:24:31 --> Hooks Class Initialized
INFO - 2021-03-24 21:24:31 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:24:31 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:24:31 --> Utf8 Class Initialized
DEBUG - 2021-03-24 21:24:31 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:24:31 --> Utf8 Class Initialized
INFO - 2021-03-24 21:24:31 --> URI Class Initialized
INFO - 2021-03-24 21:24:31 --> URI Class Initialized
INFO - 2021-03-24 21:24:31 --> Router Class Initialized
INFO - 2021-03-24 21:24:31 --> Router Class Initialized
INFO - 2021-03-24 21:24:31 --> Output Class Initialized
INFO - 2021-03-24 21:24:31 --> Output Class Initialized
INFO - 2021-03-24 21:24:31 --> Security Class Initialized
INFO - 2021-03-24 21:24:31 --> Security Class Initialized
DEBUG - 2021-03-24 21:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:24:31 --> Input Class Initialized
DEBUG - 2021-03-24 21:24:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:24:31 --> Input Class Initialized
INFO - 2021-03-24 21:24:31 --> Language Class Initialized
INFO - 2021-03-24 21:24:31 --> Language Class Initialized
INFO - 2021-03-24 21:24:31 --> Loader Class Initialized
INFO - 2021-03-24 21:24:31 --> Loader Class Initialized
INFO - 2021-03-24 21:24:31 --> Helper loaded: url_helper
INFO - 2021-03-24 21:24:31 --> Helper loaded: url_helper
INFO - 2021-03-24 21:24:31 --> Helper loaded: form_helper
INFO - 2021-03-24 21:24:31 --> Helper loaded: form_helper
INFO - 2021-03-24 21:24:31 --> Helper loaded: common_helper
INFO - 2021-03-24 21:24:31 --> Helper loaded: common_helper
INFO - 2021-03-24 21:24:31 --> Helper loaded: util_helper
INFO - 2021-03-24 21:24:31 --> Helper loaded: util_helper
INFO - 2021-03-24 21:24:31 --> Database Driver Class Initialized
INFO - 2021-03-24 21:24:31 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:24:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-03-24 21:24:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:24:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:24:31 --> Form Validation Class Initialized
INFO - 2021-03-24 21:24:31 --> Controller Class Initialized
INFO - 2021-03-24 21:24:31 --> Model Class Initialized
INFO - 2021-03-24 21:24:31 --> Model Class Initialized
INFO - 2021-03-24 21:24:31 --> Model Class Initialized
INFO - 2021-03-24 21:24:31 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:24:31 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:24:31 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:24:31 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:24:31 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:24:31 --> Final output sent to browser
DEBUG - 2021-03-24 21:24:31 --> Total execution time: 0.0465
INFO - 2021-03-24 21:24:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:24:31 --> Form Validation Class Initialized
INFO - 2021-03-24 21:24:31 --> Controller Class Initialized
INFO - 2021-03-24 21:24:31 --> Model Class Initialized
INFO - 2021-03-24 21:24:31 --> Model Class Initialized
INFO - 2021-03-24 21:24:31 --> Model Class Initialized
INFO - 2021-03-24 21:24:31 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:24:31 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:24:31 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:24:31 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:24:31 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:24:31 --> Final output sent to browser
DEBUG - 2021-03-24 21:24:31 --> Total execution time: 0.0580
INFO - 2021-03-24 21:24:53 --> Config Class Initialized
INFO - 2021-03-24 21:24:53 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:24:53 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:24:53 --> Utf8 Class Initialized
INFO - 2021-03-24 21:24:53 --> URI Class Initialized
INFO - 2021-03-24 21:24:53 --> Router Class Initialized
INFO - 2021-03-24 21:24:53 --> Output Class Initialized
INFO - 2021-03-24 21:24:53 --> Security Class Initialized
DEBUG - 2021-03-24 21:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:24:53 --> Input Class Initialized
INFO - 2021-03-24 21:24:53 --> Language Class Initialized
INFO - 2021-03-24 21:24:53 --> Loader Class Initialized
INFO - 2021-03-24 21:24:53 --> Helper loaded: url_helper
INFO - 2021-03-24 21:24:53 --> Helper loaded: form_helper
INFO - 2021-03-24 21:24:53 --> Helper loaded: common_helper
INFO - 2021-03-24 21:24:53 --> Helper loaded: util_helper
INFO - 2021-03-24 21:24:53 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:24:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:24:53 --> Form Validation Class Initialized
INFO - 2021-03-24 21:24:53 --> Controller Class Initialized
INFO - 2021-03-24 21:24:53 --> Model Class Initialized
INFO - 2021-03-24 21:24:53 --> Model Class Initialized
INFO - 2021-03-24 21:24:53 --> Model Class Initialized
INFO - 2021-03-24 21:24:53 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:24:53 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:24:53 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:24:53 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:24:53 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:24:53 --> Final output sent to browser
DEBUG - 2021-03-24 21:24:53 --> Total execution time: 0.0479
INFO - 2021-03-24 21:24:53 --> Config Class Initialized
INFO - 2021-03-24 21:24:53 --> Hooks Class Initialized
INFO - 2021-03-24 21:24:53 --> Config Class Initialized
DEBUG - 2021-03-24 21:24:53 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:24:53 --> Hooks Class Initialized
INFO - 2021-03-24 21:24:53 --> Utf8 Class Initialized
INFO - 2021-03-24 21:24:53 --> URI Class Initialized
DEBUG - 2021-03-24 21:24:53 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:24:53 --> Utf8 Class Initialized
INFO - 2021-03-24 21:24:53 --> Router Class Initialized
INFO - 2021-03-24 21:24:53 --> URI Class Initialized
INFO - 2021-03-24 21:24:53 --> Router Class Initialized
INFO - 2021-03-24 21:24:53 --> Output Class Initialized
INFO - 2021-03-24 21:24:53 --> Output Class Initialized
INFO - 2021-03-24 21:24:53 --> Security Class Initialized
INFO - 2021-03-24 21:24:53 --> Security Class Initialized
DEBUG - 2021-03-24 21:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:24:53 --> Input Class Initialized
DEBUG - 2021-03-24 21:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:24:53 --> Language Class Initialized
INFO - 2021-03-24 21:24:53 --> Input Class Initialized
INFO - 2021-03-24 21:24:53 --> Language Class Initialized
INFO - 2021-03-24 21:24:53 --> Loader Class Initialized
INFO - 2021-03-24 21:24:53 --> Helper loaded: url_helper
INFO - 2021-03-24 21:24:53 --> Loader Class Initialized
INFO - 2021-03-24 21:24:53 --> Helper loaded: url_helper
INFO - 2021-03-24 21:24:53 --> Helper loaded: form_helper
INFO - 2021-03-24 21:24:53 --> Helper loaded: common_helper
INFO - 2021-03-24 21:24:53 --> Helper loaded: form_helper
INFO - 2021-03-24 21:24:53 --> Helper loaded: util_helper
INFO - 2021-03-24 21:24:53 --> Helper loaded: common_helper
INFO - 2021-03-24 21:24:53 --> Helper loaded: util_helper
INFO - 2021-03-24 21:24:53 --> Database Driver Class Initialized
INFO - 2021-03-24 21:24:53 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:24:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:24:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2021-03-24 21:24:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:24:53 --> Form Validation Class Initialized
INFO - 2021-03-24 21:24:53 --> Controller Class Initialized
INFO - 2021-03-24 21:24:53 --> Model Class Initialized
INFO - 2021-03-24 21:24:53 --> Model Class Initialized
INFO - 2021-03-24 21:24:53 --> Model Class Initialized
INFO - 2021-03-24 21:24:53 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:24:53 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:24:53 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:24:53 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:24:53 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:24:53 --> Final output sent to browser
DEBUG - 2021-03-24 21:24:53 --> Total execution time: 0.0493
INFO - 2021-03-24 21:24:53 --> Config Class Initialized
INFO - 2021-03-24 21:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:24:53 --> Hooks Class Initialized
INFO - 2021-03-24 21:24:53 --> Form Validation Class Initialized
INFO - 2021-03-24 21:24:53 --> Controller Class Initialized
DEBUG - 2021-03-24 21:24:53 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:24:53 --> Model Class Initialized
INFO - 2021-03-24 21:24:53 --> Utf8 Class Initialized
INFO - 2021-03-24 21:24:53 --> Model Class Initialized
INFO - 2021-03-24 21:24:53 --> Model Class Initialized
INFO - 2021-03-24 21:24:53 --> URI Class Initialized
INFO - 2021-03-24 21:24:53 --> Config Class Initialized
INFO - 2021-03-24 21:24:53 --> Hooks Class Initialized
INFO - 2021-03-24 21:24:53 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
DEBUG - 2021-03-24 21:24:53 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:24:53 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:24:53 --> Utf8 Class Initialized
INFO - 2021-03-24 21:24:53 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:24:53 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:24:53 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:24:53 --> Final output sent to browser
DEBUG - 2021-03-24 21:24:53 --> Total execution time: 0.0606
INFO - 2021-03-24 21:24:53 --> Router Class Initialized
INFO - 2021-03-24 21:24:53 --> URI Class Initialized
INFO - 2021-03-24 21:24:53 --> Output Class Initialized
INFO - 2021-03-24 21:24:53 --> Router Class Initialized
INFO - 2021-03-24 21:24:53 --> Security Class Initialized
DEBUG - 2021-03-24 21:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:24:53 --> Output Class Initialized
INFO - 2021-03-24 21:24:53 --> Input Class Initialized
INFO - 2021-03-24 21:24:53 --> Language Class Initialized
INFO - 2021-03-24 21:24:53 --> Security Class Initialized
DEBUG - 2021-03-24 21:24:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:24:53 --> Input Class Initialized
INFO - 2021-03-24 21:24:53 --> Loader Class Initialized
INFO - 2021-03-24 21:24:53 --> Language Class Initialized
INFO - 2021-03-24 21:24:53 --> Helper loaded: url_helper
INFO - 2021-03-24 21:24:53 --> Helper loaded: form_helper
INFO - 2021-03-24 21:24:53 --> Loader Class Initialized
INFO - 2021-03-24 21:24:53 --> Helper loaded: common_helper
INFO - 2021-03-24 21:24:53 --> Helper loaded: util_helper
INFO - 2021-03-24 21:24:53 --> Helper loaded: url_helper
INFO - 2021-03-24 21:24:53 --> Helper loaded: form_helper
INFO - 2021-03-24 21:24:53 --> Helper loaded: common_helper
INFO - 2021-03-24 21:24:53 --> Helper loaded: util_helper
INFO - 2021-03-24 21:24:53 --> Database Driver Class Initialized
INFO - 2021-03-24 21:24:53 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:24:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:24:53 --> Session: Class initialized using 'files' driver.
DEBUG - 2021-03-24 21:24:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:24:53 --> Form Validation Class Initialized
INFO - 2021-03-24 21:24:53 --> Controller Class Initialized
INFO - 2021-03-24 21:24:53 --> Model Class Initialized
INFO - 2021-03-24 21:24:53 --> Model Class Initialized
INFO - 2021-03-24 21:24:53 --> Model Class Initialized
INFO - 2021-03-24 21:24:53 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:24:53 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:24:53 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:24:53 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:24:53 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:24:53 --> Final output sent to browser
DEBUG - 2021-03-24 21:24:53 --> Total execution time: 0.0596
INFO - 2021-03-24 21:24:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:24:53 --> Form Validation Class Initialized
INFO - 2021-03-24 21:24:53 --> Controller Class Initialized
INFO - 2021-03-24 21:24:53 --> Model Class Initialized
INFO - 2021-03-24 21:24:53 --> Model Class Initialized
INFO - 2021-03-24 21:24:53 --> Model Class Initialized
INFO - 2021-03-24 21:24:53 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:24:53 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:24:53 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:24:53 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:24:53 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:24:53 --> Final output sent to browser
DEBUG - 2021-03-24 21:24:53 --> Total execution time: 0.0678
INFO - 2021-03-24 21:24:58 --> Config Class Initialized
INFO - 2021-03-24 21:24:58 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:24:58 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:24:58 --> Utf8 Class Initialized
INFO - 2021-03-24 21:24:58 --> URI Class Initialized
INFO - 2021-03-24 21:24:58 --> Router Class Initialized
INFO - 2021-03-24 21:24:58 --> Output Class Initialized
INFO - 2021-03-24 21:24:58 --> Security Class Initialized
DEBUG - 2021-03-24 21:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:24:58 --> Input Class Initialized
INFO - 2021-03-24 21:24:58 --> Language Class Initialized
INFO - 2021-03-24 21:24:58 --> Loader Class Initialized
INFO - 2021-03-24 21:24:58 --> Helper loaded: url_helper
INFO - 2021-03-24 21:24:58 --> Helper loaded: form_helper
INFO - 2021-03-24 21:24:58 --> Helper loaded: common_helper
INFO - 2021-03-24 21:24:58 --> Helper loaded: util_helper
INFO - 2021-03-24 21:24:58 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:24:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:24:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:24:58 --> Form Validation Class Initialized
INFO - 2021-03-24 21:24:58 --> Controller Class Initialized
INFO - 2021-03-24 21:24:58 --> Model Class Initialized
INFO - 2021-03-24 21:24:58 --> Model Class Initialized
INFO - 2021-03-24 21:24:58 --> Model Class Initialized
INFO - 2021-03-24 21:24:58 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-03-24 21:24:58 --> Config Class Initialized
INFO - 2021-03-24 21:24:58 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:24:58 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:24:58 --> Utf8 Class Initialized
INFO - 2021-03-24 21:24:58 --> URI Class Initialized
INFO - 2021-03-24 21:24:58 --> Router Class Initialized
INFO - 2021-03-24 21:24:58 --> Output Class Initialized
INFO - 2021-03-24 21:24:58 --> Security Class Initialized
DEBUG - 2021-03-24 21:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:24:58 --> Input Class Initialized
INFO - 2021-03-24 21:24:58 --> Language Class Initialized
INFO - 2021-03-24 21:24:58 --> Loader Class Initialized
INFO - 2021-03-24 21:24:58 --> Helper loaded: url_helper
INFO - 2021-03-24 21:24:58 --> Helper loaded: form_helper
INFO - 2021-03-24 21:24:58 --> Helper loaded: common_helper
INFO - 2021-03-24 21:24:58 --> Helper loaded: util_helper
INFO - 2021-03-24 21:24:58 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:24:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:24:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:24:58 --> Form Validation Class Initialized
INFO - 2021-03-24 21:24:58 --> Controller Class Initialized
INFO - 2021-03-24 21:24:58 --> Model Class Initialized
INFO - 2021-03-24 21:24:58 --> Model Class Initialized
INFO - 2021-03-24 21:24:58 --> Model Class Initialized
INFO - 2021-03-24 21:24:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:24:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:24:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:24:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:24:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:24:58 --> Final output sent to browser
DEBUG - 2021-03-24 21:24:58 --> Total execution time: 0.0469
INFO - 2021-03-24 21:24:58 --> Config Class Initialized
INFO - 2021-03-24 21:24:58 --> Hooks Class Initialized
INFO - 2021-03-24 21:24:58 --> Config Class Initialized
INFO - 2021-03-24 21:24:58 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:24:58 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:24:58 --> Utf8 Class Initialized
INFO - 2021-03-24 21:24:58 --> URI Class Initialized
DEBUG - 2021-03-24 21:24:58 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:24:58 --> Utf8 Class Initialized
INFO - 2021-03-24 21:24:58 --> Router Class Initialized
INFO - 2021-03-24 21:24:58 --> URI Class Initialized
INFO - 2021-03-24 21:24:58 --> Output Class Initialized
INFO - 2021-03-24 21:24:58 --> Router Class Initialized
INFO - 2021-03-24 21:24:58 --> Security Class Initialized
INFO - 2021-03-24 21:24:58 --> Output Class Initialized
DEBUG - 2021-03-24 21:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:24:58 --> Input Class Initialized
INFO - 2021-03-24 21:24:58 --> Security Class Initialized
INFO - 2021-03-24 21:24:58 --> Language Class Initialized
DEBUG - 2021-03-24 21:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:24:58 --> Input Class Initialized
INFO - 2021-03-24 21:24:58 --> Language Class Initialized
INFO - 2021-03-24 21:24:58 --> Loader Class Initialized
INFO - 2021-03-24 21:24:58 --> Helper loaded: url_helper
INFO - 2021-03-24 21:24:58 --> Loader Class Initialized
INFO - 2021-03-24 21:24:58 --> Helper loaded: form_helper
INFO - 2021-03-24 21:24:58 --> Helper loaded: url_helper
INFO - 2021-03-24 21:24:58 --> Helper loaded: common_helper
INFO - 2021-03-24 21:24:58 --> Helper loaded: form_helper
INFO - 2021-03-24 21:24:58 --> Helper loaded: util_helper
INFO - 2021-03-24 21:24:58 --> Helper loaded: common_helper
INFO - 2021-03-24 21:24:58 --> Helper loaded: util_helper
INFO - 2021-03-24 21:24:58 --> Database Driver Class Initialized
INFO - 2021-03-24 21:24:58 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:24:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:24:58 --> Session: Class initialized using 'files' driver.
DEBUG - 2021-03-24 21:24:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:24:58 --> Form Validation Class Initialized
INFO - 2021-03-24 21:24:58 --> Controller Class Initialized
INFO - 2021-03-24 21:24:58 --> Model Class Initialized
INFO - 2021-03-24 21:24:58 --> Model Class Initialized
INFO - 2021-03-24 21:24:58 --> Model Class Initialized
INFO - 2021-03-24 21:24:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:24:58 --> Config Class Initialized
INFO - 2021-03-24 21:24:58 --> Hooks Class Initialized
INFO - 2021-03-24 21:24:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:24:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:24:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:24:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:24:58 --> Final output sent to browser
DEBUG - 2021-03-24 21:24:58 --> Total execution time: 0.0481
DEBUG - 2021-03-24 21:24:58 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:24:58 --> Utf8 Class Initialized
INFO - 2021-03-24 21:24:58 --> URI Class Initialized
INFO - 2021-03-24 21:24:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:24:58 --> Router Class Initialized
INFO - 2021-03-24 21:24:58 --> Config Class Initialized
INFO - 2021-03-24 21:24:58 --> Hooks Class Initialized
INFO - 2021-03-24 21:24:58 --> Form Validation Class Initialized
INFO - 2021-03-24 21:24:58 --> Controller Class Initialized
INFO - 2021-03-24 21:24:58 --> Output Class Initialized
INFO - 2021-03-24 21:24:58 --> Model Class Initialized
DEBUG - 2021-03-24 21:24:58 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:24:58 --> Security Class Initialized
INFO - 2021-03-24 21:24:58 --> Utf8 Class Initialized
INFO - 2021-03-24 21:24:58 --> Model Class Initialized
INFO - 2021-03-24 21:24:58 --> Model Class Initialized
DEBUG - 2021-03-24 21:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:24:58 --> URI Class Initialized
INFO - 2021-03-24 21:24:58 --> Input Class Initialized
INFO - 2021-03-24 21:24:58 --> Language Class Initialized
INFO - 2021-03-24 21:24:58 --> Router Class Initialized
INFO - 2021-03-24 21:24:58 --> Loader Class Initialized
INFO - 2021-03-24 21:24:58 --> Output Class Initialized
INFO - 2021-03-24 21:24:58 --> Helper loaded: url_helper
INFO - 2021-03-24 21:24:58 --> Security Class Initialized
INFO - 2021-03-24 21:24:58 --> Helper loaded: form_helper
DEBUG - 2021-03-24 21:24:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:24:58 --> Input Class Initialized
INFO - 2021-03-24 21:24:58 --> Helper loaded: common_helper
INFO - 2021-03-24 21:24:58 --> Language Class Initialized
INFO - 2021-03-24 21:24:58 --> Helper loaded: util_helper
INFO - 2021-03-24 21:24:58 --> Loader Class Initialized
INFO - 2021-03-24 21:24:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:24:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:24:58 --> Helper loaded: url_helper
INFO - 2021-03-24 21:24:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:24:58 --> Database Driver Class Initialized
INFO - 2021-03-24 21:24:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:24:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:24:58 --> Final output sent to browser
INFO - 2021-03-24 21:24:58 --> Helper loaded: form_helper
DEBUG - 2021-03-24 21:24:58 --> Total execution time: 0.0727
INFO - 2021-03-24 21:24:58 --> Helper loaded: common_helper
INFO - 2021-03-24 21:24:58 --> Helper loaded: util_helper
DEBUG - 2021-03-24 21:24:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:24:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:24:58 --> Form Validation Class Initialized
INFO - 2021-03-24 21:24:58 --> Controller Class Initialized
INFO - 2021-03-24 21:24:58 --> Model Class Initialized
INFO - 2021-03-24 21:24:58 --> Model Class Initialized
INFO - 2021-03-24 21:24:58 --> Database Driver Class Initialized
INFO - 2021-03-24 21:24:58 --> Model Class Initialized
INFO - 2021-03-24 21:24:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:24:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
DEBUG - 2021-03-24 21:24:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:24:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:24:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:24:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:24:58 --> Final output sent to browser
DEBUG - 2021-03-24 21:24:58 --> Total execution time: 0.0495
INFO - 2021-03-24 21:24:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:24:58 --> Form Validation Class Initialized
INFO - 2021-03-24 21:24:58 --> Controller Class Initialized
INFO - 2021-03-24 21:24:58 --> Model Class Initialized
INFO - 2021-03-24 21:24:58 --> Model Class Initialized
INFO - 2021-03-24 21:24:58 --> Model Class Initialized
INFO - 2021-03-24 21:24:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:24:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:24:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:24:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:24:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:24:58 --> Final output sent to browser
DEBUG - 2021-03-24 21:24:58 --> Total execution time: 0.0590
INFO - 2021-03-24 21:25:04 --> Config Class Initialized
INFO - 2021-03-24 21:25:04 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:25:04 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:25:04 --> Utf8 Class Initialized
INFO - 2021-03-24 21:25:04 --> URI Class Initialized
INFO - 2021-03-24 21:25:04 --> Router Class Initialized
INFO - 2021-03-24 21:25:04 --> Output Class Initialized
INFO - 2021-03-24 21:25:04 --> Security Class Initialized
DEBUG - 2021-03-24 21:25:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:25:04 --> Input Class Initialized
INFO - 2021-03-24 21:25:04 --> Language Class Initialized
INFO - 2021-03-24 21:25:04 --> Loader Class Initialized
INFO - 2021-03-24 21:25:04 --> Helper loaded: url_helper
INFO - 2021-03-24 21:25:04 --> Helper loaded: form_helper
INFO - 2021-03-24 21:25:04 --> Helper loaded: common_helper
INFO - 2021-03-24 21:25:04 --> Helper loaded: util_helper
INFO - 2021-03-24 21:25:04 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:25:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:25:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:25:04 --> Form Validation Class Initialized
INFO - 2021-03-24 21:25:04 --> Controller Class Initialized
INFO - 2021-03-24 21:25:04 --> Model Class Initialized
INFO - 2021-03-24 21:25:04 --> Model Class Initialized
INFO - 2021-03-24 21:25:04 --> Model Class Initialized
INFO - 2021-03-24 21:25:04 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-03-24 21:25:04 --> Config Class Initialized
INFO - 2021-03-24 21:25:04 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:25:04 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:25:04 --> Utf8 Class Initialized
INFO - 2021-03-24 21:25:04 --> URI Class Initialized
INFO - 2021-03-24 21:25:04 --> Router Class Initialized
INFO - 2021-03-24 21:25:04 --> Output Class Initialized
INFO - 2021-03-24 21:25:04 --> Security Class Initialized
DEBUG - 2021-03-24 21:25:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:25:04 --> Input Class Initialized
INFO - 2021-03-24 21:25:04 --> Language Class Initialized
INFO - 2021-03-24 21:25:04 --> Loader Class Initialized
INFO - 2021-03-24 21:25:04 --> Helper loaded: url_helper
INFO - 2021-03-24 21:25:04 --> Helper loaded: form_helper
INFO - 2021-03-24 21:25:04 --> Helper loaded: common_helper
INFO - 2021-03-24 21:25:04 --> Helper loaded: util_helper
INFO - 2021-03-24 21:25:04 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:25:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:25:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:25:04 --> Form Validation Class Initialized
INFO - 2021-03-24 21:25:04 --> Controller Class Initialized
INFO - 2021-03-24 21:25:04 --> Model Class Initialized
INFO - 2021-03-24 21:25:04 --> Model Class Initialized
INFO - 2021-03-24 21:25:04 --> Model Class Initialized
INFO - 2021-03-24 21:25:04 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:25:04 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:25:04 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:25:04 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:25:04 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:25:04 --> Final output sent to browser
DEBUG - 2021-03-24 21:25:04 --> Total execution time: 0.0461
INFO - 2021-03-24 21:25:04 --> Config Class Initialized
INFO - 2021-03-24 21:25:04 --> Hooks Class Initialized
INFO - 2021-03-24 21:25:04 --> Config Class Initialized
INFO - 2021-03-24 21:25:04 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:25:04 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:25:04 --> Utf8 Class Initialized
DEBUG - 2021-03-24 21:25:04 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:25:04 --> Utf8 Class Initialized
INFO - 2021-03-24 21:25:04 --> URI Class Initialized
INFO - 2021-03-24 21:25:04 --> URI Class Initialized
INFO - 2021-03-24 21:25:04 --> Router Class Initialized
INFO - 2021-03-24 21:25:04 --> Router Class Initialized
INFO - 2021-03-24 21:25:04 --> Output Class Initialized
INFO - 2021-03-24 21:25:04 --> Output Class Initialized
INFO - 2021-03-24 21:25:04 --> Security Class Initialized
INFO - 2021-03-24 21:25:04 --> Security Class Initialized
DEBUG - 2021-03-24 21:25:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:25:04 --> Input Class Initialized
DEBUG - 2021-03-24 21:25:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:25:04 --> Input Class Initialized
INFO - 2021-03-24 21:25:04 --> Language Class Initialized
INFO - 2021-03-24 21:25:04 --> Language Class Initialized
INFO - 2021-03-24 21:25:04 --> Loader Class Initialized
INFO - 2021-03-24 21:25:04 --> Loader Class Initialized
INFO - 2021-03-24 21:25:04 --> Helper loaded: url_helper
INFO - 2021-03-24 21:25:04 --> Helper loaded: url_helper
INFO - 2021-03-24 21:25:04 --> Helper loaded: form_helper
INFO - 2021-03-24 21:25:04 --> Helper loaded: form_helper
INFO - 2021-03-24 21:25:04 --> Helper loaded: common_helper
INFO - 2021-03-24 21:25:04 --> Helper loaded: common_helper
INFO - 2021-03-24 21:25:04 --> Helper loaded: util_helper
INFO - 2021-03-24 21:25:04 --> Helper loaded: util_helper
INFO - 2021-03-24 21:25:04 --> Database Driver Class Initialized
INFO - 2021-03-24 21:25:04 --> Config Class Initialized
INFO - 2021-03-24 21:25:04 --> Config Class Initialized
INFO - 2021-03-24 21:25:04 --> Hooks Class Initialized
INFO - 2021-03-24 21:25:04 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:25:04 --> UTF-8 Support Enabled
DEBUG - 2021-03-24 21:25:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-03-24 21:25:04 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:25:04 --> Utf8 Class Initialized
INFO - 2021-03-24 21:25:04 --> Utf8 Class Initialized
INFO - 2021-03-24 21:25:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:25:04 --> URI Class Initialized
INFO - 2021-03-24 21:25:04 --> URI Class Initialized
INFO - 2021-03-24 21:25:04 --> Form Validation Class Initialized
INFO - 2021-03-24 21:25:04 --> Router Class Initialized
INFO - 2021-03-24 21:25:04 --> Controller Class Initialized
INFO - 2021-03-24 21:25:04 --> Router Class Initialized
INFO - 2021-03-24 21:25:04 --> Output Class Initialized
INFO - 2021-03-24 21:25:04 --> Output Class Initialized
INFO - 2021-03-24 21:25:04 --> Model Class Initialized
INFO - 2021-03-24 21:25:04 --> Security Class Initialized
INFO - 2021-03-24 21:25:04 --> Security Class Initialized
INFO - 2021-03-24 21:25:04 --> Model Class Initialized
INFO - 2021-03-24 21:25:04 --> Model Class Initialized
DEBUG - 2021-03-24 21:25:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-24 21:25:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:25:04 --> Input Class Initialized
INFO - 2021-03-24 21:25:04 --> Input Class Initialized
INFO - 2021-03-24 21:25:04 --> Language Class Initialized
INFO - 2021-03-24 21:25:04 --> Language Class Initialized
INFO - 2021-03-24 21:25:04 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:25:04 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:25:04 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:25:04 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:25:04 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:25:04 --> Loader Class Initialized
INFO - 2021-03-24 21:25:04 --> Loader Class Initialized
INFO - 2021-03-24 21:25:04 --> Final output sent to browser
DEBUG - 2021-03-24 21:25:04 --> Total execution time: 0.0479
INFO - 2021-03-24 21:25:04 --> Helper loaded: url_helper
INFO - 2021-03-24 21:25:04 --> Helper loaded: url_helper
INFO - 2021-03-24 21:25:04 --> Helper loaded: form_helper
INFO - 2021-03-24 21:25:04 --> Helper loaded: form_helper
INFO - 2021-03-24 21:25:04 --> Helper loaded: common_helper
INFO - 2021-03-24 21:25:04 --> Helper loaded: common_helper
INFO - 2021-03-24 21:25:04 --> Helper loaded: util_helper
INFO - 2021-03-24 21:25:04 --> Database Driver Class Initialized
INFO - 2021-03-24 21:25:04 --> Helper loaded: util_helper
DEBUG - 2021-03-24 21:25:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:25:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:25:04 --> Database Driver Class Initialized
INFO - 2021-03-24 21:25:04 --> Database Driver Class Initialized
INFO - 2021-03-24 21:25:04 --> Form Validation Class Initialized
INFO - 2021-03-24 21:25:04 --> Controller Class Initialized
INFO - 2021-03-24 21:25:04 --> Model Class Initialized
INFO - 2021-03-24 21:25:04 --> Model Class Initialized
INFO - 2021-03-24 21:25:04 --> Model Class Initialized
DEBUG - 2021-03-24 21:25:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:25:04 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:25:04 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:25:04 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:25:04 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:25:04 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:25:04 --> Final output sent to browser
DEBUG - 2021-03-24 21:25:04 --> Total execution time: 0.0718
INFO - 2021-03-24 21:25:04 --> Session: Class initialized using 'files' driver.
DEBUG - 2021-03-24 21:25:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:25:04 --> Form Validation Class Initialized
INFO - 2021-03-24 21:25:04 --> Controller Class Initialized
INFO - 2021-03-24 21:25:04 --> Model Class Initialized
INFO - 2021-03-24 21:25:04 --> Model Class Initialized
INFO - 2021-03-24 21:25:04 --> Model Class Initialized
INFO - 2021-03-24 21:25:04 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:25:04 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:25:04 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:25:04 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:25:04 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:25:04 --> Final output sent to browser
DEBUG - 2021-03-24 21:25:04 --> Total execution time: 0.0595
INFO - 2021-03-24 21:25:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:25:04 --> Form Validation Class Initialized
INFO - 2021-03-24 21:25:04 --> Controller Class Initialized
INFO - 2021-03-24 21:25:04 --> Model Class Initialized
INFO - 2021-03-24 21:25:04 --> Model Class Initialized
INFO - 2021-03-24 21:25:04 --> Model Class Initialized
INFO - 2021-03-24 21:25:04 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:25:04 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:25:04 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:25:04 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:25:04 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:25:04 --> Final output sent to browser
DEBUG - 2021-03-24 21:25:04 --> Total execution time: 0.0716
INFO - 2021-03-24 21:25:10 --> Config Class Initialized
INFO - 2021-03-24 21:25:10 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:25:10 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:25:10 --> Utf8 Class Initialized
INFO - 2021-03-24 21:25:10 --> URI Class Initialized
INFO - 2021-03-24 21:25:10 --> Router Class Initialized
INFO - 2021-03-24 21:25:10 --> Output Class Initialized
INFO - 2021-03-24 21:25:10 --> Security Class Initialized
DEBUG - 2021-03-24 21:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:25:10 --> Input Class Initialized
INFO - 2021-03-24 21:25:10 --> Language Class Initialized
INFO - 2021-03-24 21:25:10 --> Loader Class Initialized
INFO - 2021-03-24 21:25:10 --> Helper loaded: url_helper
INFO - 2021-03-24 21:25:10 --> Helper loaded: form_helper
INFO - 2021-03-24 21:25:10 --> Helper loaded: common_helper
INFO - 2021-03-24 21:25:10 --> Helper loaded: util_helper
INFO - 2021-03-24 21:25:10 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:25:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:25:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:25:10 --> Form Validation Class Initialized
INFO - 2021-03-24 21:25:10 --> Controller Class Initialized
INFO - 2021-03-24 21:25:10 --> Model Class Initialized
INFO - 2021-03-24 21:25:10 --> Model Class Initialized
INFO - 2021-03-24 21:25:10 --> Model Class Initialized
INFO - 2021-03-24 21:25:10 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:25:10 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:25:10 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:25:10 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:25:10 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:25:10 --> Final output sent to browser
DEBUG - 2021-03-24 21:25:10 --> Total execution time: 0.0387
INFO - 2021-03-24 21:25:10 --> Config Class Initialized
INFO - 2021-03-24 21:25:10 --> Hooks Class Initialized
INFO - 2021-03-24 21:25:10 --> Config Class Initialized
INFO - 2021-03-24 21:25:10 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:25:10 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:25:10 --> Utf8 Class Initialized
DEBUG - 2021-03-24 21:25:10 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:25:10 --> Utf8 Class Initialized
INFO - 2021-03-24 21:25:10 --> URI Class Initialized
INFO - 2021-03-24 21:25:10 --> URI Class Initialized
INFO - 2021-03-24 21:25:10 --> Router Class Initialized
INFO - 2021-03-24 21:25:10 --> Router Class Initialized
INFO - 2021-03-24 21:25:10 --> Output Class Initialized
INFO - 2021-03-24 21:25:10 --> Output Class Initialized
INFO - 2021-03-24 21:25:10 --> Security Class Initialized
INFO - 2021-03-24 21:25:10 --> Security Class Initialized
DEBUG - 2021-03-24 21:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:25:10 --> Input Class Initialized
DEBUG - 2021-03-24 21:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:25:10 --> Input Class Initialized
INFO - 2021-03-24 21:25:10 --> Language Class Initialized
INFO - 2021-03-24 21:25:10 --> Language Class Initialized
INFO - 2021-03-24 21:25:10 --> Loader Class Initialized
INFO - 2021-03-24 21:25:10 --> Loader Class Initialized
INFO - 2021-03-24 21:25:10 --> Helper loaded: url_helper
INFO - 2021-03-24 21:25:10 --> Helper loaded: form_helper
INFO - 2021-03-24 21:25:10 --> Helper loaded: url_helper
INFO - 2021-03-24 21:25:10 --> Helper loaded: common_helper
INFO - 2021-03-24 21:25:10 --> Config Class Initialized
INFO - 2021-03-24 21:25:10 --> Helper loaded: util_helper
INFO - 2021-03-24 21:25:10 --> Helper loaded: form_helper
INFO - 2021-03-24 21:25:10 --> Helper loaded: common_helper
INFO - 2021-03-24 21:25:10 --> Helper loaded: util_helper
INFO - 2021-03-24 21:25:10 --> Database Driver Class Initialized
INFO - 2021-03-24 21:25:10 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:25:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:25:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:25:10 --> Config Class Initialized
INFO - 2021-03-24 21:25:10 --> Hooks Class Initialized
INFO - 2021-03-24 21:25:10 --> Form Validation Class Initialized
INFO - 2021-03-24 21:25:10 --> Controller Class Initialized
INFO - 2021-03-24 21:25:10 --> Hooks Class Initialized
INFO - 2021-03-24 21:25:10 --> Model Class Initialized
DEBUG - 2021-03-24 21:25:10 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:25:10 --> Utf8 Class Initialized
INFO - 2021-03-24 21:25:10 --> Model Class Initialized
DEBUG - 2021-03-24 21:25:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:25:10 --> Model Class Initialized
INFO - 2021-03-24 21:25:10 --> URI Class Initialized
INFO - 2021-03-24 21:25:10 --> Router Class Initialized
INFO - 2021-03-24 21:25:10 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:25:10 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
DEBUG - 2021-03-24 21:25:10 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:25:10 --> Output Class Initialized
INFO - 2021-03-24 21:25:10 --> Utf8 Class Initialized
INFO - 2021-03-24 21:25:10 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:25:10 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:25:10 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:25:10 --> Security Class Initialized
INFO - 2021-03-24 21:25:10 --> Final output sent to browser
INFO - 2021-03-24 21:25:10 --> URI Class Initialized
DEBUG - 2021-03-24 21:25:10 --> Total execution time: 0.0466
DEBUG - 2021-03-24 21:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:25:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:25:10 --> Input Class Initialized
INFO - 2021-03-24 21:25:10 --> Language Class Initialized
INFO - 2021-03-24 21:25:10 --> Form Validation Class Initialized
INFO - 2021-03-24 21:25:10 --> Router Class Initialized
INFO - 2021-03-24 21:25:10 --> Controller Class Initialized
INFO - 2021-03-24 21:25:10 --> Model Class Initialized
INFO - 2021-03-24 21:25:10 --> Output Class Initialized
INFO - 2021-03-24 21:25:10 --> Loader Class Initialized
INFO - 2021-03-24 21:25:10 --> Model Class Initialized
INFO - 2021-03-24 21:25:10 --> Model Class Initialized
INFO - 2021-03-24 21:25:10 --> Helper loaded: url_helper
INFO - 2021-03-24 21:25:10 --> Security Class Initialized
INFO - 2021-03-24 21:25:10 --> Helper loaded: form_helper
DEBUG - 2021-03-24 21:25:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:25:10 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:25:10 --> Input Class Initialized
INFO - 2021-03-24 21:25:10 --> Helper loaded: common_helper
INFO - 2021-03-24 21:25:10 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:25:10 --> Language Class Initialized
INFO - 2021-03-24 21:25:10 --> Helper loaded: util_helper
INFO - 2021-03-24 21:25:10 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:25:10 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:25:10 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:25:10 --> Final output sent to browser
DEBUG - 2021-03-24 21:25:10 --> Total execution time: 0.0608
INFO - 2021-03-24 21:25:10 --> Loader Class Initialized
INFO - 2021-03-24 21:25:10 --> Helper loaded: url_helper
INFO - 2021-03-24 21:25:10 --> Database Driver Class Initialized
INFO - 2021-03-24 21:25:10 --> Helper loaded: form_helper
INFO - 2021-03-24 21:25:10 --> Helper loaded: common_helper
INFO - 2021-03-24 21:25:10 --> Helper loaded: util_helper
DEBUG - 2021-03-24 21:25:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:25:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:25:10 --> Form Validation Class Initialized
INFO - 2021-03-24 21:25:10 --> Controller Class Initialized
INFO - 2021-03-24 21:25:10 --> Model Class Initialized
INFO - 2021-03-24 21:25:10 --> Model Class Initialized
INFO - 2021-03-24 21:25:10 --> Database Driver Class Initialized
INFO - 2021-03-24 21:25:10 --> Model Class Initialized
INFO - 2021-03-24 21:25:10 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:25:10 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
DEBUG - 2021-03-24 21:25:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:25:10 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:25:10 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:25:10 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:25:10 --> Final output sent to browser
DEBUG - 2021-03-24 21:25:10 --> Total execution time: 0.0506
INFO - 2021-03-24 21:25:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:25:10 --> Form Validation Class Initialized
INFO - 2021-03-24 21:25:10 --> Controller Class Initialized
INFO - 2021-03-24 21:25:10 --> Model Class Initialized
INFO - 2021-03-24 21:25:10 --> Model Class Initialized
INFO - 2021-03-24 21:25:10 --> Model Class Initialized
INFO - 2021-03-24 21:25:10 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:25:10 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:25:10 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:25:10 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:25:10 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:25:10 --> Final output sent to browser
DEBUG - 2021-03-24 21:25:10 --> Total execution time: 0.0796
INFO - 2021-03-24 21:25:13 --> Config Class Initialized
INFO - 2021-03-24 21:25:13 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:25:13 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:25:13 --> Utf8 Class Initialized
INFO - 2021-03-24 21:25:13 --> URI Class Initialized
INFO - 2021-03-24 21:25:13 --> Router Class Initialized
INFO - 2021-03-24 21:25:13 --> Output Class Initialized
INFO - 2021-03-24 21:25:13 --> Security Class Initialized
DEBUG - 2021-03-24 21:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:25:13 --> Input Class Initialized
INFO - 2021-03-24 21:25:13 --> Language Class Initialized
INFO - 2021-03-24 21:25:13 --> Loader Class Initialized
INFO - 2021-03-24 21:25:13 --> Helper loaded: url_helper
INFO - 2021-03-24 21:25:13 --> Helper loaded: form_helper
INFO - 2021-03-24 21:25:13 --> Helper loaded: common_helper
INFO - 2021-03-24 21:25:13 --> Helper loaded: util_helper
INFO - 2021-03-24 21:25:13 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:25:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:25:13 --> Form Validation Class Initialized
INFO - 2021-03-24 21:25:13 --> Controller Class Initialized
INFO - 2021-03-24 21:25:13 --> Model Class Initialized
INFO - 2021-03-24 21:25:13 --> Model Class Initialized
INFO - 2021-03-24 21:25:13 --> Model Class Initialized
INFO - 2021-03-24 21:25:13 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:25:13 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:25:13 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:25:13 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:25:13 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:25:13 --> Final output sent to browser
DEBUG - 2021-03-24 21:25:13 --> Total execution time: 0.0354
INFO - 2021-03-24 21:25:13 --> Config Class Initialized
INFO - 2021-03-24 21:25:13 --> Hooks Class Initialized
INFO - 2021-03-24 21:25:13 --> Config Class Initialized
INFO - 2021-03-24 21:25:13 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:25:13 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:25:13 --> Utf8 Class Initialized
INFO - 2021-03-24 21:25:13 --> URI Class Initialized
DEBUG - 2021-03-24 21:25:13 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:25:13 --> Router Class Initialized
INFO - 2021-03-24 21:25:13 --> Utf8 Class Initialized
INFO - 2021-03-24 21:25:13 --> URI Class Initialized
INFO - 2021-03-24 21:25:13 --> Output Class Initialized
INFO - 2021-03-24 21:25:13 --> Security Class Initialized
INFO - 2021-03-24 21:25:13 --> Router Class Initialized
DEBUG - 2021-03-24 21:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:25:13 --> Input Class Initialized
INFO - 2021-03-24 21:25:13 --> Output Class Initialized
INFO - 2021-03-24 21:25:13 --> Language Class Initialized
INFO - 2021-03-24 21:25:13 --> Loader Class Initialized
INFO - 2021-03-24 21:25:13 --> Helper loaded: url_helper
INFO - 2021-03-24 21:25:13 --> Security Class Initialized
INFO - 2021-03-24 21:25:13 --> Config Class Initialized
INFO - 2021-03-24 21:25:13 --> Hooks Class Initialized
INFO - 2021-03-24 21:25:13 --> Helper loaded: form_helper
DEBUG - 2021-03-24 21:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:25:13 --> Helper loaded: common_helper
INFO - 2021-03-24 21:25:13 --> Helper loaded: util_helper
DEBUG - 2021-03-24 21:25:13 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:25:13 --> Utf8 Class Initialized
INFO - 2021-03-24 21:25:13 --> Input Class Initialized
INFO - 2021-03-24 21:25:13 --> URI Class Initialized
INFO - 2021-03-24 21:25:13 --> Language Class Initialized
INFO - 2021-03-24 21:25:13 --> Router Class Initialized
INFO - 2021-03-24 21:25:13 --> Output Class Initialized
INFO - 2021-03-24 21:25:13 --> Database Driver Class Initialized
INFO - 2021-03-24 21:25:13 --> Security Class Initialized
DEBUG - 2021-03-24 21:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:25:13 --> Input Class Initialized
INFO - 2021-03-24 21:25:13 --> Language Class Initialized
DEBUG - 2021-03-24 21:25:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:25:13 --> Loader Class Initialized
INFO - 2021-03-24 21:25:13 --> Loader Class Initialized
INFO - 2021-03-24 21:25:13 --> Form Validation Class Initialized
INFO - 2021-03-24 21:25:13 --> Controller Class Initialized
INFO - 2021-03-24 21:25:13 --> Helper loaded: url_helper
INFO - 2021-03-24 21:25:13 --> Helper loaded: url_helper
INFO - 2021-03-24 21:25:13 --> Model Class Initialized
INFO - 2021-03-24 21:25:13 --> Helper loaded: form_helper
INFO - 2021-03-24 21:25:13 --> Model Class Initialized
INFO - 2021-03-24 21:25:13 --> Helper loaded: form_helper
INFO - 2021-03-24 21:25:13 --> Model Class Initialized
INFO - 2021-03-24 21:25:13 --> Helper loaded: common_helper
INFO - 2021-03-24 21:25:13 --> Helper loaded: common_helper
INFO - 2021-03-24 21:25:13 --> Helper loaded: util_helper
INFO - 2021-03-24 21:25:13 --> Helper loaded: util_helper
INFO - 2021-03-24 21:25:13 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:25:13 --> Config Class Initialized
INFO - 2021-03-24 21:25:13 --> Hooks Class Initialized
INFO - 2021-03-24 21:25:13 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:25:13 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:25:13 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:25:13 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:25:13 --> Final output sent to browser
DEBUG - 2021-03-24 21:25:13 --> Total execution time: 0.0458
DEBUG - 2021-03-24 21:25:13 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:25:13 --> Utf8 Class Initialized
INFO - 2021-03-24 21:25:13 --> URI Class Initialized
INFO - 2021-03-24 21:25:13 --> Router Class Initialized
INFO - 2021-03-24 21:25:13 --> Database Driver Class Initialized
INFO - 2021-03-24 21:25:13 --> Database Driver Class Initialized
INFO - 2021-03-24 21:25:13 --> Output Class Initialized
INFO - 2021-03-24 21:25:13 --> Security Class Initialized
DEBUG - 2021-03-24 21:25:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:25:13 --> Input Class Initialized
INFO - 2021-03-24 21:25:13 --> Language Class Initialized
DEBUG - 2021-03-24 21:25:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:25:13 --> Loader Class Initialized
INFO - 2021-03-24 21:25:13 --> Form Validation Class Initialized
DEBUG - 2021-03-24 21:25:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:25:13 --> Controller Class Initialized
INFO - 2021-03-24 21:25:13 --> Model Class Initialized
INFO - 2021-03-24 21:25:13 --> Helper loaded: url_helper
INFO - 2021-03-24 21:25:13 --> Model Class Initialized
INFO - 2021-03-24 21:25:13 --> Model Class Initialized
INFO - 2021-03-24 21:25:13 --> Helper loaded: form_helper
INFO - 2021-03-24 21:25:13 --> Helper loaded: common_helper
INFO - 2021-03-24 21:25:13 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:25:13 --> Helper loaded: util_helper
INFO - 2021-03-24 21:25:13 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:25:13 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:25:13 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:25:13 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:25:13 --> Final output sent to browser
DEBUG - 2021-03-24 21:25:13 --> Total execution time: 0.0704
INFO - 2021-03-24 21:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:25:13 --> Form Validation Class Initialized
INFO - 2021-03-24 21:25:13 --> Controller Class Initialized
INFO - 2021-03-24 21:25:13 --> Model Class Initialized
INFO - 2021-03-24 21:25:13 --> Database Driver Class Initialized
INFO - 2021-03-24 21:25:13 --> Model Class Initialized
INFO - 2021-03-24 21:25:13 --> Model Class Initialized
INFO - 2021-03-24 21:25:13 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
DEBUG - 2021-03-24 21:25:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:25:13 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:25:13 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:25:13 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:25:13 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:25:13 --> Final output sent to browser
DEBUG - 2021-03-24 21:25:13 --> Total execution time: 0.0658
INFO - 2021-03-24 21:25:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:25:13 --> Form Validation Class Initialized
INFO - 2021-03-24 21:25:13 --> Controller Class Initialized
INFO - 2021-03-24 21:25:13 --> Model Class Initialized
INFO - 2021-03-24 21:25:13 --> Model Class Initialized
INFO - 2021-03-24 21:25:13 --> Model Class Initialized
INFO - 2021-03-24 21:25:13 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:25:13 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:25:13 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:25:13 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:25:13 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:25:13 --> Final output sent to browser
DEBUG - 2021-03-24 21:25:13 --> Total execution time: 0.0575
INFO - 2021-03-24 21:25:18 --> Config Class Initialized
INFO - 2021-03-24 21:25:18 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:25:18 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:25:18 --> Utf8 Class Initialized
INFO - 2021-03-24 21:25:18 --> URI Class Initialized
INFO - 2021-03-24 21:25:18 --> Router Class Initialized
INFO - 2021-03-24 21:25:18 --> Output Class Initialized
INFO - 2021-03-24 21:25:18 --> Security Class Initialized
DEBUG - 2021-03-24 21:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:25:18 --> Input Class Initialized
INFO - 2021-03-24 21:25:18 --> Language Class Initialized
INFO - 2021-03-24 21:25:18 --> Loader Class Initialized
INFO - 2021-03-24 21:25:18 --> Helper loaded: url_helper
INFO - 2021-03-24 21:25:18 --> Helper loaded: form_helper
INFO - 2021-03-24 21:25:18 --> Helper loaded: common_helper
INFO - 2021-03-24 21:25:18 --> Helper loaded: util_helper
INFO - 2021-03-24 21:25:18 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:25:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:25:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:25:18 --> Form Validation Class Initialized
INFO - 2021-03-24 21:25:18 --> Controller Class Initialized
INFO - 2021-03-24 21:25:18 --> Model Class Initialized
INFO - 2021-03-24 21:25:18 --> Model Class Initialized
INFO - 2021-03-24 21:25:18 --> Model Class Initialized
INFO - 2021-03-24 21:25:18 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-03-24 21:25:18 --> Config Class Initialized
INFO - 2021-03-24 21:25:18 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:25:18 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:25:18 --> Utf8 Class Initialized
INFO - 2021-03-24 21:25:18 --> URI Class Initialized
INFO - 2021-03-24 21:25:18 --> Router Class Initialized
INFO - 2021-03-24 21:25:18 --> Output Class Initialized
INFO - 2021-03-24 21:25:18 --> Security Class Initialized
DEBUG - 2021-03-24 21:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:25:18 --> Input Class Initialized
INFO - 2021-03-24 21:25:18 --> Language Class Initialized
INFO - 2021-03-24 21:25:18 --> Loader Class Initialized
INFO - 2021-03-24 21:25:18 --> Helper loaded: url_helper
INFO - 2021-03-24 21:25:18 --> Helper loaded: form_helper
INFO - 2021-03-24 21:25:18 --> Helper loaded: common_helper
INFO - 2021-03-24 21:25:18 --> Helper loaded: util_helper
INFO - 2021-03-24 21:25:18 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:25:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:25:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:25:18 --> Form Validation Class Initialized
INFO - 2021-03-24 21:25:18 --> Controller Class Initialized
INFO - 2021-03-24 21:25:18 --> Model Class Initialized
INFO - 2021-03-24 21:25:18 --> Model Class Initialized
INFO - 2021-03-24 21:25:18 --> Model Class Initialized
INFO - 2021-03-24 21:25:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:25:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:25:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:25:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:25:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:25:18 --> Final output sent to browser
DEBUG - 2021-03-24 21:25:18 --> Total execution time: 0.0359
INFO - 2021-03-24 21:25:18 --> Config Class Initialized
INFO - 2021-03-24 21:25:18 --> Hooks Class Initialized
INFO - 2021-03-24 21:25:18 --> Config Class Initialized
INFO - 2021-03-24 21:25:18 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:25:18 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:25:18 --> Utf8 Class Initialized
INFO - 2021-03-24 21:25:18 --> URI Class Initialized
DEBUG - 2021-03-24 21:25:18 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:25:18 --> Utf8 Class Initialized
INFO - 2021-03-24 21:25:18 --> URI Class Initialized
INFO - 2021-03-24 21:25:18 --> Router Class Initialized
INFO - 2021-03-24 21:25:18 --> Output Class Initialized
INFO - 2021-03-24 21:25:18 --> Router Class Initialized
INFO - 2021-03-24 21:25:18 --> Security Class Initialized
INFO - 2021-03-24 21:25:18 --> Output Class Initialized
DEBUG - 2021-03-24 21:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:25:18 --> Input Class Initialized
INFO - 2021-03-24 21:25:18 --> Security Class Initialized
INFO - 2021-03-24 21:25:18 --> Language Class Initialized
DEBUG - 2021-03-24 21:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:25:18 --> Input Class Initialized
INFO - 2021-03-24 21:25:18 --> Language Class Initialized
INFO - 2021-03-24 21:25:18 --> Loader Class Initialized
INFO - 2021-03-24 21:25:18 --> Loader Class Initialized
INFO - 2021-03-24 21:25:18 --> Helper loaded: url_helper
INFO - 2021-03-24 21:25:18 --> Helper loaded: url_helper
INFO - 2021-03-24 21:25:18 --> Helper loaded: form_helper
INFO - 2021-03-24 21:25:18 --> Helper loaded: form_helper
INFO - 2021-03-24 21:25:18 --> Helper loaded: common_helper
INFO - 2021-03-24 21:25:18 --> Helper loaded: common_helper
INFO - 2021-03-24 21:25:18 --> Helper loaded: util_helper
INFO - 2021-03-24 21:25:18 --> Helper loaded: util_helper
INFO - 2021-03-24 21:25:18 --> Config Class Initialized
INFO - 2021-03-24 21:25:18 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:25:18 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:25:18 --> Utf8 Class Initialized
INFO - 2021-03-24 21:25:18 --> URI Class Initialized
INFO - 2021-03-24 21:25:18 --> Database Driver Class Initialized
INFO - 2021-03-24 21:25:18 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:25:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:25:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:25:18 --> Form Validation Class Initialized
INFO - 2021-03-24 21:25:18 --> Controller Class Initialized
DEBUG - 2021-03-24 21:25:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:25:18 --> Model Class Initialized
INFO - 2021-03-24 21:25:18 --> Model Class Initialized
INFO - 2021-03-24 21:25:18 --> Model Class Initialized
INFO - 2021-03-24 21:25:18 --> Config Class Initialized
INFO - 2021-03-24 21:25:18 --> Hooks Class Initialized
INFO - 2021-03-24 21:25:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
DEBUG - 2021-03-24 21:25:18 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:25:18 --> Utf8 Class Initialized
INFO - 2021-03-24 21:25:18 --> URI Class Initialized
INFO - 2021-03-24 21:25:18 --> Router Class Initialized
INFO - 2021-03-24 21:25:18 --> Router Class Initialized
INFO - 2021-03-24 21:25:18 --> Output Class Initialized
INFO - 2021-03-24 21:25:18 --> Output Class Initialized
INFO - 2021-03-24 21:25:18 --> Security Class Initialized
INFO - 2021-03-24 21:25:18 --> Security Class Initialized
DEBUG - 2021-03-24 21:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:25:18 --> Input Class Initialized
INFO - 2021-03-24 21:25:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:25:18 --> Language Class Initialized
DEBUG - 2021-03-24 21:25:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:25:18 --> Input Class Initialized
INFO - 2021-03-24 21:25:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:25:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:25:18 --> Language Class Initialized
INFO - 2021-03-24 21:25:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:25:18 --> Final output sent to browser
DEBUG - 2021-03-24 21:25:18 --> Total execution time: 0.0547
INFO - 2021-03-24 21:25:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:25:18 --> Loader Class Initialized
INFO - 2021-03-24 21:25:18 --> Loader Class Initialized
INFO - 2021-03-24 21:25:18 --> Form Validation Class Initialized
INFO - 2021-03-24 21:25:18 --> Controller Class Initialized
INFO - 2021-03-24 21:25:18 --> Helper loaded: url_helper
INFO - 2021-03-24 21:25:18 --> Helper loaded: url_helper
INFO - 2021-03-24 21:25:18 --> Model Class Initialized
INFO - 2021-03-24 21:25:18 --> Model Class Initialized
INFO - 2021-03-24 21:25:18 --> Helper loaded: form_helper
INFO - 2021-03-24 21:25:18 --> Model Class Initialized
INFO - 2021-03-24 21:25:18 --> Helper loaded: common_helper
INFO - 2021-03-24 21:25:18 --> Helper loaded: form_helper
INFO - 2021-03-24 21:25:18 --> Helper loaded: util_helper
INFO - 2021-03-24 21:25:18 --> Helper loaded: common_helper
INFO - 2021-03-24 21:25:18 --> Helper loaded: util_helper
INFO - 2021-03-24 21:25:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:25:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:25:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:25:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:25:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:25:18 --> Final output sent to browser
DEBUG - 2021-03-24 21:25:18 --> Total execution time: 0.0704
INFO - 2021-03-24 21:25:18 --> Database Driver Class Initialized
INFO - 2021-03-24 21:25:18 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:25:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:25:18 --> Session: Class initialized using 'files' driver.
DEBUG - 2021-03-24 21:25:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:25:18 --> Form Validation Class Initialized
INFO - 2021-03-24 21:25:18 --> Controller Class Initialized
INFO - 2021-03-24 21:25:18 --> Model Class Initialized
INFO - 2021-03-24 21:25:18 --> Model Class Initialized
INFO - 2021-03-24 21:25:18 --> Model Class Initialized
INFO - 2021-03-24 21:25:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:25:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:25:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:25:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:25:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:25:18 --> Final output sent to browser
DEBUG - 2021-03-24 21:25:18 --> Total execution time: 0.0492
INFO - 2021-03-24 21:25:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:25:18 --> Form Validation Class Initialized
INFO - 2021-03-24 21:25:18 --> Controller Class Initialized
INFO - 2021-03-24 21:25:18 --> Model Class Initialized
INFO - 2021-03-24 21:25:18 --> Model Class Initialized
INFO - 2021-03-24 21:25:18 --> Model Class Initialized
INFO - 2021-03-24 21:25:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:25:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:25:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:25:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:25:18 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:25:18 --> Final output sent to browser
DEBUG - 2021-03-24 21:25:18 --> Total execution time: 0.0766
INFO - 2021-03-24 21:25:20 --> Config Class Initialized
INFO - 2021-03-24 21:25:20 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:25:20 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:25:20 --> Utf8 Class Initialized
INFO - 2021-03-24 21:25:20 --> URI Class Initialized
INFO - 2021-03-24 21:25:20 --> Router Class Initialized
INFO - 2021-03-24 21:25:20 --> Output Class Initialized
INFO - 2021-03-24 21:25:20 --> Security Class Initialized
DEBUG - 2021-03-24 21:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:25:20 --> Input Class Initialized
INFO - 2021-03-24 21:25:20 --> Language Class Initialized
INFO - 2021-03-24 21:25:20 --> Loader Class Initialized
INFO - 2021-03-24 21:25:20 --> Helper loaded: url_helper
INFO - 2021-03-24 21:25:20 --> Helper loaded: form_helper
INFO - 2021-03-24 21:25:20 --> Helper loaded: common_helper
INFO - 2021-03-24 21:25:20 --> Helper loaded: util_helper
INFO - 2021-03-24 21:25:20 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:25:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:25:20 --> Form Validation Class Initialized
INFO - 2021-03-24 21:25:20 --> Controller Class Initialized
INFO - 2021-03-24 21:25:20 --> Model Class Initialized
INFO - 2021-03-24 21:25:20 --> Model Class Initialized
INFO - 2021-03-24 21:25:20 --> Model Class Initialized
INFO - 2021-03-24 21:25:20 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:25:20 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:25:20 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:25:20 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:25:20 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:25:20 --> Final output sent to browser
DEBUG - 2021-03-24 21:25:20 --> Total execution time: 0.0360
INFO - 2021-03-24 21:25:20 --> Config Class Initialized
INFO - 2021-03-24 21:25:20 --> Hooks Class Initialized
INFO - 2021-03-24 21:25:20 --> Config Class Initialized
DEBUG - 2021-03-24 21:25:20 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:25:20 --> Utf8 Class Initialized
INFO - 2021-03-24 21:25:20 --> Hooks Class Initialized
INFO - 2021-03-24 21:25:20 --> URI Class Initialized
INFO - 2021-03-24 21:25:20 --> Router Class Initialized
DEBUG - 2021-03-24 21:25:20 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:25:20 --> Utf8 Class Initialized
INFO - 2021-03-24 21:25:20 --> Output Class Initialized
INFO - 2021-03-24 21:25:20 --> Security Class Initialized
INFO - 2021-03-24 21:25:20 --> URI Class Initialized
DEBUG - 2021-03-24 21:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:25:20 --> Input Class Initialized
INFO - 2021-03-24 21:25:20 --> Router Class Initialized
INFO - 2021-03-24 21:25:20 --> Language Class Initialized
INFO - 2021-03-24 21:25:20 --> Config Class Initialized
INFO - 2021-03-24 21:25:20 --> Hooks Class Initialized
INFO - 2021-03-24 21:25:20 --> Output Class Initialized
INFO - 2021-03-24 21:25:20 --> Loader Class Initialized
INFO - 2021-03-24 21:25:20 --> Helper loaded: url_helper
INFO - 2021-03-24 21:25:20 --> Security Class Initialized
DEBUG - 2021-03-24 21:25:20 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:25:20 --> Utf8 Class Initialized
INFO - 2021-03-24 21:25:20 --> Helper loaded: form_helper
INFO - 2021-03-24 21:25:20 --> URI Class Initialized
DEBUG - 2021-03-24 21:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:25:20 --> Helper loaded: common_helper
INFO - 2021-03-24 21:25:20 --> Input Class Initialized
INFO - 2021-03-24 21:25:20 --> Helper loaded: util_helper
INFO - 2021-03-24 21:25:20 --> Router Class Initialized
INFO - 2021-03-24 21:25:20 --> Language Class Initialized
INFO - 2021-03-24 21:25:20 --> Output Class Initialized
INFO - 2021-03-24 21:25:20 --> Security Class Initialized
INFO - 2021-03-24 21:25:20 --> Loader Class Initialized
DEBUG - 2021-03-24 21:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:25:20 --> Input Class Initialized
INFO - 2021-03-24 21:25:20 --> Language Class Initialized
INFO - 2021-03-24 21:25:20 --> Helper loaded: url_helper
INFO - 2021-03-24 21:25:20 --> Loader Class Initialized
INFO - 2021-03-24 21:25:20 --> Helper loaded: form_helper
INFO - 2021-03-24 21:25:20 --> Helper loaded: url_helper
INFO - 2021-03-24 21:25:20 --> Helper loaded: common_helper
INFO - 2021-03-24 21:25:20 --> Helper loaded: util_helper
INFO - 2021-03-24 21:25:20 --> Helper loaded: form_helper
INFO - 2021-03-24 21:25:20 --> Config Class Initialized
INFO - 2021-03-24 21:25:20 --> Hooks Class Initialized
INFO - 2021-03-24 21:25:20 --> Helper loaded: common_helper
INFO - 2021-03-24 21:25:20 --> Helper loaded: util_helper
DEBUG - 2021-03-24 21:25:20 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:25:20 --> Utf8 Class Initialized
INFO - 2021-03-24 21:25:20 --> URI Class Initialized
INFO - 2021-03-24 21:25:20 --> Database Driver Class Initialized
INFO - 2021-03-24 21:25:20 --> Router Class Initialized
INFO - 2021-03-24 21:25:20 --> Output Class Initialized
INFO - 2021-03-24 21:25:20 --> Database Driver Class Initialized
INFO - 2021-03-24 21:25:20 --> Database Driver Class Initialized
INFO - 2021-03-24 21:25:20 --> Security Class Initialized
DEBUG - 2021-03-24 21:25:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:25:20 --> Session: Class initialized using 'files' driver.
DEBUG - 2021-03-24 21:25:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:25:20 --> Input Class Initialized
DEBUG - 2021-03-24 21:25:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:25:20 --> Form Validation Class Initialized
INFO - 2021-03-24 21:25:20 --> Language Class Initialized
INFO - 2021-03-24 21:25:20 --> Controller Class Initialized
DEBUG - 2021-03-24 21:25:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:25:20 --> Model Class Initialized
INFO - 2021-03-24 21:25:20 --> Model Class Initialized
INFO - 2021-03-24 21:25:20 --> Model Class Initialized
INFO - 2021-03-24 21:25:20 --> Loader Class Initialized
INFO - 2021-03-24 21:25:20 --> Helper loaded: url_helper
INFO - 2021-03-24 21:25:20 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:25:20 --> Helper loaded: form_helper
INFO - 2021-03-24 21:25:20 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:25:20 --> Helper loaded: common_helper
INFO - 2021-03-24 21:25:20 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:25:20 --> Helper loaded: util_helper
INFO - 2021-03-24 21:25:20 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:25:20 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:25:20 --> Final output sent to browser
DEBUG - 2021-03-24 21:25:20 --> Total execution time: 0.0602
INFO - 2021-03-24 21:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:25:20 --> Form Validation Class Initialized
INFO - 2021-03-24 21:25:20 --> Controller Class Initialized
INFO - 2021-03-24 21:25:20 --> Database Driver Class Initialized
INFO - 2021-03-24 21:25:20 --> Model Class Initialized
INFO - 2021-03-24 21:25:20 --> Model Class Initialized
INFO - 2021-03-24 21:25:20 --> Model Class Initialized
DEBUG - 2021-03-24 21:25:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:25:20 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:25:20 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:25:20 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:25:20 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:25:20 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:25:20 --> Final output sent to browser
DEBUG - 2021-03-24 21:25:20 --> Total execution time: 0.0750
INFO - 2021-03-24 21:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:25:20 --> Form Validation Class Initialized
INFO - 2021-03-24 21:25:20 --> Controller Class Initialized
INFO - 2021-03-24 21:25:20 --> Model Class Initialized
INFO - 2021-03-24 21:25:20 --> Model Class Initialized
INFO - 2021-03-24 21:25:20 --> Model Class Initialized
INFO - 2021-03-24 21:25:20 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:25:20 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:25:20 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:25:20 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:25:20 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:25:20 --> Final output sent to browser
DEBUG - 2021-03-24 21:25:20 --> Total execution time: 0.0735
INFO - 2021-03-24 21:25:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:25:20 --> Form Validation Class Initialized
INFO - 2021-03-24 21:25:20 --> Controller Class Initialized
INFO - 2021-03-24 21:25:20 --> Model Class Initialized
INFO - 2021-03-24 21:25:20 --> Model Class Initialized
INFO - 2021-03-24 21:25:20 --> Model Class Initialized
INFO - 2021-03-24 21:25:20 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:25:20 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:25:20 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:25:20 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:25:20 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:25:20 --> Final output sent to browser
DEBUG - 2021-03-24 21:25:20 --> Total execution time: 0.0696
INFO - 2021-03-24 21:25:28 --> Config Class Initialized
INFO - 2021-03-24 21:25:28 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:25:28 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:25:28 --> Utf8 Class Initialized
INFO - 2021-03-24 21:25:28 --> URI Class Initialized
INFO - 2021-03-24 21:25:28 --> Router Class Initialized
INFO - 2021-03-24 21:25:28 --> Output Class Initialized
INFO - 2021-03-24 21:25:28 --> Security Class Initialized
DEBUG - 2021-03-24 21:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:25:28 --> Input Class Initialized
INFO - 2021-03-24 21:25:28 --> Language Class Initialized
INFO - 2021-03-24 21:25:28 --> Loader Class Initialized
INFO - 2021-03-24 21:25:28 --> Helper loaded: url_helper
INFO - 2021-03-24 21:25:28 --> Helper loaded: form_helper
INFO - 2021-03-24 21:25:28 --> Helper loaded: common_helper
INFO - 2021-03-24 21:25:28 --> Helper loaded: util_helper
INFO - 2021-03-24 21:25:28 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:25:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:25:28 --> Form Validation Class Initialized
INFO - 2021-03-24 21:25:28 --> Controller Class Initialized
INFO - 2021-03-24 21:25:28 --> Model Class Initialized
INFO - 2021-03-24 21:25:28 --> Model Class Initialized
INFO - 2021-03-24 21:25:28 --> Model Class Initialized
INFO - 2021-03-24 21:25:28 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:25:28 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:25:28 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:25:28 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:25:28 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:25:28 --> Final output sent to browser
DEBUG - 2021-03-24 21:25:28 --> Total execution time: 0.0379
INFO - 2021-03-24 21:25:28 --> Config Class Initialized
INFO - 2021-03-24 21:25:28 --> Hooks Class Initialized
INFO - 2021-03-24 21:25:28 --> Config Class Initialized
INFO - 2021-03-24 21:25:28 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:25:28 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:25:28 --> Utf8 Class Initialized
DEBUG - 2021-03-24 21:25:28 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:25:28 --> Utf8 Class Initialized
INFO - 2021-03-24 21:25:28 --> URI Class Initialized
INFO - 2021-03-24 21:25:28 --> URI Class Initialized
INFO - 2021-03-24 21:25:28 --> Router Class Initialized
INFO - 2021-03-24 21:25:28 --> Router Class Initialized
INFO - 2021-03-24 21:25:28 --> Output Class Initialized
INFO - 2021-03-24 21:25:28 --> Output Class Initialized
INFO - 2021-03-24 21:25:28 --> Security Class Initialized
DEBUG - 2021-03-24 21:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:25:28 --> Input Class Initialized
INFO - 2021-03-24 21:25:28 --> Language Class Initialized
INFO - 2021-03-24 21:25:28 --> Security Class Initialized
DEBUG - 2021-03-24 21:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:25:28 --> Input Class Initialized
INFO - 2021-03-24 21:25:28 --> Language Class Initialized
INFO - 2021-03-24 21:25:28 --> Loader Class Initialized
INFO - 2021-03-24 21:25:28 --> Helper loaded: url_helper
INFO - 2021-03-24 21:25:28 --> Helper loaded: form_helper
INFO - 2021-03-24 21:25:28 --> Helper loaded: common_helper
INFO - 2021-03-24 21:25:28 --> Loader Class Initialized
INFO - 2021-03-24 21:25:28 --> Helper loaded: util_helper
INFO - 2021-03-24 21:25:28 --> Helper loaded: url_helper
INFO - 2021-03-24 21:25:28 --> Helper loaded: form_helper
INFO - 2021-03-24 21:25:28 --> Helper loaded: common_helper
INFO - 2021-03-24 21:25:28 --> Helper loaded: util_helper
INFO - 2021-03-24 21:25:28 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:25:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:25:28 --> Form Validation Class Initialized
INFO - 2021-03-24 21:25:28 --> Config Class Initialized
INFO - 2021-03-24 21:25:28 --> Database Driver Class Initialized
INFO - 2021-03-24 21:25:28 --> Controller Class Initialized
INFO - 2021-03-24 21:25:28 --> Hooks Class Initialized
INFO - 2021-03-24 21:25:28 --> Model Class Initialized
INFO - 2021-03-24 21:25:28 --> Model Class Initialized
DEBUG - 2021-03-24 21:25:28 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:25:28 --> Model Class Initialized
INFO - 2021-03-24 21:25:28 --> Utf8 Class Initialized
INFO - 2021-03-24 21:25:28 --> URI Class Initialized
INFO - 2021-03-24 21:25:28 --> Config Class Initialized
INFO - 2021-03-24 21:25:28 --> Hooks Class Initialized
INFO - 2021-03-24 21:25:28 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:25:28 --> Router Class Initialized
INFO - 2021-03-24 21:25:28 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:25:28 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:25:28 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:25:28 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:25:28 --> Final output sent to browser
DEBUG - 2021-03-24 21:25:28 --> Total execution time: 0.0498
INFO - 2021-03-24 21:25:28 --> Output Class Initialized
DEBUG - 2021-03-24 21:25:28 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:25:28 --> Utf8 Class Initialized
INFO - 2021-03-24 21:25:28 --> Security Class Initialized
INFO - 2021-03-24 21:25:28 --> URI Class Initialized
DEBUG - 2021-03-24 21:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:25:28 --> Input Class Initialized
INFO - 2021-03-24 21:25:28 --> Router Class Initialized
INFO - 2021-03-24 21:25:28 --> Language Class Initialized
INFO - 2021-03-24 21:25:28 --> Output Class Initialized
INFO - 2021-03-24 21:25:28 --> Security Class Initialized
INFO - 2021-03-24 21:25:28 --> Loader Class Initialized
DEBUG - 2021-03-24 21:25:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-03-24 21:25:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:25:28 --> Input Class Initialized
INFO - 2021-03-24 21:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:25:28 --> Helper loaded: url_helper
INFO - 2021-03-24 21:25:28 --> Language Class Initialized
INFO - 2021-03-24 21:25:28 --> Form Validation Class Initialized
INFO - 2021-03-24 21:25:28 --> Helper loaded: form_helper
INFO - 2021-03-24 21:25:28 --> Controller Class Initialized
INFO - 2021-03-24 21:25:28 --> Helper loaded: common_helper
INFO - 2021-03-24 21:25:28 --> Model Class Initialized
INFO - 2021-03-24 21:25:28 --> Loader Class Initialized
INFO - 2021-03-24 21:25:28 --> Helper loaded: util_helper
INFO - 2021-03-24 21:25:28 --> Model Class Initialized
INFO - 2021-03-24 21:25:28 --> Model Class Initialized
INFO - 2021-03-24 21:25:28 --> Helper loaded: url_helper
INFO - 2021-03-24 21:25:28 --> Helper loaded: form_helper
INFO - 2021-03-24 21:25:28 --> Helper loaded: common_helper
INFO - 2021-03-24 21:25:28 --> Helper loaded: util_helper
INFO - 2021-03-24 21:25:28 --> Database Driver Class Initialized
INFO - 2021-03-24 21:25:28 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:25:28 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:25:28 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:25:28 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:25:28 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:25:28 --> Final output sent to browser
DEBUG - 2021-03-24 21:25:28 --> Total execution time: 0.0765
DEBUG - 2021-03-24 21:25:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:25:28 --> Database Driver Class Initialized
INFO - 2021-03-24 21:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:25:28 --> Form Validation Class Initialized
INFO - 2021-03-24 21:25:28 --> Controller Class Initialized
INFO - 2021-03-24 21:25:28 --> Model Class Initialized
DEBUG - 2021-03-24 21:25:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:25:28 --> Model Class Initialized
INFO - 2021-03-24 21:25:28 --> Model Class Initialized
INFO - 2021-03-24 21:25:28 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:25:28 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:25:28 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:25:28 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:25:28 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:25:28 --> Final output sent to browser
DEBUG - 2021-03-24 21:25:28 --> Total execution time: 0.0565
INFO - 2021-03-24 21:25:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:25:28 --> Form Validation Class Initialized
INFO - 2021-03-24 21:25:28 --> Controller Class Initialized
INFO - 2021-03-24 21:25:28 --> Model Class Initialized
INFO - 2021-03-24 21:25:28 --> Model Class Initialized
INFO - 2021-03-24 21:25:28 --> Model Class Initialized
INFO - 2021-03-24 21:25:28 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:25:28 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:25:28 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:25:28 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:25:28 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:25:28 --> Final output sent to browser
DEBUG - 2021-03-24 21:25:28 --> Total execution time: 0.0683
INFO - 2021-03-24 21:25:34 --> Config Class Initialized
INFO - 2021-03-24 21:25:34 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:25:34 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:25:34 --> Utf8 Class Initialized
INFO - 2021-03-24 21:25:34 --> URI Class Initialized
INFO - 2021-03-24 21:25:34 --> Router Class Initialized
INFO - 2021-03-24 21:25:34 --> Output Class Initialized
INFO - 2021-03-24 21:25:34 --> Security Class Initialized
DEBUG - 2021-03-24 21:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:25:34 --> Input Class Initialized
INFO - 2021-03-24 21:25:34 --> Language Class Initialized
INFO - 2021-03-24 21:25:34 --> Loader Class Initialized
INFO - 2021-03-24 21:25:34 --> Helper loaded: url_helper
INFO - 2021-03-24 21:25:34 --> Helper loaded: form_helper
INFO - 2021-03-24 21:25:34 --> Helper loaded: common_helper
INFO - 2021-03-24 21:25:34 --> Helper loaded: util_helper
INFO - 2021-03-24 21:25:34 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:25:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:25:34 --> Form Validation Class Initialized
INFO - 2021-03-24 21:25:34 --> Controller Class Initialized
INFO - 2021-03-24 21:25:34 --> Model Class Initialized
INFO - 2021-03-24 21:25:34 --> Model Class Initialized
INFO - 2021-03-24 21:25:34 --> Model Class Initialized
INFO - 2021-03-24 21:25:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-03-24 21:25:34 --> Config Class Initialized
INFO - 2021-03-24 21:25:34 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:25:34 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:25:34 --> Utf8 Class Initialized
INFO - 2021-03-24 21:25:34 --> URI Class Initialized
INFO - 2021-03-24 21:25:34 --> Router Class Initialized
INFO - 2021-03-24 21:25:34 --> Output Class Initialized
INFO - 2021-03-24 21:25:34 --> Security Class Initialized
DEBUG - 2021-03-24 21:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:25:34 --> Input Class Initialized
INFO - 2021-03-24 21:25:34 --> Language Class Initialized
INFO - 2021-03-24 21:25:34 --> Loader Class Initialized
INFO - 2021-03-24 21:25:34 --> Helper loaded: url_helper
INFO - 2021-03-24 21:25:34 --> Helper loaded: form_helper
INFO - 2021-03-24 21:25:34 --> Helper loaded: common_helper
INFO - 2021-03-24 21:25:34 --> Helper loaded: util_helper
INFO - 2021-03-24 21:25:34 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:25:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:25:34 --> Form Validation Class Initialized
INFO - 2021-03-24 21:25:34 --> Controller Class Initialized
INFO - 2021-03-24 21:25:34 --> Model Class Initialized
INFO - 2021-03-24 21:25:34 --> Model Class Initialized
INFO - 2021-03-24 21:25:34 --> Model Class Initialized
INFO - 2021-03-24 21:25:34 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:25:34 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:25:34 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:25:34 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:25:34 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:25:34 --> Final output sent to browser
DEBUG - 2021-03-24 21:25:34 --> Total execution time: 0.0367
INFO - 2021-03-24 21:25:34 --> Config Class Initialized
INFO - 2021-03-24 21:25:34 --> Hooks Class Initialized
INFO - 2021-03-24 21:25:34 --> Config Class Initialized
INFO - 2021-03-24 21:25:34 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:25:34 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:25:34 --> Utf8 Class Initialized
DEBUG - 2021-03-24 21:25:34 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:25:34 --> Utf8 Class Initialized
INFO - 2021-03-24 21:25:34 --> URI Class Initialized
INFO - 2021-03-24 21:25:34 --> URI Class Initialized
INFO - 2021-03-24 21:25:34 --> Router Class Initialized
INFO - 2021-03-24 21:25:34 --> Router Class Initialized
INFO - 2021-03-24 21:25:34 --> Output Class Initialized
INFO - 2021-03-24 21:25:34 --> Output Class Initialized
INFO - 2021-03-24 21:25:34 --> Security Class Initialized
INFO - 2021-03-24 21:25:34 --> Security Class Initialized
DEBUG - 2021-03-24 21:25:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-24 21:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:25:34 --> Input Class Initialized
INFO - 2021-03-24 21:25:34 --> Input Class Initialized
INFO - 2021-03-24 21:25:34 --> Language Class Initialized
INFO - 2021-03-24 21:25:34 --> Language Class Initialized
INFO - 2021-03-24 21:25:34 --> Loader Class Initialized
INFO - 2021-03-24 21:25:34 --> Loader Class Initialized
INFO - 2021-03-24 21:25:34 --> Helper loaded: url_helper
INFO - 2021-03-24 21:25:34 --> Helper loaded: form_helper
INFO - 2021-03-24 21:25:34 --> Helper loaded: url_helper
INFO - 2021-03-24 21:25:34 --> Helper loaded: common_helper
INFO - 2021-03-24 21:25:34 --> Helper loaded: form_helper
INFO - 2021-03-24 21:25:34 --> Helper loaded: util_helper
INFO - 2021-03-24 21:25:34 --> Helper loaded: common_helper
INFO - 2021-03-24 21:25:34 --> Helper loaded: util_helper
INFO - 2021-03-24 21:25:34 --> Config Class Initialized
INFO - 2021-03-24 21:25:34 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:25:34 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:25:34 --> Utf8 Class Initialized
INFO - 2021-03-24 21:25:34 --> URI Class Initialized
INFO - 2021-03-24 21:25:34 --> Database Driver Class Initialized
INFO - 2021-03-24 21:25:34 --> Router Class Initialized
INFO - 2021-03-24 21:25:34 --> Output Class Initialized
INFO - 2021-03-24 21:25:34 --> Security Class Initialized
DEBUG - 2021-03-24 21:25:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:25:34 --> Form Validation Class Initialized
INFO - 2021-03-24 21:25:34 --> Controller Class Initialized
INFO - 2021-03-24 21:25:34 --> Config Class Initialized
INFO - 2021-03-24 21:25:34 --> Hooks Class Initialized
INFO - 2021-03-24 21:25:34 --> Model Class Initialized
INFO - 2021-03-24 21:25:34 --> Model Class Initialized
INFO - 2021-03-24 21:25:34 --> Model Class Initialized
DEBUG - 2021-03-24 21:25:34 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:25:34 --> Utf8 Class Initialized
INFO - 2021-03-24 21:25:34 --> URI Class Initialized
INFO - 2021-03-24 21:25:34 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:25:34 --> Database Driver Class Initialized
INFO - 2021-03-24 21:25:34 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
DEBUG - 2021-03-24 21:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:25:34 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:25:34 --> Router Class Initialized
INFO - 2021-03-24 21:25:34 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:25:34 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:25:34 --> Final output sent to browser
DEBUG - 2021-03-24 21:25:34 --> Total execution time: 0.0515
INFO - 2021-03-24 21:25:34 --> Output Class Initialized
DEBUG - 2021-03-24 21:25:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:25:34 --> Security Class Initialized
INFO - 2021-03-24 21:25:34 --> Input Class Initialized
INFO - 2021-03-24 21:25:34 --> Language Class Initialized
DEBUG - 2021-03-24 21:25:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:25:34 --> Input Class Initialized
INFO - 2021-03-24 21:25:34 --> Form Validation Class Initialized
INFO - 2021-03-24 21:25:34 --> Controller Class Initialized
INFO - 2021-03-24 21:25:34 --> Language Class Initialized
INFO - 2021-03-24 21:25:34 --> Model Class Initialized
INFO - 2021-03-24 21:25:34 --> Loader Class Initialized
INFO - 2021-03-24 21:25:34 --> Model Class Initialized
INFO - 2021-03-24 21:25:34 --> Model Class Initialized
INFO - 2021-03-24 21:25:34 --> Loader Class Initialized
INFO - 2021-03-24 21:25:34 --> Helper loaded: url_helper
INFO - 2021-03-24 21:25:34 --> Helper loaded: url_helper
INFO - 2021-03-24 21:25:34 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:25:34 --> Helper loaded: form_helper
INFO - 2021-03-24 21:25:34 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:25:34 --> Helper loaded: common_helper
INFO - 2021-03-24 21:25:34 --> Helper loaded: form_helper
INFO - 2021-03-24 21:25:34 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:25:34 --> Helper loaded: util_helper
INFO - 2021-03-24 21:25:34 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:25:34 --> Helper loaded: common_helper
INFO - 2021-03-24 21:25:34 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:25:34 --> Final output sent to browser
DEBUG - 2021-03-24 21:25:34 --> Total execution time: 0.0635
INFO - 2021-03-24 21:25:34 --> Helper loaded: util_helper
INFO - 2021-03-24 21:25:34 --> Database Driver Class Initialized
INFO - 2021-03-24 21:25:34 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:25:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:25:34 --> Session: Class initialized using 'files' driver.
DEBUG - 2021-03-24 21:25:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:25:34 --> Form Validation Class Initialized
INFO - 2021-03-24 21:25:34 --> Controller Class Initialized
INFO - 2021-03-24 21:25:34 --> Model Class Initialized
INFO - 2021-03-24 21:25:34 --> Model Class Initialized
INFO - 2021-03-24 21:25:34 --> Model Class Initialized
INFO - 2021-03-24 21:25:34 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:25:34 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:25:34 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:25:34 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:25:34 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:25:34 --> Final output sent to browser
DEBUG - 2021-03-24 21:25:34 --> Total execution time: 0.0647
INFO - 2021-03-24 21:25:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:25:34 --> Form Validation Class Initialized
INFO - 2021-03-24 21:25:34 --> Controller Class Initialized
INFO - 2021-03-24 21:25:34 --> Model Class Initialized
INFO - 2021-03-24 21:25:34 --> Model Class Initialized
INFO - 2021-03-24 21:25:34 --> Model Class Initialized
INFO - 2021-03-24 21:25:34 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:25:34 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:25:34 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:25:34 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:25:34 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:25:34 --> Final output sent to browser
DEBUG - 2021-03-24 21:25:34 --> Total execution time: 0.0663
INFO - 2021-03-24 21:25:39 --> Config Class Initialized
INFO - 2021-03-24 21:25:39 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:25:39 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:25:39 --> Utf8 Class Initialized
INFO - 2021-03-24 21:25:39 --> URI Class Initialized
INFO - 2021-03-24 21:25:39 --> Router Class Initialized
INFO - 2021-03-24 21:25:39 --> Output Class Initialized
INFO - 2021-03-24 21:25:39 --> Security Class Initialized
DEBUG - 2021-03-24 21:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:25:39 --> Input Class Initialized
INFO - 2021-03-24 21:25:39 --> Language Class Initialized
INFO - 2021-03-24 21:25:39 --> Loader Class Initialized
INFO - 2021-03-24 21:25:39 --> Helper loaded: url_helper
INFO - 2021-03-24 21:25:39 --> Helper loaded: form_helper
INFO - 2021-03-24 21:25:39 --> Helper loaded: common_helper
INFO - 2021-03-24 21:25:39 --> Helper loaded: util_helper
INFO - 2021-03-24 21:25:39 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:25:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:25:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:25:39 --> Form Validation Class Initialized
INFO - 2021-03-24 21:25:39 --> Controller Class Initialized
INFO - 2021-03-24 21:25:39 --> Model Class Initialized
INFO - 2021-03-24 21:25:39 --> Model Class Initialized
INFO - 2021-03-24 21:25:39 --> Model Class Initialized
INFO - 2021-03-24 21:25:39 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:25:39 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:25:39 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:25:39 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:25:39 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:25:39 --> Final output sent to browser
DEBUG - 2021-03-24 21:25:39 --> Total execution time: 0.0476
INFO - 2021-03-24 21:25:39 --> Config Class Initialized
INFO - 2021-03-24 21:25:39 --> Config Class Initialized
INFO - 2021-03-24 21:25:39 --> Hooks Class Initialized
INFO - 2021-03-24 21:25:39 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:25:39 --> UTF-8 Support Enabled
DEBUG - 2021-03-24 21:25:39 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:25:39 --> Utf8 Class Initialized
INFO - 2021-03-24 21:25:39 --> Utf8 Class Initialized
INFO - 2021-03-24 21:25:39 --> URI Class Initialized
INFO - 2021-03-24 21:25:39 --> URI Class Initialized
INFO - 2021-03-24 21:25:39 --> Router Class Initialized
INFO - 2021-03-24 21:25:39 --> Router Class Initialized
INFO - 2021-03-24 21:25:39 --> Output Class Initialized
INFO - 2021-03-24 21:25:39 --> Output Class Initialized
INFO - 2021-03-24 21:25:39 --> Security Class Initialized
DEBUG - 2021-03-24 21:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:25:39 --> Input Class Initialized
INFO - 2021-03-24 21:25:39 --> Security Class Initialized
INFO - 2021-03-24 21:25:39 --> Language Class Initialized
DEBUG - 2021-03-24 21:25:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:25:39 --> Input Class Initialized
INFO - 2021-03-24 21:25:39 --> Language Class Initialized
INFO - 2021-03-24 21:25:39 --> Loader Class Initialized
INFO - 2021-03-24 21:25:39 --> Helper loaded: url_helper
INFO - 2021-03-24 21:25:39 --> Config Class Initialized
INFO - 2021-03-24 21:25:39 --> Hooks Class Initialized
INFO - 2021-03-24 21:25:39 --> Helper loaded: form_helper
INFO - 2021-03-24 21:25:39 --> Helper loaded: common_helper
INFO - 2021-03-24 21:25:39 --> Helper loaded: util_helper
DEBUG - 2021-03-24 21:25:39 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:25:39 --> Utf8 Class Initialized
INFO - 2021-03-24 21:25:39 --> URI Class Initialized
INFO - 2021-03-24 21:25:40 --> Router Class Initialized
INFO - 2021-03-24 21:25:40 --> Config Class Initialized
INFO - 2021-03-24 21:25:40 --> Hooks Class Initialized
INFO - 2021-03-24 21:25:40 --> Database Driver Class Initialized
INFO - 2021-03-24 21:25:40 --> Output Class Initialized
INFO - 2021-03-24 21:25:40 --> Security Class Initialized
DEBUG - 2021-03-24 21:25:40 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:25:40 --> Utf8 Class Initialized
INFO - 2021-03-24 21:25:40 --> Loader Class Initialized
DEBUG - 2021-03-24 21:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:25:40 --> Input Class Initialized
INFO - 2021-03-24 21:25:40 --> URI Class Initialized
DEBUG - 2021-03-24 21:25:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:25:40 --> Language Class Initialized
INFO - 2021-03-24 21:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:25:40 --> Router Class Initialized
INFO - 2021-03-24 21:25:40 --> Helper loaded: url_helper
INFO - 2021-03-24 21:25:40 --> Form Validation Class Initialized
INFO - 2021-03-24 21:25:40 --> Controller Class Initialized
INFO - 2021-03-24 21:25:40 --> Output Class Initialized
INFO - 2021-03-24 21:25:40 --> Loader Class Initialized
INFO - 2021-03-24 21:25:40 --> Model Class Initialized
INFO - 2021-03-24 21:25:40 --> Helper loaded: url_helper
INFO - 2021-03-24 21:25:40 --> Security Class Initialized
INFO - 2021-03-24 21:25:40 --> Model Class Initialized
INFO - 2021-03-24 21:25:40 --> Model Class Initialized
INFO - 2021-03-24 21:25:40 --> Helper loaded: form_helper
DEBUG - 2021-03-24 21:25:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:25:40 --> Helper loaded: form_helper
INFO - 2021-03-24 21:25:40 --> Input Class Initialized
INFO - 2021-03-24 21:25:40 --> Language Class Initialized
INFO - 2021-03-24 21:25:40 --> Helper loaded: common_helper
INFO - 2021-03-24 21:25:40 --> Helper loaded: common_helper
INFO - 2021-03-24 21:25:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:25:40 --> Helper loaded: util_helper
INFO - 2021-03-24 21:25:40 --> Helper loaded: util_helper
INFO - 2021-03-24 21:25:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:25:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:25:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:25:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:25:40 --> Final output sent to browser
DEBUG - 2021-03-24 21:25:40 --> Total execution time: 0.0532
INFO - 2021-03-24 21:25:40 --> Loader Class Initialized
INFO - 2021-03-24 21:25:40 --> Helper loaded: url_helper
INFO - 2021-03-24 21:25:40 --> Helper loaded: form_helper
INFO - 2021-03-24 21:25:40 --> Database Driver Class Initialized
INFO - 2021-03-24 21:25:40 --> Helper loaded: common_helper
INFO - 2021-03-24 21:25:40 --> Helper loaded: util_helper
DEBUG - 2021-03-24 21:25:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:25:40 --> Database Driver Class Initialized
INFO - 2021-03-24 21:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:25:40 --> Form Validation Class Initialized
INFO - 2021-03-24 21:25:40 --> Controller Class Initialized
INFO - 2021-03-24 21:25:40 --> Model Class Initialized
DEBUG - 2021-03-24 21:25:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:25:40 --> Model Class Initialized
INFO - 2021-03-24 21:25:40 --> Model Class Initialized
INFO - 2021-03-24 21:25:40 --> Database Driver Class Initialized
INFO - 2021-03-24 21:25:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
DEBUG - 2021-03-24 21:25:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:25:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:25:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:25:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:25:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:25:40 --> Final output sent to browser
DEBUG - 2021-03-24 21:25:40 --> Total execution time: 0.0762
INFO - 2021-03-24 21:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:25:40 --> Form Validation Class Initialized
INFO - 2021-03-24 21:25:40 --> Controller Class Initialized
INFO - 2021-03-24 21:25:40 --> Model Class Initialized
INFO - 2021-03-24 21:25:40 --> Model Class Initialized
INFO - 2021-03-24 21:25:40 --> Model Class Initialized
INFO - 2021-03-24 21:25:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:25:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:25:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:25:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:25:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:25:40 --> Final output sent to browser
DEBUG - 2021-03-24 21:25:40 --> Total execution time: 0.0681
INFO - 2021-03-24 21:25:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:25:40 --> Form Validation Class Initialized
INFO - 2021-03-24 21:25:40 --> Controller Class Initialized
INFO - 2021-03-24 21:25:40 --> Model Class Initialized
INFO - 2021-03-24 21:25:40 --> Model Class Initialized
INFO - 2021-03-24 21:25:40 --> Model Class Initialized
INFO - 2021-03-24 21:25:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:25:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:25:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:25:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:25:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:25:40 --> Final output sent to browser
DEBUG - 2021-03-24 21:25:40 --> Total execution time: 0.0739
INFO - 2021-03-24 21:26:37 --> Config Class Initialized
INFO - 2021-03-24 21:26:37 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:26:37 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:26:37 --> Utf8 Class Initialized
INFO - 2021-03-24 21:26:37 --> URI Class Initialized
INFO - 2021-03-24 21:26:37 --> Router Class Initialized
INFO - 2021-03-24 21:26:37 --> Output Class Initialized
INFO - 2021-03-24 21:26:37 --> Security Class Initialized
DEBUG - 2021-03-24 21:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:26:37 --> Input Class Initialized
INFO - 2021-03-24 21:26:37 --> Language Class Initialized
INFO - 2021-03-24 21:26:37 --> Loader Class Initialized
INFO - 2021-03-24 21:26:37 --> Helper loaded: url_helper
INFO - 2021-03-24 21:26:37 --> Helper loaded: form_helper
INFO - 2021-03-24 21:26:37 --> Helper loaded: common_helper
INFO - 2021-03-24 21:26:37 --> Helper loaded: util_helper
INFO - 2021-03-24 21:26:37 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:26:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:26:37 --> Form Validation Class Initialized
INFO - 2021-03-24 21:26:37 --> Controller Class Initialized
INFO - 2021-03-24 21:26:37 --> Model Class Initialized
INFO - 2021-03-24 21:26:37 --> Model Class Initialized
INFO - 2021-03-24 21:26:37 --> Model Class Initialized
INFO - 2021-03-24 21:26:37 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:26:37 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:26:37 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:26:37 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:26:37 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:26:37 --> Final output sent to browser
DEBUG - 2021-03-24 21:26:37 --> Total execution time: 0.0531
INFO - 2021-03-24 21:26:38 --> Config Class Initialized
INFO - 2021-03-24 21:26:38 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:26:38 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:26:38 --> Utf8 Class Initialized
INFO - 2021-03-24 21:26:38 --> URI Class Initialized
INFO - 2021-03-24 21:26:38 --> Router Class Initialized
INFO - 2021-03-24 21:26:38 --> Config Class Initialized
INFO - 2021-03-24 21:26:38 --> Hooks Class Initialized
INFO - 2021-03-24 21:26:38 --> Output Class Initialized
DEBUG - 2021-03-24 21:26:38 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:26:38 --> Utf8 Class Initialized
INFO - 2021-03-24 21:26:38 --> Security Class Initialized
INFO - 2021-03-24 21:26:38 --> URI Class Initialized
DEBUG - 2021-03-24 21:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:26:38 --> Input Class Initialized
INFO - 2021-03-24 21:26:38 --> Language Class Initialized
INFO - 2021-03-24 21:26:38 --> Router Class Initialized
INFO - 2021-03-24 21:26:38 --> Output Class Initialized
INFO - 2021-03-24 21:26:38 --> Loader Class Initialized
INFO - 2021-03-24 21:26:38 --> Security Class Initialized
INFO - 2021-03-24 21:26:38 --> Helper loaded: url_helper
DEBUG - 2021-03-24 21:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:26:38 --> Input Class Initialized
INFO - 2021-03-24 21:26:38 --> Language Class Initialized
INFO - 2021-03-24 21:26:38 --> Helper loaded: form_helper
INFO - 2021-03-24 21:26:38 --> Helper loaded: common_helper
INFO - 2021-03-24 21:26:38 --> Helper loaded: util_helper
INFO - 2021-03-24 21:26:38 --> Loader Class Initialized
INFO - 2021-03-24 21:26:38 --> Helper loaded: url_helper
INFO - 2021-03-24 21:26:38 --> Config Class Initialized
INFO - 2021-03-24 21:26:38 --> Hooks Class Initialized
INFO - 2021-03-24 21:26:38 --> Helper loaded: form_helper
INFO - 2021-03-24 21:26:38 --> Database Driver Class Initialized
INFO - 2021-03-24 21:26:38 --> Helper loaded: common_helper
INFO - 2021-03-24 21:26:38 --> Helper loaded: util_helper
DEBUG - 2021-03-24 21:26:38 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:26:38 --> Utf8 Class Initialized
INFO - 2021-03-24 21:26:38 --> URI Class Initialized
DEBUG - 2021-03-24 21:26:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:26:38 --> Router Class Initialized
INFO - 2021-03-24 21:26:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:26:38 --> Form Validation Class Initialized
INFO - 2021-03-24 21:26:38 --> Controller Class Initialized
INFO - 2021-03-24 21:26:38 --> Output Class Initialized
INFO - 2021-03-24 21:26:38 --> Model Class Initialized
INFO - 2021-03-24 21:26:38 --> Security Class Initialized
INFO - 2021-03-24 21:26:38 --> Model Class Initialized
INFO - 2021-03-24 21:26:38 --> Model Class Initialized
DEBUG - 2021-03-24 21:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:26:38 --> Input Class Initialized
INFO - 2021-03-24 21:26:38 --> Language Class Initialized
INFO - 2021-03-24 21:26:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:26:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:26:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:26:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:26:38 --> Loader Class Initialized
INFO - 2021-03-24 21:26:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:26:38 --> Final output sent to browser
DEBUG - 2021-03-24 21:26:38 --> Total execution time: 0.0524
INFO - 2021-03-24 21:26:38 --> Helper loaded: url_helper
INFO - 2021-03-24 21:26:38 --> Helper loaded: form_helper
INFO - 2021-03-24 21:26:38 --> Config Class Initialized
INFO - 2021-03-24 21:26:38 --> Hooks Class Initialized
INFO - 2021-03-24 21:26:38 --> Helper loaded: common_helper
INFO - 2021-03-24 21:26:38 --> Helper loaded: util_helper
DEBUG - 2021-03-24 21:26:38 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:26:38 --> Utf8 Class Initialized
INFO - 2021-03-24 21:26:38 --> URI Class Initialized
INFO - 2021-03-24 21:26:38 --> Router Class Initialized
INFO - 2021-03-24 21:26:38 --> Output Class Initialized
INFO - 2021-03-24 21:26:38 --> Database Driver Class Initialized
INFO - 2021-03-24 21:26:38 --> Security Class Initialized
DEBUG - 2021-03-24 21:26:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:26:38 --> Input Class Initialized
INFO - 2021-03-24 21:26:38 --> Language Class Initialized
DEBUG - 2021-03-24 21:26:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:26:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:26:38 --> Form Validation Class Initialized
INFO - 2021-03-24 21:26:38 --> Controller Class Initialized
INFO - 2021-03-24 21:26:38 --> Loader Class Initialized
INFO - 2021-03-24 21:26:38 --> Helper loaded: url_helper
INFO - 2021-03-24 21:26:38 --> Model Class Initialized
INFO - 2021-03-24 21:26:38 --> Model Class Initialized
INFO - 2021-03-24 21:26:38 --> Model Class Initialized
INFO - 2021-03-24 21:26:38 --> Helper loaded: form_helper
INFO - 2021-03-24 21:26:38 --> Helper loaded: common_helper
INFO - 2021-03-24 21:26:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:26:38 --> Helper loaded: util_helper
INFO - 2021-03-24 21:26:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:26:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:26:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:26:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:26:38 --> Final output sent to browser
DEBUG - 2021-03-24 21:26:38 --> Total execution time: 0.0799
INFO - 2021-03-24 21:26:38 --> Database Driver Class Initialized
INFO - 2021-03-24 21:26:38 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:26:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:26:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2021-03-24 21:26:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:26:38 --> Form Validation Class Initialized
INFO - 2021-03-24 21:26:38 --> Controller Class Initialized
INFO - 2021-03-24 21:26:38 --> Model Class Initialized
INFO - 2021-03-24 21:26:38 --> Model Class Initialized
INFO - 2021-03-24 21:26:38 --> Model Class Initialized
INFO - 2021-03-24 21:26:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:26:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:26:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:26:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:26:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:26:38 --> Final output sent to browser
DEBUG - 2021-03-24 21:26:38 --> Total execution time: 0.0762
INFO - 2021-03-24 21:26:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:26:38 --> Form Validation Class Initialized
INFO - 2021-03-24 21:26:38 --> Controller Class Initialized
INFO - 2021-03-24 21:26:38 --> Model Class Initialized
INFO - 2021-03-24 21:26:38 --> Model Class Initialized
INFO - 2021-03-24 21:26:38 --> Model Class Initialized
INFO - 2021-03-24 21:26:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:26:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:26:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:26:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:26:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:26:38 --> Final output sent to browser
DEBUG - 2021-03-24 21:26:38 --> Total execution time: 0.0674
INFO - 2021-03-24 21:26:40 --> Config Class Initialized
INFO - 2021-03-24 21:26:40 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:26:40 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:26:40 --> Utf8 Class Initialized
INFO - 2021-03-24 21:26:40 --> URI Class Initialized
INFO - 2021-03-24 21:26:40 --> Router Class Initialized
INFO - 2021-03-24 21:26:40 --> Output Class Initialized
INFO - 2021-03-24 21:26:40 --> Security Class Initialized
DEBUG - 2021-03-24 21:26:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:26:40 --> Input Class Initialized
INFO - 2021-03-24 21:26:40 --> Language Class Initialized
INFO - 2021-03-24 21:26:40 --> Loader Class Initialized
INFO - 2021-03-24 21:26:40 --> Helper loaded: url_helper
INFO - 2021-03-24 21:26:40 --> Helper loaded: form_helper
INFO - 2021-03-24 21:26:40 --> Helper loaded: common_helper
INFO - 2021-03-24 21:26:40 --> Helper loaded: util_helper
INFO - 2021-03-24 21:26:40 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:26:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:26:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:26:40 --> Form Validation Class Initialized
INFO - 2021-03-24 21:26:40 --> Controller Class Initialized
INFO - 2021-03-24 21:26:40 --> Model Class Initialized
INFO - 2021-03-24 21:26:40 --> Model Class Initialized
INFO - 2021-03-24 21:26:40 --> Model Class Initialized
INFO - 2021-03-24 21:26:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-03-24 21:28:36 --> Config Class Initialized
INFO - 2021-03-24 21:28:36 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:28:36 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:28:36 --> Utf8 Class Initialized
INFO - 2021-03-24 21:28:36 --> URI Class Initialized
INFO - 2021-03-24 21:28:36 --> Router Class Initialized
INFO - 2021-03-24 21:28:36 --> Output Class Initialized
INFO - 2021-03-24 21:28:36 --> Security Class Initialized
DEBUG - 2021-03-24 21:28:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:28:36 --> Input Class Initialized
INFO - 2021-03-24 21:28:36 --> Language Class Initialized
INFO - 2021-03-24 21:28:36 --> Loader Class Initialized
INFO - 2021-03-24 21:28:36 --> Helper loaded: url_helper
INFO - 2021-03-24 21:28:36 --> Helper loaded: form_helper
INFO - 2021-03-24 21:28:36 --> Helper loaded: common_helper
INFO - 2021-03-24 21:28:36 --> Helper loaded: util_helper
INFO - 2021-03-24 21:28:36 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:28:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:28:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:28:36 --> Form Validation Class Initialized
INFO - 2021-03-24 21:28:36 --> Controller Class Initialized
INFO - 2021-03-24 21:28:36 --> Model Class Initialized
INFO - 2021-03-24 21:28:36 --> Model Class Initialized
INFO - 2021-03-24 21:28:36 --> Model Class Initialized
INFO - 2021-03-24 21:28:36 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-03-24 21:28:37 --> Config Class Initialized
INFO - 2021-03-24 21:28:37 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:28:37 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:28:37 --> Utf8 Class Initialized
INFO - 2021-03-24 21:28:37 --> URI Class Initialized
INFO - 2021-03-24 21:28:37 --> Router Class Initialized
INFO - 2021-03-24 21:28:37 --> Output Class Initialized
INFO - 2021-03-24 21:28:37 --> Security Class Initialized
DEBUG - 2021-03-24 21:28:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:28:37 --> Input Class Initialized
INFO - 2021-03-24 21:28:37 --> Language Class Initialized
INFO - 2021-03-24 21:28:37 --> Loader Class Initialized
INFO - 2021-03-24 21:28:37 --> Helper loaded: url_helper
INFO - 2021-03-24 21:28:37 --> Helper loaded: form_helper
INFO - 2021-03-24 21:28:37 --> Helper loaded: common_helper
INFO - 2021-03-24 21:28:37 --> Helper loaded: util_helper
INFO - 2021-03-24 21:28:37 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:28:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:28:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:28:37 --> Form Validation Class Initialized
INFO - 2021-03-24 21:28:37 --> Controller Class Initialized
INFO - 2021-03-24 21:28:37 --> Model Class Initialized
INFO - 2021-03-24 21:28:37 --> Model Class Initialized
INFO - 2021-03-24 21:28:37 --> Model Class Initialized
INFO - 2021-03-24 21:28:37 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:28:37 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:28:37 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:28:37 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:28:37 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:28:37 --> Final output sent to browser
DEBUG - 2021-03-24 21:28:37 --> Total execution time: 0.0366
INFO - 2021-03-24 21:28:37 --> Config Class Initialized
INFO - 2021-03-24 21:28:37 --> Hooks Class Initialized
INFO - 2021-03-24 21:28:37 --> Config Class Initialized
INFO - 2021-03-24 21:28:37 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:28:37 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:28:37 --> Utf8 Class Initialized
INFO - 2021-03-24 21:28:37 --> URI Class Initialized
DEBUG - 2021-03-24 21:28:37 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:28:37 --> Utf8 Class Initialized
INFO - 2021-03-24 21:28:37 --> URI Class Initialized
INFO - 2021-03-24 21:28:37 --> Router Class Initialized
INFO - 2021-03-24 21:28:38 --> Router Class Initialized
INFO - 2021-03-24 21:28:38 --> Output Class Initialized
INFO - 2021-03-24 21:28:38 --> Security Class Initialized
INFO - 2021-03-24 21:28:38 --> Output Class Initialized
DEBUG - 2021-03-24 21:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:28:38 --> Security Class Initialized
INFO - 2021-03-24 21:28:38 --> Input Class Initialized
INFO - 2021-03-24 21:28:38 --> Language Class Initialized
DEBUG - 2021-03-24 21:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:28:38 --> Input Class Initialized
INFO - 2021-03-24 21:28:38 --> Language Class Initialized
INFO - 2021-03-24 21:28:38 --> Loader Class Initialized
INFO - 2021-03-24 21:28:38 --> Helper loaded: url_helper
INFO - 2021-03-24 21:28:38 --> Loader Class Initialized
INFO - 2021-03-24 21:28:38 --> Helper loaded: form_helper
INFO - 2021-03-24 21:28:38 --> Helper loaded: url_helper
INFO - 2021-03-24 21:28:38 --> Helper loaded: common_helper
INFO - 2021-03-24 21:28:38 --> Config Class Initialized
INFO - 2021-03-24 21:28:38 --> Helper loaded: form_helper
INFO - 2021-03-24 21:28:38 --> Hooks Class Initialized
INFO - 2021-03-24 21:28:38 --> Helper loaded: util_helper
INFO - 2021-03-24 21:28:38 --> Helper loaded: common_helper
INFO - 2021-03-24 21:28:38 --> Helper loaded: util_helper
DEBUG - 2021-03-24 21:28:38 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:28:38 --> Utf8 Class Initialized
INFO - 2021-03-24 21:28:38 --> URI Class Initialized
INFO - 2021-03-24 21:28:38 --> Router Class Initialized
INFO - 2021-03-24 21:28:38 --> Database Driver Class Initialized
INFO - 2021-03-24 21:28:38 --> Database Driver Class Initialized
INFO - 2021-03-24 21:28:38 --> Output Class Initialized
INFO - 2021-03-24 21:28:38 --> Security Class Initialized
DEBUG - 2021-03-24 21:28:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-03-24 21:28:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:28:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2021-03-24 21:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:28:38 --> Input Class Initialized
INFO - 2021-03-24 21:28:38 --> Language Class Initialized
INFO - 2021-03-24 21:28:38 --> Form Validation Class Initialized
INFO - 2021-03-24 21:28:38 --> Controller Class Initialized
INFO - 2021-03-24 21:28:38 --> Model Class Initialized
INFO - 2021-03-24 21:28:38 --> Model Class Initialized
INFO - 2021-03-24 21:28:38 --> Loader Class Initialized
INFO - 2021-03-24 21:28:38 --> Model Class Initialized
INFO - 2021-03-24 21:28:38 --> Helper loaded: url_helper
INFO - 2021-03-24 21:28:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:28:38 --> Helper loaded: form_helper
INFO - 2021-03-24 21:28:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:28:38 --> Helper loaded: common_helper
INFO - 2021-03-24 21:28:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:28:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:28:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:28:38 --> Helper loaded: util_helper
INFO - 2021-03-24 21:28:38 --> Final output sent to browser
DEBUG - 2021-03-24 21:28:38 --> Total execution time: 0.0479
INFO - 2021-03-24 21:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:28:38 --> Form Validation Class Initialized
INFO - 2021-03-24 21:28:38 --> Controller Class Initialized
INFO - 2021-03-24 21:28:38 --> Model Class Initialized
INFO - 2021-03-24 21:28:38 --> Model Class Initialized
INFO - 2021-03-24 21:28:38 --> Model Class Initialized
INFO - 2021-03-24 21:28:38 --> Database Driver Class Initialized
INFO - 2021-03-24 21:28:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:28:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:28:38 --> Config Class Initialized
DEBUG - 2021-03-24 21:28:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:28:38 --> Hooks Class Initialized
INFO - 2021-03-24 21:28:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:28:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:28:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:28:38 --> Final output sent to browser
DEBUG - 2021-03-24 21:28:38 --> Total execution time: 0.0610
INFO - 2021-03-24 21:28:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2021-03-24 21:28:38 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:28:38 --> Utf8 Class Initialized
INFO - 2021-03-24 21:28:38 --> Form Validation Class Initialized
INFO - 2021-03-24 21:28:38 --> Controller Class Initialized
INFO - 2021-03-24 21:28:38 --> URI Class Initialized
INFO - 2021-03-24 21:28:38 --> Model Class Initialized
INFO - 2021-03-24 21:28:38 --> Model Class Initialized
INFO - 2021-03-24 21:28:38 --> Router Class Initialized
INFO - 2021-03-24 21:28:38 --> Model Class Initialized
INFO - 2021-03-24 21:28:38 --> Output Class Initialized
INFO - 2021-03-24 21:28:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:28:38 --> Security Class Initialized
INFO - 2021-03-24 21:28:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
DEBUG - 2021-03-24 21:28:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:28:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:28:38 --> Input Class Initialized
INFO - 2021-03-24 21:28:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:28:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:28:38 --> Language Class Initialized
INFO - 2021-03-24 21:28:38 --> Final output sent to browser
DEBUG - 2021-03-24 21:28:38 --> Total execution time: 0.0605
INFO - 2021-03-24 21:28:38 --> Loader Class Initialized
INFO - 2021-03-24 21:28:38 --> Helper loaded: url_helper
INFO - 2021-03-24 21:28:38 --> Helper loaded: form_helper
INFO - 2021-03-24 21:28:38 --> Helper loaded: common_helper
INFO - 2021-03-24 21:28:38 --> Helper loaded: util_helper
INFO - 2021-03-24 21:28:38 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:28:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:28:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:28:38 --> Form Validation Class Initialized
INFO - 2021-03-24 21:28:38 --> Controller Class Initialized
INFO - 2021-03-24 21:28:38 --> Model Class Initialized
INFO - 2021-03-24 21:28:38 --> Model Class Initialized
INFO - 2021-03-24 21:28:38 --> Model Class Initialized
INFO - 2021-03-24 21:28:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:28:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:28:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:28:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:28:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:28:38 --> Final output sent to browser
DEBUG - 2021-03-24 21:28:38 --> Total execution time: 0.0603
INFO - 2021-03-24 21:28:40 --> Config Class Initialized
INFO - 2021-03-24 21:28:40 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:28:40 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:28:40 --> Utf8 Class Initialized
INFO - 2021-03-24 21:28:40 --> URI Class Initialized
INFO - 2021-03-24 21:28:40 --> Router Class Initialized
INFO - 2021-03-24 21:28:40 --> Output Class Initialized
INFO - 2021-03-24 21:28:40 --> Security Class Initialized
DEBUG - 2021-03-24 21:28:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:28:40 --> Input Class Initialized
INFO - 2021-03-24 21:28:40 --> Language Class Initialized
INFO - 2021-03-24 21:28:40 --> Loader Class Initialized
INFO - 2021-03-24 21:28:40 --> Helper loaded: url_helper
INFO - 2021-03-24 21:28:40 --> Helper loaded: form_helper
INFO - 2021-03-24 21:28:40 --> Helper loaded: common_helper
INFO - 2021-03-24 21:28:40 --> Helper loaded: util_helper
INFO - 2021-03-24 21:28:40 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:28:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:28:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:28:40 --> Form Validation Class Initialized
INFO - 2021-03-24 21:28:40 --> Controller Class Initialized
INFO - 2021-03-24 21:28:40 --> Model Class Initialized
INFO - 2021-03-24 21:28:40 --> Model Class Initialized
INFO - 2021-03-24 21:28:40 --> Model Class Initialized
INFO - 2021-03-24 21:28:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-03-24 21:29:17 --> Config Class Initialized
INFO - 2021-03-24 21:29:17 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:29:17 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:29:17 --> Utf8 Class Initialized
INFO - 2021-03-24 21:29:17 --> URI Class Initialized
INFO - 2021-03-24 21:29:17 --> Router Class Initialized
INFO - 2021-03-24 21:29:17 --> Output Class Initialized
INFO - 2021-03-24 21:29:17 --> Security Class Initialized
DEBUG - 2021-03-24 21:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:29:17 --> Input Class Initialized
INFO - 2021-03-24 21:29:17 --> Language Class Initialized
INFO - 2021-03-24 21:29:17 --> Loader Class Initialized
INFO - 2021-03-24 21:29:17 --> Helper loaded: url_helper
INFO - 2021-03-24 21:29:17 --> Helper loaded: form_helper
INFO - 2021-03-24 21:29:17 --> Helper loaded: common_helper
INFO - 2021-03-24 21:29:17 --> Helper loaded: util_helper
INFO - 2021-03-24 21:29:17 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:29:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:29:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:29:17 --> Form Validation Class Initialized
INFO - 2021-03-24 21:29:17 --> Controller Class Initialized
INFO - 2021-03-24 21:29:17 --> Model Class Initialized
INFO - 2021-03-24 21:29:17 --> Model Class Initialized
INFO - 2021-03-24 21:29:17 --> Model Class Initialized
INFO - 2021-03-24 21:29:17 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-03-24 21:29:17 --> Config Class Initialized
INFO - 2021-03-24 21:29:17 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:29:17 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:29:17 --> Utf8 Class Initialized
INFO - 2021-03-24 21:29:17 --> URI Class Initialized
INFO - 2021-03-24 21:29:17 --> Router Class Initialized
INFO - 2021-03-24 21:29:17 --> Output Class Initialized
INFO - 2021-03-24 21:29:17 --> Security Class Initialized
DEBUG - 2021-03-24 21:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:29:17 --> Input Class Initialized
INFO - 2021-03-24 21:29:17 --> Language Class Initialized
INFO - 2021-03-24 21:29:17 --> Loader Class Initialized
INFO - 2021-03-24 21:29:17 --> Helper loaded: url_helper
INFO - 2021-03-24 21:29:17 --> Helper loaded: form_helper
INFO - 2021-03-24 21:29:17 --> Helper loaded: common_helper
INFO - 2021-03-24 21:29:17 --> Helper loaded: util_helper
INFO - 2021-03-24 21:29:17 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:29:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:29:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:29:17 --> Form Validation Class Initialized
INFO - 2021-03-24 21:29:17 --> Controller Class Initialized
INFO - 2021-03-24 21:29:17 --> Model Class Initialized
INFO - 2021-03-24 21:29:17 --> Model Class Initialized
INFO - 2021-03-24 21:29:17 --> Model Class Initialized
INFO - 2021-03-24 21:29:17 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:29:17 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:29:17 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:29:17 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:29:17 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:29:17 --> Final output sent to browser
DEBUG - 2021-03-24 21:29:17 --> Total execution time: 0.0390
INFO - 2021-03-24 21:29:17 --> Config Class Initialized
INFO - 2021-03-24 21:29:17 --> Hooks Class Initialized
INFO - 2021-03-24 21:29:17 --> Config Class Initialized
INFO - 2021-03-24 21:29:17 --> Hooks Class Initialized
INFO - 2021-03-24 21:29:17 --> Config Class Initialized
INFO - 2021-03-24 21:29:17 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:29:17 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:29:17 --> Utf8 Class Initialized
DEBUG - 2021-03-24 21:29:17 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:29:17 --> Utf8 Class Initialized
INFO - 2021-03-24 21:29:17 --> URI Class Initialized
INFO - 2021-03-24 21:29:17 --> URI Class Initialized
INFO - 2021-03-24 21:29:17 --> Router Class Initialized
INFO - 2021-03-24 21:29:17 --> Router Class Initialized
INFO - 2021-03-24 21:29:17 --> Output Class Initialized
INFO - 2021-03-24 21:29:17 --> Output Class Initialized
INFO - 2021-03-24 21:29:17 --> Security Class Initialized
INFO - 2021-03-24 21:29:17 --> Security Class Initialized
DEBUG - 2021-03-24 21:29:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-24 21:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:29:17 --> Input Class Initialized
INFO - 2021-03-24 21:29:17 --> Input Class Initialized
INFO - 2021-03-24 21:29:17 --> Language Class Initialized
INFO - 2021-03-24 21:29:17 --> Language Class Initialized
INFO - 2021-03-24 21:29:17 --> Loader Class Initialized
INFO - 2021-03-24 21:29:17 --> Loader Class Initialized
INFO - 2021-03-24 21:29:17 --> Helper loaded: url_helper
INFO - 2021-03-24 21:29:17 --> Helper loaded: url_helper
DEBUG - 2021-03-24 21:29:17 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:29:17 --> Utf8 Class Initialized
INFO - 2021-03-24 21:29:17 --> Helper loaded: form_helper
INFO - 2021-03-24 21:29:17 --> Helper loaded: form_helper
INFO - 2021-03-24 21:29:17 --> URI Class Initialized
INFO - 2021-03-24 21:29:17 --> Helper loaded: common_helper
INFO - 2021-03-24 21:29:17 --> Helper loaded: common_helper
INFO - 2021-03-24 21:29:17 --> Helper loaded: util_helper
INFO - 2021-03-24 21:29:17 --> Helper loaded: util_helper
INFO - 2021-03-24 21:29:17 --> Router Class Initialized
INFO - 2021-03-24 21:29:17 --> Output Class Initialized
INFO - 2021-03-24 21:29:17 --> Security Class Initialized
DEBUG - 2021-03-24 21:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:29:17 --> Input Class Initialized
INFO - 2021-03-24 21:29:17 --> Database Driver Class Initialized
INFO - 2021-03-24 21:29:17 --> Language Class Initialized
DEBUG - 2021-03-24 21:29:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:29:17 --> Loader Class Initialized
INFO - 2021-03-24 21:29:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:29:17 --> Config Class Initialized
INFO - 2021-03-24 21:29:17 --> Hooks Class Initialized
INFO - 2021-03-24 21:29:17 --> Helper loaded: url_helper
INFO - 2021-03-24 21:29:17 --> Form Validation Class Initialized
INFO - 2021-03-24 21:29:17 --> Controller Class Initialized
INFO - 2021-03-24 21:29:17 --> Helper loaded: form_helper
DEBUG - 2021-03-24 21:29:17 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:29:17 --> Utf8 Class Initialized
INFO - 2021-03-24 21:29:17 --> Model Class Initialized
INFO - 2021-03-24 21:29:17 --> Helper loaded: common_helper
INFO - 2021-03-24 21:29:17 --> Model Class Initialized
INFO - 2021-03-24 21:29:17 --> URI Class Initialized
INFO - 2021-03-24 21:29:17 --> Helper loaded: util_helper
INFO - 2021-03-24 21:29:17 --> Model Class Initialized
INFO - 2021-03-24 21:29:17 --> Router Class Initialized
INFO - 2021-03-24 21:29:17 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:29:17 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:29:17 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:29:17 --> Output Class Initialized
INFO - 2021-03-24 21:29:17 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:29:17 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:29:17 --> Final output sent to browser
DEBUG - 2021-03-24 21:29:17 --> Total execution time: 0.0492
INFO - 2021-03-24 21:29:17 --> Database Driver Class Initialized
INFO - 2021-03-24 21:29:17 --> Security Class Initialized
DEBUG - 2021-03-24 21:29:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:29:17 --> Input Class Initialized
DEBUG - 2021-03-24 21:29:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:29:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:29:17 --> Language Class Initialized
INFO - 2021-03-24 21:29:17 --> Form Validation Class Initialized
INFO - 2021-03-24 21:29:17 --> Controller Class Initialized
INFO - 2021-03-24 21:29:17 --> Model Class Initialized
INFO - 2021-03-24 21:29:17 --> Model Class Initialized
INFO - 2021-03-24 21:29:17 --> Database Driver Class Initialized
INFO - 2021-03-24 21:29:17 --> Model Class Initialized
DEBUG - 2021-03-24 21:29:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:29:17 --> Loader Class Initialized
INFO - 2021-03-24 21:29:17 --> Helper loaded: url_helper
INFO - 2021-03-24 21:29:17 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:29:17 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:29:17 --> Helper loaded: form_helper
INFO - 2021-03-24 21:29:17 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:29:17 --> Helper loaded: common_helper
INFO - 2021-03-24 21:29:17 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:29:17 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:29:17 --> Helper loaded: util_helper
INFO - 2021-03-24 21:29:17 --> Final output sent to browser
DEBUG - 2021-03-24 21:29:17 --> Total execution time: 0.0702
INFO - 2021-03-24 21:29:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:29:17 --> Form Validation Class Initialized
INFO - 2021-03-24 21:29:17 --> Controller Class Initialized
INFO - 2021-03-24 21:29:17 --> Model Class Initialized
INFO - 2021-03-24 21:29:17 --> Model Class Initialized
INFO - 2021-03-24 21:29:17 --> Model Class Initialized
INFO - 2021-03-24 21:29:17 --> Database Driver Class Initialized
INFO - 2021-03-24 21:29:17 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
DEBUG - 2021-03-24 21:29:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:29:17 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:29:17 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:29:17 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:29:17 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:29:17 --> Final output sent to browser
DEBUG - 2021-03-24 21:29:17 --> Total execution time: 0.0874
INFO - 2021-03-24 21:29:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:29:17 --> Form Validation Class Initialized
INFO - 2021-03-24 21:29:17 --> Controller Class Initialized
INFO - 2021-03-24 21:29:17 --> Model Class Initialized
INFO - 2021-03-24 21:29:17 --> Model Class Initialized
INFO - 2021-03-24 21:29:17 --> Model Class Initialized
INFO - 2021-03-24 21:29:17 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:29:17 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:29:17 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:29:17 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:29:17 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:29:17 --> Final output sent to browser
DEBUG - 2021-03-24 21:29:17 --> Total execution time: 0.0740
INFO - 2021-03-24 21:29:21 --> Config Class Initialized
INFO - 2021-03-24 21:29:21 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:29:21 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:29:21 --> Utf8 Class Initialized
INFO - 2021-03-24 21:29:21 --> URI Class Initialized
INFO - 2021-03-24 21:29:21 --> Router Class Initialized
INFO - 2021-03-24 21:29:21 --> Output Class Initialized
INFO - 2021-03-24 21:29:21 --> Security Class Initialized
DEBUG - 2021-03-24 21:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:29:21 --> Input Class Initialized
INFO - 2021-03-24 21:29:21 --> Language Class Initialized
INFO - 2021-03-24 21:29:21 --> Loader Class Initialized
INFO - 2021-03-24 21:29:21 --> Helper loaded: url_helper
INFO - 2021-03-24 21:29:21 --> Helper loaded: form_helper
INFO - 2021-03-24 21:29:21 --> Helper loaded: common_helper
INFO - 2021-03-24 21:29:21 --> Helper loaded: util_helper
INFO - 2021-03-24 21:29:21 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:29:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:29:21 --> Form Validation Class Initialized
INFO - 2021-03-24 21:29:21 --> Controller Class Initialized
INFO - 2021-03-24 21:29:21 --> Model Class Initialized
INFO - 2021-03-24 21:29:21 --> Model Class Initialized
INFO - 2021-03-24 21:29:21 --> Model Class Initialized
INFO - 2021-03-24 21:29:21 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-03-24 21:29:21 --> Config Class Initialized
INFO - 2021-03-24 21:29:21 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:29:21 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:29:21 --> Utf8 Class Initialized
INFO - 2021-03-24 21:29:21 --> URI Class Initialized
INFO - 2021-03-24 21:29:21 --> Router Class Initialized
INFO - 2021-03-24 21:29:21 --> Output Class Initialized
INFO - 2021-03-24 21:29:21 --> Security Class Initialized
DEBUG - 2021-03-24 21:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:29:21 --> Input Class Initialized
INFO - 2021-03-24 21:29:21 --> Language Class Initialized
INFO - 2021-03-24 21:29:21 --> Loader Class Initialized
INFO - 2021-03-24 21:29:21 --> Helper loaded: url_helper
INFO - 2021-03-24 21:29:21 --> Helper loaded: form_helper
INFO - 2021-03-24 21:29:21 --> Helper loaded: common_helper
INFO - 2021-03-24 21:29:21 --> Helper loaded: util_helper
INFO - 2021-03-24 21:29:21 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:29:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:29:21 --> Form Validation Class Initialized
INFO - 2021-03-24 21:29:21 --> Controller Class Initialized
INFO - 2021-03-24 21:29:21 --> Model Class Initialized
INFO - 2021-03-24 21:29:21 --> Model Class Initialized
INFO - 2021-03-24 21:29:21 --> Model Class Initialized
INFO - 2021-03-24 21:29:21 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:29:21 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:29:21 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:29:21 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:29:21 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:29:21 --> Final output sent to browser
DEBUG - 2021-03-24 21:29:21 --> Total execution time: 0.0376
INFO - 2021-03-24 21:29:21 --> Config Class Initialized
INFO - 2021-03-24 21:29:21 --> Hooks Class Initialized
INFO - 2021-03-24 21:29:21 --> Config Class Initialized
INFO - 2021-03-24 21:29:21 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:29:21 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:29:21 --> Utf8 Class Initialized
INFO - 2021-03-24 21:29:21 --> URI Class Initialized
DEBUG - 2021-03-24 21:29:21 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:29:21 --> Utf8 Class Initialized
INFO - 2021-03-24 21:29:21 --> Router Class Initialized
INFO - 2021-03-24 21:29:21 --> URI Class Initialized
INFO - 2021-03-24 21:29:21 --> Output Class Initialized
INFO - 2021-03-24 21:29:21 --> Router Class Initialized
INFO - 2021-03-24 21:29:21 --> Security Class Initialized
INFO - 2021-03-24 21:29:21 --> Output Class Initialized
DEBUG - 2021-03-24 21:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:29:21 --> Input Class Initialized
INFO - 2021-03-24 21:29:21 --> Language Class Initialized
INFO - 2021-03-24 21:29:21 --> Security Class Initialized
DEBUG - 2021-03-24 21:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:29:21 --> Input Class Initialized
INFO - 2021-03-24 21:29:21 --> Language Class Initialized
INFO - 2021-03-24 21:29:21 --> Loader Class Initialized
INFO - 2021-03-24 21:29:21 --> Helper loaded: url_helper
INFO - 2021-03-24 21:29:21 --> Loader Class Initialized
INFO - 2021-03-24 21:29:21 --> Helper loaded: form_helper
INFO - 2021-03-24 21:29:21 --> Helper loaded: common_helper
INFO - 2021-03-24 21:29:21 --> Helper loaded: url_helper
INFO - 2021-03-24 21:29:21 --> Helper loaded: util_helper
INFO - 2021-03-24 21:29:21 --> Helper loaded: form_helper
INFO - 2021-03-24 21:29:21 --> Helper loaded: common_helper
INFO - 2021-03-24 21:29:21 --> Helper loaded: util_helper
INFO - 2021-03-24 21:29:21 --> Database Driver Class Initialized
INFO - 2021-03-24 21:29:21 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:29:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:29:21 --> Session: Class initialized using 'files' driver.
DEBUG - 2021-03-24 21:29:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:29:21 --> Form Validation Class Initialized
INFO - 2021-03-24 21:29:21 --> Controller Class Initialized
INFO - 2021-03-24 21:29:21 --> Model Class Initialized
INFO - 2021-03-24 21:29:21 --> Model Class Initialized
INFO - 2021-03-24 21:29:21 --> Model Class Initialized
INFO - 2021-03-24 21:29:21 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:29:21 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:29:21 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:29:21 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:29:21 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:29:21 --> Final output sent to browser
DEBUG - 2021-03-24 21:29:21 --> Total execution time: 0.0474
INFO - 2021-03-24 21:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:29:21 --> Form Validation Class Initialized
INFO - 2021-03-24 21:29:21 --> Controller Class Initialized
INFO - 2021-03-24 21:29:21 --> Config Class Initialized
INFO - 2021-03-24 21:29:21 --> Hooks Class Initialized
INFO - 2021-03-24 21:29:21 --> Model Class Initialized
INFO - 2021-03-24 21:29:21 --> Model Class Initialized
INFO - 2021-03-24 21:29:21 --> Config Class Initialized
INFO - 2021-03-24 21:29:21 --> Model Class Initialized
INFO - 2021-03-24 21:29:21 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:29:21 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:29:21 --> Utf8 Class Initialized
INFO - 2021-03-24 21:29:21 --> URI Class Initialized
INFO - 2021-03-24 21:29:21 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
DEBUG - 2021-03-24 21:29:21 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:29:21 --> Utf8 Class Initialized
INFO - 2021-03-24 21:29:21 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:29:21 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:29:21 --> URI Class Initialized
INFO - 2021-03-24 21:29:21 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:29:21 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:29:21 --> Final output sent to browser
DEBUG - 2021-03-24 21:29:21 --> Total execution time: 0.0581
INFO - 2021-03-24 21:29:21 --> Router Class Initialized
INFO - 2021-03-24 21:29:21 --> Router Class Initialized
INFO - 2021-03-24 21:29:21 --> Output Class Initialized
INFO - 2021-03-24 21:29:21 --> Output Class Initialized
INFO - 2021-03-24 21:29:21 --> Security Class Initialized
INFO - 2021-03-24 21:29:21 --> Security Class Initialized
DEBUG - 2021-03-24 21:29:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-24 21:29:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:29:21 --> Input Class Initialized
INFO - 2021-03-24 21:29:21 --> Input Class Initialized
INFO - 2021-03-24 21:29:21 --> Language Class Initialized
INFO - 2021-03-24 21:29:21 --> Language Class Initialized
INFO - 2021-03-24 21:29:21 --> Loader Class Initialized
INFO - 2021-03-24 21:29:21 --> Loader Class Initialized
INFO - 2021-03-24 21:29:21 --> Helper loaded: url_helper
INFO - 2021-03-24 21:29:21 --> Helper loaded: url_helper
INFO - 2021-03-24 21:29:21 --> Helper loaded: form_helper
INFO - 2021-03-24 21:29:21 --> Helper loaded: form_helper
INFO - 2021-03-24 21:29:21 --> Helper loaded: common_helper
INFO - 2021-03-24 21:29:21 --> Helper loaded: common_helper
INFO - 2021-03-24 21:29:21 --> Helper loaded: util_helper
INFO - 2021-03-24 21:29:21 --> Helper loaded: util_helper
INFO - 2021-03-24 21:29:21 --> Database Driver Class Initialized
INFO - 2021-03-24 21:29:21 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:29:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-03-24 21:29:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:29:21 --> Form Validation Class Initialized
INFO - 2021-03-24 21:29:21 --> Controller Class Initialized
INFO - 2021-03-24 21:29:21 --> Model Class Initialized
INFO - 2021-03-24 21:29:21 --> Model Class Initialized
INFO - 2021-03-24 21:29:21 --> Model Class Initialized
INFO - 2021-03-24 21:29:21 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:29:21 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:29:21 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:29:21 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:29:21 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:29:21 --> Final output sent to browser
DEBUG - 2021-03-24 21:29:21 --> Total execution time: 0.0546
INFO - 2021-03-24 21:29:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:29:21 --> Form Validation Class Initialized
INFO - 2021-03-24 21:29:21 --> Controller Class Initialized
INFO - 2021-03-24 21:29:21 --> Model Class Initialized
INFO - 2021-03-24 21:29:21 --> Model Class Initialized
INFO - 2021-03-24 21:29:21 --> Model Class Initialized
INFO - 2021-03-24 21:29:21 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:29:21 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:29:21 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:29:21 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:29:21 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:29:21 --> Final output sent to browser
DEBUG - 2021-03-24 21:29:21 --> Total execution time: 0.0658
INFO - 2021-03-24 21:31:51 --> Config Class Initialized
INFO - 2021-03-24 21:31:51 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:31:51 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:31:51 --> Utf8 Class Initialized
INFO - 2021-03-24 21:31:51 --> URI Class Initialized
INFO - 2021-03-24 21:31:51 --> Router Class Initialized
INFO - 2021-03-24 21:31:51 --> Output Class Initialized
INFO - 2021-03-24 21:31:51 --> Security Class Initialized
DEBUG - 2021-03-24 21:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:31:51 --> Input Class Initialized
INFO - 2021-03-24 21:31:51 --> Language Class Initialized
INFO - 2021-03-24 21:31:51 --> Loader Class Initialized
INFO - 2021-03-24 21:31:51 --> Helper loaded: url_helper
INFO - 2021-03-24 21:31:51 --> Helper loaded: form_helper
INFO - 2021-03-24 21:31:51 --> Helper loaded: common_helper
INFO - 2021-03-24 21:31:51 --> Helper loaded: util_helper
INFO - 2021-03-24 21:31:51 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:31:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:31:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:31:51 --> Form Validation Class Initialized
INFO - 2021-03-24 21:31:51 --> Controller Class Initialized
INFO - 2021-03-24 21:31:51 --> Model Class Initialized
INFO - 2021-03-24 21:31:51 --> Model Class Initialized
INFO - 2021-03-24 21:31:51 --> Model Class Initialized
INFO - 2021-03-24 21:31:51 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:31:51 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:31:51 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:31:51 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:31:51 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:31:51 --> Final output sent to browser
DEBUG - 2021-03-24 21:31:51 --> Total execution time: 0.0464
INFO - 2021-03-24 21:31:51 --> Config Class Initialized
INFO - 2021-03-24 21:31:51 --> Hooks Class Initialized
INFO - 2021-03-24 21:31:51 --> Config Class Initialized
INFO - 2021-03-24 21:31:51 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:31:51 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:31:51 --> Utf8 Class Initialized
INFO - 2021-03-24 21:31:51 --> URI Class Initialized
DEBUG - 2021-03-24 21:31:51 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:31:51 --> Utf8 Class Initialized
INFO - 2021-03-24 21:31:51 --> URI Class Initialized
INFO - 2021-03-24 21:31:51 --> Router Class Initialized
INFO - 2021-03-24 21:31:51 --> Router Class Initialized
INFO - 2021-03-24 21:31:51 --> Output Class Initialized
INFO - 2021-03-24 21:31:51 --> Security Class Initialized
DEBUG - 2021-03-24 21:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:31:51 --> Input Class Initialized
INFO - 2021-03-24 21:31:51 --> Language Class Initialized
INFO - 2021-03-24 21:31:51 --> Output Class Initialized
INFO - 2021-03-24 21:31:51 --> Security Class Initialized
INFO - 2021-03-24 21:31:51 --> Loader Class Initialized
DEBUG - 2021-03-24 21:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:31:51 --> Input Class Initialized
INFO - 2021-03-24 21:31:51 --> Helper loaded: url_helper
INFO - 2021-03-24 21:31:51 --> Language Class Initialized
INFO - 2021-03-24 21:31:51 --> Helper loaded: form_helper
INFO - 2021-03-24 21:31:51 --> Helper loaded: common_helper
INFO - 2021-03-24 21:31:51 --> Helper loaded: util_helper
INFO - 2021-03-24 21:31:51 --> Loader Class Initialized
INFO - 2021-03-24 21:31:51 --> Helper loaded: url_helper
INFO - 2021-03-24 21:31:51 --> Config Class Initialized
INFO - 2021-03-24 21:31:51 --> Helper loaded: form_helper
INFO - 2021-03-24 21:31:51 --> Hooks Class Initialized
INFO - 2021-03-24 21:31:51 --> Helper loaded: common_helper
INFO - 2021-03-24 21:31:51 --> Helper loaded: util_helper
INFO - 2021-03-24 21:31:51 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:31:51 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:31:51 --> Utf8 Class Initialized
INFO - 2021-03-24 21:31:51 --> URI Class Initialized
DEBUG - 2021-03-24 21:31:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:31:51 --> Router Class Initialized
INFO - 2021-03-24 21:31:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:31:51 --> Form Validation Class Initialized
INFO - 2021-03-24 21:31:51 --> Output Class Initialized
INFO - 2021-03-24 21:31:51 --> Database Driver Class Initialized
INFO - 2021-03-24 21:31:51 --> Controller Class Initialized
INFO - 2021-03-24 21:31:51 --> Security Class Initialized
INFO - 2021-03-24 21:31:51 --> Model Class Initialized
INFO - 2021-03-24 21:31:51 --> Model Class Initialized
DEBUG - 2021-03-24 21:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:31:51 --> Input Class Initialized
INFO - 2021-03-24 21:31:51 --> Model Class Initialized
DEBUG - 2021-03-24 21:31:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:31:51 --> Language Class Initialized
INFO - 2021-03-24 21:31:51 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:31:51 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:31:51 --> Loader Class Initialized
INFO - 2021-03-24 21:31:51 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:31:51 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:31:51 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:31:51 --> Helper loaded: url_helper
INFO - 2021-03-24 21:31:51 --> Final output sent to browser
DEBUG - 2021-03-24 21:31:51 --> Total execution time: 0.0480
INFO - 2021-03-24 21:31:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:31:51 --> Helper loaded: form_helper
INFO - 2021-03-24 21:31:51 --> Form Validation Class Initialized
INFO - 2021-03-24 21:31:51 --> Helper loaded: common_helper
INFO - 2021-03-24 21:31:51 --> Controller Class Initialized
INFO - 2021-03-24 21:31:51 --> Helper loaded: util_helper
INFO - 2021-03-24 21:31:51 --> Model Class Initialized
INFO - 2021-03-24 21:31:51 --> Model Class Initialized
INFO - 2021-03-24 21:31:51 --> Model Class Initialized
INFO - 2021-03-24 21:31:51 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:31:51 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:31:51 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:31:51 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:31:51 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:31:51 --> Final output sent to browser
INFO - 2021-03-24 21:31:51 --> Config Class Initialized
DEBUG - 2021-03-24 21:31:51 --> Total execution time: 0.0607
INFO - 2021-03-24 21:31:51 --> Hooks Class Initialized
INFO - 2021-03-24 21:31:51 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:31:51 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:31:51 --> Utf8 Class Initialized
INFO - 2021-03-24 21:31:51 --> URI Class Initialized
DEBUG - 2021-03-24 21:31:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:31:51 --> Router Class Initialized
INFO - 2021-03-24 21:31:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:31:51 --> Output Class Initialized
INFO - 2021-03-24 21:31:51 --> Form Validation Class Initialized
INFO - 2021-03-24 21:31:51 --> Controller Class Initialized
INFO - 2021-03-24 21:31:51 --> Model Class Initialized
INFO - 2021-03-24 21:31:51 --> Security Class Initialized
INFO - 2021-03-24 21:31:51 --> Model Class Initialized
INFO - 2021-03-24 21:31:51 --> Model Class Initialized
DEBUG - 2021-03-24 21:31:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:31:51 --> Input Class Initialized
INFO - 2021-03-24 21:31:51 --> Language Class Initialized
INFO - 2021-03-24 21:31:51 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:31:51 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:31:51 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:31:51 --> Loader Class Initialized
INFO - 2021-03-24 21:31:51 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:31:51 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:31:51 --> Final output sent to browser
DEBUG - 2021-03-24 21:31:51 --> Total execution time: 0.0578
INFO - 2021-03-24 21:31:51 --> Helper loaded: url_helper
INFO - 2021-03-24 21:31:51 --> Helper loaded: form_helper
INFO - 2021-03-24 21:31:51 --> Helper loaded: common_helper
INFO - 2021-03-24 21:31:51 --> Helper loaded: util_helper
INFO - 2021-03-24 21:31:51 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:31:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:31:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:31:51 --> Form Validation Class Initialized
INFO - 2021-03-24 21:31:51 --> Controller Class Initialized
INFO - 2021-03-24 21:31:51 --> Model Class Initialized
INFO - 2021-03-24 21:31:51 --> Model Class Initialized
INFO - 2021-03-24 21:31:51 --> Model Class Initialized
INFO - 2021-03-24 21:31:51 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:31:51 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:31:51 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:31:51 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:31:51 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:31:51 --> Final output sent to browser
DEBUG - 2021-03-24 21:31:51 --> Total execution time: 0.0543
INFO - 2021-03-24 21:32:03 --> Config Class Initialized
INFO - 2021-03-24 21:32:03 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:32:03 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:32:03 --> Utf8 Class Initialized
INFO - 2021-03-24 21:32:03 --> URI Class Initialized
INFO - 2021-03-24 21:32:03 --> Router Class Initialized
INFO - 2021-03-24 21:32:03 --> Output Class Initialized
INFO - 2021-03-24 21:32:03 --> Security Class Initialized
DEBUG - 2021-03-24 21:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:32:03 --> Input Class Initialized
INFO - 2021-03-24 21:32:03 --> Language Class Initialized
INFO - 2021-03-24 21:32:03 --> Loader Class Initialized
INFO - 2021-03-24 21:32:03 --> Helper loaded: url_helper
INFO - 2021-03-24 21:32:03 --> Helper loaded: form_helper
INFO - 2021-03-24 21:32:03 --> Helper loaded: common_helper
INFO - 2021-03-24 21:32:03 --> Helper loaded: util_helper
INFO - 2021-03-24 21:32:03 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:32:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:32:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:32:03 --> Form Validation Class Initialized
INFO - 2021-03-24 21:32:03 --> Controller Class Initialized
INFO - 2021-03-24 21:32:03 --> Model Class Initialized
INFO - 2021-03-24 21:32:03 --> Model Class Initialized
INFO - 2021-03-24 21:32:03 --> Model Class Initialized
INFO - 2021-03-24 21:32:03 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:32:03 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:32:03 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/list.php
INFO - 2021-03-24 21:32:03 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:32:03 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:32:03 --> Final output sent to browser
DEBUG - 2021-03-24 21:32:03 --> Total execution time: 0.0355
INFO - 2021-03-24 21:32:03 --> Config Class Initialized
INFO - 2021-03-24 21:32:03 --> Hooks Class Initialized
INFO - 2021-03-24 21:32:03 --> Config Class Initialized
INFO - 2021-03-24 21:32:03 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:32:03 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:32:03 --> Utf8 Class Initialized
INFO - 2021-03-24 21:32:03 --> URI Class Initialized
DEBUG - 2021-03-24 21:32:03 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:32:03 --> Utf8 Class Initialized
INFO - 2021-03-24 21:32:03 --> Router Class Initialized
INFO - 2021-03-24 21:32:03 --> URI Class Initialized
INFO - 2021-03-24 21:32:03 --> Output Class Initialized
INFO - 2021-03-24 21:32:03 --> Router Class Initialized
INFO - 2021-03-24 21:32:03 --> Security Class Initialized
DEBUG - 2021-03-24 21:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:32:03 --> Input Class Initialized
INFO - 2021-03-24 21:32:03 --> Output Class Initialized
INFO - 2021-03-24 21:32:03 --> Language Class Initialized
INFO - 2021-03-24 21:32:03 --> Security Class Initialized
ERROR - 2021-03-24 21:32:03 --> 404 Page Not Found: administrator/Dist/img
DEBUG - 2021-03-24 21:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:32:03 --> Input Class Initialized
INFO - 2021-03-24 21:32:03 --> Language Class Initialized
ERROR - 2021-03-24 21:32:03 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-24 21:32:03 --> Config Class Initialized
INFO - 2021-03-24 21:32:03 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:32:03 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:32:03 --> Utf8 Class Initialized
INFO - 2021-03-24 21:32:03 --> URI Class Initialized
INFO - 2021-03-24 21:32:03 --> Router Class Initialized
INFO - 2021-03-24 21:32:03 --> Config Class Initialized
INFO - 2021-03-24 21:32:03 --> Hooks Class Initialized
INFO - 2021-03-24 21:32:03 --> Output Class Initialized
INFO - 2021-03-24 21:32:03 --> Security Class Initialized
DEBUG - 2021-03-24 21:32:03 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:32:03 --> Utf8 Class Initialized
DEBUG - 2021-03-24 21:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:32:03 --> Input Class Initialized
INFO - 2021-03-24 21:32:03 --> URI Class Initialized
INFO - 2021-03-24 21:32:03 --> Language Class Initialized
INFO - 2021-03-24 21:32:03 --> Router Class Initialized
ERROR - 2021-03-24 21:32:03 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-24 21:32:03 --> Output Class Initialized
INFO - 2021-03-24 21:32:03 --> Security Class Initialized
DEBUG - 2021-03-24 21:32:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:32:03 --> Input Class Initialized
INFO - 2021-03-24 21:32:03 --> Language Class Initialized
ERROR - 2021-03-24 21:32:03 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-24 21:32:30 --> Config Class Initialized
INFO - 2021-03-24 21:32:30 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:32:30 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:32:30 --> Utf8 Class Initialized
INFO - 2021-03-24 21:32:30 --> URI Class Initialized
INFO - 2021-03-24 21:32:30 --> Router Class Initialized
INFO - 2021-03-24 21:32:30 --> Output Class Initialized
INFO - 2021-03-24 21:32:30 --> Security Class Initialized
DEBUG - 2021-03-24 21:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:32:30 --> Input Class Initialized
INFO - 2021-03-24 21:32:30 --> Language Class Initialized
INFO - 2021-03-24 21:32:30 --> Loader Class Initialized
INFO - 2021-03-24 21:32:30 --> Helper loaded: url_helper
INFO - 2021-03-24 21:32:30 --> Helper loaded: form_helper
INFO - 2021-03-24 21:32:30 --> Helper loaded: common_helper
INFO - 2021-03-24 21:32:30 --> Helper loaded: util_helper
INFO - 2021-03-24 21:32:30 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:32:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:32:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:32:30 --> Form Validation Class Initialized
INFO - 2021-03-24 21:32:30 --> Controller Class Initialized
INFO - 2021-03-24 21:32:30 --> Model Class Initialized
INFO - 2021-03-24 21:32:30 --> Model Class Initialized
INFO - 2021-03-24 21:32:30 --> Model Class Initialized
INFO - 2021-03-24 21:32:30 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:32:30 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:32:30 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:32:30 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:32:30 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:32:30 --> Final output sent to browser
DEBUG - 2021-03-24 21:32:30 --> Total execution time: 0.0393
INFO - 2021-03-24 21:32:30 --> Config Class Initialized
INFO - 2021-03-24 21:32:30 --> Hooks Class Initialized
INFO - 2021-03-24 21:32:30 --> Config Class Initialized
DEBUG - 2021-03-24 21:32:30 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:32:30 --> Hooks Class Initialized
INFO - 2021-03-24 21:32:30 --> Utf8 Class Initialized
INFO - 2021-03-24 21:32:30 --> URI Class Initialized
INFO - 2021-03-24 21:32:30 --> Router Class Initialized
DEBUG - 2021-03-24 21:32:30 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:32:30 --> Utf8 Class Initialized
INFO - 2021-03-24 21:32:30 --> Output Class Initialized
INFO - 2021-03-24 21:32:30 --> URI Class Initialized
INFO - 2021-03-24 21:32:30 --> Security Class Initialized
DEBUG - 2021-03-24 21:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:32:30 --> Router Class Initialized
INFO - 2021-03-24 21:32:30 --> Input Class Initialized
INFO - 2021-03-24 21:32:30 --> Language Class Initialized
INFO - 2021-03-24 21:32:30 --> Output Class Initialized
INFO - 2021-03-24 21:32:30 --> Security Class Initialized
INFO - 2021-03-24 21:32:30 --> Loader Class Initialized
DEBUG - 2021-03-24 21:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:32:30 --> Input Class Initialized
INFO - 2021-03-24 21:32:30 --> Helper loaded: url_helper
INFO - 2021-03-24 21:32:30 --> Language Class Initialized
INFO - 2021-03-24 21:32:30 --> Helper loaded: form_helper
INFO - 2021-03-24 21:32:30 --> Helper loaded: common_helper
INFO - 2021-03-24 21:32:30 --> Helper loaded: util_helper
INFO - 2021-03-24 21:32:30 --> Loader Class Initialized
INFO - 2021-03-24 21:32:30 --> Helper loaded: url_helper
INFO - 2021-03-24 21:32:30 --> Helper loaded: form_helper
INFO - 2021-03-24 21:32:30 --> Database Driver Class Initialized
INFO - 2021-03-24 21:32:30 --> Config Class Initialized
INFO - 2021-03-24 21:32:30 --> Helper loaded: common_helper
INFO - 2021-03-24 21:32:30 --> Hooks Class Initialized
INFO - 2021-03-24 21:32:30 --> Helper loaded: util_helper
DEBUG - 2021-03-24 21:32:30 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:32:30 --> Utf8 Class Initialized
DEBUG - 2021-03-24 21:32:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:32:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:32:30 --> URI Class Initialized
INFO - 2021-03-24 21:32:30 --> Form Validation Class Initialized
INFO - 2021-03-24 21:32:30 --> Router Class Initialized
INFO - 2021-03-24 21:32:30 --> Controller Class Initialized
INFO - 2021-03-24 21:32:30 --> Database Driver Class Initialized
INFO - 2021-03-24 21:32:30 --> Model Class Initialized
INFO - 2021-03-24 21:32:30 --> Model Class Initialized
INFO - 2021-03-24 21:32:30 --> Model Class Initialized
INFO - 2021-03-24 21:32:30 --> Output Class Initialized
INFO - 2021-03-24 21:32:30 --> Security Class Initialized
DEBUG - 2021-03-24 21:32:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:32:30 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
DEBUG - 2021-03-24 21:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:32:30 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:32:30 --> Input Class Initialized
INFO - 2021-03-24 21:32:30 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:32:30 --> Language Class Initialized
INFO - 2021-03-24 21:32:30 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:32:30 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:32:30 --> Final output sent to browser
DEBUG - 2021-03-24 21:32:30 --> Total execution time: 0.0462
INFO - 2021-03-24 21:32:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:32:30 --> Loader Class Initialized
INFO - 2021-03-24 21:32:30 --> Form Validation Class Initialized
INFO - 2021-03-24 21:32:30 --> Controller Class Initialized
INFO - 2021-03-24 21:32:30 --> Helper loaded: url_helper
INFO - 2021-03-24 21:32:30 --> Model Class Initialized
INFO - 2021-03-24 21:32:30 --> Model Class Initialized
INFO - 2021-03-24 21:32:30 --> Helper loaded: form_helper
INFO - 2021-03-24 21:32:30 --> Helper loaded: common_helper
INFO - 2021-03-24 21:32:30 --> Model Class Initialized
INFO - 2021-03-24 21:32:30 --> Helper loaded: util_helper
INFO - 2021-03-24 21:32:30 --> Config Class Initialized
INFO - 2021-03-24 21:32:30 --> Hooks Class Initialized
INFO - 2021-03-24 21:32:30 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:32:30 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:32:30 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:32:30 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:32:30 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:32:30 --> Database Driver Class Initialized
INFO - 2021-03-24 21:32:30 --> Final output sent to browser
DEBUG - 2021-03-24 21:32:30 --> Total execution time: 0.0600
DEBUG - 2021-03-24 21:32:30 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:32:30 --> Utf8 Class Initialized
DEBUG - 2021-03-24 21:32:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:32:30 --> URI Class Initialized
INFO - 2021-03-24 21:32:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:32:30 --> Router Class Initialized
INFO - 2021-03-24 21:32:30 --> Form Validation Class Initialized
INFO - 2021-03-24 21:32:30 --> Controller Class Initialized
INFO - 2021-03-24 21:32:30 --> Model Class Initialized
INFO - 2021-03-24 21:32:30 --> Model Class Initialized
INFO - 2021-03-24 21:32:30 --> Model Class Initialized
INFO - 2021-03-24 21:32:30 --> Output Class Initialized
INFO - 2021-03-24 21:32:30 --> Security Class Initialized
INFO - 2021-03-24 21:32:30 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:32:30 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
DEBUG - 2021-03-24 21:32:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:32:30 --> Input Class Initialized
INFO - 2021-03-24 21:32:30 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:32:30 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:32:30 --> Language Class Initialized
INFO - 2021-03-24 21:32:30 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:32:30 --> Final output sent to browser
DEBUG - 2021-03-24 21:32:30 --> Total execution time: 0.0544
INFO - 2021-03-24 21:32:30 --> Loader Class Initialized
INFO - 2021-03-24 21:32:30 --> Helper loaded: url_helper
INFO - 2021-03-24 21:32:30 --> Helper loaded: form_helper
INFO - 2021-03-24 21:32:30 --> Helper loaded: common_helper
INFO - 2021-03-24 21:32:30 --> Helper loaded: util_helper
INFO - 2021-03-24 21:32:30 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:32:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:32:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:32:30 --> Form Validation Class Initialized
INFO - 2021-03-24 21:32:30 --> Controller Class Initialized
INFO - 2021-03-24 21:32:30 --> Model Class Initialized
INFO - 2021-03-24 21:32:30 --> Model Class Initialized
INFO - 2021-03-24 21:32:30 --> Model Class Initialized
INFO - 2021-03-24 21:32:30 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:32:30 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:32:30 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:32:30 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:32:30 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:32:30 --> Final output sent to browser
DEBUG - 2021-03-24 21:32:30 --> Total execution time: 0.0590
INFO - 2021-03-24 21:32:37 --> Config Class Initialized
INFO - 2021-03-24 21:32:37 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:32:37 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:32:37 --> Utf8 Class Initialized
INFO - 2021-03-24 21:32:37 --> URI Class Initialized
INFO - 2021-03-24 21:32:37 --> Router Class Initialized
INFO - 2021-03-24 21:32:37 --> Output Class Initialized
INFO - 2021-03-24 21:32:37 --> Security Class Initialized
DEBUG - 2021-03-24 21:32:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:32:37 --> Input Class Initialized
INFO - 2021-03-24 21:32:37 --> Language Class Initialized
INFO - 2021-03-24 21:32:37 --> Loader Class Initialized
INFO - 2021-03-24 21:32:37 --> Helper loaded: url_helper
INFO - 2021-03-24 21:32:37 --> Helper loaded: form_helper
INFO - 2021-03-24 21:32:37 --> Helper loaded: common_helper
INFO - 2021-03-24 21:32:37 --> Helper loaded: util_helper
INFO - 2021-03-24 21:32:37 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:32:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:32:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:32:37 --> Form Validation Class Initialized
INFO - 2021-03-24 21:32:37 --> Controller Class Initialized
INFO - 2021-03-24 21:32:37 --> Model Class Initialized
INFO - 2021-03-24 21:32:37 --> Model Class Initialized
INFO - 2021-03-24 21:32:37 --> Model Class Initialized
INFO - 2021-03-24 21:32:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-03-24 21:32:37 --> Config Class Initialized
INFO - 2021-03-24 21:32:37 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:32:37 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:32:37 --> Utf8 Class Initialized
INFO - 2021-03-24 21:32:37 --> URI Class Initialized
INFO - 2021-03-24 21:32:37 --> Router Class Initialized
INFO - 2021-03-24 21:32:37 --> Output Class Initialized
INFO - 2021-03-24 21:32:37 --> Security Class Initialized
DEBUG - 2021-03-24 21:32:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:32:37 --> Input Class Initialized
INFO - 2021-03-24 21:32:37 --> Language Class Initialized
INFO - 2021-03-24 21:32:37 --> Loader Class Initialized
INFO - 2021-03-24 21:32:37 --> Helper loaded: url_helper
INFO - 2021-03-24 21:32:37 --> Helper loaded: form_helper
INFO - 2021-03-24 21:32:37 --> Helper loaded: common_helper
INFO - 2021-03-24 21:32:37 --> Helper loaded: util_helper
INFO - 2021-03-24 21:32:37 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:32:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:32:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:32:38 --> Form Validation Class Initialized
INFO - 2021-03-24 21:32:38 --> Controller Class Initialized
INFO - 2021-03-24 21:32:38 --> Model Class Initialized
INFO - 2021-03-24 21:32:38 --> Model Class Initialized
INFO - 2021-03-24 21:32:38 --> Model Class Initialized
INFO - 2021-03-24 21:32:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:32:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:32:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:32:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:32:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:32:38 --> Final output sent to browser
DEBUG - 2021-03-24 21:32:38 --> Total execution time: 0.0505
INFO - 2021-03-24 21:32:38 --> Config Class Initialized
INFO - 2021-03-24 21:32:38 --> Hooks Class Initialized
INFO - 2021-03-24 21:32:38 --> Config Class Initialized
INFO - 2021-03-24 21:32:38 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:32:38 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:32:38 --> Utf8 Class Initialized
DEBUG - 2021-03-24 21:32:38 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:32:38 --> Utf8 Class Initialized
INFO - 2021-03-24 21:32:38 --> URI Class Initialized
INFO - 2021-03-24 21:32:38 --> URI Class Initialized
INFO - 2021-03-24 21:32:38 --> Router Class Initialized
INFO - 2021-03-24 21:32:38 --> Router Class Initialized
INFO - 2021-03-24 21:32:38 --> Output Class Initialized
INFO - 2021-03-24 21:32:38 --> Output Class Initialized
INFO - 2021-03-24 21:32:38 --> Security Class Initialized
DEBUG - 2021-03-24 21:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:32:38 --> Security Class Initialized
INFO - 2021-03-24 21:32:38 --> Input Class Initialized
INFO - 2021-03-24 21:32:38 --> Language Class Initialized
DEBUG - 2021-03-24 21:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:32:38 --> Input Class Initialized
INFO - 2021-03-24 21:32:38 --> Language Class Initialized
INFO - 2021-03-24 21:32:38 --> Loader Class Initialized
INFO - 2021-03-24 21:32:38 --> Helper loaded: url_helper
INFO - 2021-03-24 21:32:38 --> Loader Class Initialized
INFO - 2021-03-24 21:32:38 --> Helper loaded: form_helper
INFO - 2021-03-24 21:32:38 --> Helper loaded: url_helper
INFO - 2021-03-24 21:32:38 --> Helper loaded: common_helper
INFO - 2021-03-24 21:32:38 --> Helper loaded: util_helper
INFO - 2021-03-24 21:32:38 --> Helper loaded: form_helper
INFO - 2021-03-24 21:32:38 --> Helper loaded: common_helper
INFO - 2021-03-24 21:32:38 --> Helper loaded: util_helper
INFO - 2021-03-24 21:32:38 --> Database Driver Class Initialized
INFO - 2021-03-24 21:32:38 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:32:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:32:38 --> Session: Class initialized using 'files' driver.
DEBUG - 2021-03-24 21:32:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:32:38 --> Form Validation Class Initialized
INFO - 2021-03-24 21:32:38 --> Controller Class Initialized
INFO - 2021-03-24 21:32:38 --> Config Class Initialized
INFO - 2021-03-24 21:32:38 --> Hooks Class Initialized
INFO - 2021-03-24 21:32:38 --> Model Class Initialized
INFO - 2021-03-24 21:32:38 --> Model Class Initialized
INFO - 2021-03-24 21:32:38 --> Model Class Initialized
DEBUG - 2021-03-24 21:32:38 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:32:38 --> Utf8 Class Initialized
INFO - 2021-03-24 21:32:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:32:38 --> URI Class Initialized
INFO - 2021-03-24 21:32:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:32:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:32:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:32:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:32:38 --> Router Class Initialized
INFO - 2021-03-24 21:32:38 --> Final output sent to browser
DEBUG - 2021-03-24 21:32:38 --> Total execution time: 0.0473
INFO - 2021-03-24 21:32:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:32:38 --> Output Class Initialized
INFO - 2021-03-24 21:32:38 --> Form Validation Class Initialized
INFO - 2021-03-24 21:32:38 --> Controller Class Initialized
INFO - 2021-03-24 21:32:38 --> Security Class Initialized
INFO - 2021-03-24 21:32:38 --> Model Class Initialized
DEBUG - 2021-03-24 21:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:32:38 --> Input Class Initialized
INFO - 2021-03-24 21:32:38 --> Model Class Initialized
INFO - 2021-03-24 21:32:38 --> Model Class Initialized
INFO - 2021-03-24 21:32:38 --> Language Class Initialized
INFO - 2021-03-24 21:32:38 --> Config Class Initialized
INFO - 2021-03-24 21:32:38 --> Hooks Class Initialized
INFO - 2021-03-24 21:32:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
DEBUG - 2021-03-24 21:32:38 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:32:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:32:38 --> Loader Class Initialized
INFO - 2021-03-24 21:32:38 --> Utf8 Class Initialized
INFO - 2021-03-24 21:32:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:32:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:32:38 --> URI Class Initialized
INFO - 2021-03-24 21:32:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:32:38 --> Helper loaded: url_helper
INFO - 2021-03-24 21:32:38 --> Final output sent to browser
DEBUG - 2021-03-24 21:32:38 --> Total execution time: 0.0588
INFO - 2021-03-24 21:32:38 --> Router Class Initialized
INFO - 2021-03-24 21:32:38 --> Helper loaded: form_helper
INFO - 2021-03-24 21:32:38 --> Helper loaded: common_helper
INFO - 2021-03-24 21:32:38 --> Output Class Initialized
INFO - 2021-03-24 21:32:38 --> Helper loaded: util_helper
INFO - 2021-03-24 21:32:38 --> Security Class Initialized
DEBUG - 2021-03-24 21:32:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:32:38 --> Input Class Initialized
INFO - 2021-03-24 21:32:38 --> Language Class Initialized
INFO - 2021-03-24 21:32:38 --> Database Driver Class Initialized
INFO - 2021-03-24 21:32:38 --> Loader Class Initialized
INFO - 2021-03-24 21:32:38 --> Helper loaded: url_helper
DEBUG - 2021-03-24 21:32:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:32:38 --> Helper loaded: form_helper
INFO - 2021-03-24 21:32:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:32:38 --> Helper loaded: common_helper
INFO - 2021-03-24 21:32:38 --> Helper loaded: util_helper
INFO - 2021-03-24 21:32:38 --> Form Validation Class Initialized
INFO - 2021-03-24 21:32:38 --> Controller Class Initialized
INFO - 2021-03-24 21:32:38 --> Model Class Initialized
INFO - 2021-03-24 21:32:38 --> Model Class Initialized
INFO - 2021-03-24 21:32:38 --> Model Class Initialized
INFO - 2021-03-24 21:32:38 --> Database Driver Class Initialized
INFO - 2021-03-24 21:32:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:32:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:32:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:32:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:32:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
DEBUG - 2021-03-24 21:32:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:32:38 --> Final output sent to browser
DEBUG - 2021-03-24 21:32:38 --> Total execution time: 0.0534
INFO - 2021-03-24 21:32:38 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:32:38 --> Form Validation Class Initialized
INFO - 2021-03-24 21:32:38 --> Controller Class Initialized
INFO - 2021-03-24 21:32:38 --> Model Class Initialized
INFO - 2021-03-24 21:32:38 --> Model Class Initialized
INFO - 2021-03-24 21:32:38 --> Model Class Initialized
INFO - 2021-03-24 21:32:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:32:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:32:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:32:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:32:38 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:32:38 --> Final output sent to browser
DEBUG - 2021-03-24 21:32:38 --> Total execution time: 0.0479
INFO - 2021-03-24 21:32:41 --> Config Class Initialized
INFO - 2021-03-24 21:32:41 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:32:41 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:32:41 --> Utf8 Class Initialized
INFO - 2021-03-24 21:32:41 --> URI Class Initialized
INFO - 2021-03-24 21:32:41 --> Router Class Initialized
INFO - 2021-03-24 21:32:41 --> Output Class Initialized
INFO - 2021-03-24 21:32:41 --> Security Class Initialized
DEBUG - 2021-03-24 21:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:32:41 --> Input Class Initialized
INFO - 2021-03-24 21:32:41 --> Language Class Initialized
INFO - 2021-03-24 21:32:41 --> Loader Class Initialized
INFO - 2021-03-24 21:32:41 --> Helper loaded: url_helper
INFO - 2021-03-24 21:32:41 --> Helper loaded: form_helper
INFO - 2021-03-24 21:32:41 --> Helper loaded: common_helper
INFO - 2021-03-24 21:32:41 --> Helper loaded: util_helper
INFO - 2021-03-24 21:32:41 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:32:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:32:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:32:41 --> Form Validation Class Initialized
INFO - 2021-03-24 21:32:41 --> Controller Class Initialized
INFO - 2021-03-24 21:32:41 --> Model Class Initialized
INFO - 2021-03-24 21:32:41 --> Model Class Initialized
INFO - 2021-03-24 21:32:41 --> Model Class Initialized
INFO - 2021-03-24 21:32:41 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:32:41 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:32:41 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/list.php
INFO - 2021-03-24 21:32:41 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:32:41 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:32:41 --> Final output sent to browser
DEBUG - 2021-03-24 21:32:41 --> Total execution time: 0.0343
INFO - 2021-03-24 21:32:41 --> Config Class Initialized
INFO - 2021-03-24 21:32:41 --> Hooks Class Initialized
INFO - 2021-03-24 21:32:41 --> Config Class Initialized
INFO - 2021-03-24 21:32:41 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:32:41 --> UTF-8 Support Enabled
DEBUG - 2021-03-24 21:32:41 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:32:41 --> Utf8 Class Initialized
INFO - 2021-03-24 21:32:41 --> Utf8 Class Initialized
INFO - 2021-03-24 21:32:41 --> URI Class Initialized
INFO - 2021-03-24 21:32:41 --> URI Class Initialized
INFO - 2021-03-24 21:32:41 --> Router Class Initialized
INFO - 2021-03-24 21:32:41 --> Router Class Initialized
INFO - 2021-03-24 21:32:41 --> Output Class Initialized
INFO - 2021-03-24 21:32:41 --> Output Class Initialized
INFO - 2021-03-24 21:32:41 --> Security Class Initialized
INFO - 2021-03-24 21:32:41 --> Security Class Initialized
DEBUG - 2021-03-24 21:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:32:41 --> Input Class Initialized
INFO - 2021-03-24 21:32:41 --> Language Class Initialized
DEBUG - 2021-03-24 21:32:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-03-24 21:32:41 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-24 21:32:41 --> Config Class Initialized
INFO - 2021-03-24 21:32:41 --> Hooks Class Initialized
INFO - 2021-03-24 21:32:41 --> Input Class Initialized
DEBUG - 2021-03-24 21:32:41 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:32:41 --> Utf8 Class Initialized
INFO - 2021-03-24 21:32:41 --> Language Class Initialized
INFO - 2021-03-24 21:32:41 --> URI Class Initialized
ERROR - 2021-03-24 21:32:41 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-24 21:32:41 --> Config Class Initialized
INFO - 2021-03-24 21:32:41 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:32:41 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:32:41 --> Utf8 Class Initialized
INFO - 2021-03-24 21:32:41 --> Router Class Initialized
INFO - 2021-03-24 21:32:41 --> URI Class Initialized
INFO - 2021-03-24 21:32:41 --> Router Class Initialized
INFO - 2021-03-24 21:32:41 --> Output Class Initialized
INFO - 2021-03-24 21:32:41 --> Output Class Initialized
INFO - 2021-03-24 21:32:41 --> Security Class Initialized
INFO - 2021-03-24 21:32:41 --> Security Class Initialized
DEBUG - 2021-03-24 21:32:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-24 21:32:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:32:41 --> Input Class Initialized
INFO - 2021-03-24 21:32:41 --> Input Class Initialized
INFO - 2021-03-24 21:32:41 --> Language Class Initialized
INFO - 2021-03-24 21:32:41 --> Language Class Initialized
ERROR - 2021-03-24 21:32:41 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-03-24 21:32:41 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-24 21:37:58 --> Config Class Initialized
INFO - 2021-03-24 21:37:58 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:37:58 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:37:58 --> Utf8 Class Initialized
INFO - 2021-03-24 21:37:58 --> URI Class Initialized
INFO - 2021-03-24 21:37:58 --> Router Class Initialized
INFO - 2021-03-24 21:37:58 --> Output Class Initialized
INFO - 2021-03-24 21:37:58 --> Security Class Initialized
DEBUG - 2021-03-24 21:37:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:37:58 --> Input Class Initialized
INFO - 2021-03-24 21:37:58 --> Language Class Initialized
INFO - 2021-03-24 21:37:58 --> Loader Class Initialized
INFO - 2021-03-24 21:37:58 --> Helper loaded: url_helper
INFO - 2021-03-24 21:37:58 --> Helper loaded: form_helper
INFO - 2021-03-24 21:37:58 --> Helper loaded: common_helper
INFO - 2021-03-24 21:37:58 --> Helper loaded: util_helper
INFO - 2021-03-24 21:37:58 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:37:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:37:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:37:58 --> Form Validation Class Initialized
INFO - 2021-03-24 21:37:58 --> Controller Class Initialized
INFO - 2021-03-24 21:37:58 --> Model Class Initialized
INFO - 2021-03-24 21:37:58 --> Model Class Initialized
INFO - 2021-03-24 21:37:58 --> Model Class Initialized
INFO - 2021-03-24 21:37:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:37:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:37:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:37:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:37:58 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:37:58 --> Final output sent to browser
DEBUG - 2021-03-24 21:37:58 --> Total execution time: 0.0503
INFO - 2021-03-24 21:37:59 --> Config Class Initialized
INFO - 2021-03-24 21:37:59 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:37:59 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:37:59 --> Utf8 Class Initialized
INFO - 2021-03-24 21:37:59 --> URI Class Initialized
INFO - 2021-03-24 21:37:59 --> Config Class Initialized
INFO - 2021-03-24 21:37:59 --> Router Class Initialized
INFO - 2021-03-24 21:37:59 --> Hooks Class Initialized
INFO - 2021-03-24 21:37:59 --> Output Class Initialized
INFO - 2021-03-24 21:37:59 --> Security Class Initialized
DEBUG - 2021-03-24 21:37:59 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:37:59 --> Utf8 Class Initialized
DEBUG - 2021-03-24 21:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:37:59 --> Input Class Initialized
INFO - 2021-03-24 21:37:59 --> URI Class Initialized
INFO - 2021-03-24 21:37:59 --> Language Class Initialized
INFO - 2021-03-24 21:37:59 --> Router Class Initialized
INFO - 2021-03-24 21:37:59 --> Output Class Initialized
INFO - 2021-03-24 21:37:59 --> Loader Class Initialized
INFO - 2021-03-24 21:37:59 --> Helper loaded: url_helper
INFO - 2021-03-24 21:37:59 --> Security Class Initialized
DEBUG - 2021-03-24 21:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:37:59 --> Helper loaded: form_helper
INFO - 2021-03-24 21:37:59 --> Input Class Initialized
INFO - 2021-03-24 21:37:59 --> Language Class Initialized
INFO - 2021-03-24 21:37:59 --> Helper loaded: common_helper
INFO - 2021-03-24 21:37:59 --> Helper loaded: util_helper
INFO - 2021-03-24 21:37:59 --> Loader Class Initialized
INFO - 2021-03-24 21:37:59 --> Helper loaded: url_helper
INFO - 2021-03-24 21:37:59 --> Helper loaded: form_helper
INFO - 2021-03-24 21:37:59 --> Database Driver Class Initialized
INFO - 2021-03-24 21:37:59 --> Helper loaded: common_helper
INFO - 2021-03-24 21:37:59 --> Helper loaded: util_helper
INFO - 2021-03-24 21:37:59 --> Config Class Initialized
INFO - 2021-03-24 21:37:59 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:37:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-03-24 21:37:59 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:37:59 --> Utf8 Class Initialized
INFO - 2021-03-24 21:37:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:37:59 --> URI Class Initialized
INFO - 2021-03-24 21:37:59 --> Form Validation Class Initialized
INFO - 2021-03-24 21:37:59 --> Controller Class Initialized
INFO - 2021-03-24 21:37:59 --> Database Driver Class Initialized
INFO - 2021-03-24 21:37:59 --> Router Class Initialized
INFO - 2021-03-24 21:37:59 --> Model Class Initialized
INFO - 2021-03-24 21:37:59 --> Model Class Initialized
INFO - 2021-03-24 21:37:59 --> Model Class Initialized
INFO - 2021-03-24 21:37:59 --> Output Class Initialized
DEBUG - 2021-03-24 21:37:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:37:59 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:37:59 --> Security Class Initialized
INFO - 2021-03-24 21:37:59 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:37:59 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
DEBUG - 2021-03-24 21:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:37:59 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:37:59 --> Input Class Initialized
INFO - 2021-03-24 21:37:59 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:37:59 --> Final output sent to browser
INFO - 2021-03-24 21:37:59 --> Config Class Initialized
DEBUG - 2021-03-24 21:37:59 --> Total execution time: 0.0519
INFO - 2021-03-24 21:37:59 --> Hooks Class Initialized
INFO - 2021-03-24 21:37:59 --> Language Class Initialized
INFO - 2021-03-24 21:37:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:37:59 --> Form Validation Class Initialized
INFO - 2021-03-24 21:37:59 --> Controller Class Initialized
DEBUG - 2021-03-24 21:37:59 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:37:59 --> Utf8 Class Initialized
INFO - 2021-03-24 21:37:59 --> Model Class Initialized
INFO - 2021-03-24 21:37:59 --> Loader Class Initialized
INFO - 2021-03-24 21:37:59 --> Model Class Initialized
INFO - 2021-03-24 21:37:59 --> URI Class Initialized
INFO - 2021-03-24 21:37:59 --> Model Class Initialized
INFO - 2021-03-24 21:37:59 --> Helper loaded: url_helper
INFO - 2021-03-24 21:37:59 --> Router Class Initialized
INFO - 2021-03-24 21:37:59 --> Helper loaded: form_helper
INFO - 2021-03-24 21:37:59 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:37:59 --> Helper loaded: common_helper
INFO - 2021-03-24 21:37:59 --> Helper loaded: util_helper
INFO - 2021-03-24 21:37:59 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:37:59 --> Output Class Initialized
INFO - 2021-03-24 21:37:59 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:37:59 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:37:59 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:37:59 --> Security Class Initialized
INFO - 2021-03-24 21:37:59 --> Final output sent to browser
DEBUG - 2021-03-24 21:37:59 --> Total execution time: 0.0641
DEBUG - 2021-03-24 21:37:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:37:59 --> Input Class Initialized
INFO - 2021-03-24 21:37:59 --> Language Class Initialized
INFO - 2021-03-24 21:37:59 --> Database Driver Class Initialized
INFO - 2021-03-24 21:37:59 --> Loader Class Initialized
INFO - 2021-03-24 21:37:59 --> Helper loaded: url_helper
DEBUG - 2021-03-24 21:37:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:37:59 --> Helper loaded: form_helper
INFO - 2021-03-24 21:37:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:37:59 --> Helper loaded: common_helper
INFO - 2021-03-24 21:37:59 --> Helper loaded: util_helper
INFO - 2021-03-24 21:37:59 --> Form Validation Class Initialized
INFO - 2021-03-24 21:37:59 --> Controller Class Initialized
INFO - 2021-03-24 21:37:59 --> Model Class Initialized
INFO - 2021-03-24 21:37:59 --> Model Class Initialized
INFO - 2021-03-24 21:37:59 --> Model Class Initialized
INFO - 2021-03-24 21:37:59 --> Database Driver Class Initialized
INFO - 2021-03-24 21:37:59 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:37:59 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:37:59 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:37:59 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:37:59 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:37:59 --> Final output sent to browser
DEBUG - 2021-03-24 21:37:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-03-24 21:37:59 --> Total execution time: 0.0537
INFO - 2021-03-24 21:37:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:37:59 --> Form Validation Class Initialized
INFO - 2021-03-24 21:37:59 --> Controller Class Initialized
INFO - 2021-03-24 21:37:59 --> Model Class Initialized
INFO - 2021-03-24 21:37:59 --> Model Class Initialized
INFO - 2021-03-24 21:37:59 --> Model Class Initialized
INFO - 2021-03-24 21:37:59 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:37:59 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:37:59 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/edit.php
INFO - 2021-03-24 21:37:59 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:37:59 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:37:59 --> Final output sent to browser
DEBUG - 2021-03-24 21:37:59 --> Total execution time: 0.0638
INFO - 2021-03-24 21:38:01 --> Config Class Initialized
INFO - 2021-03-24 21:38:01 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:38:01 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:38:01 --> Utf8 Class Initialized
INFO - 2021-03-24 21:38:01 --> URI Class Initialized
INFO - 2021-03-24 21:38:01 --> Router Class Initialized
INFO - 2021-03-24 21:38:01 --> Output Class Initialized
INFO - 2021-03-24 21:38:01 --> Security Class Initialized
DEBUG - 2021-03-24 21:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:38:01 --> Input Class Initialized
INFO - 2021-03-24 21:38:01 --> Language Class Initialized
INFO - 2021-03-24 21:38:01 --> Loader Class Initialized
INFO - 2021-03-24 21:38:01 --> Helper loaded: url_helper
INFO - 2021-03-24 21:38:01 --> Helper loaded: form_helper
INFO - 2021-03-24 21:38:01 --> Helper loaded: common_helper
INFO - 2021-03-24 21:38:01 --> Helper loaded: util_helper
INFO - 2021-03-24 21:38:01 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:38:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:38:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:38:01 --> Form Validation Class Initialized
INFO - 2021-03-24 21:38:01 --> Controller Class Initialized
INFO - 2021-03-24 21:38:01 --> Model Class Initialized
INFO - 2021-03-24 21:38:01 --> Model Class Initialized
INFO - 2021-03-24 21:38:01 --> Model Class Initialized
INFO - 2021-03-24 21:38:01 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:38:01 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:38:01 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/list.php
INFO - 2021-03-24 21:38:01 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:38:01 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:38:01 --> Final output sent to browser
DEBUG - 2021-03-24 21:38:01 --> Total execution time: 0.0368
INFO - 2021-03-24 21:44:19 --> Config Class Initialized
INFO - 2021-03-24 21:44:19 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:44:19 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:44:19 --> Utf8 Class Initialized
INFO - 2021-03-24 21:44:19 --> URI Class Initialized
INFO - 2021-03-24 21:44:19 --> Router Class Initialized
INFO - 2021-03-24 21:44:19 --> Output Class Initialized
INFO - 2021-03-24 21:44:19 --> Security Class Initialized
DEBUG - 2021-03-24 21:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:44:19 --> Input Class Initialized
INFO - 2021-03-24 21:44:19 --> Language Class Initialized
INFO - 2021-03-24 21:44:19 --> Loader Class Initialized
INFO - 2021-03-24 21:44:19 --> Helper loaded: url_helper
INFO - 2021-03-24 21:44:19 --> Helper loaded: form_helper
INFO - 2021-03-24 21:44:19 --> Helper loaded: common_helper
INFO - 2021-03-24 21:44:19 --> Helper loaded: util_helper
INFO - 2021-03-24 21:44:19 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:44:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:44:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:44:19 --> Form Validation Class Initialized
INFO - 2021-03-24 21:44:19 --> Controller Class Initialized
INFO - 2021-03-24 21:44:19 --> Model Class Initialized
INFO - 2021-03-24 21:44:19 --> Model Class Initialized
INFO - 2021-03-24 21:44:19 --> Model Class Initialized
INFO - 2021-03-24 21:44:19 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:44:19 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:44:19 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/list.php
INFO - 2021-03-24 21:44:19 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:44:19 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:44:19 --> Final output sent to browser
DEBUG - 2021-03-24 21:44:19 --> Total execution time: 0.0388
INFO - 2021-03-24 21:44:19 --> Config Class Initialized
INFO - 2021-03-24 21:44:19 --> Hooks Class Initialized
INFO - 2021-03-24 21:44:19 --> Config Class Initialized
INFO - 2021-03-24 21:44:19 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:44:19 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:44:19 --> Utf8 Class Initialized
DEBUG - 2021-03-24 21:44:19 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:44:19 --> Utf8 Class Initialized
INFO - 2021-03-24 21:44:19 --> URI Class Initialized
INFO - 2021-03-24 21:44:19 --> URI Class Initialized
INFO - 2021-03-24 21:44:19 --> Router Class Initialized
INFO - 2021-03-24 21:44:19 --> Output Class Initialized
INFO - 2021-03-24 21:44:19 --> Security Class Initialized
INFO - 2021-03-24 21:44:19 --> Router Class Initialized
DEBUG - 2021-03-24 21:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:44:19 --> Input Class Initialized
INFO - 2021-03-24 21:44:19 --> Language Class Initialized
INFO - 2021-03-24 21:44:19 --> Output Class Initialized
ERROR - 2021-03-24 21:44:19 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-24 21:44:19 --> Security Class Initialized
DEBUG - 2021-03-24 21:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:44:19 --> Input Class Initialized
INFO - 2021-03-24 21:44:19 --> Language Class Initialized
ERROR - 2021-03-24 21:44:19 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-24 21:44:19 --> Config Class Initialized
INFO - 2021-03-24 21:44:19 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:44:19 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:44:19 --> Utf8 Class Initialized
INFO - 2021-03-24 21:44:19 --> Config Class Initialized
INFO - 2021-03-24 21:44:19 --> URI Class Initialized
INFO - 2021-03-24 21:44:19 --> Hooks Class Initialized
INFO - 2021-03-24 21:44:19 --> Router Class Initialized
DEBUG - 2021-03-24 21:44:19 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:44:19 --> Utf8 Class Initialized
INFO - 2021-03-24 21:44:19 --> Output Class Initialized
INFO - 2021-03-24 21:44:19 --> URI Class Initialized
INFO - 2021-03-24 21:44:19 --> Security Class Initialized
INFO - 2021-03-24 21:44:19 --> Router Class Initialized
DEBUG - 2021-03-24 21:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:44:19 --> Input Class Initialized
INFO - 2021-03-24 21:44:19 --> Language Class Initialized
INFO - 2021-03-24 21:44:19 --> Output Class Initialized
INFO - 2021-03-24 21:44:19 --> Security Class Initialized
ERROR - 2021-03-24 21:44:19 --> 404 Page Not Found: administrator/Dist/img
DEBUG - 2021-03-24 21:44:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:44:19 --> Input Class Initialized
INFO - 2021-03-24 21:44:19 --> Language Class Initialized
ERROR - 2021-03-24 21:44:19 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-24 21:44:25 --> Config Class Initialized
INFO - 2021-03-24 21:44:25 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:44:25 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:44:25 --> Utf8 Class Initialized
INFO - 2021-03-24 21:44:25 --> URI Class Initialized
INFO - 2021-03-24 21:44:25 --> Router Class Initialized
INFO - 2021-03-24 21:44:25 --> Output Class Initialized
INFO - 2021-03-24 21:44:25 --> Security Class Initialized
DEBUG - 2021-03-24 21:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:44:25 --> Input Class Initialized
INFO - 2021-03-24 21:44:25 --> Language Class Initialized
INFO - 2021-03-24 21:44:25 --> Loader Class Initialized
INFO - 2021-03-24 21:44:25 --> Helper loaded: url_helper
INFO - 2021-03-24 21:44:25 --> Helper loaded: form_helper
INFO - 2021-03-24 21:44:25 --> Helper loaded: common_helper
INFO - 2021-03-24 21:44:25 --> Helper loaded: util_helper
INFO - 2021-03-24 21:44:25 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:44:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:44:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:44:25 --> Form Validation Class Initialized
INFO - 2021-03-24 21:44:25 --> Controller Class Initialized
INFO - 2021-03-24 21:44:25 --> Model Class Initialized
INFO - 2021-03-24 21:44:25 --> Model Class Initialized
INFO - 2021-03-24 21:44:25 --> Model Class Initialized
INFO - 2021-03-24 21:44:25 --> Config Class Initialized
INFO - 2021-03-24 21:44:25 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:44:25 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:44:25 --> Utf8 Class Initialized
INFO - 2021-03-24 21:44:25 --> URI Class Initialized
INFO - 2021-03-24 21:44:25 --> Router Class Initialized
INFO - 2021-03-24 21:44:25 --> Output Class Initialized
INFO - 2021-03-24 21:44:25 --> Security Class Initialized
DEBUG - 2021-03-24 21:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:44:25 --> Input Class Initialized
INFO - 2021-03-24 21:44:25 --> Language Class Initialized
INFO - 2021-03-24 21:44:25 --> Loader Class Initialized
INFO - 2021-03-24 21:44:25 --> Helper loaded: url_helper
INFO - 2021-03-24 21:44:25 --> Helper loaded: form_helper
INFO - 2021-03-24 21:44:25 --> Helper loaded: common_helper
INFO - 2021-03-24 21:44:25 --> Helper loaded: util_helper
INFO - 2021-03-24 21:44:25 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:44:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:44:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:44:25 --> Form Validation Class Initialized
INFO - 2021-03-24 21:44:25 --> Controller Class Initialized
INFO - 2021-03-24 21:44:25 --> Model Class Initialized
INFO - 2021-03-24 21:44:25 --> Model Class Initialized
INFO - 2021-03-24 21:44:25 --> Model Class Initialized
INFO - 2021-03-24 21:44:25 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:44:25 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:44:25 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/list.php
INFO - 2021-03-24 21:44:25 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:44:25 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:44:25 --> Final output sent to browser
DEBUG - 2021-03-24 21:44:25 --> Total execution time: 0.0366
INFO - 2021-03-24 21:44:25 --> Config Class Initialized
INFO - 2021-03-24 21:44:25 --> Hooks Class Initialized
INFO - 2021-03-24 21:44:25 --> Config Class Initialized
INFO - 2021-03-24 21:44:25 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:44:25 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:44:25 --> Utf8 Class Initialized
INFO - 2021-03-24 21:44:25 --> URI Class Initialized
DEBUG - 2021-03-24 21:44:25 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:44:25 --> Utf8 Class Initialized
INFO - 2021-03-24 21:44:25 --> Router Class Initialized
INFO - 2021-03-24 21:44:25 --> URI Class Initialized
INFO - 2021-03-24 21:44:25 --> Output Class Initialized
INFO - 2021-03-24 21:44:25 --> Router Class Initialized
INFO - 2021-03-24 21:44:25 --> Security Class Initialized
INFO - 2021-03-24 21:44:25 --> Output Class Initialized
DEBUG - 2021-03-24 21:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:44:25 --> Input Class Initialized
INFO - 2021-03-24 21:44:25 --> Language Class Initialized
INFO - 2021-03-24 21:44:25 --> Security Class Initialized
ERROR - 2021-03-24 21:44:25 --> 404 Page Not Found: administrator/Dist/img
DEBUG - 2021-03-24 21:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:44:25 --> Input Class Initialized
INFO - 2021-03-24 21:44:25 --> Language Class Initialized
INFO - 2021-03-24 21:44:25 --> Config Class Initialized
INFO - 2021-03-24 21:44:25 --> Hooks Class Initialized
ERROR - 2021-03-24 21:44:25 --> 404 Page Not Found: administrator/Dist/img
DEBUG - 2021-03-24 21:44:25 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:44:25 --> Utf8 Class Initialized
INFO - 2021-03-24 21:44:25 --> URI Class Initialized
INFO - 2021-03-24 21:44:25 --> Config Class Initialized
INFO - 2021-03-24 21:44:25 --> Hooks Class Initialized
INFO - 2021-03-24 21:44:25 --> Router Class Initialized
DEBUG - 2021-03-24 21:44:25 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:44:25 --> Utf8 Class Initialized
INFO - 2021-03-24 21:44:25 --> Output Class Initialized
INFO - 2021-03-24 21:44:25 --> URI Class Initialized
INFO - 2021-03-24 21:44:25 --> Router Class Initialized
INFO - 2021-03-24 21:44:25 --> Security Class Initialized
DEBUG - 2021-03-24 21:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:44:25 --> Input Class Initialized
INFO - 2021-03-24 21:44:25 --> Output Class Initialized
INFO - 2021-03-24 21:44:25 --> Language Class Initialized
INFO - 2021-03-24 21:44:25 --> Security Class Initialized
ERROR - 2021-03-24 21:44:25 --> 404 Page Not Found: administrator/Dist/img
DEBUG - 2021-03-24 21:44:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:44:25 --> Input Class Initialized
INFO - 2021-03-24 21:44:25 --> Language Class Initialized
ERROR - 2021-03-24 21:44:25 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-24 21:49:53 --> Config Class Initialized
INFO - 2021-03-24 21:49:53 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:49:53 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:49:53 --> Utf8 Class Initialized
INFO - 2021-03-24 21:49:53 --> URI Class Initialized
INFO - 2021-03-24 21:49:53 --> Router Class Initialized
INFO - 2021-03-24 21:49:53 --> Output Class Initialized
INFO - 2021-03-24 21:49:53 --> Security Class Initialized
DEBUG - 2021-03-24 21:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:49:53 --> Input Class Initialized
INFO - 2021-03-24 21:49:53 --> Language Class Initialized
INFO - 2021-03-24 21:49:53 --> Loader Class Initialized
INFO - 2021-03-24 21:49:53 --> Helper loaded: url_helper
INFO - 2021-03-24 21:49:53 --> Helper loaded: form_helper
INFO - 2021-03-24 21:49:53 --> Helper loaded: common_helper
INFO - 2021-03-24 21:49:53 --> Helper loaded: util_helper
INFO - 2021-03-24 21:49:53 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:49:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:49:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:49:53 --> Form Validation Class Initialized
INFO - 2021-03-24 21:49:53 --> Controller Class Initialized
INFO - 2021-03-24 21:49:53 --> Model Class Initialized
INFO - 2021-03-24 21:49:53 --> Model Class Initialized
INFO - 2021-03-24 21:49:53 --> Model Class Initialized
INFO - 2021-03-24 21:49:53 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:49:53 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:49:53 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/list.php
INFO - 2021-03-24 21:49:53 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:49:53 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:49:53 --> Final output sent to browser
DEBUG - 2021-03-24 21:49:53 --> Total execution time: 0.0513
INFO - 2021-03-24 21:49:53 --> Config Class Initialized
INFO - 2021-03-24 21:49:53 --> Hooks Class Initialized
INFO - 2021-03-24 21:49:53 --> Config Class Initialized
INFO - 2021-03-24 21:49:53 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:49:53 --> UTF-8 Support Enabled
DEBUG - 2021-03-24 21:49:53 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:49:53 --> Utf8 Class Initialized
INFO - 2021-03-24 21:49:53 --> Utf8 Class Initialized
INFO - 2021-03-24 21:49:53 --> URI Class Initialized
INFO - 2021-03-24 21:49:53 --> URI Class Initialized
INFO - 2021-03-24 21:49:53 --> Router Class Initialized
INFO - 2021-03-24 21:49:53 --> Router Class Initialized
INFO - 2021-03-24 21:49:53 --> Output Class Initialized
INFO - 2021-03-24 21:49:53 --> Output Class Initialized
INFO - 2021-03-24 21:49:53 --> Security Class Initialized
INFO - 2021-03-24 21:49:53 --> Security Class Initialized
DEBUG - 2021-03-24 21:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:49:53 --> Input Class Initialized
INFO - 2021-03-24 21:49:53 --> Language Class Initialized
DEBUG - 2021-03-24 21:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:49:53 --> Input Class Initialized
ERROR - 2021-03-24 21:49:53 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-24 21:49:53 --> Language Class Initialized
ERROR - 2021-03-24 21:49:53 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-24 21:49:53 --> Config Class Initialized
INFO - 2021-03-24 21:49:53 --> Hooks Class Initialized
INFO - 2021-03-24 21:49:53 --> Config Class Initialized
INFO - 2021-03-24 21:49:53 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:49:53 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:49:53 --> Utf8 Class Initialized
INFO - 2021-03-24 21:49:53 --> URI Class Initialized
DEBUG - 2021-03-24 21:49:53 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:49:53 --> Utf8 Class Initialized
INFO - 2021-03-24 21:49:53 --> Router Class Initialized
INFO - 2021-03-24 21:49:53 --> URI Class Initialized
INFO - 2021-03-24 21:49:53 --> Output Class Initialized
INFO - 2021-03-24 21:49:53 --> Router Class Initialized
INFO - 2021-03-24 21:49:53 --> Security Class Initialized
INFO - 2021-03-24 21:49:53 --> Output Class Initialized
DEBUG - 2021-03-24 21:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:49:53 --> Input Class Initialized
INFO - 2021-03-24 21:49:53 --> Security Class Initialized
INFO - 2021-03-24 21:49:53 --> Language Class Initialized
DEBUG - 2021-03-24 21:49:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:49:53 --> Input Class Initialized
ERROR - 2021-03-24 21:49:53 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-24 21:49:53 --> Language Class Initialized
ERROR - 2021-03-24 21:49:53 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-24 21:51:19 --> Config Class Initialized
INFO - 2021-03-24 21:51:19 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:51:19 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:51:19 --> Utf8 Class Initialized
INFO - 2021-03-24 21:51:19 --> URI Class Initialized
INFO - 2021-03-24 21:51:19 --> Router Class Initialized
INFO - 2021-03-24 21:51:19 --> Output Class Initialized
INFO - 2021-03-24 21:51:19 --> Security Class Initialized
DEBUG - 2021-03-24 21:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:51:19 --> Input Class Initialized
INFO - 2021-03-24 21:51:19 --> Language Class Initialized
INFO - 2021-03-24 21:51:19 --> Loader Class Initialized
INFO - 2021-03-24 21:51:19 --> Helper loaded: url_helper
INFO - 2021-03-24 21:51:19 --> Helper loaded: form_helper
INFO - 2021-03-24 21:51:19 --> Helper loaded: common_helper
INFO - 2021-03-24 21:51:19 --> Helper loaded: util_helper
INFO - 2021-03-24 21:51:19 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:51:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:51:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:51:19 --> Form Validation Class Initialized
INFO - 2021-03-24 21:51:19 --> Controller Class Initialized
INFO - 2021-03-24 21:51:19 --> Model Class Initialized
INFO - 2021-03-24 21:51:19 --> Model Class Initialized
INFO - 2021-03-24 21:51:19 --> Model Class Initialized
INFO - 2021-03-24 21:51:19 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:51:19 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:51:19 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/user/list.php
INFO - 2021-03-24 21:51:19 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:51:19 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:51:19 --> Final output sent to browser
DEBUG - 2021-03-24 21:51:19 --> Total execution time: 0.0460
INFO - 2021-03-24 21:51:19 --> Config Class Initialized
INFO - 2021-03-24 21:51:19 --> Hooks Class Initialized
INFO - 2021-03-24 21:51:19 --> Config Class Initialized
INFO - 2021-03-24 21:51:19 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:51:19 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:51:19 --> Utf8 Class Initialized
DEBUG - 2021-03-24 21:51:19 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:51:19 --> Utf8 Class Initialized
INFO - 2021-03-24 21:51:19 --> URI Class Initialized
INFO - 2021-03-24 21:51:19 --> URI Class Initialized
INFO - 2021-03-24 21:51:19 --> Router Class Initialized
INFO - 2021-03-24 21:51:19 --> Output Class Initialized
INFO - 2021-03-24 21:51:19 --> Router Class Initialized
INFO - 2021-03-24 21:51:19 --> Security Class Initialized
INFO - 2021-03-24 21:51:19 --> Output Class Initialized
DEBUG - 2021-03-24 21:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:51:19 --> Input Class Initialized
INFO - 2021-03-24 21:51:19 --> Security Class Initialized
INFO - 2021-03-24 21:51:19 --> Language Class Initialized
ERROR - 2021-03-24 21:51:19 --> 404 Page Not Found: administrator/Dist/img
DEBUG - 2021-03-24 21:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:51:19 --> Input Class Initialized
INFO - 2021-03-24 21:51:19 --> Language Class Initialized
INFO - 2021-03-24 21:51:19 --> Config Class Initialized
INFO - 2021-03-24 21:51:19 --> Hooks Class Initialized
ERROR - 2021-03-24 21:51:19 --> 404 Page Not Found: administrator/Dist/img
DEBUG - 2021-03-24 21:51:19 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:51:19 --> Utf8 Class Initialized
INFO - 2021-03-24 21:51:19 --> Config Class Initialized
INFO - 2021-03-24 21:51:19 --> Hooks Class Initialized
INFO - 2021-03-24 21:51:19 --> URI Class Initialized
INFO - 2021-03-24 21:51:19 --> Router Class Initialized
INFO - 2021-03-24 21:51:19 --> Output Class Initialized
DEBUG - 2021-03-24 21:51:19 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:51:19 --> Utf8 Class Initialized
INFO - 2021-03-24 21:51:19 --> Security Class Initialized
INFO - 2021-03-24 21:51:19 --> URI Class Initialized
DEBUG - 2021-03-24 21:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:51:19 --> Input Class Initialized
INFO - 2021-03-24 21:51:19 --> Router Class Initialized
INFO - 2021-03-24 21:51:19 --> Language Class Initialized
INFO - 2021-03-24 21:51:19 --> Output Class Initialized
ERROR - 2021-03-24 21:51:19 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-24 21:51:19 --> Security Class Initialized
DEBUG - 2021-03-24 21:51:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:51:19 --> Input Class Initialized
INFO - 2021-03-24 21:51:19 --> Language Class Initialized
ERROR - 2021-03-24 21:51:19 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-24 21:51:43 --> Config Class Initialized
INFO - 2021-03-24 21:51:43 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:51:43 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:51:43 --> Utf8 Class Initialized
INFO - 2021-03-24 21:51:43 --> URI Class Initialized
INFO - 2021-03-24 21:51:43 --> Router Class Initialized
INFO - 2021-03-24 21:51:43 --> Output Class Initialized
INFO - 2021-03-24 21:51:43 --> Security Class Initialized
DEBUG - 2021-03-24 21:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:51:43 --> Input Class Initialized
INFO - 2021-03-24 21:51:43 --> Language Class Initialized
INFO - 2021-03-24 21:51:43 --> Loader Class Initialized
INFO - 2021-03-24 21:51:43 --> Helper loaded: url_helper
INFO - 2021-03-24 21:51:43 --> Helper loaded: form_helper
INFO - 2021-03-24 21:51:43 --> Helper loaded: common_helper
INFO - 2021-03-24 21:51:43 --> Helper loaded: util_helper
INFO - 2021-03-24 21:51:43 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:51:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:51:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:51:43 --> Form Validation Class Initialized
INFO - 2021-03-24 21:51:43 --> Controller Class Initialized
INFO - 2021-03-24 21:51:43 --> Model Class Initialized
INFO - 2021-03-24 21:51:43 --> Model Class Initialized
INFO - 2021-03-24 21:51:43 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:51:43 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:51:43 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/role/list.php
INFO - 2021-03-24 21:51:43 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:51:43 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:51:43 --> Final output sent to browser
DEBUG - 2021-03-24 21:51:43 --> Total execution time: 0.0344
INFO - 2021-03-24 21:51:43 --> Config Class Initialized
INFO - 2021-03-24 21:51:43 --> Hooks Class Initialized
INFO - 2021-03-24 21:51:43 --> Config Class Initialized
INFO - 2021-03-24 21:51:43 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:51:43 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:51:43 --> Utf8 Class Initialized
INFO - 2021-03-24 21:51:43 --> URI Class Initialized
DEBUG - 2021-03-24 21:51:43 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:51:43 --> Utf8 Class Initialized
INFO - 2021-03-24 21:51:43 --> URI Class Initialized
INFO - 2021-03-24 21:51:43 --> Router Class Initialized
INFO - 2021-03-24 21:51:43 --> Router Class Initialized
INFO - 2021-03-24 21:51:43 --> Output Class Initialized
INFO - 2021-03-24 21:51:43 --> Output Class Initialized
INFO - 2021-03-24 21:51:43 --> Security Class Initialized
INFO - 2021-03-24 21:51:43 --> Security Class Initialized
DEBUG - 2021-03-24 21:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:51:43 --> Input Class Initialized
INFO - 2021-03-24 21:51:43 --> Language Class Initialized
DEBUG - 2021-03-24 21:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:51:43 --> Input Class Initialized
INFO - 2021-03-24 21:51:43 --> Language Class Initialized
ERROR - 2021-03-24 21:51:43 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-03-24 21:51:43 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-24 21:51:43 --> Config Class Initialized
INFO - 2021-03-24 21:51:43 --> Hooks Class Initialized
INFO - 2021-03-24 21:51:43 --> Config Class Initialized
DEBUG - 2021-03-24 21:51:43 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:51:43 --> Hooks Class Initialized
INFO - 2021-03-24 21:51:43 --> Utf8 Class Initialized
INFO - 2021-03-24 21:51:43 --> URI Class Initialized
DEBUG - 2021-03-24 21:51:43 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:51:43 --> Utf8 Class Initialized
INFO - 2021-03-24 21:51:43 --> Router Class Initialized
INFO - 2021-03-24 21:51:43 --> URI Class Initialized
INFO - 2021-03-24 21:51:43 --> Output Class Initialized
INFO - 2021-03-24 21:51:43 --> Router Class Initialized
INFO - 2021-03-24 21:51:43 --> Security Class Initialized
INFO - 2021-03-24 21:51:43 --> Output Class Initialized
DEBUG - 2021-03-24 21:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:51:43 --> Input Class Initialized
INFO - 2021-03-24 21:51:43 --> Security Class Initialized
INFO - 2021-03-24 21:51:43 --> Language Class Initialized
DEBUG - 2021-03-24 21:51:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:51:43 --> Input Class Initialized
ERROR - 2021-03-24 21:51:43 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-24 21:51:43 --> Language Class Initialized
ERROR - 2021-03-24 21:51:43 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-24 21:51:52 --> Config Class Initialized
INFO - 2021-03-24 21:51:52 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:51:52 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:51:52 --> Utf8 Class Initialized
INFO - 2021-03-24 21:51:52 --> URI Class Initialized
INFO - 2021-03-24 21:51:52 --> Router Class Initialized
INFO - 2021-03-24 21:51:52 --> Output Class Initialized
INFO - 2021-03-24 21:51:52 --> Security Class Initialized
DEBUG - 2021-03-24 21:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:51:52 --> Input Class Initialized
INFO - 2021-03-24 21:51:52 --> Language Class Initialized
INFO - 2021-03-24 21:51:52 --> Loader Class Initialized
INFO - 2021-03-24 21:51:52 --> Helper loaded: url_helper
INFO - 2021-03-24 21:51:52 --> Helper loaded: form_helper
INFO - 2021-03-24 21:51:52 --> Helper loaded: common_helper
INFO - 2021-03-24 21:51:52 --> Helper loaded: util_helper
INFO - 2021-03-24 21:51:52 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:51:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:51:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:51:52 --> Form Validation Class Initialized
INFO - 2021-03-24 21:51:52 --> Controller Class Initialized
INFO - 2021-03-24 21:51:52 --> Model Class Initialized
INFO - 2021-03-24 21:51:52 --> Model Class Initialized
INFO - 2021-03-24 21:51:52 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:51:52 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:51:52 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/role/add.php
INFO - 2021-03-24 21:51:52 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:51:52 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:51:52 --> Final output sent to browser
DEBUG - 2021-03-24 21:51:52 --> Total execution time: 0.0453
INFO - 2021-03-24 21:51:52 --> Config Class Initialized
INFO - 2021-03-24 21:51:52 --> Hooks Class Initialized
INFO - 2021-03-24 21:51:52 --> Config Class Initialized
INFO - 2021-03-24 21:51:52 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:51:52 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:51:52 --> Utf8 Class Initialized
INFO - 2021-03-24 21:51:52 --> URI Class Initialized
DEBUG - 2021-03-24 21:51:52 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:51:52 --> Utf8 Class Initialized
INFO - 2021-03-24 21:51:52 --> Router Class Initialized
INFO - 2021-03-24 21:51:52 --> Output Class Initialized
INFO - 2021-03-24 21:51:52 --> URI Class Initialized
INFO - 2021-03-24 21:51:52 --> Security Class Initialized
INFO - 2021-03-24 21:51:52 --> Router Class Initialized
DEBUG - 2021-03-24 21:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:51:52 --> Input Class Initialized
INFO - 2021-03-24 21:51:52 --> Language Class Initialized
INFO - 2021-03-24 21:51:52 --> Output Class Initialized
ERROR - 2021-03-24 21:51:52 --> 404 Page Not Found: administrator/Role/dist
INFO - 2021-03-24 21:51:52 --> Security Class Initialized
DEBUG - 2021-03-24 21:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:51:52 --> Input Class Initialized
INFO - 2021-03-24 21:51:52 --> Language Class Initialized
ERROR - 2021-03-24 21:51:52 --> 404 Page Not Found: administrator/Role/dist
INFO - 2021-03-24 21:51:52 --> Config Class Initialized
INFO - 2021-03-24 21:51:52 --> Hooks Class Initialized
INFO - 2021-03-24 21:51:52 --> Config Class Initialized
INFO - 2021-03-24 21:51:52 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:51:52 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:51:52 --> Utf8 Class Initialized
INFO - 2021-03-24 21:51:52 --> URI Class Initialized
DEBUG - 2021-03-24 21:51:52 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:51:52 --> Utf8 Class Initialized
INFO - 2021-03-24 21:51:52 --> URI Class Initialized
INFO - 2021-03-24 21:51:52 --> Router Class Initialized
INFO - 2021-03-24 21:51:52 --> Router Class Initialized
INFO - 2021-03-24 21:51:52 --> Output Class Initialized
INFO - 2021-03-24 21:51:52 --> Output Class Initialized
INFO - 2021-03-24 21:51:52 --> Security Class Initialized
INFO - 2021-03-24 21:51:52 --> Security Class Initialized
DEBUG - 2021-03-24 21:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:51:52 --> Input Class Initialized
DEBUG - 2021-03-24 21:51:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:51:52 --> Input Class Initialized
INFO - 2021-03-24 21:51:52 --> Language Class Initialized
INFO - 2021-03-24 21:51:52 --> Language Class Initialized
ERROR - 2021-03-24 21:51:52 --> 404 Page Not Found: administrator/Role/dist
ERROR - 2021-03-24 21:51:52 --> 404 Page Not Found: administrator/Role/dist
INFO - 2021-03-24 21:51:56 --> Config Class Initialized
INFO - 2021-03-24 21:51:56 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:51:56 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:51:56 --> Utf8 Class Initialized
INFO - 2021-03-24 21:51:56 --> URI Class Initialized
INFO - 2021-03-24 21:51:56 --> Router Class Initialized
INFO - 2021-03-24 21:51:56 --> Output Class Initialized
INFO - 2021-03-24 21:51:56 --> Security Class Initialized
DEBUG - 2021-03-24 21:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:51:56 --> Input Class Initialized
INFO - 2021-03-24 21:51:56 --> Language Class Initialized
INFO - 2021-03-24 21:51:56 --> Loader Class Initialized
INFO - 2021-03-24 21:51:56 --> Helper loaded: url_helper
INFO - 2021-03-24 21:51:56 --> Helper loaded: form_helper
INFO - 2021-03-24 21:51:56 --> Helper loaded: common_helper
INFO - 2021-03-24 21:51:56 --> Helper loaded: util_helper
INFO - 2021-03-24 21:51:56 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:51:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:51:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:51:56 --> Form Validation Class Initialized
INFO - 2021-03-24 21:51:56 --> Controller Class Initialized
INFO - 2021-03-24 21:51:56 --> Model Class Initialized
INFO - 2021-03-24 21:51:56 --> Model Class Initialized
INFO - 2021-03-24 21:51:56 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-03-24 21:51:56 --> Config Class Initialized
INFO - 2021-03-24 21:51:56 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:51:56 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:51:56 --> Utf8 Class Initialized
INFO - 2021-03-24 21:51:56 --> URI Class Initialized
INFO - 2021-03-24 21:51:56 --> Router Class Initialized
INFO - 2021-03-24 21:51:56 --> Output Class Initialized
INFO - 2021-03-24 21:51:56 --> Security Class Initialized
DEBUG - 2021-03-24 21:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:51:56 --> Input Class Initialized
INFO - 2021-03-24 21:51:56 --> Language Class Initialized
INFO - 2021-03-24 21:51:56 --> Loader Class Initialized
INFO - 2021-03-24 21:51:56 --> Helper loaded: url_helper
INFO - 2021-03-24 21:51:56 --> Helper loaded: form_helper
INFO - 2021-03-24 21:51:56 --> Helper loaded: common_helper
INFO - 2021-03-24 21:51:56 --> Helper loaded: util_helper
INFO - 2021-03-24 21:51:56 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:51:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:51:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:51:56 --> Form Validation Class Initialized
INFO - 2021-03-24 21:51:56 --> Controller Class Initialized
INFO - 2021-03-24 21:51:56 --> Model Class Initialized
INFO - 2021-03-24 21:51:56 --> Model Class Initialized
INFO - 2021-03-24 21:51:56 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:51:56 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:51:56 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/role/add.php
INFO - 2021-03-24 21:51:56 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:51:56 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:51:56 --> Final output sent to browser
DEBUG - 2021-03-24 21:51:56 --> Total execution time: 0.0341
INFO - 2021-03-24 21:51:56 --> Config Class Initialized
INFO - 2021-03-24 21:51:56 --> Config Class Initialized
INFO - 2021-03-24 21:51:56 --> Hooks Class Initialized
INFO - 2021-03-24 21:51:56 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:51:56 --> UTF-8 Support Enabled
DEBUG - 2021-03-24 21:51:56 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:51:56 --> Utf8 Class Initialized
INFO - 2021-03-24 21:51:56 --> Utf8 Class Initialized
INFO - 2021-03-24 21:51:56 --> URI Class Initialized
INFO - 2021-03-24 21:51:56 --> URI Class Initialized
INFO - 2021-03-24 21:51:56 --> Router Class Initialized
INFO - 2021-03-24 21:51:56 --> Router Class Initialized
INFO - 2021-03-24 21:51:56 --> Output Class Initialized
INFO - 2021-03-24 21:51:56 --> Output Class Initialized
INFO - 2021-03-24 21:51:56 --> Security Class Initialized
INFO - 2021-03-24 21:51:56 --> Security Class Initialized
DEBUG - 2021-03-24 21:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:51:56 --> Input Class Initialized
DEBUG - 2021-03-24 21:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:51:56 --> Input Class Initialized
INFO - 2021-03-24 21:51:56 --> Language Class Initialized
INFO - 2021-03-24 21:51:56 --> Language Class Initialized
ERROR - 2021-03-24 21:51:56 --> 404 Page Not Found: administrator/Role/dist
ERROR - 2021-03-24 21:51:56 --> 404 Page Not Found: administrator/Role/dist
INFO - 2021-03-24 21:51:56 --> Config Class Initialized
INFO - 2021-03-24 21:51:56 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:51:56 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:51:56 --> Utf8 Class Initialized
INFO - 2021-03-24 21:51:56 --> URI Class Initialized
INFO - 2021-03-24 21:51:56 --> Config Class Initialized
INFO - 2021-03-24 21:51:56 --> Hooks Class Initialized
INFO - 2021-03-24 21:51:56 --> Router Class Initialized
DEBUG - 2021-03-24 21:51:56 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:51:56 --> Output Class Initialized
INFO - 2021-03-24 21:51:56 --> Utf8 Class Initialized
INFO - 2021-03-24 21:51:56 --> URI Class Initialized
INFO - 2021-03-24 21:51:56 --> Security Class Initialized
DEBUG - 2021-03-24 21:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:51:56 --> Router Class Initialized
INFO - 2021-03-24 21:51:56 --> Input Class Initialized
INFO - 2021-03-24 21:51:56 --> Language Class Initialized
INFO - 2021-03-24 21:51:56 --> Output Class Initialized
ERROR - 2021-03-24 21:51:56 --> 404 Page Not Found: administrator/Role/dist
INFO - 2021-03-24 21:51:56 --> Security Class Initialized
DEBUG - 2021-03-24 21:51:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:51:56 --> Input Class Initialized
INFO - 2021-03-24 21:51:56 --> Language Class Initialized
ERROR - 2021-03-24 21:51:56 --> 404 Page Not Found: administrator/Role/dist
INFO - 2021-03-24 21:51:59 --> Config Class Initialized
INFO - 2021-03-24 21:51:59 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:51:59 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:51:59 --> Utf8 Class Initialized
INFO - 2021-03-24 21:51:59 --> URI Class Initialized
INFO - 2021-03-24 21:51:59 --> Router Class Initialized
INFO - 2021-03-24 21:51:59 --> Output Class Initialized
INFO - 2021-03-24 21:51:59 --> Security Class Initialized
DEBUG - 2021-03-24 21:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:51:59 --> Input Class Initialized
INFO - 2021-03-24 21:51:59 --> Language Class Initialized
INFO - 2021-03-24 21:51:59 --> Loader Class Initialized
INFO - 2021-03-24 21:51:59 --> Helper loaded: url_helper
INFO - 2021-03-24 21:51:59 --> Helper loaded: form_helper
INFO - 2021-03-24 21:51:59 --> Helper loaded: common_helper
INFO - 2021-03-24 21:51:59 --> Helper loaded: util_helper
INFO - 2021-03-24 21:51:59 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:51:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:51:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:51:59 --> Form Validation Class Initialized
INFO - 2021-03-24 21:51:59 --> Controller Class Initialized
INFO - 2021-03-24 21:51:59 --> Model Class Initialized
INFO - 2021-03-24 21:51:59 --> Model Class Initialized
INFO - 2021-03-24 21:51:59 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:51:59 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:51:59 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/role/list.php
INFO - 2021-03-24 21:51:59 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:51:59 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:51:59 --> Final output sent to browser
DEBUG - 2021-03-24 21:51:59 --> Total execution time: 0.0342
INFO - 2021-03-24 21:51:59 --> Config Class Initialized
INFO - 2021-03-24 21:51:59 --> Hooks Class Initialized
INFO - 2021-03-24 21:51:59 --> Config Class Initialized
DEBUG - 2021-03-24 21:51:59 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:51:59 --> Utf8 Class Initialized
INFO - 2021-03-24 21:51:59 --> Hooks Class Initialized
INFO - 2021-03-24 21:51:59 --> URI Class Initialized
DEBUG - 2021-03-24 21:51:59 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:51:59 --> Router Class Initialized
INFO - 2021-03-24 21:51:59 --> Utf8 Class Initialized
INFO - 2021-03-24 21:51:59 --> URI Class Initialized
INFO - 2021-03-24 21:51:59 --> Output Class Initialized
INFO - 2021-03-24 21:51:59 --> Router Class Initialized
INFO - 2021-03-24 21:51:59 --> Security Class Initialized
DEBUG - 2021-03-24 21:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:51:59 --> Input Class Initialized
INFO - 2021-03-24 21:51:59 --> Output Class Initialized
INFO - 2021-03-24 21:51:59 --> Language Class Initialized
INFO - 2021-03-24 21:51:59 --> Security Class Initialized
INFO - 2021-03-24 21:51:59 --> Config Class Initialized
INFO - 2021-03-24 21:51:59 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:51:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-03-24 21:51:59 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-24 21:51:59 --> Input Class Initialized
INFO - 2021-03-24 21:51:59 --> Language Class Initialized
DEBUG - 2021-03-24 21:51:59 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:51:59 --> Utf8 Class Initialized
INFO - 2021-03-24 21:51:59 --> URI Class Initialized
ERROR - 2021-03-24 21:51:59 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-24 21:51:59 --> Router Class Initialized
INFO - 2021-03-24 21:51:59 --> Output Class Initialized
INFO - 2021-03-24 21:51:59 --> Security Class Initialized
DEBUG - 2021-03-24 21:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:51:59 --> Input Class Initialized
INFO - 2021-03-24 21:51:59 --> Language Class Initialized
ERROR - 2021-03-24 21:51:59 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-24 21:51:59 --> Config Class Initialized
INFO - 2021-03-24 21:51:59 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:51:59 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:51:59 --> Utf8 Class Initialized
INFO - 2021-03-24 21:51:59 --> URI Class Initialized
INFO - 2021-03-24 21:51:59 --> Router Class Initialized
INFO - 2021-03-24 21:51:59 --> Output Class Initialized
INFO - 2021-03-24 21:51:59 --> Security Class Initialized
DEBUG - 2021-03-24 21:51:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:51:59 --> Input Class Initialized
INFO - 2021-03-24 21:51:59 --> Language Class Initialized
ERROR - 2021-03-24 21:51:59 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-24 21:52:07 --> Config Class Initialized
INFO - 2021-03-24 21:52:07 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:52:07 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:52:07 --> Utf8 Class Initialized
INFO - 2021-03-24 21:52:07 --> URI Class Initialized
INFO - 2021-03-24 21:52:07 --> Router Class Initialized
INFO - 2021-03-24 21:52:07 --> Output Class Initialized
INFO - 2021-03-24 21:52:07 --> Security Class Initialized
DEBUG - 2021-03-24 21:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:52:07 --> Input Class Initialized
INFO - 2021-03-24 21:52:07 --> Language Class Initialized
INFO - 2021-03-24 21:52:07 --> Loader Class Initialized
INFO - 2021-03-24 21:52:07 --> Helper loaded: url_helper
INFO - 2021-03-24 21:52:07 --> Helper loaded: form_helper
INFO - 2021-03-24 21:52:07 --> Helper loaded: common_helper
INFO - 2021-03-24 21:52:07 --> Helper loaded: util_helper
INFO - 2021-03-24 21:52:07 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:52:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:52:07 --> Form Validation Class Initialized
INFO - 2021-03-24 21:52:07 --> Controller Class Initialized
INFO - 2021-03-24 21:52:07 --> Model Class Initialized
INFO - 2021-03-24 21:52:07 --> Model Class Initialized
INFO - 2021-03-24 21:52:07 --> Config Class Initialized
INFO - 2021-03-24 21:52:07 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:52:07 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:52:07 --> Utf8 Class Initialized
INFO - 2021-03-24 21:52:07 --> URI Class Initialized
INFO - 2021-03-24 21:52:07 --> Router Class Initialized
INFO - 2021-03-24 21:52:07 --> Output Class Initialized
INFO - 2021-03-24 21:52:07 --> Security Class Initialized
DEBUG - 2021-03-24 21:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:52:07 --> Input Class Initialized
INFO - 2021-03-24 21:52:07 --> Language Class Initialized
INFO - 2021-03-24 21:52:07 --> Loader Class Initialized
INFO - 2021-03-24 21:52:07 --> Helper loaded: url_helper
INFO - 2021-03-24 21:52:07 --> Helper loaded: form_helper
INFO - 2021-03-24 21:52:07 --> Helper loaded: common_helper
INFO - 2021-03-24 21:52:07 --> Helper loaded: util_helper
INFO - 2021-03-24 21:52:07 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:52:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:52:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:52:07 --> Form Validation Class Initialized
INFO - 2021-03-24 21:52:07 --> Controller Class Initialized
INFO - 2021-03-24 21:52:07 --> Model Class Initialized
INFO - 2021-03-24 21:52:07 --> Model Class Initialized
INFO - 2021-03-24 21:52:07 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:52:07 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:52:07 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/role/list.php
INFO - 2021-03-24 21:52:07 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:52:07 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:52:07 --> Final output sent to browser
DEBUG - 2021-03-24 21:52:07 --> Total execution time: 0.0410
INFO - 2021-03-24 21:52:07 --> Config Class Initialized
INFO - 2021-03-24 21:52:07 --> Hooks Class Initialized
INFO - 2021-03-24 21:52:07 --> Config Class Initialized
INFO - 2021-03-24 21:52:07 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:52:07 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:52:07 --> Utf8 Class Initialized
DEBUG - 2021-03-24 21:52:07 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:52:07 --> Utf8 Class Initialized
INFO - 2021-03-24 21:52:07 --> URI Class Initialized
INFO - 2021-03-24 21:52:07 --> URI Class Initialized
INFO - 2021-03-24 21:52:07 --> Router Class Initialized
INFO - 2021-03-24 21:52:07 --> Output Class Initialized
INFO - 2021-03-24 21:52:07 --> Router Class Initialized
INFO - 2021-03-24 21:52:07 --> Security Class Initialized
DEBUG - 2021-03-24 21:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:52:07 --> Input Class Initialized
INFO - 2021-03-24 21:52:07 --> Output Class Initialized
INFO - 2021-03-24 21:52:07 --> Language Class Initialized
INFO - 2021-03-24 21:52:07 --> Security Class Initialized
ERROR - 2021-03-24 21:52:07 --> 404 Page Not Found: administrator/Dist/img
DEBUG - 2021-03-24 21:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:52:07 --> Input Class Initialized
INFO - 2021-03-24 21:52:07 --> Language Class Initialized
ERROR - 2021-03-24 21:52:07 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-24 21:52:07 --> Config Class Initialized
INFO - 2021-03-24 21:52:07 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:52:07 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:52:07 --> Utf8 Class Initialized
INFO - 2021-03-24 21:52:07 --> URI Class Initialized
INFO - 2021-03-24 21:52:07 --> Config Class Initialized
INFO - 2021-03-24 21:52:07 --> Hooks Class Initialized
INFO - 2021-03-24 21:52:07 --> Router Class Initialized
INFO - 2021-03-24 21:52:07 --> Output Class Initialized
DEBUG - 2021-03-24 21:52:07 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:52:07 --> Utf8 Class Initialized
INFO - 2021-03-24 21:52:07 --> Security Class Initialized
INFO - 2021-03-24 21:52:07 --> URI Class Initialized
DEBUG - 2021-03-24 21:52:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:52:07 --> Input Class Initialized
INFO - 2021-03-24 21:52:07 --> Router Class Initialized
INFO - 2021-03-24 21:52:07 --> Language Class Initialized
INFO - 2021-03-24 21:52:07 --> Output Class Initialized
ERROR - 2021-03-24 21:52:07 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-24 21:52:08 --> Security Class Initialized
DEBUG - 2021-03-24 21:52:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:52:08 --> Input Class Initialized
INFO - 2021-03-24 21:52:08 --> Language Class Initialized
ERROR - 2021-03-24 21:52:08 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-24 21:55:55 --> Config Class Initialized
INFO - 2021-03-24 21:55:55 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:55:55 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:55:55 --> Utf8 Class Initialized
INFO - 2021-03-24 21:55:55 --> URI Class Initialized
INFO - 2021-03-24 21:55:55 --> Router Class Initialized
INFO - 2021-03-24 21:55:55 --> Output Class Initialized
INFO - 2021-03-24 21:55:55 --> Security Class Initialized
DEBUG - 2021-03-24 21:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:55:55 --> Input Class Initialized
INFO - 2021-03-24 21:55:55 --> Language Class Initialized
INFO - 2021-03-24 21:55:55 --> Loader Class Initialized
INFO - 2021-03-24 21:55:55 --> Helper loaded: url_helper
INFO - 2021-03-24 21:55:55 --> Helper loaded: form_helper
INFO - 2021-03-24 21:55:55 --> Helper loaded: common_helper
INFO - 2021-03-24 21:55:55 --> Helper loaded: util_helper
INFO - 2021-03-24 21:55:55 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:55:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:55:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:55:55 --> Form Validation Class Initialized
INFO - 2021-03-24 21:55:55 --> Controller Class Initialized
INFO - 2021-03-24 21:55:55 --> Model Class Initialized
INFO - 2021-03-24 21:55:55 --> Model Class Initialized
INFO - 2021-03-24 21:55:55 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:55:55 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:55:55 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/role/list.php
INFO - 2021-03-24 21:55:55 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:55:55 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:55:55 --> Final output sent to browser
DEBUG - 2021-03-24 21:55:55 --> Total execution time: 0.0473
INFO - 2021-03-24 21:55:55 --> Config Class Initialized
INFO - 2021-03-24 21:55:55 --> Config Class Initialized
INFO - 2021-03-24 21:55:55 --> Hooks Class Initialized
INFO - 2021-03-24 21:55:55 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:55:55 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:55:55 --> Utf8 Class Initialized
DEBUG - 2021-03-24 21:55:55 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:55:55 --> Utf8 Class Initialized
INFO - 2021-03-24 21:55:55 --> URI Class Initialized
INFO - 2021-03-24 21:55:55 --> URI Class Initialized
INFO - 2021-03-24 21:55:55 --> Router Class Initialized
INFO - 2021-03-24 21:55:55 --> Router Class Initialized
INFO - 2021-03-24 21:55:55 --> Output Class Initialized
INFO - 2021-03-24 21:55:55 --> Security Class Initialized
INFO - 2021-03-24 21:55:55 --> Output Class Initialized
DEBUG - 2021-03-24 21:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:55:55 --> Input Class Initialized
INFO - 2021-03-24 21:55:55 --> Language Class Initialized
INFO - 2021-03-24 21:55:55 --> Security Class Initialized
ERROR - 2021-03-24 21:55:55 --> 404 Page Not Found: administrator/Dist/img
DEBUG - 2021-03-24 21:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:55:55 --> Input Class Initialized
INFO - 2021-03-24 21:55:55 --> Language Class Initialized
ERROR - 2021-03-24 21:55:55 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-24 21:55:55 --> Config Class Initialized
INFO - 2021-03-24 21:55:55 --> Config Class Initialized
INFO - 2021-03-24 21:55:55 --> Hooks Class Initialized
INFO - 2021-03-24 21:55:55 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:55:55 --> UTF-8 Support Enabled
DEBUG - 2021-03-24 21:55:55 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:55:55 --> Utf8 Class Initialized
INFO - 2021-03-24 21:55:55 --> Utf8 Class Initialized
INFO - 2021-03-24 21:55:55 --> URI Class Initialized
INFO - 2021-03-24 21:55:55 --> URI Class Initialized
INFO - 2021-03-24 21:55:55 --> Router Class Initialized
INFO - 2021-03-24 21:55:55 --> Router Class Initialized
INFO - 2021-03-24 21:55:55 --> Output Class Initialized
INFO - 2021-03-24 21:55:55 --> Output Class Initialized
INFO - 2021-03-24 21:55:55 --> Security Class Initialized
INFO - 2021-03-24 21:55:55 --> Security Class Initialized
DEBUG - 2021-03-24 21:55:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-24 21:55:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:55:55 --> Input Class Initialized
INFO - 2021-03-24 21:55:55 --> Input Class Initialized
INFO - 2021-03-24 21:55:55 --> Language Class Initialized
INFO - 2021-03-24 21:55:55 --> Language Class Initialized
ERROR - 2021-03-24 21:55:55 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-03-24 21:55:55 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-24 21:56:03 --> Config Class Initialized
INFO - 2021-03-24 21:56:03 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:56:03 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:56:03 --> Utf8 Class Initialized
INFO - 2021-03-24 21:56:03 --> URI Class Initialized
INFO - 2021-03-24 21:56:03 --> Router Class Initialized
INFO - 2021-03-24 21:56:03 --> Output Class Initialized
INFO - 2021-03-24 21:56:03 --> Security Class Initialized
DEBUG - 2021-03-24 21:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:56:03 --> Input Class Initialized
INFO - 2021-03-24 21:56:03 --> Language Class Initialized
INFO - 2021-03-24 21:56:03 --> Loader Class Initialized
INFO - 2021-03-24 21:56:03 --> Helper loaded: url_helper
INFO - 2021-03-24 21:56:03 --> Helper loaded: form_helper
INFO - 2021-03-24 21:56:03 --> Helper loaded: common_helper
INFO - 2021-03-24 21:56:03 --> Helper loaded: util_helper
INFO - 2021-03-24 21:56:03 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:56:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:56:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:56:03 --> Form Validation Class Initialized
INFO - 2021-03-24 21:56:03 --> Controller Class Initialized
INFO - 2021-03-24 21:56:03 --> Model Class Initialized
INFO - 2021-03-24 21:56:03 --> Model Class Initialized
INFO - 2021-03-24 21:56:03 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:56:03 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:56:03 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/role/add.php
INFO - 2021-03-24 21:56:03 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:56:03 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:56:03 --> Final output sent to browser
DEBUG - 2021-03-24 21:56:03 --> Total execution time: 0.0457
INFO - 2021-03-24 21:56:03 --> Config Class Initialized
INFO - 2021-03-24 21:56:03 --> Hooks Class Initialized
INFO - 2021-03-24 21:56:03 --> Config Class Initialized
INFO - 2021-03-24 21:56:03 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:56:03 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:56:03 --> Utf8 Class Initialized
INFO - 2021-03-24 21:56:03 --> URI Class Initialized
DEBUG - 2021-03-24 21:56:03 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:56:03 --> Utf8 Class Initialized
INFO - 2021-03-24 21:56:03 --> Router Class Initialized
INFO - 2021-03-24 21:56:03 --> URI Class Initialized
INFO - 2021-03-24 21:56:03 --> Output Class Initialized
INFO - 2021-03-24 21:56:03 --> Router Class Initialized
INFO - 2021-03-24 21:56:03 --> Security Class Initialized
INFO - 2021-03-24 21:56:03 --> Output Class Initialized
DEBUG - 2021-03-24 21:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:56:03 --> Input Class Initialized
INFO - 2021-03-24 21:56:03 --> Security Class Initialized
INFO - 2021-03-24 21:56:03 --> Language Class Initialized
DEBUG - 2021-03-24 21:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:56:03 --> Input Class Initialized
ERROR - 2021-03-24 21:56:03 --> 404 Page Not Found: administrator/Role/dist
INFO - 2021-03-24 21:56:03 --> Language Class Initialized
ERROR - 2021-03-24 21:56:03 --> 404 Page Not Found: administrator/Role/dist
INFO - 2021-03-24 21:56:03 --> Config Class Initialized
INFO - 2021-03-24 21:56:03 --> Hooks Class Initialized
INFO - 2021-03-24 21:56:03 --> Config Class Initialized
INFO - 2021-03-24 21:56:03 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:56:03 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:56:03 --> Utf8 Class Initialized
INFO - 2021-03-24 21:56:03 --> URI Class Initialized
DEBUG - 2021-03-24 21:56:03 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:56:03 --> Utf8 Class Initialized
INFO - 2021-03-24 21:56:03 --> URI Class Initialized
INFO - 2021-03-24 21:56:03 --> Router Class Initialized
INFO - 2021-03-24 21:56:03 --> Router Class Initialized
INFO - 2021-03-24 21:56:03 --> Output Class Initialized
INFO - 2021-03-24 21:56:03 --> Security Class Initialized
INFO - 2021-03-24 21:56:03 --> Output Class Initialized
DEBUG - 2021-03-24 21:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:56:03 --> Input Class Initialized
INFO - 2021-03-24 21:56:03 --> Security Class Initialized
INFO - 2021-03-24 21:56:03 --> Language Class Initialized
DEBUG - 2021-03-24 21:56:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:56:03 --> Input Class Initialized
INFO - 2021-03-24 21:56:03 --> Language Class Initialized
ERROR - 2021-03-24 21:56:03 --> 404 Page Not Found: administrator/Role/dist
ERROR - 2021-03-24 21:56:03 --> 404 Page Not Found: administrator/Role/dist
INFO - 2021-03-24 21:56:07 --> Config Class Initialized
INFO - 2021-03-24 21:56:07 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:56:07 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:56:07 --> Utf8 Class Initialized
INFO - 2021-03-24 21:56:07 --> URI Class Initialized
INFO - 2021-03-24 21:56:07 --> Router Class Initialized
INFO - 2021-03-24 21:56:07 --> Output Class Initialized
INFO - 2021-03-24 21:56:07 --> Security Class Initialized
DEBUG - 2021-03-24 21:56:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:56:07 --> Input Class Initialized
INFO - 2021-03-24 21:56:07 --> Language Class Initialized
INFO - 2021-03-24 21:56:07 --> Loader Class Initialized
INFO - 2021-03-24 21:56:07 --> Helper loaded: url_helper
INFO - 2021-03-24 21:56:07 --> Helper loaded: form_helper
INFO - 2021-03-24 21:56:07 --> Helper loaded: common_helper
INFO - 2021-03-24 21:56:07 --> Helper loaded: util_helper
INFO - 2021-03-24 21:56:07 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:56:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:56:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:56:07 --> Form Validation Class Initialized
INFO - 2021-03-24 21:56:07 --> Controller Class Initialized
INFO - 2021-03-24 21:56:07 --> Model Class Initialized
INFO - 2021-03-24 21:56:07 --> Model Class Initialized
INFO - 2021-03-24 21:56:07 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-03-24 21:56:08 --> Config Class Initialized
INFO - 2021-03-24 21:56:08 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:56:08 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:56:08 --> Utf8 Class Initialized
INFO - 2021-03-24 21:56:08 --> URI Class Initialized
INFO - 2021-03-24 21:56:08 --> Router Class Initialized
INFO - 2021-03-24 21:56:08 --> Output Class Initialized
INFO - 2021-03-24 21:56:08 --> Security Class Initialized
DEBUG - 2021-03-24 21:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:56:08 --> Input Class Initialized
INFO - 2021-03-24 21:56:08 --> Language Class Initialized
INFO - 2021-03-24 21:56:08 --> Loader Class Initialized
INFO - 2021-03-24 21:56:08 --> Helper loaded: url_helper
INFO - 2021-03-24 21:56:08 --> Helper loaded: form_helper
INFO - 2021-03-24 21:56:08 --> Helper loaded: common_helper
INFO - 2021-03-24 21:56:08 --> Helper loaded: util_helper
INFO - 2021-03-24 21:56:08 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:56:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:56:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:56:08 --> Form Validation Class Initialized
INFO - 2021-03-24 21:56:08 --> Controller Class Initialized
INFO - 2021-03-24 21:56:08 --> Model Class Initialized
INFO - 2021-03-24 21:56:08 --> Model Class Initialized
INFO - 2021-03-24 21:56:08 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:56:08 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:56:08 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/role/add.php
INFO - 2021-03-24 21:56:08 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:56:08 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:56:08 --> Final output sent to browser
DEBUG - 2021-03-24 21:56:08 --> Total execution time: 0.0342
INFO - 2021-03-24 21:56:08 --> Config Class Initialized
INFO - 2021-03-24 21:56:08 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:56:08 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:56:08 --> Utf8 Class Initialized
INFO - 2021-03-24 21:56:08 --> URI Class Initialized
INFO - 2021-03-24 21:56:08 --> Config Class Initialized
INFO - 2021-03-24 21:56:08 --> Hooks Class Initialized
INFO - 2021-03-24 21:56:08 --> Router Class Initialized
INFO - 2021-03-24 21:56:08 --> Output Class Initialized
DEBUG - 2021-03-24 21:56:08 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:56:08 --> Utf8 Class Initialized
INFO - 2021-03-24 21:56:08 --> URI Class Initialized
INFO - 2021-03-24 21:56:08 --> Security Class Initialized
DEBUG - 2021-03-24 21:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:56:08 --> Input Class Initialized
INFO - 2021-03-24 21:56:08 --> Router Class Initialized
INFO - 2021-03-24 21:56:08 --> Language Class Initialized
INFO - 2021-03-24 21:56:08 --> Output Class Initialized
INFO - 2021-03-24 21:56:08 --> Security Class Initialized
ERROR - 2021-03-24 21:56:08 --> 404 Page Not Found: administrator/Role/dist
DEBUG - 2021-03-24 21:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:56:08 --> Input Class Initialized
INFO - 2021-03-24 21:56:08 --> Language Class Initialized
ERROR - 2021-03-24 21:56:08 --> 404 Page Not Found: administrator/Role/dist
INFO - 2021-03-24 21:56:08 --> Config Class Initialized
INFO - 2021-03-24 21:56:08 --> Hooks Class Initialized
INFO - 2021-03-24 21:56:08 --> Config Class Initialized
INFO - 2021-03-24 21:56:08 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:56:08 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:56:08 --> Utf8 Class Initialized
INFO - 2021-03-24 21:56:08 --> URI Class Initialized
DEBUG - 2021-03-24 21:56:08 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:56:08 --> Utf8 Class Initialized
INFO - 2021-03-24 21:56:08 --> URI Class Initialized
INFO - 2021-03-24 21:56:08 --> Router Class Initialized
INFO - 2021-03-24 21:56:08 --> Router Class Initialized
INFO - 2021-03-24 21:56:08 --> Output Class Initialized
INFO - 2021-03-24 21:56:08 --> Security Class Initialized
INFO - 2021-03-24 21:56:08 --> Output Class Initialized
DEBUG - 2021-03-24 21:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:56:08 --> Security Class Initialized
INFO - 2021-03-24 21:56:08 --> Input Class Initialized
INFO - 2021-03-24 21:56:08 --> Language Class Initialized
DEBUG - 2021-03-24 21:56:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:56:08 --> Input Class Initialized
INFO - 2021-03-24 21:56:08 --> Language Class Initialized
ERROR - 2021-03-24 21:56:08 --> 404 Page Not Found: administrator/Role/dist
ERROR - 2021-03-24 21:56:08 --> 404 Page Not Found: administrator/Role/dist
INFO - 2021-03-24 21:57:03 --> Config Class Initialized
INFO - 2021-03-24 21:57:03 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:57:03 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:57:03 --> Utf8 Class Initialized
INFO - 2021-03-24 21:57:03 --> URI Class Initialized
INFO - 2021-03-24 21:57:03 --> Router Class Initialized
INFO - 2021-03-24 21:57:03 --> Output Class Initialized
INFO - 2021-03-24 21:57:03 --> Security Class Initialized
DEBUG - 2021-03-24 21:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:57:03 --> Input Class Initialized
INFO - 2021-03-24 21:57:03 --> Language Class Initialized
INFO - 2021-03-24 21:57:03 --> Loader Class Initialized
INFO - 2021-03-24 21:57:03 --> Helper loaded: url_helper
INFO - 2021-03-24 21:57:03 --> Helper loaded: form_helper
INFO - 2021-03-24 21:57:03 --> Helper loaded: common_helper
INFO - 2021-03-24 21:57:03 --> Helper loaded: util_helper
INFO - 2021-03-24 21:57:03 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:57:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:57:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:57:03 --> Form Validation Class Initialized
INFO - 2021-03-24 21:57:03 --> Controller Class Initialized
INFO - 2021-03-24 21:57:03 --> Model Class Initialized
INFO - 2021-03-24 21:57:03 --> Model Class Initialized
INFO - 2021-03-24 21:57:03 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-03-24 21:57:03 --> Config Class Initialized
INFO - 2021-03-24 21:57:03 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:57:03 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:57:03 --> Utf8 Class Initialized
INFO - 2021-03-24 21:57:03 --> URI Class Initialized
INFO - 2021-03-24 21:57:03 --> Router Class Initialized
INFO - 2021-03-24 21:57:03 --> Output Class Initialized
INFO - 2021-03-24 21:57:03 --> Security Class Initialized
DEBUG - 2021-03-24 21:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:57:03 --> Input Class Initialized
INFO - 2021-03-24 21:57:03 --> Language Class Initialized
INFO - 2021-03-24 21:57:03 --> Loader Class Initialized
INFO - 2021-03-24 21:57:03 --> Helper loaded: url_helper
INFO - 2021-03-24 21:57:03 --> Helper loaded: form_helper
INFO - 2021-03-24 21:57:03 --> Helper loaded: common_helper
INFO - 2021-03-24 21:57:03 --> Helper loaded: util_helper
INFO - 2021-03-24 21:57:03 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:57:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:57:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:57:03 --> Form Validation Class Initialized
INFO - 2021-03-24 21:57:03 --> Controller Class Initialized
INFO - 2021-03-24 21:57:03 --> Model Class Initialized
INFO - 2021-03-24 21:57:03 --> Model Class Initialized
INFO - 2021-03-24 21:57:03 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:57:03 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:57:03 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/role/add.php
INFO - 2021-03-24 21:57:03 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:57:03 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:57:03 --> Final output sent to browser
DEBUG - 2021-03-24 21:57:03 --> Total execution time: 0.0481
INFO - 2021-03-24 21:57:03 --> Config Class Initialized
INFO - 2021-03-24 21:57:03 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:57:03 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:57:03 --> Utf8 Class Initialized
INFO - 2021-03-24 21:57:03 --> Config Class Initialized
INFO - 2021-03-24 21:57:03 --> Hooks Class Initialized
INFO - 2021-03-24 21:57:03 --> URI Class Initialized
INFO - 2021-03-24 21:57:03 --> Router Class Initialized
DEBUG - 2021-03-24 21:57:03 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:57:03 --> Utf8 Class Initialized
INFO - 2021-03-24 21:57:03 --> Output Class Initialized
INFO - 2021-03-24 21:57:03 --> URI Class Initialized
INFO - 2021-03-24 21:57:03 --> Security Class Initialized
INFO - 2021-03-24 21:57:03 --> Router Class Initialized
DEBUG - 2021-03-24 21:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:57:03 --> Input Class Initialized
INFO - 2021-03-24 21:57:03 --> Output Class Initialized
INFO - 2021-03-24 21:57:03 --> Language Class Initialized
INFO - 2021-03-24 21:57:03 --> Security Class Initialized
ERROR - 2021-03-24 21:57:03 --> 404 Page Not Found: administrator/Role/dist
DEBUG - 2021-03-24 21:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:57:03 --> Input Class Initialized
INFO - 2021-03-24 21:57:03 --> Language Class Initialized
ERROR - 2021-03-24 21:57:03 --> 404 Page Not Found: administrator/Role/dist
INFO - 2021-03-24 21:57:03 --> Config Class Initialized
INFO - 2021-03-24 21:57:03 --> Config Class Initialized
INFO - 2021-03-24 21:57:03 --> Hooks Class Initialized
INFO - 2021-03-24 21:57:03 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:57:03 --> UTF-8 Support Enabled
DEBUG - 2021-03-24 21:57:03 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:57:03 --> Utf8 Class Initialized
INFO - 2021-03-24 21:57:03 --> Utf8 Class Initialized
INFO - 2021-03-24 21:57:03 --> URI Class Initialized
INFO - 2021-03-24 21:57:03 --> URI Class Initialized
INFO - 2021-03-24 21:57:03 --> Router Class Initialized
INFO - 2021-03-24 21:57:03 --> Router Class Initialized
INFO - 2021-03-24 21:57:03 --> Output Class Initialized
INFO - 2021-03-24 21:57:03 --> Output Class Initialized
INFO - 2021-03-24 21:57:03 --> Security Class Initialized
INFO - 2021-03-24 21:57:03 --> Security Class Initialized
DEBUG - 2021-03-24 21:57:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-24 21:57:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:57:03 --> Input Class Initialized
INFO - 2021-03-24 21:57:03 --> Input Class Initialized
INFO - 2021-03-24 21:57:03 --> Language Class Initialized
INFO - 2021-03-24 21:57:03 --> Language Class Initialized
ERROR - 2021-03-24 21:57:03 --> 404 Page Not Found: administrator/Role/dist
ERROR - 2021-03-24 21:57:03 --> 404 Page Not Found: administrator/Role/dist
INFO - 2021-03-24 21:57:56 --> Config Class Initialized
INFO - 2021-03-24 21:57:56 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:57:56 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:57:56 --> Utf8 Class Initialized
INFO - 2021-03-24 21:57:56 --> URI Class Initialized
INFO - 2021-03-24 21:57:56 --> Router Class Initialized
INFO - 2021-03-24 21:57:56 --> Output Class Initialized
INFO - 2021-03-24 21:57:56 --> Security Class Initialized
DEBUG - 2021-03-24 21:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:57:56 --> Input Class Initialized
INFO - 2021-03-24 21:57:56 --> Language Class Initialized
INFO - 2021-03-24 21:57:56 --> Loader Class Initialized
INFO - 2021-03-24 21:57:56 --> Helper loaded: url_helper
INFO - 2021-03-24 21:57:56 --> Helper loaded: form_helper
INFO - 2021-03-24 21:57:56 --> Helper loaded: common_helper
INFO - 2021-03-24 21:57:56 --> Helper loaded: util_helper
INFO - 2021-03-24 21:57:56 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:57:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:57:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:57:56 --> Form Validation Class Initialized
INFO - 2021-03-24 21:57:56 --> Controller Class Initialized
INFO - 2021-03-24 21:57:56 --> Model Class Initialized
INFO - 2021-03-24 21:57:56 --> Model Class Initialized
INFO - 2021-03-24 21:57:56 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:57:56 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:57:56 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/role/add.php
INFO - 2021-03-24 21:57:56 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:57:56 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:57:56 --> Final output sent to browser
DEBUG - 2021-03-24 21:57:56 --> Total execution time: 0.0348
INFO - 2021-03-24 21:57:56 --> Config Class Initialized
INFO - 2021-03-24 21:57:56 --> Hooks Class Initialized
INFO - 2021-03-24 21:57:56 --> Config Class Initialized
INFO - 2021-03-24 21:57:56 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:57:56 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:57:56 --> Utf8 Class Initialized
INFO - 2021-03-24 21:57:56 --> URI Class Initialized
DEBUG - 2021-03-24 21:57:56 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:57:56 --> Utf8 Class Initialized
INFO - 2021-03-24 21:57:56 --> URI Class Initialized
INFO - 2021-03-24 21:57:56 --> Router Class Initialized
INFO - 2021-03-24 21:57:56 --> Router Class Initialized
INFO - 2021-03-24 21:57:56 --> Output Class Initialized
INFO - 2021-03-24 21:57:56 --> Security Class Initialized
INFO - 2021-03-24 21:57:56 --> Output Class Initialized
DEBUG - 2021-03-24 21:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:57:56 --> Security Class Initialized
INFO - 2021-03-24 21:57:56 --> Input Class Initialized
INFO - 2021-03-24 21:57:56 --> Language Class Initialized
DEBUG - 2021-03-24 21:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:57:56 --> Input Class Initialized
INFO - 2021-03-24 21:57:56 --> Language Class Initialized
ERROR - 2021-03-24 21:57:56 --> 404 Page Not Found: administrator/Role/dist
ERROR - 2021-03-24 21:57:56 --> 404 Page Not Found: administrator/Role/dist
INFO - 2021-03-24 21:57:56 --> Config Class Initialized
INFO - 2021-03-24 21:57:56 --> Hooks Class Initialized
INFO - 2021-03-24 21:57:56 --> Config Class Initialized
INFO - 2021-03-24 21:57:56 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:57:56 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:57:56 --> Utf8 Class Initialized
DEBUG - 2021-03-24 21:57:56 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:57:56 --> Utf8 Class Initialized
INFO - 2021-03-24 21:57:56 --> URI Class Initialized
INFO - 2021-03-24 21:57:56 --> URI Class Initialized
INFO - 2021-03-24 21:57:56 --> Router Class Initialized
INFO - 2021-03-24 21:57:56 --> Router Class Initialized
INFO - 2021-03-24 21:57:56 --> Output Class Initialized
INFO - 2021-03-24 21:57:56 --> Output Class Initialized
INFO - 2021-03-24 21:57:56 --> Security Class Initialized
INFO - 2021-03-24 21:57:56 --> Security Class Initialized
DEBUG - 2021-03-24 21:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:57:56 --> Input Class Initialized
DEBUG - 2021-03-24 21:57:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:57:56 --> Input Class Initialized
INFO - 2021-03-24 21:57:56 --> Language Class Initialized
INFO - 2021-03-24 21:57:56 --> Language Class Initialized
ERROR - 2021-03-24 21:57:56 --> 404 Page Not Found: administrator/Role/dist
ERROR - 2021-03-24 21:57:56 --> 404 Page Not Found: administrator/Role/dist
INFO - 2021-03-24 21:58:00 --> Config Class Initialized
INFO - 2021-03-24 21:58:00 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:58:00 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:58:00 --> Utf8 Class Initialized
INFO - 2021-03-24 21:58:00 --> URI Class Initialized
INFO - 2021-03-24 21:58:00 --> Router Class Initialized
INFO - 2021-03-24 21:58:00 --> Output Class Initialized
INFO - 2021-03-24 21:58:00 --> Security Class Initialized
DEBUG - 2021-03-24 21:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:58:00 --> Input Class Initialized
INFO - 2021-03-24 21:58:00 --> Language Class Initialized
INFO - 2021-03-24 21:58:00 --> Loader Class Initialized
INFO - 2021-03-24 21:58:00 --> Helper loaded: url_helper
INFO - 2021-03-24 21:58:00 --> Helper loaded: form_helper
INFO - 2021-03-24 21:58:00 --> Helper loaded: common_helper
INFO - 2021-03-24 21:58:00 --> Helper loaded: util_helper
INFO - 2021-03-24 21:58:00 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:58:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:58:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:58:00 --> Form Validation Class Initialized
INFO - 2021-03-24 21:58:00 --> Controller Class Initialized
INFO - 2021-03-24 21:58:00 --> Model Class Initialized
INFO - 2021-03-24 21:58:00 --> Model Class Initialized
INFO - 2021-03-24 21:58:00 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-03-24 21:58:00 --> Config Class Initialized
INFO - 2021-03-24 21:58:00 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:58:00 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:58:00 --> Utf8 Class Initialized
INFO - 2021-03-24 21:58:00 --> URI Class Initialized
INFO - 2021-03-24 21:58:00 --> Router Class Initialized
INFO - 2021-03-24 21:58:00 --> Output Class Initialized
INFO - 2021-03-24 21:58:00 --> Security Class Initialized
DEBUG - 2021-03-24 21:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:58:00 --> Input Class Initialized
INFO - 2021-03-24 21:58:00 --> Language Class Initialized
INFO - 2021-03-24 21:58:00 --> Loader Class Initialized
INFO - 2021-03-24 21:58:00 --> Helper loaded: url_helper
INFO - 2021-03-24 21:58:00 --> Helper loaded: form_helper
INFO - 2021-03-24 21:58:00 --> Helper loaded: common_helper
INFO - 2021-03-24 21:58:00 --> Helper loaded: util_helper
INFO - 2021-03-24 21:58:00 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:58:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:58:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:58:00 --> Form Validation Class Initialized
INFO - 2021-03-24 21:58:00 --> Controller Class Initialized
INFO - 2021-03-24 21:58:00 --> Model Class Initialized
INFO - 2021-03-24 21:58:00 --> Model Class Initialized
INFO - 2021-03-24 21:58:00 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:58:00 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:58:00 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/role/add.php
INFO - 2021-03-24 21:58:00 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:58:00 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:58:00 --> Final output sent to browser
DEBUG - 2021-03-24 21:58:00 --> Total execution time: 0.0421
INFO - 2021-03-24 21:58:00 --> Config Class Initialized
INFO - 2021-03-24 21:58:00 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:58:00 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:58:00 --> Utf8 Class Initialized
INFO - 2021-03-24 21:58:00 --> Config Class Initialized
INFO - 2021-03-24 21:58:00 --> URI Class Initialized
INFO - 2021-03-24 21:58:00 --> Hooks Class Initialized
INFO - 2021-03-24 21:58:00 --> Router Class Initialized
INFO - 2021-03-24 21:58:00 --> Output Class Initialized
DEBUG - 2021-03-24 21:58:00 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:58:00 --> Utf8 Class Initialized
INFO - 2021-03-24 21:58:00 --> Security Class Initialized
INFO - 2021-03-24 21:58:00 --> URI Class Initialized
DEBUG - 2021-03-24 21:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:58:00 --> Input Class Initialized
INFO - 2021-03-24 21:58:00 --> Language Class Initialized
INFO - 2021-03-24 21:58:00 --> Router Class Initialized
ERROR - 2021-03-24 21:58:00 --> 404 Page Not Found: administrator/Role/dist
INFO - 2021-03-24 21:58:00 --> Output Class Initialized
INFO - 2021-03-24 21:58:00 --> Security Class Initialized
DEBUG - 2021-03-24 21:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:58:00 --> Input Class Initialized
INFO - 2021-03-24 21:58:00 --> Language Class Initialized
ERROR - 2021-03-24 21:58:00 --> 404 Page Not Found: administrator/Role/dist
INFO - 2021-03-24 21:58:00 --> Config Class Initialized
INFO - 2021-03-24 21:58:00 --> Config Class Initialized
INFO - 2021-03-24 21:58:00 --> Hooks Class Initialized
INFO - 2021-03-24 21:58:00 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:58:00 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:58:00 --> Utf8 Class Initialized
DEBUG - 2021-03-24 21:58:00 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:58:00 --> Utf8 Class Initialized
INFO - 2021-03-24 21:58:00 --> URI Class Initialized
INFO - 2021-03-24 21:58:00 --> URI Class Initialized
INFO - 2021-03-24 21:58:00 --> Router Class Initialized
INFO - 2021-03-24 21:58:00 --> Router Class Initialized
INFO - 2021-03-24 21:58:00 --> Output Class Initialized
INFO - 2021-03-24 21:58:00 --> Output Class Initialized
INFO - 2021-03-24 21:58:00 --> Security Class Initialized
INFO - 2021-03-24 21:58:00 --> Security Class Initialized
DEBUG - 2021-03-24 21:58:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-03-24 21:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:58:00 --> Input Class Initialized
INFO - 2021-03-24 21:58:00 --> Input Class Initialized
INFO - 2021-03-24 21:58:00 --> Language Class Initialized
INFO - 2021-03-24 21:58:00 --> Language Class Initialized
ERROR - 2021-03-24 21:58:00 --> 404 Page Not Found: administrator/Role/dist
ERROR - 2021-03-24 21:58:00 --> 404 Page Not Found: administrator/Role/dist
INFO - 2021-03-24 21:58:42 --> Config Class Initialized
INFO - 2021-03-24 21:58:42 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:58:42 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:58:42 --> Utf8 Class Initialized
INFO - 2021-03-24 21:58:42 --> URI Class Initialized
INFO - 2021-03-24 21:58:42 --> Router Class Initialized
INFO - 2021-03-24 21:58:42 --> Output Class Initialized
INFO - 2021-03-24 21:58:42 --> Security Class Initialized
DEBUG - 2021-03-24 21:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:58:42 --> Input Class Initialized
INFO - 2021-03-24 21:58:42 --> Language Class Initialized
INFO - 2021-03-24 21:58:42 --> Loader Class Initialized
INFO - 2021-03-24 21:58:42 --> Helper loaded: url_helper
INFO - 2021-03-24 21:58:42 --> Helper loaded: form_helper
INFO - 2021-03-24 21:58:42 --> Helper loaded: common_helper
INFO - 2021-03-24 21:58:42 --> Helper loaded: util_helper
INFO - 2021-03-24 21:58:42 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:58:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:58:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:58:42 --> Form Validation Class Initialized
INFO - 2021-03-24 21:58:42 --> Controller Class Initialized
INFO - 2021-03-24 21:58:42 --> Model Class Initialized
INFO - 2021-03-24 21:58:42 --> Model Class Initialized
INFO - 2021-03-24 21:58:42 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:58:42 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:58:42 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/role/add.php
INFO - 2021-03-24 21:58:42 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:58:42 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:58:42 --> Final output sent to browser
DEBUG - 2021-03-24 21:58:42 --> Total execution time: 0.0556
INFO - 2021-03-24 21:58:42 --> Config Class Initialized
INFO - 2021-03-24 21:58:42 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:58:42 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:58:42 --> Utf8 Class Initialized
INFO - 2021-03-24 21:58:42 --> URI Class Initialized
INFO - 2021-03-24 21:58:42 --> Router Class Initialized
INFO - 2021-03-24 21:58:42 --> Output Class Initialized
INFO - 2021-03-24 21:58:42 --> Config Class Initialized
INFO - 2021-03-24 21:58:42 --> Security Class Initialized
INFO - 2021-03-24 21:58:42 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:58:42 --> Input Class Initialized
INFO - 2021-03-24 21:58:42 --> Language Class Initialized
ERROR - 2021-03-24 21:58:42 --> 404 Page Not Found: administrator/Role/dist
DEBUG - 2021-03-24 21:58:42 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:58:42 --> Utf8 Class Initialized
INFO - 2021-03-24 21:58:42 --> URI Class Initialized
INFO - 2021-03-24 21:58:42 --> Router Class Initialized
INFO - 2021-03-24 21:58:42 --> Output Class Initialized
INFO - 2021-03-24 21:58:42 --> Security Class Initialized
DEBUG - 2021-03-24 21:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:58:42 --> Input Class Initialized
INFO - 2021-03-24 21:58:42 --> Language Class Initialized
ERROR - 2021-03-24 21:58:42 --> 404 Page Not Found: administrator/Role/dist
INFO - 2021-03-24 21:58:42 --> Config Class Initialized
INFO - 2021-03-24 21:58:42 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:58:42 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:58:42 --> Utf8 Class Initialized
INFO - 2021-03-24 21:58:42 --> URI Class Initialized
INFO - 2021-03-24 21:58:42 --> Router Class Initialized
INFO - 2021-03-24 21:58:42 --> Output Class Initialized
INFO - 2021-03-24 21:58:42 --> Config Class Initialized
INFO - 2021-03-24 21:58:42 --> Hooks Class Initialized
INFO - 2021-03-24 21:58:42 --> Security Class Initialized
DEBUG - 2021-03-24 21:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:58:42 --> Input Class Initialized
INFO - 2021-03-24 21:58:42 --> Language Class Initialized
ERROR - 2021-03-24 21:58:42 --> 404 Page Not Found: administrator/Role/dist
DEBUG - 2021-03-24 21:58:42 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:58:42 --> Utf8 Class Initialized
INFO - 2021-03-24 21:58:42 --> URI Class Initialized
INFO - 2021-03-24 21:58:42 --> Router Class Initialized
INFO - 2021-03-24 21:58:42 --> Output Class Initialized
INFO - 2021-03-24 21:58:42 --> Security Class Initialized
DEBUG - 2021-03-24 21:58:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:58:42 --> Input Class Initialized
INFO - 2021-03-24 21:58:42 --> Language Class Initialized
ERROR - 2021-03-24 21:58:42 --> 404 Page Not Found: administrator/Role/dist
INFO - 2021-03-24 21:58:49 --> Config Class Initialized
INFO - 2021-03-24 21:58:49 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:58:49 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:58:49 --> Utf8 Class Initialized
INFO - 2021-03-24 21:58:49 --> URI Class Initialized
INFO - 2021-03-24 21:58:49 --> Router Class Initialized
INFO - 2021-03-24 21:58:49 --> Output Class Initialized
INFO - 2021-03-24 21:58:49 --> Security Class Initialized
DEBUG - 2021-03-24 21:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:58:49 --> Input Class Initialized
INFO - 2021-03-24 21:58:49 --> Language Class Initialized
INFO - 2021-03-24 21:58:49 --> Loader Class Initialized
INFO - 2021-03-24 21:58:49 --> Helper loaded: url_helper
INFO - 2021-03-24 21:58:49 --> Helper loaded: form_helper
INFO - 2021-03-24 21:58:49 --> Helper loaded: common_helper
INFO - 2021-03-24 21:58:49 --> Helper loaded: util_helper
INFO - 2021-03-24 21:58:49 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:58:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:58:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:58:49 --> Form Validation Class Initialized
INFO - 2021-03-24 21:58:49 --> Controller Class Initialized
INFO - 2021-03-24 21:58:49 --> Model Class Initialized
INFO - 2021-03-24 21:58:49 --> Model Class Initialized
INFO - 2021-03-24 21:58:49 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-03-24 21:58:49 --> Config Class Initialized
INFO - 2021-03-24 21:58:49 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:58:49 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:58:49 --> Utf8 Class Initialized
INFO - 2021-03-24 21:58:49 --> URI Class Initialized
INFO - 2021-03-24 21:58:49 --> Router Class Initialized
INFO - 2021-03-24 21:58:49 --> Output Class Initialized
INFO - 2021-03-24 21:58:49 --> Security Class Initialized
DEBUG - 2021-03-24 21:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:58:49 --> Input Class Initialized
INFO - 2021-03-24 21:58:49 --> Language Class Initialized
INFO - 2021-03-24 21:58:49 --> Loader Class Initialized
INFO - 2021-03-24 21:58:49 --> Helper loaded: url_helper
INFO - 2021-03-24 21:58:49 --> Helper loaded: form_helper
INFO - 2021-03-24 21:58:49 --> Helper loaded: common_helper
INFO - 2021-03-24 21:58:49 --> Helper loaded: util_helper
INFO - 2021-03-24 21:58:49 --> Database Driver Class Initialized
DEBUG - 2021-03-24 21:58:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 21:58:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 21:58:49 --> Form Validation Class Initialized
INFO - 2021-03-24 21:58:49 --> Controller Class Initialized
INFO - 2021-03-24 21:58:49 --> Model Class Initialized
INFO - 2021-03-24 21:58:49 --> Model Class Initialized
INFO - 2021-03-24 21:58:49 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 21:58:49 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 21:58:49 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/role/add.php
INFO - 2021-03-24 21:58:49 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 21:58:49 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 21:58:49 --> Final output sent to browser
DEBUG - 2021-03-24 21:58:49 --> Total execution time: 0.0483
INFO - 2021-03-24 21:58:49 --> Config Class Initialized
INFO - 2021-03-24 21:58:49 --> Hooks Class Initialized
INFO - 2021-03-24 21:58:49 --> Config Class Initialized
INFO - 2021-03-24 21:58:49 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:58:49 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:58:49 --> Utf8 Class Initialized
INFO - 2021-03-24 21:58:49 --> URI Class Initialized
DEBUG - 2021-03-24 21:58:49 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:58:49 --> Utf8 Class Initialized
INFO - 2021-03-24 21:58:49 --> URI Class Initialized
INFO - 2021-03-24 21:58:49 --> Router Class Initialized
INFO - 2021-03-24 21:58:49 --> Router Class Initialized
INFO - 2021-03-24 21:58:49 --> Output Class Initialized
INFO - 2021-03-24 21:58:49 --> Output Class Initialized
INFO - 2021-03-24 21:58:49 --> Security Class Initialized
INFO - 2021-03-24 21:58:49 --> Security Class Initialized
DEBUG - 2021-03-24 21:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:58:49 --> Input Class Initialized
DEBUG - 2021-03-24 21:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:58:49 --> Input Class Initialized
INFO - 2021-03-24 21:58:49 --> Language Class Initialized
INFO - 2021-03-24 21:58:49 --> Language Class Initialized
ERROR - 2021-03-24 21:58:49 --> 404 Page Not Found: administrator/Role/dist
ERROR - 2021-03-24 21:58:49 --> 404 Page Not Found: administrator/Role/dist
INFO - 2021-03-24 21:58:49 --> Config Class Initialized
INFO - 2021-03-24 21:58:49 --> Hooks Class Initialized
DEBUG - 2021-03-24 21:58:49 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:58:49 --> Utf8 Class Initialized
INFO - 2021-03-24 21:58:49 --> URI Class Initialized
INFO - 2021-03-24 21:58:49 --> Router Class Initialized
INFO - 2021-03-24 21:58:49 --> Config Class Initialized
INFO - 2021-03-24 21:58:49 --> Hooks Class Initialized
INFO - 2021-03-24 21:58:49 --> Output Class Initialized
INFO - 2021-03-24 21:58:49 --> Security Class Initialized
DEBUG - 2021-03-24 21:58:49 --> UTF-8 Support Enabled
INFO - 2021-03-24 21:58:49 --> Utf8 Class Initialized
DEBUG - 2021-03-24 21:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:58:49 --> Input Class Initialized
INFO - 2021-03-24 21:58:49 --> URI Class Initialized
INFO - 2021-03-24 21:58:49 --> Language Class Initialized
INFO - 2021-03-24 21:58:49 --> Router Class Initialized
ERROR - 2021-03-24 21:58:49 --> 404 Page Not Found: administrator/Role/dist
INFO - 2021-03-24 21:58:49 --> Output Class Initialized
INFO - 2021-03-24 21:58:49 --> Security Class Initialized
DEBUG - 2021-03-24 21:58:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 21:58:49 --> Input Class Initialized
INFO - 2021-03-24 21:58:49 --> Language Class Initialized
ERROR - 2021-03-24 21:58:49 --> 404 Page Not Found: administrator/Role/dist
INFO - 2021-03-24 22:03:45 --> Config Class Initialized
INFO - 2021-03-24 22:03:45 --> Hooks Class Initialized
DEBUG - 2021-03-24 22:03:45 --> UTF-8 Support Enabled
INFO - 2021-03-24 22:03:45 --> Utf8 Class Initialized
INFO - 2021-03-24 22:03:45 --> URI Class Initialized
INFO - 2021-03-24 22:03:45 --> Router Class Initialized
INFO - 2021-03-24 22:03:45 --> Output Class Initialized
INFO - 2021-03-24 22:03:45 --> Security Class Initialized
DEBUG - 2021-03-24 22:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 22:03:45 --> Input Class Initialized
INFO - 2021-03-24 22:03:45 --> Language Class Initialized
INFO - 2021-03-24 22:03:45 --> Loader Class Initialized
INFO - 2021-03-24 22:03:45 --> Helper loaded: url_helper
INFO - 2021-03-24 22:03:45 --> Helper loaded: form_helper
INFO - 2021-03-24 22:03:45 --> Helper loaded: common_helper
INFO - 2021-03-24 22:03:45 --> Helper loaded: util_helper
INFO - 2021-03-24 22:03:45 --> Database Driver Class Initialized
DEBUG - 2021-03-24 22:03:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 22:03:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 22:03:45 --> Form Validation Class Initialized
INFO - 2021-03-24 22:03:45 --> Controller Class Initialized
INFO - 2021-03-24 22:03:45 --> Model Class Initialized
INFO - 2021-03-24 22:03:45 --> Model Class Initialized
INFO - 2021-03-24 22:03:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 22:03:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 22:03:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/role/list.php
INFO - 2021-03-24 22:03:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 22:03:45 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 22:03:45 --> Final output sent to browser
DEBUG - 2021-03-24 22:03:45 --> Total execution time: 0.0495
INFO - 2021-03-24 22:03:45 --> Config Class Initialized
INFO - 2021-03-24 22:03:45 --> Hooks Class Initialized
INFO - 2021-03-24 22:03:45 --> Config Class Initialized
INFO - 2021-03-24 22:03:45 --> Hooks Class Initialized
DEBUG - 2021-03-24 22:03:45 --> UTF-8 Support Enabled
INFO - 2021-03-24 22:03:45 --> Utf8 Class Initialized
INFO - 2021-03-24 22:03:45 --> URI Class Initialized
DEBUG - 2021-03-24 22:03:45 --> UTF-8 Support Enabled
INFO - 2021-03-24 22:03:45 --> Router Class Initialized
INFO - 2021-03-24 22:03:45 --> Output Class Initialized
INFO - 2021-03-24 22:03:45 --> Utf8 Class Initialized
INFO - 2021-03-24 22:03:45 --> Security Class Initialized
INFO - 2021-03-24 22:03:45 --> URI Class Initialized
DEBUG - 2021-03-24 22:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 22:03:45 --> Input Class Initialized
INFO - 2021-03-24 22:03:45 --> Router Class Initialized
INFO - 2021-03-24 22:03:45 --> Language Class Initialized
INFO - 2021-03-24 22:03:45 --> Output Class Initialized
ERROR - 2021-03-24 22:03:45 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-24 22:03:45 --> Security Class Initialized
DEBUG - 2021-03-24 22:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 22:03:45 --> Input Class Initialized
INFO - 2021-03-24 22:03:45 --> Language Class Initialized
ERROR - 2021-03-24 22:03:45 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-24 22:03:45 --> Config Class Initialized
INFO - 2021-03-24 22:03:45 --> Hooks Class Initialized
DEBUG - 2021-03-24 22:03:45 --> UTF-8 Support Enabled
INFO - 2021-03-24 22:03:45 --> Utf8 Class Initialized
INFO - 2021-03-24 22:03:45 --> URI Class Initialized
INFO - 2021-03-24 22:03:45 --> Router Class Initialized
INFO - 2021-03-24 22:03:45 --> Output Class Initialized
INFO - 2021-03-24 22:03:45 --> Security Class Initialized
INFO - 2021-03-24 22:03:45 --> Config Class Initialized
INFO - 2021-03-24 22:03:45 --> Hooks Class Initialized
DEBUG - 2021-03-24 22:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 22:03:45 --> Input Class Initialized
INFO - 2021-03-24 22:03:45 --> Language Class Initialized
DEBUG - 2021-03-24 22:03:45 --> UTF-8 Support Enabled
INFO - 2021-03-24 22:03:45 --> Utf8 Class Initialized
ERROR - 2021-03-24 22:03:45 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-24 22:03:45 --> URI Class Initialized
INFO - 2021-03-24 22:03:45 --> Router Class Initialized
INFO - 2021-03-24 22:03:45 --> Output Class Initialized
INFO - 2021-03-24 22:03:45 --> Security Class Initialized
DEBUG - 2021-03-24 22:03:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 22:03:45 --> Input Class Initialized
INFO - 2021-03-24 22:03:45 --> Language Class Initialized
ERROR - 2021-03-24 22:03:45 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-24 22:58:34 --> Config Class Initialized
INFO - 2021-03-24 22:58:34 --> Hooks Class Initialized
DEBUG - 2021-03-24 22:58:34 --> UTF-8 Support Enabled
INFO - 2021-03-24 22:58:34 --> Utf8 Class Initialized
INFO - 2021-03-24 22:58:34 --> URI Class Initialized
INFO - 2021-03-24 22:58:34 --> Router Class Initialized
INFO - 2021-03-24 22:58:34 --> Output Class Initialized
INFO - 2021-03-24 22:58:34 --> Security Class Initialized
DEBUG - 2021-03-24 22:58:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 22:58:34 --> Input Class Initialized
INFO - 2021-03-24 22:58:34 --> Language Class Initialized
INFO - 2021-03-24 22:58:34 --> Loader Class Initialized
INFO - 2021-03-24 22:58:34 --> Helper loaded: url_helper
INFO - 2021-03-24 22:58:34 --> Helper loaded: form_helper
INFO - 2021-03-24 22:58:34 --> Helper loaded: common_helper
INFO - 2021-03-24 22:58:34 --> Helper loaded: util_helper
INFO - 2021-03-24 22:58:34 --> Database Driver Class Initialized
DEBUG - 2021-03-24 22:58:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 22:58:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 22:58:34 --> Form Validation Class Initialized
INFO - 2021-03-24 22:58:34 --> Controller Class Initialized
INFO - 2021-03-24 22:58:34 --> Model Class Initialized
INFO - 2021-03-24 22:58:34 --> Model Class Initialized
INFO - 2021-03-24 23:22:18 --> Config Class Initialized
INFO - 2021-03-24 23:22:18 --> Hooks Class Initialized
DEBUG - 2021-03-24 23:22:18 --> UTF-8 Support Enabled
INFO - 2021-03-24 23:22:18 --> Utf8 Class Initialized
INFO - 2021-03-24 23:22:18 --> URI Class Initialized
INFO - 2021-03-24 23:22:18 --> Router Class Initialized
INFO - 2021-03-24 23:22:18 --> Output Class Initialized
INFO - 2021-03-24 23:22:18 --> Security Class Initialized
DEBUG - 2021-03-24 23:22:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 23:22:18 --> Input Class Initialized
INFO - 2021-03-24 23:22:18 --> Language Class Initialized
INFO - 2021-03-24 23:22:18 --> Loader Class Initialized
INFO - 2021-03-24 23:22:18 --> Helper loaded: url_helper
INFO - 2021-03-24 23:22:18 --> Helper loaded: form_helper
INFO - 2021-03-24 23:22:18 --> Helper loaded: common_helper
INFO - 2021-03-24 23:22:18 --> Helper loaded: util_helper
INFO - 2021-03-24 23:22:18 --> Database Driver Class Initialized
DEBUG - 2021-03-24 23:22:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 23:22:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 23:22:18 --> Form Validation Class Initialized
INFO - 2021-03-24 23:22:18 --> Controller Class Initialized
INFO - 2021-03-24 23:22:18 --> Model Class Initialized
INFO - 2021-03-24 23:22:18 --> Model Class Initialized
INFO - 2021-03-24 23:37:03 --> Config Class Initialized
INFO - 2021-03-24 23:37:03 --> Hooks Class Initialized
DEBUG - 2021-03-24 23:37:03 --> UTF-8 Support Enabled
INFO - 2021-03-24 23:37:03 --> Utf8 Class Initialized
INFO - 2021-03-24 23:37:03 --> URI Class Initialized
INFO - 2021-03-24 23:37:03 --> Router Class Initialized
INFO - 2021-03-24 23:37:03 --> Output Class Initialized
INFO - 2021-03-24 23:37:03 --> Security Class Initialized
DEBUG - 2021-03-24 23:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 23:37:03 --> Input Class Initialized
INFO - 2021-03-24 23:37:03 --> Language Class Initialized
INFO - 2021-03-24 23:37:03 --> Loader Class Initialized
INFO - 2021-03-24 23:37:03 --> Helper loaded: url_helper
INFO - 2021-03-24 23:37:03 --> Helper loaded: form_helper
INFO - 2021-03-24 23:37:03 --> Helper loaded: common_helper
INFO - 2021-03-24 23:37:03 --> Helper loaded: util_helper
INFO - 2021-03-24 23:37:03 --> Database Driver Class Initialized
DEBUG - 2021-03-24 23:37:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 23:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 23:37:03 --> Form Validation Class Initialized
INFO - 2021-03-24 23:37:03 --> Controller Class Initialized
INFO - 2021-03-24 23:37:03 --> Model Class Initialized
INFO - 2021-03-24 23:37:03 --> Model Class Initialized
INFO - 2021-03-24 23:37:25 --> Config Class Initialized
INFO - 2021-03-24 23:37:25 --> Hooks Class Initialized
DEBUG - 2021-03-24 23:37:25 --> UTF-8 Support Enabled
INFO - 2021-03-24 23:37:25 --> Utf8 Class Initialized
INFO - 2021-03-24 23:37:25 --> URI Class Initialized
INFO - 2021-03-24 23:37:25 --> Router Class Initialized
INFO - 2021-03-24 23:37:25 --> Output Class Initialized
INFO - 2021-03-24 23:37:25 --> Security Class Initialized
DEBUG - 2021-03-24 23:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 23:37:25 --> Input Class Initialized
INFO - 2021-03-24 23:37:25 --> Language Class Initialized
INFO - 2021-03-24 23:37:25 --> Loader Class Initialized
INFO - 2021-03-24 23:37:25 --> Helper loaded: url_helper
INFO - 2021-03-24 23:37:25 --> Helper loaded: form_helper
INFO - 2021-03-24 23:37:25 --> Helper loaded: common_helper
INFO - 2021-03-24 23:37:25 --> Helper loaded: util_helper
INFO - 2021-03-24 23:37:25 --> Database Driver Class Initialized
DEBUG - 2021-03-24 23:37:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 23:37:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 23:37:25 --> Form Validation Class Initialized
INFO - 2021-03-24 23:37:25 --> Controller Class Initialized
INFO - 2021-03-24 23:37:25 --> Model Class Initialized
INFO - 2021-03-24 23:37:25 --> Model Class Initialized
ERROR - 2021-03-24 23:37:25 --> Severity: error --> Exception: Call to a member function get() on null C:\xampp\htdocs\robust\php\application\controllers\administrator\Permission.php 29
INFO - 2021-03-24 23:37:49 --> Config Class Initialized
INFO - 2021-03-24 23:37:49 --> Hooks Class Initialized
DEBUG - 2021-03-24 23:37:49 --> UTF-8 Support Enabled
INFO - 2021-03-24 23:37:49 --> Utf8 Class Initialized
INFO - 2021-03-24 23:37:49 --> URI Class Initialized
INFO - 2021-03-24 23:37:49 --> Router Class Initialized
INFO - 2021-03-24 23:37:49 --> Output Class Initialized
INFO - 2021-03-24 23:37:49 --> Security Class Initialized
DEBUG - 2021-03-24 23:37:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 23:37:49 --> Input Class Initialized
INFO - 2021-03-24 23:37:49 --> Language Class Initialized
INFO - 2021-03-24 23:37:49 --> Loader Class Initialized
INFO - 2021-03-24 23:37:49 --> Helper loaded: url_helper
INFO - 2021-03-24 23:37:49 --> Helper loaded: form_helper
INFO - 2021-03-24 23:37:49 --> Helper loaded: common_helper
INFO - 2021-03-24 23:37:49 --> Helper loaded: util_helper
INFO - 2021-03-24 23:37:49 --> Database Driver Class Initialized
DEBUG - 2021-03-24 23:37:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 23:37:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 23:37:49 --> Form Validation Class Initialized
INFO - 2021-03-24 23:37:49 --> Controller Class Initialized
INFO - 2021-03-24 23:37:49 --> Model Class Initialized
INFO - 2021-03-24 23:37:49 --> Model Class Initialized
ERROR - 2021-03-24 23:37:49 --> Severity: error --> Exception: Call to a member function get() on null C:\xampp\htdocs\robust\php\application\controllers\administrator\Permission.php 29
INFO - 2021-03-24 23:38:39 --> Config Class Initialized
INFO - 2021-03-24 23:38:39 --> Hooks Class Initialized
DEBUG - 2021-03-24 23:38:40 --> UTF-8 Support Enabled
INFO - 2021-03-24 23:38:40 --> Utf8 Class Initialized
INFO - 2021-03-24 23:38:40 --> URI Class Initialized
INFO - 2021-03-24 23:38:40 --> Router Class Initialized
INFO - 2021-03-24 23:38:40 --> Output Class Initialized
INFO - 2021-03-24 23:38:40 --> Security Class Initialized
DEBUG - 2021-03-24 23:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 23:38:40 --> Input Class Initialized
INFO - 2021-03-24 23:38:40 --> Language Class Initialized
INFO - 2021-03-24 23:38:40 --> Loader Class Initialized
INFO - 2021-03-24 23:38:40 --> Helper loaded: url_helper
INFO - 2021-03-24 23:38:40 --> Helper loaded: form_helper
INFO - 2021-03-24 23:38:40 --> Helper loaded: common_helper
INFO - 2021-03-24 23:38:40 --> Helper loaded: util_helper
INFO - 2021-03-24 23:38:40 --> Database Driver Class Initialized
DEBUG - 2021-03-24 23:38:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 23:38:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 23:38:40 --> Form Validation Class Initialized
INFO - 2021-03-24 23:38:40 --> Controller Class Initialized
INFO - 2021-03-24 23:38:40 --> Model Class Initialized
INFO - 2021-03-24 23:38:40 --> Model Class Initialized
INFO - 2021-03-24 23:38:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 23:38:40 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
ERROR - 2021-03-24 23:38:40 --> Severity: error --> Exception: syntax error, unexpected 'ad' (T_STRING) C:\xampp\htdocs\robust\php\application\views\admin\permission\list.php 43
INFO - 2021-03-24 23:38:40 --> Config Class Initialized
INFO - 2021-03-24 23:38:40 --> Hooks Class Initialized
INFO - 2021-03-24 23:38:40 --> Config Class Initialized
INFO - 2021-03-24 23:38:40 --> Hooks Class Initialized
DEBUG - 2021-03-24 23:38:40 --> UTF-8 Support Enabled
INFO - 2021-03-24 23:38:40 --> Utf8 Class Initialized
INFO - 2021-03-24 23:38:40 --> URI Class Initialized
DEBUG - 2021-03-24 23:38:40 --> UTF-8 Support Enabled
INFO - 2021-03-24 23:38:40 --> Utf8 Class Initialized
INFO - 2021-03-24 23:38:40 --> Router Class Initialized
INFO - 2021-03-24 23:38:40 --> URI Class Initialized
INFO - 2021-03-24 23:38:40 --> Router Class Initialized
INFO - 2021-03-24 23:38:40 --> Output Class Initialized
INFO - 2021-03-24 23:38:40 --> Security Class Initialized
INFO - 2021-03-24 23:38:40 --> Output Class Initialized
DEBUG - 2021-03-24 23:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 23:38:40 --> Input Class Initialized
INFO - 2021-03-24 23:38:40 --> Security Class Initialized
INFO - 2021-03-24 23:38:40 --> Language Class Initialized
DEBUG - 2021-03-24 23:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 23:38:40 --> Input Class Initialized
INFO - 2021-03-24 23:38:40 --> Language Class Initialized
ERROR - 2021-03-24 23:38:40 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-03-24 23:38:40 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-24 23:38:40 --> Config Class Initialized
INFO - 2021-03-24 23:38:40 --> Config Class Initialized
INFO - 2021-03-24 23:38:40 --> Hooks Class Initialized
INFO - 2021-03-24 23:38:40 --> Hooks Class Initialized
DEBUG - 2021-03-24 23:38:40 --> UTF-8 Support Enabled
INFO - 2021-03-24 23:38:40 --> Utf8 Class Initialized
DEBUG - 2021-03-24 23:38:40 --> UTF-8 Support Enabled
INFO - 2021-03-24 23:38:40 --> Utf8 Class Initialized
INFO - 2021-03-24 23:38:40 --> URI Class Initialized
INFO - 2021-03-24 23:38:40 --> URI Class Initialized
INFO - 2021-03-24 23:38:40 --> Router Class Initialized
INFO - 2021-03-24 23:38:40 --> Router Class Initialized
INFO - 2021-03-24 23:38:40 --> Output Class Initialized
INFO - 2021-03-24 23:38:40 --> Output Class Initialized
INFO - 2021-03-24 23:38:40 --> Security Class Initialized
INFO - 2021-03-24 23:38:40 --> Security Class Initialized
DEBUG - 2021-03-24 23:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 23:38:40 --> Input Class Initialized
INFO - 2021-03-24 23:38:40 --> Language Class Initialized
DEBUG - 2021-03-24 23:38:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 23:38:40 --> Input Class Initialized
INFO - 2021-03-24 23:38:40 --> Language Class Initialized
ERROR - 2021-03-24 23:38:40 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-03-24 23:38:40 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-24 23:39:02 --> Config Class Initialized
INFO - 2021-03-24 23:39:02 --> Hooks Class Initialized
DEBUG - 2021-03-24 23:39:02 --> UTF-8 Support Enabled
INFO - 2021-03-24 23:39:02 --> Utf8 Class Initialized
INFO - 2021-03-24 23:39:02 --> URI Class Initialized
INFO - 2021-03-24 23:39:02 --> Router Class Initialized
INFO - 2021-03-24 23:39:02 --> Output Class Initialized
INFO - 2021-03-24 23:39:02 --> Security Class Initialized
DEBUG - 2021-03-24 23:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 23:39:02 --> Input Class Initialized
INFO - 2021-03-24 23:39:02 --> Language Class Initialized
INFO - 2021-03-24 23:39:02 --> Loader Class Initialized
INFO - 2021-03-24 23:39:02 --> Helper loaded: url_helper
INFO - 2021-03-24 23:39:02 --> Helper loaded: form_helper
INFO - 2021-03-24 23:39:02 --> Helper loaded: common_helper
INFO - 2021-03-24 23:39:02 --> Helper loaded: util_helper
INFO - 2021-03-24 23:39:02 --> Database Driver Class Initialized
DEBUG - 2021-03-24 23:39:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 23:39:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 23:39:02 --> Form Validation Class Initialized
INFO - 2021-03-24 23:39:02 --> Controller Class Initialized
INFO - 2021-03-24 23:39:02 --> Model Class Initialized
INFO - 2021-03-24 23:39:02 --> Model Class Initialized
INFO - 2021-03-24 23:39:02 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 23:39:02 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 23:39:02 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-24 23:39:02 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 23:39:02 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 23:39:02 --> Final output sent to browser
DEBUG - 2021-03-24 23:39:02 --> Total execution time: 0.0356
INFO - 2021-03-24 23:39:02 --> Config Class Initialized
INFO - 2021-03-24 23:39:02 --> Hooks Class Initialized
INFO - 2021-03-24 23:39:02 --> Config Class Initialized
INFO - 2021-03-24 23:39:02 --> Hooks Class Initialized
DEBUG - 2021-03-24 23:39:02 --> UTF-8 Support Enabled
INFO - 2021-03-24 23:39:02 --> Utf8 Class Initialized
DEBUG - 2021-03-24 23:39:02 --> UTF-8 Support Enabled
INFO - 2021-03-24 23:39:02 --> Utf8 Class Initialized
INFO - 2021-03-24 23:39:02 --> URI Class Initialized
INFO - 2021-03-24 23:39:02 --> URI Class Initialized
INFO - 2021-03-24 23:39:02 --> Router Class Initialized
INFO - 2021-03-24 23:39:02 --> Router Class Initialized
INFO - 2021-03-24 23:39:02 --> Output Class Initialized
INFO - 2021-03-24 23:39:02 --> Output Class Initialized
INFO - 2021-03-24 23:39:02 --> Security Class Initialized
INFO - 2021-03-24 23:39:02 --> Security Class Initialized
DEBUG - 2021-03-24 23:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 23:39:02 --> Input Class Initialized
INFO - 2021-03-24 23:39:02 --> Config Class Initialized
INFO - 2021-03-24 23:39:02 --> Language Class Initialized
INFO - 2021-03-24 23:39:02 --> Hooks Class Initialized
ERROR - 2021-03-24 23:39:02 --> 404 Page Not Found: administrator/Dist/img
DEBUG - 2021-03-24 23:39:02 --> UTF-8 Support Enabled
INFO - 2021-03-24 23:39:02 --> Utf8 Class Initialized
INFO - 2021-03-24 23:39:02 --> URI Class Initialized
INFO - 2021-03-24 23:39:02 --> Router Class Initialized
DEBUG - 2021-03-24 23:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 23:39:02 --> Input Class Initialized
INFO - 2021-03-24 23:39:02 --> Language Class Initialized
INFO - 2021-03-24 23:39:02 --> Config Class Initialized
INFO - 2021-03-24 23:39:02 --> Hooks Class Initialized
INFO - 2021-03-24 23:39:02 --> Output Class Initialized
ERROR - 2021-03-24 23:39:02 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-24 23:39:02 --> Security Class Initialized
DEBUG - 2021-03-24 23:39:02 --> UTF-8 Support Enabled
INFO - 2021-03-24 23:39:02 --> Utf8 Class Initialized
DEBUG - 2021-03-24 23:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 23:39:02 --> Input Class Initialized
INFO - 2021-03-24 23:39:02 --> Language Class Initialized
INFO - 2021-03-24 23:39:02 --> URI Class Initialized
ERROR - 2021-03-24 23:39:02 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-24 23:39:02 --> Router Class Initialized
INFO - 2021-03-24 23:39:02 --> Output Class Initialized
INFO - 2021-03-24 23:39:02 --> Security Class Initialized
DEBUG - 2021-03-24 23:39:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 23:39:02 --> Input Class Initialized
INFO - 2021-03-24 23:39:02 --> Language Class Initialized
ERROR - 2021-03-24 23:39:02 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-24 23:40:03 --> Config Class Initialized
INFO - 2021-03-24 23:40:03 --> Hooks Class Initialized
DEBUG - 2021-03-24 23:40:03 --> UTF-8 Support Enabled
INFO - 2021-03-24 23:40:03 --> Utf8 Class Initialized
INFO - 2021-03-24 23:40:03 --> URI Class Initialized
INFO - 2021-03-24 23:40:03 --> Router Class Initialized
INFO - 2021-03-24 23:40:03 --> Output Class Initialized
INFO - 2021-03-24 23:40:03 --> Security Class Initialized
DEBUG - 2021-03-24 23:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 23:40:03 --> Input Class Initialized
INFO - 2021-03-24 23:40:03 --> Language Class Initialized
INFO - 2021-03-24 23:40:03 --> Loader Class Initialized
INFO - 2021-03-24 23:40:03 --> Helper loaded: url_helper
INFO - 2021-03-24 23:40:03 --> Helper loaded: form_helper
INFO - 2021-03-24 23:40:03 --> Helper loaded: common_helper
INFO - 2021-03-24 23:40:03 --> Helper loaded: util_helper
INFO - 2021-03-24 23:40:03 --> Database Driver Class Initialized
DEBUG - 2021-03-24 23:40:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-03-24 23:40:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-03-24 23:40:03 --> Form Validation Class Initialized
INFO - 2021-03-24 23:40:03 --> Controller Class Initialized
INFO - 2021-03-24 23:40:03 --> Model Class Initialized
INFO - 2021-03-24 23:40:03 --> Model Class Initialized
INFO - 2021-03-24 23:40:03 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/header.php
INFO - 2021-03-24 23:40:03 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/sidebar.php
INFO - 2021-03-24 23:40:03 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/permission/list.php
INFO - 2021-03-24 23:40:03 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/footer.php
INFO - 2021-03-24 23:40:03 --> File loaded: C:\xampp\htdocs\robust\php\application\views\admin/layouts/index.php
INFO - 2021-03-24 23:40:03 --> Final output sent to browser
DEBUG - 2021-03-24 23:40:03 --> Total execution time: 0.0363
INFO - 2021-03-24 23:40:03 --> Config Class Initialized
INFO - 2021-03-24 23:40:03 --> Hooks Class Initialized
DEBUG - 2021-03-24 23:40:03 --> UTF-8 Support Enabled
INFO - 2021-03-24 23:40:03 --> Utf8 Class Initialized
INFO - 2021-03-24 23:40:03 --> Config Class Initialized
INFO - 2021-03-24 23:40:03 --> Hooks Class Initialized
INFO - 2021-03-24 23:40:03 --> URI Class Initialized
INFO - 2021-03-24 23:40:03 --> Router Class Initialized
DEBUG - 2021-03-24 23:40:03 --> UTF-8 Support Enabled
INFO - 2021-03-24 23:40:03 --> Utf8 Class Initialized
INFO - 2021-03-24 23:40:03 --> Output Class Initialized
INFO - 2021-03-24 23:40:03 --> URI Class Initialized
INFO - 2021-03-24 23:40:03 --> Security Class Initialized
DEBUG - 2021-03-24 23:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 23:40:03 --> Input Class Initialized
INFO - 2021-03-24 23:40:03 --> Router Class Initialized
INFO - 2021-03-24 23:40:03 --> Language Class Initialized
INFO - 2021-03-24 23:40:03 --> Output Class Initialized
ERROR - 2021-03-24 23:40:03 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-24 23:40:03 --> Security Class Initialized
DEBUG - 2021-03-24 23:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 23:40:03 --> Input Class Initialized
INFO - 2021-03-24 23:40:03 --> Language Class Initialized
ERROR - 2021-03-24 23:40:03 --> 404 Page Not Found: administrator/Dist/img
INFO - 2021-03-24 23:40:03 --> Config Class Initialized
INFO - 2021-03-24 23:40:03 --> Hooks Class Initialized
INFO - 2021-03-24 23:40:03 --> Config Class Initialized
INFO - 2021-03-24 23:40:03 --> Hooks Class Initialized
DEBUG - 2021-03-24 23:40:03 --> UTF-8 Support Enabled
INFO - 2021-03-24 23:40:03 --> Utf8 Class Initialized
DEBUG - 2021-03-24 23:40:03 --> UTF-8 Support Enabled
INFO - 2021-03-24 23:40:03 --> Utf8 Class Initialized
INFO - 2021-03-24 23:40:03 --> URI Class Initialized
INFO - 2021-03-24 23:40:03 --> URI Class Initialized
INFO - 2021-03-24 23:40:03 --> Router Class Initialized
INFO - 2021-03-24 23:40:03 --> Router Class Initialized
INFO - 2021-03-24 23:40:03 --> Output Class Initialized
INFO - 2021-03-24 23:40:03 --> Output Class Initialized
INFO - 2021-03-24 23:40:03 --> Security Class Initialized
DEBUG - 2021-03-24 23:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 23:40:03 --> Security Class Initialized
INFO - 2021-03-24 23:40:03 --> Input Class Initialized
INFO - 2021-03-24 23:40:03 --> Language Class Initialized
DEBUG - 2021-03-24 23:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-03-24 23:40:03 --> Input Class Initialized
INFO - 2021-03-24 23:40:03 --> Language Class Initialized
ERROR - 2021-03-24 23:40:03 --> 404 Page Not Found: administrator/Dist/img
ERROR - 2021-03-24 23:40:03 --> 404 Page Not Found: administrator/Dist/img
