<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2021-04-13 16:39:19 --> Config Class Initialized
INFO - 2021-04-13 16:39:19 --> Hooks Class Initialized
DEBUG - 2021-04-13 16:39:19 --> UTF-8 Support Enabled
INFO - 2021-04-13 16:39:19 --> Utf8 Class Initialized
INFO - 2021-04-13 16:39:19 --> URI Class Initialized
DEBUG - 2021-04-13 16:39:19 --> No URI present. Default controller set.
INFO - 2021-04-13 16:39:19 --> Router Class Initialized
INFO - 2021-04-13 16:39:19 --> Output Class Initialized
INFO - 2021-04-13 16:39:19 --> Security Class Initialized
DEBUG - 2021-04-13 16:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 16:39:19 --> Input Class Initialized
INFO - 2021-04-13 16:39:19 --> Language Class Initialized
INFO - 2021-04-13 16:39:19 --> Loader Class Initialized
INFO - 2021-04-13 16:39:19 --> Helper loaded: url_helper
INFO - 2021-04-13 16:39:19 --> Helper loaded: form_helper
INFO - 2021-04-13 16:39:19 --> Helper loaded: common_helper
INFO - 2021-04-13 16:39:19 --> Helper loaded: util_helper
INFO - 2021-04-13 16:39:19 --> Database Driver Class Initialized
ERROR - 2021-04-13 16:39:19 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 16:39:19 --> Unable to connect to the database
DEBUG - 2021-04-13 16:39:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 16:39:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 16:39:19 --> Form Validation Class Initialized
INFO - 2021-04-13 16:39:19 --> Controller Class Initialized
INFO - 2021-04-13 16:39:19 --> Model Class Initialized
INFO - 2021-04-13 16:39:19 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-13 16:39:19 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 16:39:19 --> Final output sent to browser
DEBUG - 2021-04-13 16:39:19 --> Total execution time: 0.0565
INFO - 2021-04-13 16:39:19 --> Config Class Initialized
INFO - 2021-04-13 16:39:19 --> Hooks Class Initialized
DEBUG - 2021-04-13 16:39:19 --> UTF-8 Support Enabled
INFO - 2021-04-13 16:39:19 --> Utf8 Class Initialized
INFO - 2021-04-13 16:39:19 --> URI Class Initialized
INFO - 2021-04-13 16:39:19 --> Router Class Initialized
INFO - 2021-04-13 16:39:19 --> Output Class Initialized
INFO - 2021-04-13 16:39:19 --> Security Class Initialized
DEBUG - 2021-04-13 16:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 16:39:19 --> Input Class Initialized
INFO - 2021-04-13 16:39:19 --> Language Class Initialized
ERROR - 2021-04-13 16:39:19 --> 404 Page Not Found: Fassets/img
INFO - 2021-04-13 16:39:22 --> Config Class Initialized
INFO - 2021-04-13 16:39:22 --> Hooks Class Initialized
DEBUG - 2021-04-13 16:39:22 --> UTF-8 Support Enabled
INFO - 2021-04-13 16:39:22 --> Utf8 Class Initialized
INFO - 2021-04-13 16:39:22 --> URI Class Initialized
INFO - 2021-04-13 16:39:22 --> Router Class Initialized
INFO - 2021-04-13 16:39:22 --> Output Class Initialized
INFO - 2021-04-13 16:39:22 --> Security Class Initialized
DEBUG - 2021-04-13 16:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 16:39:22 --> Input Class Initialized
INFO - 2021-04-13 16:39:22 --> Language Class Initialized
INFO - 2021-04-13 16:39:22 --> Loader Class Initialized
INFO - 2021-04-13 16:39:22 --> Helper loaded: url_helper
INFO - 2021-04-13 16:39:22 --> Helper loaded: form_helper
INFO - 2021-04-13 16:39:22 --> Helper loaded: common_helper
INFO - 2021-04-13 16:39:22 --> Helper loaded: util_helper
INFO - 2021-04-13 16:39:22 --> Database Driver Class Initialized
ERROR - 2021-04-13 16:39:22 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 16:39:22 --> Unable to connect to the database
DEBUG - 2021-04-13 16:39:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 16:39:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 16:39:22 --> Form Validation Class Initialized
INFO - 2021-04-13 16:39:22 --> Controller Class Initialized
INFO - 2021-04-13 16:39:22 --> Model Class Initialized
INFO - 2021-04-13 16:39:22 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 16:39:22 --> Final output sent to browser
DEBUG - 2021-04-13 16:39:22 --> Total execution time: 0.0261
INFO - 2021-04-13 16:39:22 --> Config Class Initialized
INFO - 2021-04-13 16:39:22 --> Hooks Class Initialized
DEBUG - 2021-04-13 16:39:22 --> UTF-8 Support Enabled
INFO - 2021-04-13 16:39:22 --> Utf8 Class Initialized
INFO - 2021-04-13 16:39:22 --> Config Class Initialized
INFO - 2021-04-13 16:39:22 --> Hooks Class Initialized
INFO - 2021-04-13 16:39:22 --> URI Class Initialized
INFO - 2021-04-13 16:39:22 --> Router Class Initialized
DEBUG - 2021-04-13 16:39:22 --> UTF-8 Support Enabled
INFO - 2021-04-13 16:39:22 --> Utf8 Class Initialized
INFO - 2021-04-13 16:39:22 --> URI Class Initialized
INFO - 2021-04-13 16:39:22 --> Output Class Initialized
INFO - 2021-04-13 16:39:22 --> Router Class Initialized
INFO - 2021-04-13 16:39:22 --> Security Class Initialized
DEBUG - 2021-04-13 16:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 16:39:22 --> Input Class Initialized
INFO - 2021-04-13 16:39:22 --> Output Class Initialized
INFO - 2021-04-13 16:39:22 --> Language Class Initialized
INFO - 2021-04-13 16:39:22 --> Security Class Initialized
ERROR - 2021-04-13 16:39:22 --> 404 Page Not Found: Fasset/img
DEBUG - 2021-04-13 16:39:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 16:39:22 --> Input Class Initialized
INFO - 2021-04-13 16:39:22 --> Language Class Initialized
ERROR - 2021-04-13 16:39:22 --> 404 Page Not Found: Fasset/img
INFO - 2021-04-13 16:39:24 --> Config Class Initialized
INFO - 2021-04-13 16:39:24 --> Hooks Class Initialized
DEBUG - 2021-04-13 16:39:24 --> UTF-8 Support Enabled
INFO - 2021-04-13 16:39:24 --> Utf8 Class Initialized
INFO - 2021-04-13 16:39:24 --> URI Class Initialized
DEBUG - 2021-04-13 16:39:24 --> No URI present. Default controller set.
INFO - 2021-04-13 16:39:24 --> Router Class Initialized
INFO - 2021-04-13 16:39:24 --> Output Class Initialized
INFO - 2021-04-13 16:39:24 --> Security Class Initialized
DEBUG - 2021-04-13 16:39:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 16:39:24 --> Input Class Initialized
INFO - 2021-04-13 16:39:24 --> Language Class Initialized
INFO - 2021-04-13 16:39:24 --> Loader Class Initialized
INFO - 2021-04-13 16:39:24 --> Helper loaded: url_helper
INFO - 2021-04-13 16:39:24 --> Helper loaded: form_helper
INFO - 2021-04-13 16:39:24 --> Helper loaded: common_helper
INFO - 2021-04-13 16:39:24 --> Helper loaded: util_helper
INFO - 2021-04-13 16:39:24 --> Database Driver Class Initialized
ERROR - 2021-04-13 16:39:24 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 16:39:24 --> Unable to connect to the database
DEBUG - 2021-04-13 16:39:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 16:39:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 16:39:24 --> Form Validation Class Initialized
INFO - 2021-04-13 16:39:24 --> Controller Class Initialized
INFO - 2021-04-13 16:39:24 --> Model Class Initialized
INFO - 2021-04-13 16:39:24 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-13 16:39:24 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 16:39:24 --> Final output sent to browser
DEBUG - 2021-04-13 16:39:24 --> Total execution time: 0.0273
INFO - 2021-04-13 16:39:26 --> Config Class Initialized
INFO - 2021-04-13 16:39:26 --> Hooks Class Initialized
DEBUG - 2021-04-13 16:39:26 --> UTF-8 Support Enabled
INFO - 2021-04-13 16:39:26 --> Utf8 Class Initialized
INFO - 2021-04-13 16:39:26 --> URI Class Initialized
INFO - 2021-04-13 16:39:26 --> Router Class Initialized
INFO - 2021-04-13 16:39:26 --> Output Class Initialized
INFO - 2021-04-13 16:39:26 --> Security Class Initialized
DEBUG - 2021-04-13 16:39:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 16:39:26 --> Input Class Initialized
INFO - 2021-04-13 16:39:26 --> Language Class Initialized
INFO - 2021-04-13 16:39:26 --> Loader Class Initialized
INFO - 2021-04-13 16:39:26 --> Helper loaded: url_helper
INFO - 2021-04-13 16:39:26 --> Helper loaded: form_helper
INFO - 2021-04-13 16:39:26 --> Helper loaded: common_helper
INFO - 2021-04-13 16:39:26 --> Helper loaded: util_helper
INFO - 2021-04-13 16:39:26 --> Database Driver Class Initialized
ERROR - 2021-04-13 16:39:26 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 16:39:26 --> Unable to connect to the database
DEBUG - 2021-04-13 16:39:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 16:39:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 16:39:26 --> Form Validation Class Initialized
INFO - 2021-04-13 16:39:26 --> Controller Class Initialized
INFO - 2021-04-13 16:39:26 --> Model Class Initialized
INFO - 2021-04-13 16:39:26 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\register.php
INFO - 2021-04-13 16:39:26 --> Final output sent to browser
DEBUG - 2021-04-13 16:39:26 --> Total execution time: 0.0251
INFO - 2021-04-13 16:39:28 --> Config Class Initialized
INFO - 2021-04-13 16:39:28 --> Hooks Class Initialized
DEBUG - 2021-04-13 16:39:28 --> UTF-8 Support Enabled
INFO - 2021-04-13 16:39:28 --> Utf8 Class Initialized
INFO - 2021-04-13 16:39:28 --> URI Class Initialized
DEBUG - 2021-04-13 16:39:28 --> No URI present. Default controller set.
INFO - 2021-04-13 16:39:28 --> Router Class Initialized
INFO - 2021-04-13 16:39:28 --> Output Class Initialized
INFO - 2021-04-13 16:39:28 --> Security Class Initialized
DEBUG - 2021-04-13 16:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 16:39:28 --> Input Class Initialized
INFO - 2021-04-13 16:39:28 --> Language Class Initialized
INFO - 2021-04-13 16:39:28 --> Loader Class Initialized
INFO - 2021-04-13 16:39:28 --> Helper loaded: url_helper
INFO - 2021-04-13 16:39:28 --> Helper loaded: form_helper
INFO - 2021-04-13 16:39:28 --> Helper loaded: common_helper
INFO - 2021-04-13 16:39:28 --> Helper loaded: util_helper
INFO - 2021-04-13 16:39:28 --> Database Driver Class Initialized
ERROR - 2021-04-13 16:39:28 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 16:39:28 --> Unable to connect to the database
DEBUG - 2021-04-13 16:39:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 16:39:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 16:39:28 --> Form Validation Class Initialized
INFO - 2021-04-13 16:39:28 --> Controller Class Initialized
INFO - 2021-04-13 16:39:28 --> Model Class Initialized
INFO - 2021-04-13 16:39:28 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-13 16:39:28 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 16:39:28 --> Final output sent to browser
DEBUG - 2021-04-13 16:39:28 --> Total execution time: 0.0282
INFO - 2021-04-13 16:39:29 --> Config Class Initialized
INFO - 2021-04-13 16:39:29 --> Hooks Class Initialized
DEBUG - 2021-04-13 16:39:29 --> UTF-8 Support Enabled
INFO - 2021-04-13 16:39:29 --> Utf8 Class Initialized
INFO - 2021-04-13 16:39:29 --> URI Class Initialized
INFO - 2021-04-13 16:39:29 --> Router Class Initialized
INFO - 2021-04-13 16:39:29 --> Output Class Initialized
INFO - 2021-04-13 16:39:29 --> Security Class Initialized
DEBUG - 2021-04-13 16:39:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 16:39:29 --> Input Class Initialized
INFO - 2021-04-13 16:39:29 --> Language Class Initialized
INFO - 2021-04-13 16:39:29 --> Loader Class Initialized
INFO - 2021-04-13 16:39:29 --> Helper loaded: url_helper
INFO - 2021-04-13 16:39:29 --> Helper loaded: form_helper
INFO - 2021-04-13 16:39:29 --> Helper loaded: common_helper
INFO - 2021-04-13 16:39:29 --> Helper loaded: util_helper
INFO - 2021-04-13 16:39:29 --> Database Driver Class Initialized
ERROR - 2021-04-13 16:39:29 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 16:39:29 --> Unable to connect to the database
DEBUG - 2021-04-13 16:39:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 16:39:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 16:39:29 --> Form Validation Class Initialized
INFO - 2021-04-13 16:39:29 --> Controller Class Initialized
INFO - 2021-04-13 16:39:29 --> Model Class Initialized
INFO - 2021-04-13 16:39:29 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 16:39:29 --> Final output sent to browser
DEBUG - 2021-04-13 16:39:29 --> Total execution time: 0.0294
INFO - 2021-04-13 16:39:33 --> Config Class Initialized
INFO - 2021-04-13 16:39:33 --> Hooks Class Initialized
DEBUG - 2021-04-13 16:39:33 --> UTF-8 Support Enabled
INFO - 2021-04-13 16:39:33 --> Utf8 Class Initialized
INFO - 2021-04-13 16:39:33 --> URI Class Initialized
DEBUG - 2021-04-13 16:39:33 --> No URI present. Default controller set.
INFO - 2021-04-13 16:39:33 --> Router Class Initialized
INFO - 2021-04-13 16:39:33 --> Output Class Initialized
INFO - 2021-04-13 16:39:33 --> Security Class Initialized
DEBUG - 2021-04-13 16:39:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 16:39:33 --> Input Class Initialized
INFO - 2021-04-13 16:39:33 --> Language Class Initialized
INFO - 2021-04-13 16:39:33 --> Loader Class Initialized
INFO - 2021-04-13 16:39:33 --> Helper loaded: url_helper
INFO - 2021-04-13 16:39:33 --> Helper loaded: form_helper
INFO - 2021-04-13 16:39:33 --> Helper loaded: common_helper
INFO - 2021-04-13 16:39:33 --> Helper loaded: util_helper
INFO - 2021-04-13 16:39:33 --> Database Driver Class Initialized
ERROR - 2021-04-13 16:39:33 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 16:39:33 --> Unable to connect to the database
DEBUG - 2021-04-13 16:39:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 16:39:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 16:39:33 --> Form Validation Class Initialized
INFO - 2021-04-13 16:39:33 --> Controller Class Initialized
INFO - 2021-04-13 16:39:33 --> Model Class Initialized
INFO - 2021-04-13 16:39:33 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-13 16:39:33 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 16:39:33 --> Final output sent to browser
DEBUG - 2021-04-13 16:39:33 --> Total execution time: 0.0273
INFO - 2021-04-13 16:39:36 --> Config Class Initialized
INFO - 2021-04-13 16:39:36 --> Hooks Class Initialized
DEBUG - 2021-04-13 16:39:36 --> UTF-8 Support Enabled
INFO - 2021-04-13 16:39:36 --> Utf8 Class Initialized
INFO - 2021-04-13 16:39:36 --> URI Class Initialized
INFO - 2021-04-13 16:39:36 --> Router Class Initialized
INFO - 2021-04-13 16:39:36 --> Output Class Initialized
INFO - 2021-04-13 16:39:36 --> Security Class Initialized
DEBUG - 2021-04-13 16:39:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 16:39:36 --> Input Class Initialized
INFO - 2021-04-13 16:39:36 --> Language Class Initialized
INFO - 2021-04-13 16:39:36 --> Loader Class Initialized
INFO - 2021-04-13 16:39:36 --> Helper loaded: url_helper
INFO - 2021-04-13 16:39:36 --> Helper loaded: form_helper
INFO - 2021-04-13 16:39:36 --> Helper loaded: common_helper
INFO - 2021-04-13 16:39:36 --> Helper loaded: util_helper
INFO - 2021-04-13 16:39:36 --> Database Driver Class Initialized
ERROR - 2021-04-13 16:39:36 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 16:39:36 --> Unable to connect to the database
DEBUG - 2021-04-13 16:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 16:39:36 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 16:39:36 --> Form Validation Class Initialized
INFO - 2021-04-13 16:39:36 --> Controller Class Initialized
INFO - 2021-04-13 16:39:36 --> Model Class Initialized
INFO - 2021-04-13 16:39:36 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 16:39:36 --> Final output sent to browser
DEBUG - 2021-04-13 16:39:36 --> Total execution time: 0.0248
INFO - 2021-04-13 16:40:00 --> Config Class Initialized
INFO - 2021-04-13 16:40:00 --> Hooks Class Initialized
DEBUG - 2021-04-13 16:40:00 --> UTF-8 Support Enabled
INFO - 2021-04-13 16:40:00 --> Utf8 Class Initialized
INFO - 2021-04-13 16:40:00 --> URI Class Initialized
INFO - 2021-04-13 16:40:00 --> Router Class Initialized
INFO - 2021-04-13 16:40:00 --> Output Class Initialized
INFO - 2021-04-13 16:40:00 --> Security Class Initialized
DEBUG - 2021-04-13 16:40:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 16:40:00 --> Input Class Initialized
INFO - 2021-04-13 16:40:00 --> Language Class Initialized
INFO - 2021-04-13 16:40:00 --> Loader Class Initialized
INFO - 2021-04-13 16:40:00 --> Helper loaded: url_helper
INFO - 2021-04-13 16:40:00 --> Helper loaded: form_helper
INFO - 2021-04-13 16:40:00 --> Helper loaded: common_helper
INFO - 2021-04-13 16:40:00 --> Helper loaded: util_helper
INFO - 2021-04-13 16:40:00 --> Database Driver Class Initialized
ERROR - 2021-04-13 16:40:00 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 16:40:00 --> Unable to connect to the database
DEBUG - 2021-04-13 16:40:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 16:40:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 16:40:00 --> Form Validation Class Initialized
INFO - 2021-04-13 16:40:00 --> Controller Class Initialized
INFO - 2021-04-13 16:40:00 --> Model Class Initialized
INFO - 2021-04-13 16:40:00 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-04-13 16:40:00 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 391
INFO - 2021-04-13 16:40:03 --> Config Class Initialized
INFO - 2021-04-13 16:40:03 --> Hooks Class Initialized
DEBUG - 2021-04-13 16:40:03 --> UTF-8 Support Enabled
INFO - 2021-04-13 16:40:03 --> Utf8 Class Initialized
INFO - 2021-04-13 16:40:03 --> URI Class Initialized
INFO - 2021-04-13 16:40:03 --> Router Class Initialized
INFO - 2021-04-13 16:40:03 --> Output Class Initialized
INFO - 2021-04-13 16:40:03 --> Security Class Initialized
DEBUG - 2021-04-13 16:40:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 16:40:03 --> Input Class Initialized
INFO - 2021-04-13 16:40:03 --> Language Class Initialized
INFO - 2021-04-13 16:40:03 --> Loader Class Initialized
INFO - 2021-04-13 16:40:03 --> Helper loaded: url_helper
INFO - 2021-04-13 16:40:03 --> Helper loaded: form_helper
INFO - 2021-04-13 16:40:03 --> Helper loaded: common_helper
INFO - 2021-04-13 16:40:03 --> Helper loaded: util_helper
INFO - 2021-04-13 16:40:03 --> Database Driver Class Initialized
ERROR - 2021-04-13 16:40:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 16:40:03 --> Unable to connect to the database
DEBUG - 2021-04-13 16:40:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 16:40:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 16:40:03 --> Form Validation Class Initialized
INFO - 2021-04-13 16:40:03 --> Controller Class Initialized
INFO - 2021-04-13 16:40:03 --> Model Class Initialized
INFO - 2021-04-13 16:40:03 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 16:40:03 --> Final output sent to browser
DEBUG - 2021-04-13 16:40:03 --> Total execution time: 0.0310
INFO - 2021-04-13 16:41:17 --> Config Class Initialized
INFO - 2021-04-13 16:41:17 --> Hooks Class Initialized
DEBUG - 2021-04-13 16:41:17 --> UTF-8 Support Enabled
INFO - 2021-04-13 16:41:17 --> Utf8 Class Initialized
INFO - 2021-04-13 16:41:17 --> URI Class Initialized
INFO - 2021-04-13 16:41:17 --> Router Class Initialized
INFO - 2021-04-13 16:41:17 --> Output Class Initialized
INFO - 2021-04-13 16:41:17 --> Security Class Initialized
DEBUG - 2021-04-13 16:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 16:41:17 --> Input Class Initialized
INFO - 2021-04-13 16:41:17 --> Language Class Initialized
INFO - 2021-04-13 16:41:17 --> Loader Class Initialized
INFO - 2021-04-13 16:41:17 --> Helper loaded: url_helper
INFO - 2021-04-13 16:41:17 --> Helper loaded: form_helper
INFO - 2021-04-13 16:41:17 --> Helper loaded: common_helper
INFO - 2021-04-13 16:41:17 --> Helper loaded: util_helper
INFO - 2021-04-13 16:41:17 --> Database Driver Class Initialized
ERROR - 2021-04-13 16:41:17 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 16:41:17 --> Unable to connect to the database
DEBUG - 2021-04-13 16:41:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 16:41:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 16:41:17 --> Form Validation Class Initialized
INFO - 2021-04-13 16:41:17 --> Controller Class Initialized
INFO - 2021-04-13 16:41:17 --> Model Class Initialized
INFO - 2021-04-13 16:41:17 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 16:41:17 --> Final output sent to browser
DEBUG - 2021-04-13 16:41:17 --> Total execution time: 0.0266
INFO - 2021-04-13 16:41:17 --> Config Class Initialized
INFO - 2021-04-13 16:41:17 --> Hooks Class Initialized
INFO - 2021-04-13 16:41:17 --> Config Class Initialized
INFO - 2021-04-13 16:41:17 --> Hooks Class Initialized
DEBUG - 2021-04-13 16:41:17 --> UTF-8 Support Enabled
INFO - 2021-04-13 16:41:17 --> Utf8 Class Initialized
INFO - 2021-04-13 16:41:17 --> URI Class Initialized
DEBUG - 2021-04-13 16:41:17 --> UTF-8 Support Enabled
INFO - 2021-04-13 16:41:17 --> Router Class Initialized
INFO - 2021-04-13 16:41:17 --> Utf8 Class Initialized
INFO - 2021-04-13 16:41:17 --> URI Class Initialized
INFO - 2021-04-13 16:41:17 --> Output Class Initialized
INFO - 2021-04-13 16:41:17 --> Router Class Initialized
INFO - 2021-04-13 16:41:17 --> Security Class Initialized
DEBUG - 2021-04-13 16:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 16:41:17 --> Output Class Initialized
INFO - 2021-04-13 16:41:17 --> Input Class Initialized
INFO - 2021-04-13 16:41:17 --> Language Class Initialized
INFO - 2021-04-13 16:41:17 --> Security Class Initialized
ERROR - 2021-04-13 16:41:17 --> 404 Page Not Found: Fasset/img
DEBUG - 2021-04-13 16:41:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 16:41:17 --> Input Class Initialized
INFO - 2021-04-13 16:41:17 --> Language Class Initialized
ERROR - 2021-04-13 16:41:17 --> 404 Page Not Found: Fasset/img
INFO - 2021-04-13 16:41:37 --> Config Class Initialized
INFO - 2021-04-13 16:41:37 --> Hooks Class Initialized
DEBUG - 2021-04-13 16:41:37 --> UTF-8 Support Enabled
INFO - 2021-04-13 16:41:37 --> Utf8 Class Initialized
INFO - 2021-04-13 16:41:37 --> URI Class Initialized
INFO - 2021-04-13 16:41:37 --> Router Class Initialized
INFO - 2021-04-13 16:41:37 --> Output Class Initialized
INFO - 2021-04-13 16:41:37 --> Security Class Initialized
DEBUG - 2021-04-13 16:41:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 16:41:37 --> Input Class Initialized
INFO - 2021-04-13 16:41:37 --> Language Class Initialized
INFO - 2021-04-13 16:41:37 --> Loader Class Initialized
INFO - 2021-04-13 16:41:37 --> Helper loaded: url_helper
INFO - 2021-04-13 16:41:37 --> Helper loaded: form_helper
INFO - 2021-04-13 16:41:37 --> Helper loaded: common_helper
INFO - 2021-04-13 16:41:37 --> Helper loaded: util_helper
INFO - 2021-04-13 16:41:37 --> Database Driver Class Initialized
ERROR - 2021-04-13 16:41:37 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 16:41:37 --> Unable to connect to the database
DEBUG - 2021-04-13 16:41:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 16:41:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 16:41:37 --> Form Validation Class Initialized
INFO - 2021-04-13 16:41:37 --> Controller Class Initialized
INFO - 2021-04-13 16:41:37 --> Model Class Initialized
INFO - 2021-04-13 16:41:37 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-04-13 16:41:37 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 391
INFO - 2021-04-13 16:41:39 --> Config Class Initialized
INFO - 2021-04-13 16:41:39 --> Hooks Class Initialized
DEBUG - 2021-04-13 16:41:39 --> UTF-8 Support Enabled
INFO - 2021-04-13 16:41:39 --> Utf8 Class Initialized
INFO - 2021-04-13 16:41:39 --> URI Class Initialized
INFO - 2021-04-13 16:41:39 --> Router Class Initialized
INFO - 2021-04-13 16:41:39 --> Output Class Initialized
INFO - 2021-04-13 16:41:39 --> Security Class Initialized
DEBUG - 2021-04-13 16:41:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 16:41:39 --> Input Class Initialized
INFO - 2021-04-13 16:41:39 --> Language Class Initialized
INFO - 2021-04-13 16:41:39 --> Loader Class Initialized
INFO - 2021-04-13 16:41:39 --> Helper loaded: url_helper
INFO - 2021-04-13 16:41:39 --> Helper loaded: form_helper
INFO - 2021-04-13 16:41:39 --> Helper loaded: common_helper
INFO - 2021-04-13 16:41:39 --> Helper loaded: util_helper
INFO - 2021-04-13 16:41:39 --> Database Driver Class Initialized
ERROR - 2021-04-13 16:41:39 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 16:41:39 --> Unable to connect to the database
DEBUG - 2021-04-13 16:41:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 16:41:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 16:41:39 --> Form Validation Class Initialized
INFO - 2021-04-13 16:41:39 --> Controller Class Initialized
INFO - 2021-04-13 16:41:39 --> Model Class Initialized
INFO - 2021-04-13 16:41:39 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 16:41:39 --> Final output sent to browser
DEBUG - 2021-04-13 16:41:39 --> Total execution time: 0.0398
INFO - 2021-04-13 16:51:37 --> Config Class Initialized
INFO - 2021-04-13 16:51:37 --> Hooks Class Initialized
DEBUG - 2021-04-13 16:51:37 --> UTF-8 Support Enabled
INFO - 2021-04-13 16:51:37 --> Utf8 Class Initialized
INFO - 2021-04-13 16:51:37 --> URI Class Initialized
INFO - 2021-04-13 16:51:37 --> Router Class Initialized
INFO - 2021-04-13 16:51:37 --> Output Class Initialized
INFO - 2021-04-13 16:51:37 --> Security Class Initialized
DEBUG - 2021-04-13 16:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 16:51:37 --> Input Class Initialized
INFO - 2021-04-13 16:51:37 --> Language Class Initialized
INFO - 2021-04-13 16:51:37 --> Loader Class Initialized
INFO - 2021-04-13 16:51:37 --> Helper loaded: url_helper
INFO - 2021-04-13 16:51:37 --> Helper loaded: form_helper
INFO - 2021-04-13 16:51:37 --> Helper loaded: common_helper
INFO - 2021-04-13 16:51:37 --> Helper loaded: util_helper
INFO - 2021-04-13 16:51:37 --> Database Driver Class Initialized
ERROR - 2021-04-13 16:51:37 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 16:51:37 --> Unable to connect to the database
DEBUG - 2021-04-13 16:51:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 16:51:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 16:51:37 --> Form Validation Class Initialized
INFO - 2021-04-13 16:51:37 --> Controller Class Initialized
INFO - 2021-04-13 16:51:37 --> Model Class Initialized
INFO - 2021-04-13 16:51:37 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 16:51:37 --> Final output sent to browser
DEBUG - 2021-04-13 16:51:37 --> Total execution time: 0.0270
INFO - 2021-04-13 16:51:37 --> Config Class Initialized
INFO - 2021-04-13 16:51:37 --> Config Class Initialized
INFO - 2021-04-13 16:51:37 --> Hooks Class Initialized
INFO - 2021-04-13 16:51:37 --> Hooks Class Initialized
DEBUG - 2021-04-13 16:51:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:51:37 --> UTF-8 Support Enabled
INFO - 2021-04-13 16:51:37 --> Utf8 Class Initialized
INFO - 2021-04-13 16:51:37 --> Utf8 Class Initialized
INFO - 2021-04-13 16:51:37 --> URI Class Initialized
INFO - 2021-04-13 16:51:37 --> URI Class Initialized
INFO - 2021-04-13 16:51:37 --> Router Class Initialized
INFO - 2021-04-13 16:51:37 --> Router Class Initialized
INFO - 2021-04-13 16:51:37 --> Output Class Initialized
INFO - 2021-04-13 16:51:37 --> Output Class Initialized
INFO - 2021-04-13 16:51:37 --> Security Class Initialized
INFO - 2021-04-13 16:51:37 --> Security Class Initialized
DEBUG - 2021-04-13 16:51:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:51:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 16:51:37 --> Input Class Initialized
INFO - 2021-04-13 16:51:37 --> Input Class Initialized
INFO - 2021-04-13 16:51:37 --> Language Class Initialized
INFO - 2021-04-13 16:51:37 --> Language Class Initialized
ERROR - 2021-04-13 16:51:37 --> 404 Page Not Found: Fasset/img
ERROR - 2021-04-13 16:51:37 --> 404 Page Not Found: Fasset/img
INFO - 2021-04-13 16:54:14 --> Config Class Initialized
INFO - 2021-04-13 16:54:14 --> Hooks Class Initialized
DEBUG - 2021-04-13 16:54:14 --> UTF-8 Support Enabled
INFO - 2021-04-13 16:54:14 --> Utf8 Class Initialized
INFO - 2021-04-13 16:54:14 --> URI Class Initialized
INFO - 2021-04-13 16:54:14 --> Router Class Initialized
INFO - 2021-04-13 16:54:14 --> Output Class Initialized
INFO - 2021-04-13 16:54:14 --> Security Class Initialized
DEBUG - 2021-04-13 16:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 16:54:14 --> Input Class Initialized
INFO - 2021-04-13 16:54:14 --> Language Class Initialized
INFO - 2021-04-13 16:54:14 --> Loader Class Initialized
INFO - 2021-04-13 16:54:14 --> Helper loaded: url_helper
INFO - 2021-04-13 16:54:14 --> Helper loaded: form_helper
INFO - 2021-04-13 16:54:14 --> Helper loaded: common_helper
INFO - 2021-04-13 16:54:14 --> Helper loaded: util_helper
INFO - 2021-04-13 16:54:14 --> Database Driver Class Initialized
ERROR - 2021-04-13 16:54:14 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 16:54:14 --> Unable to connect to the database
DEBUG - 2021-04-13 16:54:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 16:54:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 16:54:14 --> Form Validation Class Initialized
INFO - 2021-04-13 16:54:14 --> Controller Class Initialized
INFO - 2021-04-13 16:54:14 --> Model Class Initialized
INFO - 2021-04-13 16:54:14 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 16:54:14 --> Final output sent to browser
DEBUG - 2021-04-13 16:54:14 --> Total execution time: 0.0344
INFO - 2021-04-13 16:54:14 --> Config Class Initialized
INFO - 2021-04-13 16:54:14 --> Hooks Class Initialized
INFO - 2021-04-13 16:54:14 --> Config Class Initialized
INFO - 2021-04-13 16:54:14 --> Hooks Class Initialized
DEBUG - 2021-04-13 16:54:14 --> UTF-8 Support Enabled
INFO - 2021-04-13 16:54:14 --> Utf8 Class Initialized
INFO - 2021-04-13 16:54:14 --> URI Class Initialized
INFO - 2021-04-13 16:54:14 --> Router Class Initialized
DEBUG - 2021-04-13 16:54:14 --> UTF-8 Support Enabled
INFO - 2021-04-13 16:54:14 --> Utf8 Class Initialized
INFO - 2021-04-13 16:54:14 --> Output Class Initialized
INFO - 2021-04-13 16:54:14 --> URI Class Initialized
INFO - 2021-04-13 16:54:14 --> Security Class Initialized
INFO - 2021-04-13 16:54:14 --> Router Class Initialized
DEBUG - 2021-04-13 16:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 16:54:14 --> Input Class Initialized
INFO - 2021-04-13 16:54:14 --> Output Class Initialized
INFO - 2021-04-13 16:54:14 --> Language Class Initialized
INFO - 2021-04-13 16:54:14 --> Security Class Initialized
ERROR - 2021-04-13 16:54:14 --> 404 Page Not Found: Fasset/img
DEBUG - 2021-04-13 16:54:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 16:54:14 --> Input Class Initialized
INFO - 2021-04-13 16:54:14 --> Language Class Initialized
ERROR - 2021-04-13 16:54:14 --> 404 Page Not Found: Fasset/img
INFO - 2021-04-13 16:54:34 --> Config Class Initialized
INFO - 2021-04-13 16:54:34 --> Hooks Class Initialized
DEBUG - 2021-04-13 16:54:34 --> UTF-8 Support Enabled
INFO - 2021-04-13 16:54:34 --> Utf8 Class Initialized
INFO - 2021-04-13 16:54:34 --> URI Class Initialized
INFO - 2021-04-13 16:54:34 --> Router Class Initialized
INFO - 2021-04-13 16:54:34 --> Output Class Initialized
INFO - 2021-04-13 16:54:34 --> Security Class Initialized
DEBUG - 2021-04-13 16:54:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 16:54:34 --> Input Class Initialized
INFO - 2021-04-13 16:54:34 --> Language Class Initialized
INFO - 2021-04-13 16:54:34 --> Loader Class Initialized
INFO - 2021-04-13 16:54:34 --> Helper loaded: url_helper
INFO - 2021-04-13 16:54:34 --> Helper loaded: form_helper
INFO - 2021-04-13 16:54:34 --> Helper loaded: common_helper
INFO - 2021-04-13 16:54:34 --> Helper loaded: util_helper
INFO - 2021-04-13 16:54:34 --> Database Driver Class Initialized
ERROR - 2021-04-13 16:54:34 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 16:54:34 --> Unable to connect to the database
DEBUG - 2021-04-13 16:54:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 16:54:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 16:54:34 --> Form Validation Class Initialized
INFO - 2021-04-13 16:54:34 --> Controller Class Initialized
INFO - 2021-04-13 16:54:34 --> Model Class Initialized
INFO - 2021-04-13 16:54:34 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-04-13 16:54:34 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 391
INFO - 2021-04-13 16:54:37 --> Config Class Initialized
INFO - 2021-04-13 16:54:37 --> Hooks Class Initialized
DEBUG - 2021-04-13 16:54:37 --> UTF-8 Support Enabled
INFO - 2021-04-13 16:54:37 --> Utf8 Class Initialized
INFO - 2021-04-13 16:54:37 --> URI Class Initialized
INFO - 2021-04-13 16:54:37 --> Router Class Initialized
INFO - 2021-04-13 16:54:37 --> Output Class Initialized
INFO - 2021-04-13 16:54:37 --> Security Class Initialized
DEBUG - 2021-04-13 16:54:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 16:54:37 --> Input Class Initialized
INFO - 2021-04-13 16:54:37 --> Language Class Initialized
INFO - 2021-04-13 16:54:37 --> Loader Class Initialized
INFO - 2021-04-13 16:54:37 --> Helper loaded: url_helper
INFO - 2021-04-13 16:54:37 --> Helper loaded: form_helper
INFO - 2021-04-13 16:54:37 --> Helper loaded: common_helper
INFO - 2021-04-13 16:54:37 --> Helper loaded: util_helper
INFO - 2021-04-13 16:54:37 --> Database Driver Class Initialized
ERROR - 2021-04-13 16:54:37 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 16:54:37 --> Unable to connect to the database
DEBUG - 2021-04-13 16:54:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 16:54:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 16:54:37 --> Form Validation Class Initialized
INFO - 2021-04-13 16:54:37 --> Controller Class Initialized
INFO - 2021-04-13 16:54:37 --> Model Class Initialized
INFO - 2021-04-13 16:54:37 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 16:54:37 --> Final output sent to browser
DEBUG - 2021-04-13 16:54:37 --> Total execution time: 0.0308
INFO - 2021-04-13 17:17:21 --> Config Class Initialized
INFO - 2021-04-13 17:17:21 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:17:21 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:17:21 --> Utf8 Class Initialized
INFO - 2021-04-13 17:17:21 --> URI Class Initialized
INFO - 2021-04-13 17:17:21 --> Router Class Initialized
INFO - 2021-04-13 17:17:21 --> Output Class Initialized
INFO - 2021-04-13 17:17:21 --> Security Class Initialized
DEBUG - 2021-04-13 17:17:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:17:21 --> Input Class Initialized
INFO - 2021-04-13 17:17:21 --> Language Class Initialized
INFO - 2021-04-13 17:17:21 --> Loader Class Initialized
INFO - 2021-04-13 17:17:21 --> Helper loaded: url_helper
INFO - 2021-04-13 17:17:21 --> Helper loaded: form_helper
INFO - 2021-04-13 17:17:21 --> Helper loaded: common_helper
INFO - 2021-04-13 17:17:21 --> Helper loaded: util_helper
INFO - 2021-04-13 17:17:21 --> Database Driver Class Initialized
ERROR - 2021-04-13 17:17:21 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 17:17:21 --> Unable to connect to the database
DEBUG - 2021-04-13 17:17:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 17:17:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 17:17:21 --> Form Validation Class Initialized
INFO - 2021-04-13 17:17:21 --> Controller Class Initialized
INFO - 2021-04-13 17:17:21 --> Model Class Initialized
INFO - 2021-04-13 17:17:21 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 17:17:21 --> Final output sent to browser
DEBUG - 2021-04-13 17:17:21 --> Total execution time: 0.0277
INFO - 2021-04-13 17:17:22 --> Config Class Initialized
INFO - 2021-04-13 17:17:22 --> Config Class Initialized
INFO - 2021-04-13 17:17:22 --> Hooks Class Initialized
INFO - 2021-04-13 17:17:22 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:17:22 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:17:22 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:17:22 --> Utf8 Class Initialized
INFO - 2021-04-13 17:17:22 --> Utf8 Class Initialized
INFO - 2021-04-13 17:17:22 --> URI Class Initialized
INFO - 2021-04-13 17:17:22 --> URI Class Initialized
INFO - 2021-04-13 17:17:22 --> Router Class Initialized
INFO - 2021-04-13 17:17:22 --> Router Class Initialized
INFO - 2021-04-13 17:17:22 --> Output Class Initialized
INFO - 2021-04-13 17:17:22 --> Output Class Initialized
INFO - 2021-04-13 17:17:22 --> Security Class Initialized
INFO - 2021-04-13 17:17:22 --> Security Class Initialized
DEBUG - 2021-04-13 17:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:17:22 --> Input Class Initialized
INFO - 2021-04-13 17:17:22 --> Language Class Initialized
DEBUG - 2021-04-13 17:17:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:17:22 --> Input Class Initialized
INFO - 2021-04-13 17:17:22 --> Language Class Initialized
ERROR - 2021-04-13 17:17:22 --> 404 Page Not Found: Fasset/img
ERROR - 2021-04-13 17:17:22 --> 404 Page Not Found: Fasset/img
INFO - 2021-04-13 17:17:45 --> Config Class Initialized
INFO - 2021-04-13 17:17:45 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:17:45 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:17:45 --> Utf8 Class Initialized
INFO - 2021-04-13 17:17:45 --> URI Class Initialized
INFO - 2021-04-13 17:17:45 --> Router Class Initialized
INFO - 2021-04-13 17:17:45 --> Output Class Initialized
INFO - 2021-04-13 17:17:45 --> Security Class Initialized
DEBUG - 2021-04-13 17:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:17:45 --> Input Class Initialized
INFO - 2021-04-13 17:17:45 --> Language Class Initialized
INFO - 2021-04-13 17:17:45 --> Loader Class Initialized
INFO - 2021-04-13 17:17:45 --> Helper loaded: url_helper
INFO - 2021-04-13 17:17:45 --> Helper loaded: form_helper
INFO - 2021-04-13 17:17:45 --> Helper loaded: common_helper
INFO - 2021-04-13 17:17:45 --> Helper loaded: util_helper
INFO - 2021-04-13 17:17:45 --> Database Driver Class Initialized
ERROR - 2021-04-13 17:17:45 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 17:17:45 --> Unable to connect to the database
DEBUG - 2021-04-13 17:17:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 17:17:45 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 17:17:45 --> Form Validation Class Initialized
INFO - 2021-04-13 17:17:45 --> Controller Class Initialized
INFO - 2021-04-13 17:17:45 --> Model Class Initialized
INFO - 2021-04-13 17:17:45 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 17:17:45 --> Final output sent to browser
DEBUG - 2021-04-13 17:17:45 --> Total execution time: 0.0352
INFO - 2021-04-13 17:17:45 --> Config Class Initialized
INFO - 2021-04-13 17:17:45 --> Config Class Initialized
INFO - 2021-04-13 17:17:45 --> Hooks Class Initialized
INFO - 2021-04-13 17:17:45 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:17:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:17:45 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:17:45 --> Utf8 Class Initialized
INFO - 2021-04-13 17:17:45 --> Utf8 Class Initialized
INFO - 2021-04-13 17:17:45 --> URI Class Initialized
INFO - 2021-04-13 17:17:45 --> URI Class Initialized
INFO - 2021-04-13 17:17:45 --> Router Class Initialized
INFO - 2021-04-13 17:17:45 --> Router Class Initialized
INFO - 2021-04-13 17:17:45 --> Output Class Initialized
INFO - 2021-04-13 17:17:45 --> Output Class Initialized
INFO - 2021-04-13 17:17:45 --> Security Class Initialized
INFO - 2021-04-13 17:17:45 --> Security Class Initialized
DEBUG - 2021-04-13 17:17:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:17:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:17:45 --> Input Class Initialized
INFO - 2021-04-13 17:17:45 --> Input Class Initialized
INFO - 2021-04-13 17:17:45 --> Language Class Initialized
INFO - 2021-04-13 17:17:45 --> Language Class Initialized
ERROR - 2021-04-13 17:17:45 --> 404 Page Not Found: Fasset/img
ERROR - 2021-04-13 17:17:45 --> 404 Page Not Found: Fasset/img
INFO - 2021-04-13 17:17:46 --> Config Class Initialized
INFO - 2021-04-13 17:17:46 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:17:46 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:17:46 --> Utf8 Class Initialized
INFO - 2021-04-13 17:17:46 --> URI Class Initialized
INFO - 2021-04-13 17:17:46 --> Router Class Initialized
INFO - 2021-04-13 17:17:46 --> Output Class Initialized
INFO - 2021-04-13 17:17:46 --> Security Class Initialized
DEBUG - 2021-04-13 17:17:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:17:46 --> Input Class Initialized
INFO - 2021-04-13 17:17:46 --> Language Class Initialized
INFO - 2021-04-13 17:17:46 --> Loader Class Initialized
INFO - 2021-04-13 17:17:46 --> Helper loaded: url_helper
INFO - 2021-04-13 17:17:46 --> Helper loaded: form_helper
INFO - 2021-04-13 17:17:46 --> Helper loaded: common_helper
INFO - 2021-04-13 17:17:46 --> Helper loaded: util_helper
INFO - 2021-04-13 17:17:46 --> Database Driver Class Initialized
ERROR - 2021-04-13 17:17:46 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 17:17:46 --> Unable to connect to the database
DEBUG - 2021-04-13 17:17:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 17:17:46 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 17:17:46 --> Form Validation Class Initialized
INFO - 2021-04-13 17:17:46 --> Controller Class Initialized
INFO - 2021-04-13 17:17:46 --> Model Class Initialized
INFO - 2021-04-13 17:17:46 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 17:17:46 --> Final output sent to browser
DEBUG - 2021-04-13 17:17:46 --> Total execution time: 0.0261
INFO - 2021-04-13 17:17:48 --> Config Class Initialized
INFO - 2021-04-13 17:17:48 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:17:48 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:17:48 --> Utf8 Class Initialized
INFO - 2021-04-13 17:17:48 --> URI Class Initialized
INFO - 2021-04-13 17:17:48 --> Router Class Initialized
INFO - 2021-04-13 17:17:48 --> Output Class Initialized
INFO - 2021-04-13 17:17:48 --> Security Class Initialized
DEBUG - 2021-04-13 17:17:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:17:48 --> Input Class Initialized
INFO - 2021-04-13 17:17:48 --> Language Class Initialized
INFO - 2021-04-13 17:17:48 --> Loader Class Initialized
INFO - 2021-04-13 17:17:48 --> Helper loaded: url_helper
INFO - 2021-04-13 17:17:48 --> Helper loaded: form_helper
INFO - 2021-04-13 17:17:48 --> Helper loaded: common_helper
INFO - 2021-04-13 17:17:48 --> Helper loaded: util_helper
INFO - 2021-04-13 17:17:48 --> Database Driver Class Initialized
ERROR - 2021-04-13 17:17:48 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 17:17:48 --> Unable to connect to the database
DEBUG - 2021-04-13 17:17:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 17:17:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 17:17:48 --> Form Validation Class Initialized
INFO - 2021-04-13 17:17:48 --> Controller Class Initialized
INFO - 2021-04-13 17:17:48 --> Model Class Initialized
INFO - 2021-04-13 17:17:48 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 17:17:48 --> Final output sent to browser
DEBUG - 2021-04-13 17:17:48 --> Total execution time: 0.0252
INFO - 2021-04-13 17:18:09 --> Config Class Initialized
INFO - 2021-04-13 17:18:09 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:18:09 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:18:09 --> Utf8 Class Initialized
INFO - 2021-04-13 17:18:09 --> URI Class Initialized
INFO - 2021-04-13 17:18:09 --> Router Class Initialized
INFO - 2021-04-13 17:18:09 --> Output Class Initialized
INFO - 2021-04-13 17:18:09 --> Security Class Initialized
DEBUG - 2021-04-13 17:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:18:09 --> Input Class Initialized
INFO - 2021-04-13 17:18:09 --> Language Class Initialized
INFO - 2021-04-13 17:18:09 --> Loader Class Initialized
INFO - 2021-04-13 17:18:09 --> Helper loaded: url_helper
INFO - 2021-04-13 17:18:09 --> Helper loaded: form_helper
INFO - 2021-04-13 17:18:09 --> Helper loaded: common_helper
INFO - 2021-04-13 17:18:09 --> Helper loaded: util_helper
INFO - 2021-04-13 17:18:09 --> Database Driver Class Initialized
ERROR - 2021-04-13 17:18:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 17:18:09 --> Unable to connect to the database
DEBUG - 2021-04-13 17:18:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 17:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 17:18:09 --> Form Validation Class Initialized
INFO - 2021-04-13 17:18:09 --> Controller Class Initialized
INFO - 2021-04-13 17:18:09 --> Model Class Initialized
INFO - 2021-04-13 17:18:09 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 17:18:09 --> Final output sent to browser
DEBUG - 2021-04-13 17:18:09 --> Total execution time: 0.0250
INFO - 2021-04-13 17:18:10 --> Config Class Initialized
INFO - 2021-04-13 17:18:10 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:18:10 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:18:10 --> Utf8 Class Initialized
INFO - 2021-04-13 17:18:10 --> URI Class Initialized
INFO - 2021-04-13 17:18:10 --> Router Class Initialized
INFO - 2021-04-13 17:18:10 --> Output Class Initialized
INFO - 2021-04-13 17:18:10 --> Security Class Initialized
DEBUG - 2021-04-13 17:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:18:10 --> Input Class Initialized
INFO - 2021-04-13 17:18:10 --> Language Class Initialized
INFO - 2021-04-13 17:18:10 --> Loader Class Initialized
INFO - 2021-04-13 17:18:10 --> Helper loaded: url_helper
INFO - 2021-04-13 17:18:10 --> Helper loaded: form_helper
INFO - 2021-04-13 17:18:10 --> Helper loaded: common_helper
INFO - 2021-04-13 17:18:10 --> Helper loaded: util_helper
INFO - 2021-04-13 17:18:10 --> Database Driver Class Initialized
ERROR - 2021-04-13 17:18:10 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 17:18:10 --> Unable to connect to the database
DEBUG - 2021-04-13 17:18:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 17:18:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 17:18:10 --> Form Validation Class Initialized
INFO - 2021-04-13 17:18:10 --> Controller Class Initialized
INFO - 2021-04-13 17:18:10 --> Model Class Initialized
INFO - 2021-04-13 17:18:10 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 17:18:10 --> Final output sent to browser
DEBUG - 2021-04-13 17:18:10 --> Total execution time: 0.0266
INFO - 2021-04-13 17:18:10 --> Config Class Initialized
INFO - 2021-04-13 17:18:10 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:18:10 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:18:10 --> Utf8 Class Initialized
INFO - 2021-04-13 17:18:10 --> URI Class Initialized
INFO - 2021-04-13 17:18:10 --> Router Class Initialized
INFO - 2021-04-13 17:18:10 --> Output Class Initialized
INFO - 2021-04-13 17:18:10 --> Security Class Initialized
DEBUG - 2021-04-13 17:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:18:10 --> Input Class Initialized
INFO - 2021-04-13 17:18:10 --> Language Class Initialized
INFO - 2021-04-13 17:18:10 --> Loader Class Initialized
INFO - 2021-04-13 17:18:10 --> Helper loaded: url_helper
INFO - 2021-04-13 17:18:10 --> Helper loaded: form_helper
INFO - 2021-04-13 17:18:10 --> Helper loaded: common_helper
INFO - 2021-04-13 17:18:10 --> Helper loaded: util_helper
INFO - 2021-04-13 17:18:10 --> Database Driver Class Initialized
ERROR - 2021-04-13 17:18:10 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 17:18:10 --> Unable to connect to the database
DEBUG - 2021-04-13 17:18:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 17:18:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 17:18:10 --> Form Validation Class Initialized
INFO - 2021-04-13 17:18:10 --> Controller Class Initialized
INFO - 2021-04-13 17:18:10 --> Model Class Initialized
INFO - 2021-04-13 17:18:10 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 17:18:10 --> Final output sent to browser
DEBUG - 2021-04-13 17:18:10 --> Total execution time: 0.0354
INFO - 2021-04-13 17:18:10 --> Config Class Initialized
INFO - 2021-04-13 17:18:10 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:18:10 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:18:10 --> Utf8 Class Initialized
INFO - 2021-04-13 17:18:10 --> URI Class Initialized
INFO - 2021-04-13 17:18:10 --> Router Class Initialized
INFO - 2021-04-13 17:18:10 --> Output Class Initialized
INFO - 2021-04-13 17:18:10 --> Security Class Initialized
DEBUG - 2021-04-13 17:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:18:10 --> Input Class Initialized
INFO - 2021-04-13 17:18:10 --> Language Class Initialized
INFO - 2021-04-13 17:18:10 --> Loader Class Initialized
INFO - 2021-04-13 17:18:10 --> Helper loaded: url_helper
INFO - 2021-04-13 17:18:10 --> Helper loaded: form_helper
INFO - 2021-04-13 17:18:10 --> Helper loaded: common_helper
INFO - 2021-04-13 17:18:10 --> Helper loaded: util_helper
INFO - 2021-04-13 17:18:10 --> Database Driver Class Initialized
ERROR - 2021-04-13 17:18:10 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 17:18:10 --> Unable to connect to the database
DEBUG - 2021-04-13 17:18:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 17:18:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 17:18:10 --> Form Validation Class Initialized
INFO - 2021-04-13 17:18:10 --> Controller Class Initialized
INFO - 2021-04-13 17:18:10 --> Model Class Initialized
INFO - 2021-04-13 17:18:10 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 17:18:10 --> Final output sent to browser
DEBUG - 2021-04-13 17:18:10 --> Total execution time: 0.0251
INFO - 2021-04-13 17:18:10 --> Config Class Initialized
INFO - 2021-04-13 17:18:10 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:18:10 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:18:10 --> Utf8 Class Initialized
INFO - 2021-04-13 17:18:10 --> URI Class Initialized
INFO - 2021-04-13 17:18:10 --> Router Class Initialized
INFO - 2021-04-13 17:18:10 --> Output Class Initialized
INFO - 2021-04-13 17:18:10 --> Security Class Initialized
DEBUG - 2021-04-13 17:18:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:18:10 --> Input Class Initialized
INFO - 2021-04-13 17:18:10 --> Language Class Initialized
INFO - 2021-04-13 17:18:10 --> Loader Class Initialized
INFO - 2021-04-13 17:18:10 --> Helper loaded: url_helper
INFO - 2021-04-13 17:18:10 --> Helper loaded: form_helper
INFO - 2021-04-13 17:18:10 --> Helper loaded: common_helper
INFO - 2021-04-13 17:18:10 --> Helper loaded: util_helper
INFO - 2021-04-13 17:18:10 --> Database Driver Class Initialized
ERROR - 2021-04-13 17:18:10 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 17:18:10 --> Unable to connect to the database
DEBUG - 2021-04-13 17:18:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 17:18:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 17:18:10 --> Form Validation Class Initialized
INFO - 2021-04-13 17:18:10 --> Controller Class Initialized
INFO - 2021-04-13 17:18:10 --> Model Class Initialized
INFO - 2021-04-13 17:18:10 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 17:18:10 --> Final output sent to browser
DEBUG - 2021-04-13 17:18:10 --> Total execution time: 0.0261
INFO - 2021-04-13 17:18:11 --> Config Class Initialized
INFO - 2021-04-13 17:18:11 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:18:11 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:18:11 --> Utf8 Class Initialized
INFO - 2021-04-13 17:18:11 --> URI Class Initialized
INFO - 2021-04-13 17:18:11 --> Router Class Initialized
INFO - 2021-04-13 17:18:11 --> Output Class Initialized
INFO - 2021-04-13 17:18:11 --> Security Class Initialized
DEBUG - 2021-04-13 17:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:18:11 --> Input Class Initialized
INFO - 2021-04-13 17:18:11 --> Language Class Initialized
INFO - 2021-04-13 17:18:11 --> Loader Class Initialized
INFO - 2021-04-13 17:18:11 --> Helper loaded: url_helper
INFO - 2021-04-13 17:18:11 --> Helper loaded: form_helper
INFO - 2021-04-13 17:18:11 --> Helper loaded: common_helper
INFO - 2021-04-13 17:18:11 --> Helper loaded: util_helper
INFO - 2021-04-13 17:18:11 --> Database Driver Class Initialized
ERROR - 2021-04-13 17:18:11 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 17:18:11 --> Unable to connect to the database
DEBUG - 2021-04-13 17:18:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 17:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 17:18:11 --> Form Validation Class Initialized
INFO - 2021-04-13 17:18:11 --> Controller Class Initialized
INFO - 2021-04-13 17:18:11 --> Model Class Initialized
INFO - 2021-04-13 17:18:11 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 17:18:11 --> Final output sent to browser
DEBUG - 2021-04-13 17:18:11 --> Total execution time: 0.0259
INFO - 2021-04-13 17:18:11 --> Config Class Initialized
INFO - 2021-04-13 17:18:11 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:18:11 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:18:11 --> Utf8 Class Initialized
INFO - 2021-04-13 17:18:11 --> URI Class Initialized
INFO - 2021-04-13 17:18:11 --> Router Class Initialized
INFO - 2021-04-13 17:18:11 --> Output Class Initialized
INFO - 2021-04-13 17:18:11 --> Security Class Initialized
DEBUG - 2021-04-13 17:18:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:18:11 --> Input Class Initialized
INFO - 2021-04-13 17:18:11 --> Language Class Initialized
INFO - 2021-04-13 17:18:11 --> Loader Class Initialized
INFO - 2021-04-13 17:18:11 --> Helper loaded: url_helper
INFO - 2021-04-13 17:18:11 --> Helper loaded: form_helper
INFO - 2021-04-13 17:18:11 --> Helper loaded: common_helper
INFO - 2021-04-13 17:18:11 --> Helper loaded: util_helper
INFO - 2021-04-13 17:18:11 --> Database Driver Class Initialized
ERROR - 2021-04-13 17:18:11 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 17:18:11 --> Unable to connect to the database
DEBUG - 2021-04-13 17:18:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 17:18:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 17:18:11 --> Form Validation Class Initialized
INFO - 2021-04-13 17:18:11 --> Controller Class Initialized
INFO - 2021-04-13 17:18:11 --> Model Class Initialized
INFO - 2021-04-13 17:18:11 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 17:18:11 --> Final output sent to browser
DEBUG - 2021-04-13 17:18:11 --> Total execution time: 0.0251
INFO - 2021-04-13 17:18:16 --> Config Class Initialized
INFO - 2021-04-13 17:18:16 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:18:16 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:18:16 --> Utf8 Class Initialized
INFO - 2021-04-13 17:18:16 --> URI Class Initialized
INFO - 2021-04-13 17:18:16 --> Router Class Initialized
INFO - 2021-04-13 17:18:16 --> Output Class Initialized
INFO - 2021-04-13 17:18:16 --> Security Class Initialized
DEBUG - 2021-04-13 17:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:18:16 --> Input Class Initialized
INFO - 2021-04-13 17:18:16 --> Language Class Initialized
INFO - 2021-04-13 17:18:16 --> Loader Class Initialized
INFO - 2021-04-13 17:18:16 --> Helper loaded: url_helper
INFO - 2021-04-13 17:18:16 --> Helper loaded: form_helper
INFO - 2021-04-13 17:18:16 --> Helper loaded: common_helper
INFO - 2021-04-13 17:18:16 --> Helper loaded: util_helper
INFO - 2021-04-13 17:18:16 --> Database Driver Class Initialized
ERROR - 2021-04-13 17:18:16 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 17:18:16 --> Unable to connect to the database
DEBUG - 2021-04-13 17:18:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 17:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 17:18:16 --> Form Validation Class Initialized
INFO - 2021-04-13 17:18:16 --> Controller Class Initialized
INFO - 2021-04-13 17:18:16 --> Model Class Initialized
INFO - 2021-04-13 17:18:16 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 17:18:16 --> Final output sent to browser
DEBUG - 2021-04-13 17:18:16 --> Total execution time: 0.0247
INFO - 2021-04-13 17:19:07 --> Config Class Initialized
INFO - 2021-04-13 17:19:07 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:19:07 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:19:07 --> Utf8 Class Initialized
INFO - 2021-04-13 17:19:07 --> URI Class Initialized
INFO - 2021-04-13 17:19:07 --> Router Class Initialized
INFO - 2021-04-13 17:19:07 --> Output Class Initialized
INFO - 2021-04-13 17:19:07 --> Security Class Initialized
DEBUG - 2021-04-13 17:19:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:19:07 --> Input Class Initialized
INFO - 2021-04-13 17:19:07 --> Language Class Initialized
ERROR - 2021-04-13 17:19:07 --> 404 Page Not Found: Home/login
INFO - 2021-04-13 17:19:18 --> Config Class Initialized
INFO - 2021-04-13 17:19:18 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:19:18 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:19:18 --> Utf8 Class Initialized
INFO - 2021-04-13 17:19:18 --> URI Class Initialized
INFO - 2021-04-13 17:19:18 --> Router Class Initialized
INFO - 2021-04-13 17:19:18 --> Output Class Initialized
INFO - 2021-04-13 17:19:18 --> Security Class Initialized
DEBUG - 2021-04-13 17:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:19:18 --> Input Class Initialized
INFO - 2021-04-13 17:19:18 --> Language Class Initialized
INFO - 2021-04-13 17:19:18 --> Loader Class Initialized
INFO - 2021-04-13 17:19:18 --> Helper loaded: url_helper
INFO - 2021-04-13 17:19:18 --> Helper loaded: form_helper
INFO - 2021-04-13 17:19:18 --> Helper loaded: common_helper
INFO - 2021-04-13 17:19:18 --> Helper loaded: util_helper
INFO - 2021-04-13 17:19:18 --> Database Driver Class Initialized
ERROR - 2021-04-13 17:19:18 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 17:19:18 --> Unable to connect to the database
DEBUG - 2021-04-13 17:19:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 17:19:18 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 17:19:18 --> Form Validation Class Initialized
INFO - 2021-04-13 17:19:18 --> Controller Class Initialized
INFO - 2021-04-13 17:19:18 --> Model Class Initialized
INFO - 2021-04-13 17:19:18 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 17:19:18 --> Final output sent to browser
DEBUG - 2021-04-13 17:19:18 --> Total execution time: 0.0262
INFO - 2021-04-13 17:19:18 --> Config Class Initialized
INFO - 2021-04-13 17:19:18 --> Hooks Class Initialized
INFO - 2021-04-13 17:19:18 --> Config Class Initialized
INFO - 2021-04-13 17:19:18 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:19:18 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:19:18 --> Utf8 Class Initialized
DEBUG - 2021-04-13 17:19:18 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:19:18 --> Utf8 Class Initialized
INFO - 2021-04-13 17:19:18 --> URI Class Initialized
INFO - 2021-04-13 17:19:18 --> URI Class Initialized
INFO - 2021-04-13 17:19:18 --> Router Class Initialized
INFO - 2021-04-13 17:19:18 --> Router Class Initialized
INFO - 2021-04-13 17:19:18 --> Output Class Initialized
INFO - 2021-04-13 17:19:18 --> Output Class Initialized
INFO - 2021-04-13 17:19:18 --> Security Class Initialized
INFO - 2021-04-13 17:19:18 --> Security Class Initialized
DEBUG - 2021-04-13 17:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:19:18 --> Input Class Initialized
DEBUG - 2021-04-13 17:19:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:19:18 --> Language Class Initialized
INFO - 2021-04-13 17:19:18 --> Input Class Initialized
INFO - 2021-04-13 17:19:18 --> Language Class Initialized
ERROR - 2021-04-13 17:19:18 --> 404 Page Not Found: Fasset/img
ERROR - 2021-04-13 17:19:18 --> 404 Page Not Found: Fasset/img
INFO - 2021-04-13 17:30:51 --> Config Class Initialized
INFO - 2021-04-13 17:30:51 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:30:51 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:30:51 --> Utf8 Class Initialized
INFO - 2021-04-13 17:30:51 --> URI Class Initialized
DEBUG - 2021-04-13 17:30:51 --> No URI present. Default controller set.
INFO - 2021-04-13 17:30:51 --> Router Class Initialized
INFO - 2021-04-13 17:30:51 --> Output Class Initialized
INFO - 2021-04-13 17:30:51 --> Security Class Initialized
DEBUG - 2021-04-13 17:30:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:30:51 --> Input Class Initialized
INFO - 2021-04-13 17:30:51 --> Language Class Initialized
ERROR - 2021-04-13 17:30:51 --> 404 Page Not Found: user/Home/index
INFO - 2021-04-13 17:31:52 --> Config Class Initialized
INFO - 2021-04-13 17:31:52 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:31:52 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:31:52 --> Utf8 Class Initialized
INFO - 2021-04-13 17:31:52 --> URI Class Initialized
INFO - 2021-04-13 17:31:52 --> Router Class Initialized
INFO - 2021-04-13 17:31:52 --> Output Class Initialized
INFO - 2021-04-13 17:31:52 --> Security Class Initialized
DEBUG - 2021-04-13 17:31:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:31:52 --> Input Class Initialized
INFO - 2021-04-13 17:31:52 --> Language Class Initialized
ERROR - 2021-04-13 17:31:52 --> Severity: error --> Exception: syntax error, unexpected '/' C:\xampp1\htdocs\FoodTruck\php\application\controllers\user\Dashboard.php 48
INFO - 2021-04-13 17:36:14 --> Config Class Initialized
INFO - 2021-04-13 17:36:14 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:36:14 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:36:14 --> Utf8 Class Initialized
INFO - 2021-04-13 17:36:14 --> URI Class Initialized
INFO - 2021-04-13 17:36:14 --> Router Class Initialized
INFO - 2021-04-13 17:36:14 --> Output Class Initialized
INFO - 2021-04-13 17:36:14 --> Security Class Initialized
DEBUG - 2021-04-13 17:36:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:36:14 --> Input Class Initialized
INFO - 2021-04-13 17:36:14 --> Language Class Initialized
ERROR - 2021-04-13 17:36:14 --> Severity: error --> Exception: syntax error, unexpected '/' C:\xampp1\htdocs\FoodTruck\php\application\controllers\user\Dashboard.php 48
INFO - 2021-04-13 17:37:06 --> Config Class Initialized
INFO - 2021-04-13 17:37:06 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:37:06 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:37:06 --> Utf8 Class Initialized
INFO - 2021-04-13 17:37:06 --> URI Class Initialized
DEBUG - 2021-04-13 17:37:06 --> No URI present. Default controller set.
INFO - 2021-04-13 17:37:06 --> Router Class Initialized
INFO - 2021-04-13 17:37:06 --> Output Class Initialized
INFO - 2021-04-13 17:37:06 --> Security Class Initialized
DEBUG - 2021-04-13 17:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:37:06 --> Input Class Initialized
INFO - 2021-04-13 17:37:06 --> Language Class Initialized
INFO - 2021-04-13 17:37:06 --> Loader Class Initialized
INFO - 2021-04-13 17:37:06 --> Helper loaded: url_helper
INFO - 2021-04-13 17:37:06 --> Helper loaded: form_helper
INFO - 2021-04-13 17:37:06 --> Helper loaded: common_helper
INFO - 2021-04-13 17:37:06 --> Helper loaded: util_helper
INFO - 2021-04-13 17:37:06 --> Database Driver Class Initialized
ERROR - 2021-04-13 17:37:06 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 17:37:06 --> Unable to connect to the database
DEBUG - 2021-04-13 17:37:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 17:37:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 17:37:06 --> Form Validation Class Initialized
INFO - 2021-04-13 17:37:06 --> Controller Class Initialized
INFO - 2021-04-13 17:37:06 --> Model Class Initialized
INFO - 2021-04-13 17:37:06 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-13 17:37:06 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 17:37:06 --> Final output sent to browser
DEBUG - 2021-04-13 17:37:06 --> Total execution time: 0.0438
INFO - 2021-04-13 17:37:08 --> Config Class Initialized
INFO - 2021-04-13 17:37:08 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:37:08 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:37:08 --> Utf8 Class Initialized
INFO - 2021-04-13 17:37:08 --> URI Class Initialized
INFO - 2021-04-13 17:37:08 --> Router Class Initialized
INFO - 2021-04-13 17:37:08 --> Output Class Initialized
INFO - 2021-04-13 17:37:08 --> Security Class Initialized
DEBUG - 2021-04-13 17:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:37:08 --> Input Class Initialized
INFO - 2021-04-13 17:37:08 --> Language Class Initialized
INFO - 2021-04-13 17:37:08 --> Loader Class Initialized
INFO - 2021-04-13 17:37:08 --> Helper loaded: url_helper
INFO - 2021-04-13 17:37:08 --> Helper loaded: form_helper
INFO - 2021-04-13 17:37:08 --> Helper loaded: common_helper
INFO - 2021-04-13 17:37:08 --> Helper loaded: util_helper
INFO - 2021-04-13 17:37:08 --> Database Driver Class Initialized
ERROR - 2021-04-13 17:37:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 17:37:08 --> Unable to connect to the database
DEBUG - 2021-04-13 17:37:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 17:37:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 17:37:08 --> Form Validation Class Initialized
INFO - 2021-04-13 17:37:08 --> Controller Class Initialized
INFO - 2021-04-13 17:37:08 --> Model Class Initialized
INFO - 2021-04-13 17:37:08 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 17:37:08 --> Final output sent to browser
DEBUG - 2021-04-13 17:37:08 --> Total execution time: 0.0264
INFO - 2021-04-13 17:37:08 --> Config Class Initialized
INFO - 2021-04-13 17:37:08 --> Config Class Initialized
INFO - 2021-04-13 17:37:08 --> Hooks Class Initialized
INFO - 2021-04-13 17:37:08 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:37:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:37:08 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:37:08 --> Utf8 Class Initialized
INFO - 2021-04-13 17:37:08 --> Utf8 Class Initialized
INFO - 2021-04-13 17:37:08 --> URI Class Initialized
INFO - 2021-04-13 17:37:08 --> URI Class Initialized
INFO - 2021-04-13 17:37:08 --> Router Class Initialized
INFO - 2021-04-13 17:37:08 --> Router Class Initialized
INFO - 2021-04-13 17:37:08 --> Output Class Initialized
INFO - 2021-04-13 17:37:08 --> Output Class Initialized
INFO - 2021-04-13 17:37:08 --> Security Class Initialized
INFO - 2021-04-13 17:37:08 --> Security Class Initialized
DEBUG - 2021-04-13 17:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:37:08 --> Input Class Initialized
INFO - 2021-04-13 17:37:08 --> Input Class Initialized
INFO - 2021-04-13 17:37:08 --> Language Class Initialized
INFO - 2021-04-13 17:37:08 --> Language Class Initialized
ERROR - 2021-04-13 17:37:08 --> 404 Page Not Found: Fasset/img
ERROR - 2021-04-13 17:37:08 --> 404 Page Not Found: Fasset/img
INFO - 2021-04-13 17:37:09 --> Config Class Initialized
INFO - 2021-04-13 17:37:09 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:37:09 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:37:09 --> Utf8 Class Initialized
INFO - 2021-04-13 17:37:09 --> URI Class Initialized
DEBUG - 2021-04-13 17:37:09 --> No URI present. Default controller set.
INFO - 2021-04-13 17:37:09 --> Router Class Initialized
INFO - 2021-04-13 17:37:09 --> Output Class Initialized
INFO - 2021-04-13 17:37:09 --> Security Class Initialized
DEBUG - 2021-04-13 17:37:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:37:09 --> Input Class Initialized
INFO - 2021-04-13 17:37:09 --> Language Class Initialized
INFO - 2021-04-13 17:37:09 --> Loader Class Initialized
INFO - 2021-04-13 17:37:09 --> Helper loaded: url_helper
INFO - 2021-04-13 17:37:09 --> Helper loaded: form_helper
INFO - 2021-04-13 17:37:09 --> Helper loaded: common_helper
INFO - 2021-04-13 17:37:09 --> Helper loaded: util_helper
INFO - 2021-04-13 17:37:09 --> Database Driver Class Initialized
ERROR - 2021-04-13 17:37:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 17:37:09 --> Unable to connect to the database
DEBUG - 2021-04-13 17:37:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 17:37:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 17:37:09 --> Form Validation Class Initialized
INFO - 2021-04-13 17:37:09 --> Controller Class Initialized
INFO - 2021-04-13 17:37:09 --> Model Class Initialized
INFO - 2021-04-13 17:37:09 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-13 17:37:09 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 17:37:09 --> Final output sent to browser
DEBUG - 2021-04-13 17:37:09 --> Total execution time: 0.0283
INFO - 2021-04-13 17:37:11 --> Config Class Initialized
INFO - 2021-04-13 17:37:11 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:37:11 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:37:11 --> Utf8 Class Initialized
INFO - 2021-04-13 17:37:11 --> URI Class Initialized
INFO - 2021-04-13 17:37:11 --> Router Class Initialized
INFO - 2021-04-13 17:37:11 --> Output Class Initialized
INFO - 2021-04-13 17:37:11 --> Security Class Initialized
DEBUG - 2021-04-13 17:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:37:11 --> Input Class Initialized
INFO - 2021-04-13 17:37:11 --> Language Class Initialized
INFO - 2021-04-13 17:37:11 --> Loader Class Initialized
INFO - 2021-04-13 17:37:11 --> Helper loaded: url_helper
INFO - 2021-04-13 17:37:11 --> Helper loaded: form_helper
INFO - 2021-04-13 17:37:11 --> Helper loaded: common_helper
INFO - 2021-04-13 17:37:11 --> Helper loaded: util_helper
INFO - 2021-04-13 17:37:11 --> Database Driver Class Initialized
ERROR - 2021-04-13 17:37:11 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 17:37:11 --> Unable to connect to the database
DEBUG - 2021-04-13 17:37:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 17:37:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 17:37:11 --> Form Validation Class Initialized
INFO - 2021-04-13 17:37:11 --> Controller Class Initialized
INFO - 2021-04-13 17:37:11 --> Model Class Initialized
INFO - 2021-04-13 17:37:11 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\register.php
INFO - 2021-04-13 17:37:11 --> Final output sent to browser
DEBUG - 2021-04-13 17:37:11 --> Total execution time: 0.0249
INFO - 2021-04-13 17:37:13 --> Config Class Initialized
INFO - 2021-04-13 17:37:13 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:37:13 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:37:13 --> Utf8 Class Initialized
INFO - 2021-04-13 17:37:13 --> URI Class Initialized
DEBUG - 2021-04-13 17:37:13 --> No URI present. Default controller set.
INFO - 2021-04-13 17:37:13 --> Router Class Initialized
INFO - 2021-04-13 17:37:13 --> Output Class Initialized
INFO - 2021-04-13 17:37:13 --> Security Class Initialized
DEBUG - 2021-04-13 17:37:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:37:13 --> Input Class Initialized
INFO - 2021-04-13 17:37:13 --> Language Class Initialized
INFO - 2021-04-13 17:37:13 --> Loader Class Initialized
INFO - 2021-04-13 17:37:13 --> Helper loaded: url_helper
INFO - 2021-04-13 17:37:13 --> Helper loaded: form_helper
INFO - 2021-04-13 17:37:13 --> Helper loaded: common_helper
INFO - 2021-04-13 17:37:13 --> Helper loaded: util_helper
INFO - 2021-04-13 17:37:13 --> Database Driver Class Initialized
ERROR - 2021-04-13 17:37:13 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 17:37:13 --> Unable to connect to the database
DEBUG - 2021-04-13 17:37:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 17:37:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 17:37:13 --> Form Validation Class Initialized
INFO - 2021-04-13 17:37:13 --> Controller Class Initialized
INFO - 2021-04-13 17:37:13 --> Model Class Initialized
INFO - 2021-04-13 17:37:13 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-13 17:37:13 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 17:37:13 --> Final output sent to browser
DEBUG - 2021-04-13 17:37:13 --> Total execution time: 0.0262
INFO - 2021-04-13 17:37:24 --> Config Class Initialized
INFO - 2021-04-13 17:37:24 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:37:24 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:37:24 --> Utf8 Class Initialized
INFO - 2021-04-13 17:37:24 --> URI Class Initialized
INFO - 2021-04-13 17:37:24 --> Router Class Initialized
INFO - 2021-04-13 17:37:24 --> Output Class Initialized
INFO - 2021-04-13 17:37:24 --> Security Class Initialized
DEBUG - 2021-04-13 17:37:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:37:24 --> Input Class Initialized
INFO - 2021-04-13 17:37:24 --> Language Class Initialized
INFO - 2021-04-13 17:37:24 --> Loader Class Initialized
INFO - 2021-04-13 17:37:24 --> Helper loaded: url_helper
INFO - 2021-04-13 17:37:24 --> Helper loaded: form_helper
INFO - 2021-04-13 17:37:24 --> Helper loaded: common_helper
INFO - 2021-04-13 17:37:24 --> Helper loaded: util_helper
INFO - 2021-04-13 17:37:24 --> Database Driver Class Initialized
ERROR - 2021-04-13 17:37:24 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 17:37:24 --> Unable to connect to the database
DEBUG - 2021-04-13 17:37:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 17:37:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 17:37:24 --> Form Validation Class Initialized
INFO - 2021-04-13 17:37:24 --> Controller Class Initialized
INFO - 2021-04-13 17:37:24 --> Model Class Initialized
INFO - 2021-04-13 17:37:24 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 17:37:24 --> Final output sent to browser
DEBUG - 2021-04-13 17:37:24 --> Total execution time: 0.0243
INFO - 2021-04-13 17:37:27 --> Config Class Initialized
INFO - 2021-04-13 17:37:27 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:37:27 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:37:27 --> Utf8 Class Initialized
INFO - 2021-04-13 17:37:27 --> URI Class Initialized
DEBUG - 2021-04-13 17:37:27 --> No URI present. Default controller set.
INFO - 2021-04-13 17:37:27 --> Router Class Initialized
INFO - 2021-04-13 17:37:27 --> Output Class Initialized
INFO - 2021-04-13 17:37:27 --> Security Class Initialized
DEBUG - 2021-04-13 17:37:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:37:27 --> Input Class Initialized
INFO - 2021-04-13 17:37:27 --> Language Class Initialized
INFO - 2021-04-13 17:37:27 --> Loader Class Initialized
INFO - 2021-04-13 17:37:27 --> Helper loaded: url_helper
INFO - 2021-04-13 17:37:27 --> Helper loaded: form_helper
INFO - 2021-04-13 17:37:27 --> Helper loaded: common_helper
INFO - 2021-04-13 17:37:27 --> Helper loaded: util_helper
INFO - 2021-04-13 17:37:27 --> Database Driver Class Initialized
ERROR - 2021-04-13 17:37:27 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 17:37:27 --> Unable to connect to the database
DEBUG - 2021-04-13 17:37:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 17:37:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 17:37:27 --> Form Validation Class Initialized
INFO - 2021-04-13 17:37:27 --> Controller Class Initialized
INFO - 2021-04-13 17:37:27 --> Model Class Initialized
INFO - 2021-04-13 17:37:27 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-13 17:37:27 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 17:37:27 --> Final output sent to browser
DEBUG - 2021-04-13 17:37:27 --> Total execution time: 0.0355
INFO - 2021-04-13 17:40:13 --> Config Class Initialized
INFO - 2021-04-13 17:40:13 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:40:13 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:40:13 --> Utf8 Class Initialized
INFO - 2021-04-13 17:40:13 --> URI Class Initialized
INFO - 2021-04-13 17:40:13 --> Router Class Initialized
INFO - 2021-04-13 17:40:13 --> Output Class Initialized
INFO - 2021-04-13 17:40:13 --> Security Class Initialized
DEBUG - 2021-04-13 17:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:40:13 --> Input Class Initialized
INFO - 2021-04-13 17:40:13 --> Language Class Initialized
INFO - 2021-04-13 17:40:13 --> Loader Class Initialized
INFO - 2021-04-13 17:40:13 --> Helper loaded: url_helper
INFO - 2021-04-13 17:40:13 --> Helper loaded: form_helper
INFO - 2021-04-13 17:40:13 --> Helper loaded: common_helper
INFO - 2021-04-13 17:40:13 --> Helper loaded: util_helper
INFO - 2021-04-13 17:40:13 --> Database Driver Class Initialized
ERROR - 2021-04-13 17:40:13 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 17:40:13 --> Unable to connect to the database
DEBUG - 2021-04-13 17:40:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 17:40:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 17:40:13 --> Form Validation Class Initialized
INFO - 2021-04-13 17:40:13 --> Controller Class Initialized
INFO - 2021-04-13 17:40:13 --> Model Class Initialized
INFO - 2021-04-13 17:40:13 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 17:40:13 --> Final output sent to browser
DEBUG - 2021-04-13 17:40:13 --> Total execution time: 0.0356
INFO - 2021-04-13 17:40:13 --> Config Class Initialized
INFO - 2021-04-13 17:40:13 --> Config Class Initialized
INFO - 2021-04-13 17:40:13 --> Hooks Class Initialized
INFO - 2021-04-13 17:40:13 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:40:13 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:40:13 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:40:13 --> Utf8 Class Initialized
INFO - 2021-04-13 17:40:13 --> Utf8 Class Initialized
INFO - 2021-04-13 17:40:13 --> URI Class Initialized
INFO - 2021-04-13 17:40:13 --> URI Class Initialized
INFO - 2021-04-13 17:40:13 --> Router Class Initialized
INFO - 2021-04-13 17:40:13 --> Router Class Initialized
INFO - 2021-04-13 17:40:13 --> Output Class Initialized
INFO - 2021-04-13 17:40:13 --> Output Class Initialized
INFO - 2021-04-13 17:40:13 --> Security Class Initialized
INFO - 2021-04-13 17:40:13 --> Security Class Initialized
DEBUG - 2021-04-13 17:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:40:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:40:13 --> Input Class Initialized
INFO - 2021-04-13 17:40:13 --> Input Class Initialized
INFO - 2021-04-13 17:40:13 --> Language Class Initialized
INFO - 2021-04-13 17:40:13 --> Language Class Initialized
ERROR - 2021-04-13 17:40:13 --> 404 Page Not Found: Fasset/img
ERROR - 2021-04-13 17:40:13 --> 404 Page Not Found: Fasset/img
INFO - 2021-04-13 17:45:02 --> Config Class Initialized
INFO - 2021-04-13 17:45:02 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:45:02 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:45:02 --> Utf8 Class Initialized
INFO - 2021-04-13 17:45:02 --> URI Class Initialized
DEBUG - 2021-04-13 17:45:02 --> No URI present. Default controller set.
INFO - 2021-04-13 17:45:02 --> Router Class Initialized
INFO - 2021-04-13 17:45:02 --> Output Class Initialized
INFO - 2021-04-13 17:45:02 --> Security Class Initialized
DEBUG - 2021-04-13 17:45:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:45:02 --> Input Class Initialized
INFO - 2021-04-13 17:45:02 --> Language Class Initialized
INFO - 2021-04-13 17:45:02 --> Loader Class Initialized
INFO - 2021-04-13 17:45:02 --> Helper loaded: url_helper
INFO - 2021-04-13 17:45:02 --> Helper loaded: form_helper
INFO - 2021-04-13 17:45:02 --> Helper loaded: common_helper
INFO - 2021-04-13 17:45:02 --> Helper loaded: util_helper
INFO - 2021-04-13 17:45:02 --> Database Driver Class Initialized
ERROR - 2021-04-13 17:45:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 17:45:02 --> Unable to connect to the database
DEBUG - 2021-04-13 17:45:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 17:45:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 17:45:02 --> Form Validation Class Initialized
INFO - 2021-04-13 17:45:02 --> Controller Class Initialized
INFO - 2021-04-13 17:45:02 --> Model Class Initialized
INFO - 2021-04-13 17:45:02 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-13 17:45:02 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 17:45:02 --> Final output sent to browser
DEBUG - 2021-04-13 17:45:02 --> Total execution time: 0.0385
INFO - 2021-04-13 17:45:03 --> Config Class Initialized
INFO - 2021-04-13 17:45:03 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:45:03 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:45:03 --> Utf8 Class Initialized
INFO - 2021-04-13 17:45:03 --> URI Class Initialized
INFO - 2021-04-13 17:45:03 --> Router Class Initialized
INFO - 2021-04-13 17:45:03 --> Output Class Initialized
INFO - 2021-04-13 17:45:03 --> Security Class Initialized
DEBUG - 2021-04-13 17:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:45:03 --> Input Class Initialized
INFO - 2021-04-13 17:45:03 --> Language Class Initialized
INFO - 2021-04-13 17:45:03 --> Loader Class Initialized
INFO - 2021-04-13 17:45:03 --> Helper loaded: url_helper
INFO - 2021-04-13 17:45:03 --> Helper loaded: form_helper
INFO - 2021-04-13 17:45:03 --> Helper loaded: common_helper
INFO - 2021-04-13 17:45:03 --> Helper loaded: util_helper
INFO - 2021-04-13 17:45:03 --> Database Driver Class Initialized
ERROR - 2021-04-13 17:45:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 17:45:03 --> Unable to connect to the database
DEBUG - 2021-04-13 17:45:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 17:45:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 17:45:03 --> Form Validation Class Initialized
INFO - 2021-04-13 17:45:03 --> Controller Class Initialized
INFO - 2021-04-13 17:45:03 --> Model Class Initialized
INFO - 2021-04-13 17:45:03 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\register.php
INFO - 2021-04-13 17:45:03 --> Final output sent to browser
DEBUG - 2021-04-13 17:45:03 --> Total execution time: 0.0261
INFO - 2021-04-13 17:45:03 --> Config Class Initialized
INFO - 2021-04-13 17:45:03 --> Hooks Class Initialized
INFO - 2021-04-13 17:45:03 --> Config Class Initialized
INFO - 2021-04-13 17:45:03 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:45:03 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:45:03 --> Utf8 Class Initialized
DEBUG - 2021-04-13 17:45:03 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:45:03 --> URI Class Initialized
INFO - 2021-04-13 17:45:03 --> Utf8 Class Initialized
INFO - 2021-04-13 17:45:03 --> Router Class Initialized
INFO - 2021-04-13 17:45:03 --> URI Class Initialized
INFO - 2021-04-13 17:45:03 --> Output Class Initialized
INFO - 2021-04-13 17:45:03 --> Router Class Initialized
INFO - 2021-04-13 17:45:03 --> Security Class Initialized
DEBUG - 2021-04-13 17:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:45:03 --> Input Class Initialized
INFO - 2021-04-13 17:45:03 --> Language Class Initialized
INFO - 2021-04-13 17:45:03 --> Output Class Initialized
ERROR - 2021-04-13 17:45:03 --> 404 Page Not Found: Fasset/img
INFO - 2021-04-13 17:45:03 --> Security Class Initialized
DEBUG - 2021-04-13 17:45:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:45:03 --> Input Class Initialized
INFO - 2021-04-13 17:45:03 --> Language Class Initialized
ERROR - 2021-04-13 17:45:03 --> 404 Page Not Found: Fasset/img
INFO - 2021-04-13 17:45:54 --> Config Class Initialized
INFO - 2021-04-13 17:45:54 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:45:54 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:45:54 --> Utf8 Class Initialized
INFO - 2021-04-13 17:45:54 --> URI Class Initialized
INFO - 2021-04-13 17:45:54 --> Router Class Initialized
INFO - 2021-04-13 17:45:54 --> Output Class Initialized
INFO - 2021-04-13 17:45:54 --> Security Class Initialized
DEBUG - 2021-04-13 17:45:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:45:54 --> Input Class Initialized
INFO - 2021-04-13 17:45:54 --> Language Class Initialized
INFO - 2021-04-13 17:45:54 --> Loader Class Initialized
INFO - 2021-04-13 17:45:54 --> Helper loaded: url_helper
INFO - 2021-04-13 17:45:54 --> Helper loaded: form_helper
INFO - 2021-04-13 17:45:54 --> Helper loaded: common_helper
INFO - 2021-04-13 17:45:54 --> Helper loaded: util_helper
INFO - 2021-04-13 17:45:54 --> Database Driver Class Initialized
ERROR - 2021-04-13 17:45:54 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 17:45:54 --> Unable to connect to the database
DEBUG - 2021-04-13 17:45:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 17:45:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 17:45:54 --> Form Validation Class Initialized
INFO - 2021-04-13 17:45:54 --> Controller Class Initialized
INFO - 2021-04-13 17:45:54 --> Model Class Initialized
INFO - 2021-04-13 17:45:54 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-04-13 17:45:54 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 391
INFO - 2021-04-13 17:46:02 --> Config Class Initialized
INFO - 2021-04-13 17:46:02 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:46:02 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:46:02 --> Utf8 Class Initialized
INFO - 2021-04-13 17:46:02 --> URI Class Initialized
INFO - 2021-04-13 17:46:02 --> Router Class Initialized
INFO - 2021-04-13 17:46:02 --> Output Class Initialized
INFO - 2021-04-13 17:46:02 --> Security Class Initialized
DEBUG - 2021-04-13 17:46:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:46:02 --> Input Class Initialized
INFO - 2021-04-13 17:46:02 --> Language Class Initialized
INFO - 2021-04-13 17:46:02 --> Loader Class Initialized
INFO - 2021-04-13 17:46:02 --> Helper loaded: url_helper
INFO - 2021-04-13 17:46:02 --> Helper loaded: form_helper
INFO - 2021-04-13 17:46:02 --> Helper loaded: common_helper
INFO - 2021-04-13 17:46:02 --> Helper loaded: util_helper
INFO - 2021-04-13 17:46:02 --> Database Driver Class Initialized
ERROR - 2021-04-13 17:46:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 17:46:02 --> Unable to connect to the database
DEBUG - 2021-04-13 17:46:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 17:46:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 17:46:02 --> Form Validation Class Initialized
INFO - 2021-04-13 17:46:02 --> Controller Class Initialized
INFO - 2021-04-13 17:46:02 --> Model Class Initialized
INFO - 2021-04-13 17:46:02 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\register.php
INFO - 2021-04-13 17:46:02 --> Final output sent to browser
DEBUG - 2021-04-13 17:46:02 --> Total execution time: 0.0299
INFO - 2021-04-13 17:47:01 --> Config Class Initialized
INFO - 2021-04-13 17:47:01 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:47:01 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:47:01 --> Utf8 Class Initialized
INFO - 2021-04-13 17:47:01 --> URI Class Initialized
DEBUG - 2021-04-13 17:47:01 --> No URI present. Default controller set.
INFO - 2021-04-13 17:47:01 --> Router Class Initialized
INFO - 2021-04-13 17:47:01 --> Output Class Initialized
INFO - 2021-04-13 17:47:01 --> Security Class Initialized
DEBUG - 2021-04-13 17:47:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:47:01 --> Input Class Initialized
INFO - 2021-04-13 17:47:01 --> Language Class Initialized
INFO - 2021-04-13 17:47:01 --> Loader Class Initialized
INFO - 2021-04-13 17:47:01 --> Helper loaded: url_helper
INFO - 2021-04-13 17:47:01 --> Helper loaded: form_helper
INFO - 2021-04-13 17:47:01 --> Helper loaded: common_helper
INFO - 2021-04-13 17:47:01 --> Helper loaded: util_helper
INFO - 2021-04-13 17:47:01 --> Database Driver Class Initialized
ERROR - 2021-04-13 17:47:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 17:47:01 --> Unable to connect to the database
DEBUG - 2021-04-13 17:47:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 17:47:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 17:47:01 --> Form Validation Class Initialized
INFO - 2021-04-13 17:47:01 --> Controller Class Initialized
INFO - 2021-04-13 17:47:01 --> Model Class Initialized
INFO - 2021-04-13 17:47:01 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-13 17:47:01 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 17:47:01 --> Final output sent to browser
DEBUG - 2021-04-13 17:47:01 --> Total execution time: 0.0260
INFO - 2021-04-13 17:47:02 --> Config Class Initialized
INFO - 2021-04-13 17:47:02 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:47:02 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:47:02 --> Utf8 Class Initialized
INFO - 2021-04-13 17:47:02 --> URI Class Initialized
INFO - 2021-04-13 17:47:02 --> Router Class Initialized
INFO - 2021-04-13 17:47:02 --> Output Class Initialized
INFO - 2021-04-13 17:47:02 --> Security Class Initialized
DEBUG - 2021-04-13 17:47:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:47:02 --> Input Class Initialized
INFO - 2021-04-13 17:47:02 --> Language Class Initialized
INFO - 2021-04-13 17:47:02 --> Loader Class Initialized
INFO - 2021-04-13 17:47:02 --> Helper loaded: url_helper
INFO - 2021-04-13 17:47:02 --> Helper loaded: form_helper
INFO - 2021-04-13 17:47:02 --> Helper loaded: common_helper
INFO - 2021-04-13 17:47:02 --> Helper loaded: util_helper
INFO - 2021-04-13 17:47:02 --> Database Driver Class Initialized
ERROR - 2021-04-13 17:47:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 17:47:02 --> Unable to connect to the database
DEBUG - 2021-04-13 17:47:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 17:47:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 17:47:02 --> Form Validation Class Initialized
INFO - 2021-04-13 17:47:02 --> Controller Class Initialized
INFO - 2021-04-13 17:47:02 --> Model Class Initialized
INFO - 2021-04-13 17:47:02 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 17:47:02 --> Final output sent to browser
DEBUG - 2021-04-13 17:47:02 --> Total execution time: 0.0285
INFO - 2021-04-13 17:47:02 --> Config Class Initialized
INFO - 2021-04-13 17:47:02 --> Hooks Class Initialized
INFO - 2021-04-13 17:47:02 --> Config Class Initialized
INFO - 2021-04-13 17:47:02 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:47:02 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:47:02 --> Utf8 Class Initialized
INFO - 2021-04-13 17:47:02 --> URI Class Initialized
DEBUG - 2021-04-13 17:47:02 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:47:02 --> Utf8 Class Initialized
INFO - 2021-04-13 17:47:02 --> Router Class Initialized
INFO - 2021-04-13 17:47:02 --> Output Class Initialized
INFO - 2021-04-13 17:47:02 --> URI Class Initialized
INFO - 2021-04-13 17:47:02 --> Security Class Initialized
DEBUG - 2021-04-13 17:47:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:47:02 --> Router Class Initialized
INFO - 2021-04-13 17:47:02 --> Input Class Initialized
INFO - 2021-04-13 17:47:02 --> Language Class Initialized
INFO - 2021-04-13 17:47:02 --> Output Class Initialized
ERROR - 2021-04-13 17:47:02 --> 404 Page Not Found: Fasset/img
INFO - 2021-04-13 17:47:02 --> Security Class Initialized
DEBUG - 2021-04-13 17:47:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:47:02 --> Input Class Initialized
INFO - 2021-04-13 17:47:02 --> Language Class Initialized
ERROR - 2021-04-13 17:47:02 --> 404 Page Not Found: Fasset/img
INFO - 2021-04-13 17:47:19 --> Config Class Initialized
INFO - 2021-04-13 17:47:19 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:47:19 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:47:19 --> Utf8 Class Initialized
INFO - 2021-04-13 17:47:19 --> URI Class Initialized
INFO - 2021-04-13 17:47:19 --> Router Class Initialized
INFO - 2021-04-13 17:47:19 --> Output Class Initialized
INFO - 2021-04-13 17:47:19 --> Security Class Initialized
DEBUG - 2021-04-13 17:47:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:47:19 --> Input Class Initialized
INFO - 2021-04-13 17:47:19 --> Language Class Initialized
INFO - 2021-04-13 17:47:19 --> Loader Class Initialized
INFO - 2021-04-13 17:47:19 --> Helper loaded: url_helper
INFO - 2021-04-13 17:47:19 --> Helper loaded: form_helper
INFO - 2021-04-13 17:47:19 --> Helper loaded: common_helper
INFO - 2021-04-13 17:47:19 --> Helper loaded: util_helper
INFO - 2021-04-13 17:47:19 --> Database Driver Class Initialized
ERROR - 2021-04-13 17:47:19 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 17:47:19 --> Unable to connect to the database
DEBUG - 2021-04-13 17:47:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 17:47:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 17:47:19 --> Form Validation Class Initialized
INFO - 2021-04-13 17:47:19 --> Controller Class Initialized
INFO - 2021-04-13 17:47:19 --> Model Class Initialized
INFO - 2021-04-13 17:47:19 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-04-13 17:47:19 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 391
INFO - 2021-04-13 17:47:22 --> Config Class Initialized
INFO - 2021-04-13 17:47:22 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:47:22 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:47:22 --> Utf8 Class Initialized
INFO - 2021-04-13 17:47:22 --> URI Class Initialized
INFO - 2021-04-13 17:47:22 --> Router Class Initialized
INFO - 2021-04-13 17:47:22 --> Output Class Initialized
INFO - 2021-04-13 17:47:22 --> Security Class Initialized
DEBUG - 2021-04-13 17:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:47:22 --> Input Class Initialized
INFO - 2021-04-13 17:47:22 --> Language Class Initialized
INFO - 2021-04-13 17:47:22 --> Loader Class Initialized
INFO - 2021-04-13 17:47:22 --> Helper loaded: url_helper
INFO - 2021-04-13 17:47:22 --> Helper loaded: form_helper
INFO - 2021-04-13 17:47:22 --> Helper loaded: common_helper
INFO - 2021-04-13 17:47:22 --> Helper loaded: util_helper
INFO - 2021-04-13 17:47:22 --> Database Driver Class Initialized
ERROR - 2021-04-13 17:47:22 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 17:47:22 --> Unable to connect to the database
DEBUG - 2021-04-13 17:47:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 17:47:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 17:47:22 --> Form Validation Class Initialized
INFO - 2021-04-13 17:47:22 --> Controller Class Initialized
INFO - 2021-04-13 17:47:22 --> Model Class Initialized
INFO - 2021-04-13 17:47:22 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 17:47:22 --> Final output sent to browser
DEBUG - 2021-04-13 17:47:22 --> Total execution time: 0.0300
INFO - 2021-04-13 17:48:00 --> Config Class Initialized
INFO - 2021-04-13 17:48:00 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:48:00 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:48:00 --> Utf8 Class Initialized
INFO - 2021-04-13 17:48:00 --> URI Class Initialized
INFO - 2021-04-13 17:48:00 --> Router Class Initialized
INFO - 2021-04-13 17:48:00 --> Output Class Initialized
INFO - 2021-04-13 17:48:00 --> Security Class Initialized
DEBUG - 2021-04-13 17:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:48:00 --> Input Class Initialized
INFO - 2021-04-13 17:48:00 --> Language Class Initialized
INFO - 2021-04-13 17:48:00 --> Loader Class Initialized
INFO - 2021-04-13 17:48:00 --> Helper loaded: url_helper
INFO - 2021-04-13 17:48:00 --> Helper loaded: form_helper
INFO - 2021-04-13 17:48:00 --> Helper loaded: common_helper
INFO - 2021-04-13 17:48:00 --> Helper loaded: util_helper
INFO - 2021-04-13 17:48:00 --> Database Driver Class Initialized
ERROR - 2021-04-13 17:48:00 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 17:48:00 --> Unable to connect to the database
DEBUG - 2021-04-13 17:48:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 17:48:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 17:48:00 --> Form Validation Class Initialized
INFO - 2021-04-13 17:48:00 --> Controller Class Initialized
INFO - 2021-04-13 17:48:00 --> Model Class Initialized
INFO - 2021-04-13 17:48:00 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 17:48:00 --> Final output sent to browser
DEBUG - 2021-04-13 17:48:00 --> Total execution time: 0.0269
INFO - 2021-04-13 17:48:00 --> Config Class Initialized
INFO - 2021-04-13 17:48:00 --> Config Class Initialized
INFO - 2021-04-13 17:48:00 --> Hooks Class Initialized
INFO - 2021-04-13 17:48:00 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:48:00 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:48:00 --> Utf8 Class Initialized
INFO - 2021-04-13 17:48:00 --> URI Class Initialized
DEBUG - 2021-04-13 17:48:00 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:48:00 --> Router Class Initialized
INFO - 2021-04-13 17:48:00 --> Utf8 Class Initialized
INFO - 2021-04-13 17:48:00 --> URI Class Initialized
INFO - 2021-04-13 17:48:00 --> Output Class Initialized
INFO - 2021-04-13 17:48:00 --> Router Class Initialized
INFO - 2021-04-13 17:48:00 --> Security Class Initialized
INFO - 2021-04-13 17:48:00 --> Output Class Initialized
DEBUG - 2021-04-13 17:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:48:00 --> Input Class Initialized
INFO - 2021-04-13 17:48:00 --> Language Class Initialized
INFO - 2021-04-13 17:48:00 --> Security Class Initialized
ERROR - 2021-04-13 17:48:00 --> 404 Page Not Found: Fasset/img
DEBUG - 2021-04-13 17:48:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:48:00 --> Input Class Initialized
INFO - 2021-04-13 17:48:00 --> Language Class Initialized
ERROR - 2021-04-13 17:48:00 --> 404 Page Not Found: Fasset/img
INFO - 2021-04-13 17:48:01 --> Config Class Initialized
INFO - 2021-04-13 17:48:01 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:48:01 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:48:01 --> Utf8 Class Initialized
INFO - 2021-04-13 17:48:01 --> URI Class Initialized
INFO - 2021-04-13 17:48:01 --> Router Class Initialized
INFO - 2021-04-13 17:48:01 --> Output Class Initialized
INFO - 2021-04-13 17:48:01 --> Security Class Initialized
DEBUG - 2021-04-13 17:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:48:01 --> Input Class Initialized
INFO - 2021-04-13 17:48:01 --> Language Class Initialized
INFO - 2021-04-13 17:48:01 --> Loader Class Initialized
INFO - 2021-04-13 17:48:01 --> Helper loaded: url_helper
INFO - 2021-04-13 17:48:01 --> Helper loaded: form_helper
INFO - 2021-04-13 17:48:01 --> Helper loaded: common_helper
INFO - 2021-04-13 17:48:01 --> Helper loaded: util_helper
INFO - 2021-04-13 17:48:01 --> Database Driver Class Initialized
ERROR - 2021-04-13 17:48:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 17:48:01 --> Unable to connect to the database
DEBUG - 2021-04-13 17:48:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 17:48:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 17:48:01 --> Form Validation Class Initialized
INFO - 2021-04-13 17:48:01 --> Controller Class Initialized
INFO - 2021-04-13 17:48:01 --> Model Class Initialized
INFO - 2021-04-13 17:48:01 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 17:48:01 --> Final output sent to browser
DEBUG - 2021-04-13 17:48:01 --> Total execution time: 0.0263
INFO - 2021-04-13 17:48:01 --> Config Class Initialized
INFO - 2021-04-13 17:48:01 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:48:01 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:48:01 --> Utf8 Class Initialized
INFO - 2021-04-13 17:48:01 --> URI Class Initialized
INFO - 2021-04-13 17:48:01 --> Router Class Initialized
INFO - 2021-04-13 17:48:01 --> Output Class Initialized
INFO - 2021-04-13 17:48:01 --> Security Class Initialized
DEBUG - 2021-04-13 17:48:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:48:01 --> Input Class Initialized
INFO - 2021-04-13 17:48:01 --> Language Class Initialized
INFO - 2021-04-13 17:48:01 --> Loader Class Initialized
INFO - 2021-04-13 17:48:01 --> Helper loaded: url_helper
INFO - 2021-04-13 17:48:01 --> Helper loaded: form_helper
INFO - 2021-04-13 17:48:01 --> Helper loaded: common_helper
INFO - 2021-04-13 17:48:01 --> Helper loaded: util_helper
INFO - 2021-04-13 17:48:01 --> Database Driver Class Initialized
ERROR - 2021-04-13 17:48:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 17:48:01 --> Unable to connect to the database
DEBUG - 2021-04-13 17:48:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 17:48:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 17:48:01 --> Form Validation Class Initialized
INFO - 2021-04-13 17:48:01 --> Controller Class Initialized
INFO - 2021-04-13 17:48:01 --> Model Class Initialized
INFO - 2021-04-13 17:48:01 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 17:48:01 --> Final output sent to browser
DEBUG - 2021-04-13 17:48:01 --> Total execution time: 0.0254
INFO - 2021-04-13 17:48:01 --> Config Class Initialized
INFO - 2021-04-13 17:48:01 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:48:01 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:48:01 --> Utf8 Class Initialized
INFO - 2021-04-13 17:48:01 --> URI Class Initialized
DEBUG - 2021-04-13 17:48:02 --> No URI present. Default controller set.
INFO - 2021-04-13 17:48:02 --> Router Class Initialized
INFO - 2021-04-13 17:48:02 --> Output Class Initialized
INFO - 2021-04-13 17:48:02 --> Security Class Initialized
DEBUG - 2021-04-13 17:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:48:02 --> Input Class Initialized
INFO - 2021-04-13 17:48:02 --> Language Class Initialized
INFO - 2021-04-13 17:48:02 --> Loader Class Initialized
INFO - 2021-04-13 17:48:02 --> Helper loaded: url_helper
INFO - 2021-04-13 17:48:02 --> Helper loaded: form_helper
INFO - 2021-04-13 17:48:02 --> Helper loaded: common_helper
INFO - 2021-04-13 17:48:02 --> Helper loaded: util_helper
INFO - 2021-04-13 17:48:02 --> Database Driver Class Initialized
ERROR - 2021-04-13 17:48:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 17:48:02 --> Unable to connect to the database
DEBUG - 2021-04-13 17:48:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 17:48:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 17:48:02 --> Form Validation Class Initialized
INFO - 2021-04-13 17:48:02 --> Controller Class Initialized
INFO - 2021-04-13 17:48:02 --> Model Class Initialized
INFO - 2021-04-13 17:48:02 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-13 17:48:02 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 17:48:02 --> Final output sent to browser
DEBUG - 2021-04-13 17:48:02 --> Total execution time: 0.0371
INFO - 2021-04-13 17:48:03 --> Config Class Initialized
INFO - 2021-04-13 17:48:03 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:48:03 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:48:03 --> Utf8 Class Initialized
INFO - 2021-04-13 17:48:03 --> URI Class Initialized
INFO - 2021-04-13 17:48:03 --> Router Class Initialized
INFO - 2021-04-13 17:48:03 --> Output Class Initialized
INFO - 2021-04-13 17:48:03 --> Security Class Initialized
DEBUG - 2021-04-13 17:48:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:48:03 --> Input Class Initialized
INFO - 2021-04-13 17:48:03 --> Language Class Initialized
INFO - 2021-04-13 17:48:03 --> Loader Class Initialized
INFO - 2021-04-13 17:48:03 --> Helper loaded: url_helper
INFO - 2021-04-13 17:48:03 --> Helper loaded: form_helper
INFO - 2021-04-13 17:48:03 --> Helper loaded: common_helper
INFO - 2021-04-13 17:48:03 --> Helper loaded: util_helper
INFO - 2021-04-13 17:48:03 --> Database Driver Class Initialized
ERROR - 2021-04-13 17:48:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 17:48:03 --> Unable to connect to the database
DEBUG - 2021-04-13 17:48:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 17:48:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 17:48:03 --> Form Validation Class Initialized
INFO - 2021-04-13 17:48:03 --> Controller Class Initialized
INFO - 2021-04-13 17:48:03 --> Model Class Initialized
INFO - 2021-04-13 17:48:03 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 17:48:03 --> Final output sent to browser
DEBUG - 2021-04-13 17:48:03 --> Total execution time: 0.0350
INFO - 2021-04-13 17:48:04 --> Config Class Initialized
INFO - 2021-04-13 17:48:04 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:48:04 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:48:04 --> Utf8 Class Initialized
INFO - 2021-04-13 17:48:04 --> URI Class Initialized
DEBUG - 2021-04-13 17:48:04 --> No URI present. Default controller set.
INFO - 2021-04-13 17:48:04 --> Router Class Initialized
INFO - 2021-04-13 17:48:04 --> Output Class Initialized
INFO - 2021-04-13 17:48:04 --> Security Class Initialized
DEBUG - 2021-04-13 17:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:48:04 --> Input Class Initialized
INFO - 2021-04-13 17:48:04 --> Language Class Initialized
INFO - 2021-04-13 17:48:04 --> Loader Class Initialized
INFO - 2021-04-13 17:48:04 --> Helper loaded: url_helper
INFO - 2021-04-13 17:48:04 --> Helper loaded: form_helper
INFO - 2021-04-13 17:48:04 --> Helper loaded: common_helper
INFO - 2021-04-13 17:48:04 --> Helper loaded: util_helper
INFO - 2021-04-13 17:48:04 --> Database Driver Class Initialized
ERROR - 2021-04-13 17:48:04 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 17:48:04 --> Unable to connect to the database
DEBUG - 2021-04-13 17:48:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 17:48:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 17:48:04 --> Form Validation Class Initialized
INFO - 2021-04-13 17:48:04 --> Controller Class Initialized
INFO - 2021-04-13 17:48:04 --> Model Class Initialized
INFO - 2021-04-13 17:48:04 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-13 17:48:04 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 17:48:04 --> Final output sent to browser
DEBUG - 2021-04-13 17:48:04 --> Total execution time: 0.0361
INFO - 2021-04-13 17:48:06 --> Config Class Initialized
INFO - 2021-04-13 17:48:06 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:48:06 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:48:06 --> Utf8 Class Initialized
INFO - 2021-04-13 17:48:06 --> URI Class Initialized
INFO - 2021-04-13 17:48:06 --> Router Class Initialized
INFO - 2021-04-13 17:48:06 --> Output Class Initialized
INFO - 2021-04-13 17:48:06 --> Security Class Initialized
DEBUG - 2021-04-13 17:48:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:48:06 --> Input Class Initialized
INFO - 2021-04-13 17:48:06 --> Language Class Initialized
INFO - 2021-04-13 17:48:06 --> Loader Class Initialized
INFO - 2021-04-13 17:48:06 --> Helper loaded: url_helper
INFO - 2021-04-13 17:48:06 --> Helper loaded: form_helper
INFO - 2021-04-13 17:48:06 --> Helper loaded: common_helper
INFO - 2021-04-13 17:48:06 --> Helper loaded: util_helper
INFO - 2021-04-13 17:48:06 --> Database Driver Class Initialized
ERROR - 2021-04-13 17:48:06 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 17:48:06 --> Unable to connect to the database
DEBUG - 2021-04-13 17:48:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 17:48:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 17:48:06 --> Form Validation Class Initialized
INFO - 2021-04-13 17:48:06 --> Controller Class Initialized
INFO - 2021-04-13 17:48:06 --> Model Class Initialized
INFO - 2021-04-13 17:48:06 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 17:48:06 --> Final output sent to browser
DEBUG - 2021-04-13 17:48:06 --> Total execution time: 0.0347
INFO - 2021-04-13 17:48:08 --> Config Class Initialized
INFO - 2021-04-13 17:48:08 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:48:08 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:48:08 --> Utf8 Class Initialized
INFO - 2021-04-13 17:48:08 --> URI Class Initialized
DEBUG - 2021-04-13 17:48:08 --> No URI present. Default controller set.
INFO - 2021-04-13 17:48:08 --> Router Class Initialized
INFO - 2021-04-13 17:48:08 --> Output Class Initialized
INFO - 2021-04-13 17:48:08 --> Security Class Initialized
DEBUG - 2021-04-13 17:48:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:48:08 --> Input Class Initialized
INFO - 2021-04-13 17:48:08 --> Language Class Initialized
INFO - 2021-04-13 17:48:08 --> Loader Class Initialized
INFO - 2021-04-13 17:48:08 --> Helper loaded: url_helper
INFO - 2021-04-13 17:48:08 --> Helper loaded: form_helper
INFO - 2021-04-13 17:48:08 --> Helper loaded: common_helper
INFO - 2021-04-13 17:48:08 --> Helper loaded: util_helper
INFO - 2021-04-13 17:48:08 --> Database Driver Class Initialized
ERROR - 2021-04-13 17:48:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 17:48:08 --> Unable to connect to the database
DEBUG - 2021-04-13 17:48:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 17:48:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 17:48:08 --> Form Validation Class Initialized
INFO - 2021-04-13 17:48:08 --> Controller Class Initialized
INFO - 2021-04-13 17:48:08 --> Model Class Initialized
INFO - 2021-04-13 17:48:08 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-13 17:48:08 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 17:48:08 --> Final output sent to browser
DEBUG - 2021-04-13 17:48:08 --> Total execution time: 0.0269
INFO - 2021-04-13 17:48:33 --> Config Class Initialized
INFO - 2021-04-13 17:48:33 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:48:33 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:48:33 --> Utf8 Class Initialized
INFO - 2021-04-13 17:48:33 --> URI Class Initialized
DEBUG - 2021-04-13 17:48:33 --> No URI present. Default controller set.
INFO - 2021-04-13 17:48:33 --> Router Class Initialized
INFO - 2021-04-13 17:48:33 --> Output Class Initialized
INFO - 2021-04-13 17:48:33 --> Security Class Initialized
DEBUG - 2021-04-13 17:48:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:48:33 --> Input Class Initialized
INFO - 2021-04-13 17:48:33 --> Language Class Initialized
INFO - 2021-04-13 17:48:33 --> Loader Class Initialized
INFO - 2021-04-13 17:48:33 --> Helper loaded: url_helper
INFO - 2021-04-13 17:48:33 --> Helper loaded: form_helper
INFO - 2021-04-13 17:48:33 --> Helper loaded: common_helper
INFO - 2021-04-13 17:48:33 --> Helper loaded: util_helper
INFO - 2021-04-13 17:48:33 --> Database Driver Class Initialized
ERROR - 2021-04-13 17:48:33 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 17:48:33 --> Unable to connect to the database
DEBUG - 2021-04-13 17:48:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 17:48:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 17:48:33 --> Form Validation Class Initialized
INFO - 2021-04-13 17:48:33 --> Controller Class Initialized
INFO - 2021-04-13 17:48:33 --> Model Class Initialized
INFO - 2021-04-13 17:48:33 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-13 17:48:33 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 17:48:33 --> Final output sent to browser
DEBUG - 2021-04-13 17:48:33 --> Total execution time: 0.0371
INFO - 2021-04-13 17:48:35 --> Config Class Initialized
INFO - 2021-04-13 17:48:35 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:48:35 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:48:35 --> Utf8 Class Initialized
INFO - 2021-04-13 17:48:35 --> URI Class Initialized
INFO - 2021-04-13 17:48:35 --> Router Class Initialized
INFO - 2021-04-13 17:48:35 --> Output Class Initialized
INFO - 2021-04-13 17:48:35 --> Security Class Initialized
DEBUG - 2021-04-13 17:48:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:48:35 --> Input Class Initialized
INFO - 2021-04-13 17:48:35 --> Language Class Initialized
ERROR - 2021-04-13 17:48:35 --> 404 Page Not Found: Home/login
INFO - 2021-04-13 17:48:47 --> Config Class Initialized
INFO - 2021-04-13 17:48:47 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:48:47 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:48:47 --> Utf8 Class Initialized
INFO - 2021-04-13 17:48:47 --> URI Class Initialized
INFO - 2021-04-13 17:48:47 --> Router Class Initialized
INFO - 2021-04-13 17:48:47 --> Output Class Initialized
INFO - 2021-04-13 17:48:47 --> Security Class Initialized
DEBUG - 2021-04-13 17:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:48:47 --> Input Class Initialized
INFO - 2021-04-13 17:48:47 --> Language Class Initialized
INFO - 2021-04-13 17:48:47 --> Loader Class Initialized
INFO - 2021-04-13 17:48:47 --> Helper loaded: url_helper
INFO - 2021-04-13 17:48:47 --> Helper loaded: form_helper
INFO - 2021-04-13 17:48:47 --> Helper loaded: common_helper
INFO - 2021-04-13 17:48:47 --> Helper loaded: util_helper
INFO - 2021-04-13 17:48:47 --> Database Driver Class Initialized
ERROR - 2021-04-13 17:48:47 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 17:48:47 --> Unable to connect to the database
DEBUG - 2021-04-13 17:48:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 17:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 17:48:47 --> Form Validation Class Initialized
INFO - 2021-04-13 17:48:47 --> Controller Class Initialized
INFO - 2021-04-13 17:48:47 --> Model Class Initialized
INFO - 2021-04-13 17:48:47 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 17:48:47 --> Final output sent to browser
DEBUG - 2021-04-13 17:48:47 --> Total execution time: 0.0270
INFO - 2021-04-13 17:48:47 --> Config Class Initialized
INFO - 2021-04-13 17:48:47 --> Hooks Class Initialized
INFO - 2021-04-13 17:48:47 --> Config Class Initialized
INFO - 2021-04-13 17:48:47 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:48:47 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:48:47 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:48:47 --> Utf8 Class Initialized
INFO - 2021-04-13 17:48:47 --> Utf8 Class Initialized
INFO - 2021-04-13 17:48:47 --> URI Class Initialized
INFO - 2021-04-13 17:48:47 --> URI Class Initialized
INFO - 2021-04-13 17:48:47 --> Router Class Initialized
INFO - 2021-04-13 17:48:47 --> Router Class Initialized
INFO - 2021-04-13 17:48:47 --> Output Class Initialized
INFO - 2021-04-13 17:48:47 --> Output Class Initialized
INFO - 2021-04-13 17:48:47 --> Security Class Initialized
INFO - 2021-04-13 17:48:47 --> Security Class Initialized
DEBUG - 2021-04-13 17:48:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:48:47 --> Input Class Initialized
INFO - 2021-04-13 17:48:47 --> Input Class Initialized
INFO - 2021-04-13 17:48:47 --> Language Class Initialized
INFO - 2021-04-13 17:48:47 --> Language Class Initialized
ERROR - 2021-04-13 17:48:47 --> 404 Page Not Found: Fasset/img
ERROR - 2021-04-13 17:48:47 --> 404 Page Not Found: Fasset/img
INFO - 2021-04-13 17:49:30 --> Config Class Initialized
INFO - 2021-04-13 17:49:30 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:49:30 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:49:30 --> Utf8 Class Initialized
INFO - 2021-04-13 17:49:30 --> URI Class Initialized
INFO - 2021-04-13 17:49:30 --> Router Class Initialized
INFO - 2021-04-13 17:49:30 --> Output Class Initialized
INFO - 2021-04-13 17:49:30 --> Security Class Initialized
DEBUG - 2021-04-13 17:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:49:30 --> Input Class Initialized
INFO - 2021-04-13 17:49:30 --> Language Class Initialized
INFO - 2021-04-13 17:49:30 --> Loader Class Initialized
INFO - 2021-04-13 17:49:30 --> Helper loaded: url_helper
INFO - 2021-04-13 17:49:30 --> Helper loaded: form_helper
INFO - 2021-04-13 17:49:30 --> Helper loaded: common_helper
INFO - 2021-04-13 17:49:30 --> Helper loaded: util_helper
INFO - 2021-04-13 17:49:30 --> Database Driver Class Initialized
ERROR - 2021-04-13 17:49:30 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 17:49:30 --> Unable to connect to the database
DEBUG - 2021-04-13 17:49:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 17:49:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 17:49:30 --> Form Validation Class Initialized
INFO - 2021-04-13 17:49:30 --> Controller Class Initialized
INFO - 2021-04-13 17:49:30 --> Model Class Initialized
INFO - 2021-04-13 17:49:30 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 17:49:30 --> Final output sent to browser
DEBUG - 2021-04-13 17:49:30 --> Total execution time: 0.0261
INFO - 2021-04-13 17:49:30 --> Config Class Initialized
INFO - 2021-04-13 17:49:30 --> Hooks Class Initialized
INFO - 2021-04-13 17:49:30 --> Config Class Initialized
INFO - 2021-04-13 17:49:30 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:49:30 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:49:30 --> Utf8 Class Initialized
INFO - 2021-04-13 17:49:30 --> URI Class Initialized
DEBUG - 2021-04-13 17:49:30 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:49:30 --> Utf8 Class Initialized
INFO - 2021-04-13 17:49:30 --> Router Class Initialized
INFO - 2021-04-13 17:49:30 --> URI Class Initialized
INFO - 2021-04-13 17:49:30 --> Router Class Initialized
INFO - 2021-04-13 17:49:30 --> Output Class Initialized
INFO - 2021-04-13 17:49:30 --> Security Class Initialized
INFO - 2021-04-13 17:49:30 --> Output Class Initialized
DEBUG - 2021-04-13 17:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:49:30 --> Input Class Initialized
INFO - 2021-04-13 17:49:30 --> Security Class Initialized
INFO - 2021-04-13 17:49:30 --> Language Class Initialized
DEBUG - 2021-04-13 17:49:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:49:30 --> Input Class Initialized
ERROR - 2021-04-13 17:49:30 --> 404 Page Not Found: Fasset/img
INFO - 2021-04-13 17:49:30 --> Language Class Initialized
ERROR - 2021-04-13 17:49:30 --> 404 Page Not Found: Fasset/img
INFO - 2021-04-13 17:50:01 --> Config Class Initialized
INFO - 2021-04-13 17:50:01 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:50:01 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:50:01 --> Utf8 Class Initialized
INFO - 2021-04-13 17:50:01 --> URI Class Initialized
INFO - 2021-04-13 17:50:01 --> Router Class Initialized
INFO - 2021-04-13 17:50:01 --> Output Class Initialized
INFO - 2021-04-13 17:50:01 --> Security Class Initialized
DEBUG - 2021-04-13 17:50:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:50:01 --> Input Class Initialized
INFO - 2021-04-13 17:50:01 --> Language Class Initialized
INFO - 2021-04-13 17:50:01 --> Loader Class Initialized
INFO - 2021-04-13 17:50:01 --> Helper loaded: url_helper
INFO - 2021-04-13 17:50:01 --> Helper loaded: form_helper
INFO - 2021-04-13 17:50:01 --> Helper loaded: common_helper
INFO - 2021-04-13 17:50:01 --> Helper loaded: util_helper
INFO - 2021-04-13 17:50:01 --> Database Driver Class Initialized
ERROR - 2021-04-13 17:50:01 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 17:50:01 --> Unable to connect to the database
DEBUG - 2021-04-13 17:50:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 17:50:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 17:50:01 --> Form Validation Class Initialized
INFO - 2021-04-13 17:50:01 --> Controller Class Initialized
INFO - 2021-04-13 17:50:01 --> Model Class Initialized
INFO - 2021-04-13 17:50:01 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-04-13 17:50:01 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 391
INFO - 2021-04-13 17:50:04 --> Config Class Initialized
INFO - 2021-04-13 17:50:04 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:50:04 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:50:04 --> Utf8 Class Initialized
INFO - 2021-04-13 17:50:04 --> URI Class Initialized
INFO - 2021-04-13 17:50:04 --> Router Class Initialized
INFO - 2021-04-13 17:50:04 --> Output Class Initialized
INFO - 2021-04-13 17:50:04 --> Security Class Initialized
DEBUG - 2021-04-13 17:50:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:50:04 --> Input Class Initialized
INFO - 2021-04-13 17:50:04 --> Language Class Initialized
INFO - 2021-04-13 17:50:04 --> Loader Class Initialized
INFO - 2021-04-13 17:50:04 --> Helper loaded: url_helper
INFO - 2021-04-13 17:50:04 --> Helper loaded: form_helper
INFO - 2021-04-13 17:50:04 --> Helper loaded: common_helper
INFO - 2021-04-13 17:50:04 --> Helper loaded: util_helper
INFO - 2021-04-13 17:50:04 --> Database Driver Class Initialized
ERROR - 2021-04-13 17:50:04 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 17:50:04 --> Unable to connect to the database
DEBUG - 2021-04-13 17:50:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 17:50:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 17:50:04 --> Form Validation Class Initialized
INFO - 2021-04-13 17:50:04 --> Controller Class Initialized
INFO - 2021-04-13 17:50:04 --> Model Class Initialized
INFO - 2021-04-13 17:50:04 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 17:50:04 --> Final output sent to browser
DEBUG - 2021-04-13 17:50:04 --> Total execution time: 0.0405
INFO - 2021-04-13 17:54:58 --> Config Class Initialized
INFO - 2021-04-13 17:54:58 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:54:58 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:54:58 --> Utf8 Class Initialized
INFO - 2021-04-13 17:54:58 --> URI Class Initialized
INFO - 2021-04-13 17:54:58 --> Router Class Initialized
INFO - 2021-04-13 17:54:58 --> Output Class Initialized
INFO - 2021-04-13 17:54:58 --> Security Class Initialized
DEBUG - 2021-04-13 17:54:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:54:58 --> Input Class Initialized
INFO - 2021-04-13 17:54:58 --> Language Class Initialized
ERROR - 2021-04-13 17:54:58 --> Severity: error --> Exception: syntax error, unexpected '/' C:\xampp1\htdocs\FoodTruck\php\application\controllers\Home.php 158
INFO - 2021-04-13 17:55:43 --> Config Class Initialized
INFO - 2021-04-13 17:55:43 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:55:43 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:55:43 --> Utf8 Class Initialized
INFO - 2021-04-13 17:55:43 --> URI Class Initialized
INFO - 2021-04-13 17:55:43 --> Router Class Initialized
INFO - 2021-04-13 17:55:43 --> Output Class Initialized
INFO - 2021-04-13 17:55:43 --> Security Class Initialized
DEBUG - 2021-04-13 17:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:55:43 --> Input Class Initialized
INFO - 2021-04-13 17:55:43 --> Language Class Initialized
INFO - 2021-04-13 17:55:43 --> Loader Class Initialized
INFO - 2021-04-13 17:55:43 --> Helper loaded: url_helper
INFO - 2021-04-13 17:55:43 --> Helper loaded: form_helper
INFO - 2021-04-13 17:55:43 --> Helper loaded: common_helper
INFO - 2021-04-13 17:55:43 --> Helper loaded: util_helper
INFO - 2021-04-13 17:55:43 --> Database Driver Class Initialized
ERROR - 2021-04-13 17:55:43 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 17:55:43 --> Unable to connect to the database
DEBUG - 2021-04-13 17:55:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 17:55:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 17:55:43 --> Form Validation Class Initialized
INFO - 2021-04-13 17:55:43 --> Controller Class Initialized
INFO - 2021-04-13 17:55:43 --> Model Class Initialized
INFO - 2021-04-13 17:55:43 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 17:55:43 --> Final output sent to browser
DEBUG - 2021-04-13 17:55:43 --> Total execution time: 0.0326
INFO - 2021-04-13 17:55:43 --> Config Class Initialized
INFO - 2021-04-13 17:55:43 --> Config Class Initialized
INFO - 2021-04-13 17:55:43 --> Hooks Class Initialized
INFO - 2021-04-13 17:55:43 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:55:43 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:55:43 --> Utf8 Class Initialized
DEBUG - 2021-04-13 17:55:43 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:55:43 --> Utf8 Class Initialized
INFO - 2021-04-13 17:55:43 --> URI Class Initialized
INFO - 2021-04-13 17:55:43 --> URI Class Initialized
INFO - 2021-04-13 17:55:43 --> Router Class Initialized
INFO - 2021-04-13 17:55:43 --> Router Class Initialized
INFO - 2021-04-13 17:55:43 --> Output Class Initialized
INFO - 2021-04-13 17:55:43 --> Output Class Initialized
INFO - 2021-04-13 17:55:43 --> Security Class Initialized
INFO - 2021-04-13 17:55:43 --> Security Class Initialized
DEBUG - 2021-04-13 17:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:55:43 --> Input Class Initialized
DEBUG - 2021-04-13 17:55:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:55:43 --> Input Class Initialized
INFO - 2021-04-13 17:55:43 --> Language Class Initialized
INFO - 2021-04-13 17:55:43 --> Language Class Initialized
ERROR - 2021-04-13 17:55:43 --> 404 Page Not Found: Fasset/img
ERROR - 2021-04-13 17:55:43 --> 404 Page Not Found: Fasset/img
INFO - 2021-04-13 17:56:13 --> Config Class Initialized
INFO - 2021-04-13 17:56:13 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:56:13 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:56:13 --> Utf8 Class Initialized
INFO - 2021-04-13 17:56:13 --> URI Class Initialized
INFO - 2021-04-13 17:56:13 --> Router Class Initialized
INFO - 2021-04-13 17:56:13 --> Output Class Initialized
INFO - 2021-04-13 17:56:13 --> Security Class Initialized
DEBUG - 2021-04-13 17:56:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:56:13 --> Input Class Initialized
INFO - 2021-04-13 17:56:13 --> Language Class Initialized
ERROR - 2021-04-13 17:56:13 --> Severity: error --> Exception: syntax error, unexpected '/' C:\xampp1\htdocs\FoodTruck\php\application\controllers\Home.php 158
INFO - 2021-04-13 17:56:39 --> Config Class Initialized
INFO - 2021-04-13 17:56:39 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:56:39 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:56:39 --> Utf8 Class Initialized
INFO - 2021-04-13 17:56:39 --> URI Class Initialized
INFO - 2021-04-13 17:56:39 --> Router Class Initialized
INFO - 2021-04-13 17:56:39 --> Output Class Initialized
INFO - 2021-04-13 17:56:39 --> Security Class Initialized
DEBUG - 2021-04-13 17:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:56:39 --> Input Class Initialized
INFO - 2021-04-13 17:56:39 --> Language Class Initialized
INFO - 2021-04-13 17:56:39 --> Loader Class Initialized
INFO - 2021-04-13 17:56:39 --> Helper loaded: url_helper
INFO - 2021-04-13 17:56:39 --> Helper loaded: form_helper
INFO - 2021-04-13 17:56:39 --> Helper loaded: common_helper
INFO - 2021-04-13 17:56:39 --> Helper loaded: util_helper
INFO - 2021-04-13 17:56:39 --> Database Driver Class Initialized
ERROR - 2021-04-13 17:56:39 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 17:56:39 --> Unable to connect to the database
DEBUG - 2021-04-13 17:56:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 17:56:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 17:56:39 --> Form Validation Class Initialized
INFO - 2021-04-13 17:56:39 --> Controller Class Initialized
INFO - 2021-04-13 17:56:39 --> Model Class Initialized
INFO - 2021-04-13 17:56:39 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 17:56:39 --> Final output sent to browser
DEBUG - 2021-04-13 17:56:39 --> Total execution time: 0.0395
INFO - 2021-04-13 17:56:39 --> Config Class Initialized
INFO - 2021-04-13 17:56:39 --> Config Class Initialized
INFO - 2021-04-13 17:56:39 --> Hooks Class Initialized
INFO - 2021-04-13 17:56:39 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:56:39 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:56:39 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:56:39 --> Utf8 Class Initialized
INFO - 2021-04-13 17:56:39 --> Utf8 Class Initialized
INFO - 2021-04-13 17:56:39 --> URI Class Initialized
INFO - 2021-04-13 17:56:39 --> URI Class Initialized
INFO - 2021-04-13 17:56:39 --> Router Class Initialized
INFO - 2021-04-13 17:56:39 --> Router Class Initialized
INFO - 2021-04-13 17:56:39 --> Output Class Initialized
INFO - 2021-04-13 17:56:39 --> Output Class Initialized
INFO - 2021-04-13 17:56:39 --> Security Class Initialized
INFO - 2021-04-13 17:56:39 --> Security Class Initialized
DEBUG - 2021-04-13 17:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:56:39 --> Input Class Initialized
DEBUG - 2021-04-13 17:56:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:56:39 --> Input Class Initialized
INFO - 2021-04-13 17:56:39 --> Language Class Initialized
INFO - 2021-04-13 17:56:39 --> Language Class Initialized
ERROR - 2021-04-13 17:56:39 --> 404 Page Not Found: Fasset/img
ERROR - 2021-04-13 17:56:39 --> 404 Page Not Found: Fasset/img
INFO - 2021-04-13 17:57:49 --> Config Class Initialized
INFO - 2021-04-13 17:57:49 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:57:49 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:57:49 --> Utf8 Class Initialized
INFO - 2021-04-13 17:57:49 --> URI Class Initialized
INFO - 2021-04-13 17:57:49 --> Router Class Initialized
INFO - 2021-04-13 17:57:49 --> Output Class Initialized
INFO - 2021-04-13 17:57:49 --> Security Class Initialized
DEBUG - 2021-04-13 17:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:57:49 --> Input Class Initialized
INFO - 2021-04-13 17:57:49 --> Language Class Initialized
INFO - 2021-04-13 17:57:49 --> Loader Class Initialized
INFO - 2021-04-13 17:57:49 --> Helper loaded: url_helper
INFO - 2021-04-13 17:57:49 --> Helper loaded: form_helper
INFO - 2021-04-13 17:57:49 --> Helper loaded: common_helper
INFO - 2021-04-13 17:57:49 --> Helper loaded: util_helper
INFO - 2021-04-13 17:57:49 --> Database Driver Class Initialized
ERROR - 2021-04-13 17:57:49 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 17:57:49 --> Unable to connect to the database
DEBUG - 2021-04-13 17:57:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 17:57:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 17:57:49 --> Form Validation Class Initialized
INFO - 2021-04-13 17:57:49 --> Controller Class Initialized
INFO - 2021-04-13 17:57:49 --> Model Class Initialized
INFO - 2021-04-13 17:57:49 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 17:57:49 --> Final output sent to browser
DEBUG - 2021-04-13 17:57:49 --> Total execution time: 0.0371
INFO - 2021-04-13 17:57:49 --> Config Class Initialized
INFO - 2021-04-13 17:57:49 --> Hooks Class Initialized
INFO - 2021-04-13 17:57:49 --> Config Class Initialized
INFO - 2021-04-13 17:57:49 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:57:49 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:57:49 --> Utf8 Class Initialized
INFO - 2021-04-13 17:57:49 --> URI Class Initialized
DEBUG - 2021-04-13 17:57:49 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:57:49 --> Utf8 Class Initialized
INFO - 2021-04-13 17:57:49 --> Router Class Initialized
INFO - 2021-04-13 17:57:49 --> URI Class Initialized
INFO - 2021-04-13 17:57:49 --> Output Class Initialized
INFO - 2021-04-13 17:57:49 --> Router Class Initialized
INFO - 2021-04-13 17:57:49 --> Security Class Initialized
INFO - 2021-04-13 17:57:49 --> Output Class Initialized
DEBUG - 2021-04-13 17:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:57:49 --> Input Class Initialized
INFO - 2021-04-13 17:57:49 --> Security Class Initialized
INFO - 2021-04-13 17:57:49 --> Language Class Initialized
DEBUG - 2021-04-13 17:57:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:57:49 --> Input Class Initialized
ERROR - 2021-04-13 17:57:49 --> 404 Page Not Found: Fasset/img
INFO - 2021-04-13 17:57:49 --> Language Class Initialized
ERROR - 2021-04-13 17:57:49 --> 404 Page Not Found: Fasset/img
INFO - 2021-04-13 17:57:50 --> Config Class Initialized
INFO - 2021-04-13 17:57:50 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:57:50 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:57:50 --> Utf8 Class Initialized
INFO - 2021-04-13 17:57:50 --> URI Class Initialized
INFO - 2021-04-13 17:57:50 --> Router Class Initialized
INFO - 2021-04-13 17:57:50 --> Output Class Initialized
INFO - 2021-04-13 17:57:50 --> Security Class Initialized
DEBUG - 2021-04-13 17:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:57:50 --> Input Class Initialized
INFO - 2021-04-13 17:57:50 --> Language Class Initialized
INFO - 2021-04-13 17:57:50 --> Loader Class Initialized
INFO - 2021-04-13 17:57:50 --> Helper loaded: url_helper
INFO - 2021-04-13 17:57:50 --> Helper loaded: form_helper
INFO - 2021-04-13 17:57:50 --> Helper loaded: common_helper
INFO - 2021-04-13 17:57:50 --> Helper loaded: util_helper
INFO - 2021-04-13 17:57:50 --> Database Driver Class Initialized
ERROR - 2021-04-13 17:57:50 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 17:57:50 --> Unable to connect to the database
DEBUG - 2021-04-13 17:57:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 17:57:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 17:57:50 --> Form Validation Class Initialized
INFO - 2021-04-13 17:57:50 --> Controller Class Initialized
INFO - 2021-04-13 17:57:50 --> Model Class Initialized
INFO - 2021-04-13 17:57:50 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 17:57:50 --> Final output sent to browser
DEBUG - 2021-04-13 17:57:50 --> Total execution time: 0.0259
INFO - 2021-04-13 17:57:50 --> Config Class Initialized
INFO - 2021-04-13 17:57:50 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:57:50 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:57:50 --> Utf8 Class Initialized
INFO - 2021-04-13 17:57:50 --> URI Class Initialized
INFO - 2021-04-13 17:57:50 --> Router Class Initialized
INFO - 2021-04-13 17:57:50 --> Output Class Initialized
INFO - 2021-04-13 17:57:50 --> Security Class Initialized
DEBUG - 2021-04-13 17:57:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:57:50 --> Input Class Initialized
INFO - 2021-04-13 17:57:50 --> Language Class Initialized
INFO - 2021-04-13 17:57:50 --> Loader Class Initialized
INFO - 2021-04-13 17:57:50 --> Helper loaded: url_helper
INFO - 2021-04-13 17:57:50 --> Helper loaded: form_helper
INFO - 2021-04-13 17:57:50 --> Helper loaded: common_helper
INFO - 2021-04-13 17:57:50 --> Helper loaded: util_helper
INFO - 2021-04-13 17:57:50 --> Database Driver Class Initialized
ERROR - 2021-04-13 17:57:50 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 17:57:50 --> Unable to connect to the database
DEBUG - 2021-04-13 17:57:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 17:57:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 17:57:50 --> Form Validation Class Initialized
INFO - 2021-04-13 17:57:50 --> Controller Class Initialized
INFO - 2021-04-13 17:57:50 --> Model Class Initialized
INFO - 2021-04-13 17:57:50 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 17:57:50 --> Final output sent to browser
DEBUG - 2021-04-13 17:57:50 --> Total execution time: 0.0259
INFO - 2021-04-13 17:58:11 --> Config Class Initialized
INFO - 2021-04-13 17:58:11 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:58:11 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:58:11 --> Utf8 Class Initialized
INFO - 2021-04-13 17:58:11 --> URI Class Initialized
INFO - 2021-04-13 17:58:11 --> Router Class Initialized
INFO - 2021-04-13 17:58:11 --> Output Class Initialized
INFO - 2021-04-13 17:58:11 --> Security Class Initialized
DEBUG - 2021-04-13 17:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:58:11 --> Input Class Initialized
INFO - 2021-04-13 17:58:11 --> Language Class Initialized
INFO - 2021-04-13 17:58:11 --> Loader Class Initialized
INFO - 2021-04-13 17:58:11 --> Helper loaded: url_helper
INFO - 2021-04-13 17:58:11 --> Helper loaded: form_helper
INFO - 2021-04-13 17:58:11 --> Helper loaded: common_helper
INFO - 2021-04-13 17:58:11 --> Helper loaded: util_helper
INFO - 2021-04-13 17:58:11 --> Database Driver Class Initialized
ERROR - 2021-04-13 17:58:11 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 17:58:11 --> Unable to connect to the database
DEBUG - 2021-04-13 17:58:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 17:58:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 17:58:11 --> Form Validation Class Initialized
INFO - 2021-04-13 17:58:11 --> Controller Class Initialized
INFO - 2021-04-13 17:58:11 --> Model Class Initialized
INFO - 2021-04-13 17:58:11 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-04-13 17:58:11 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 391
INFO - 2021-04-13 17:58:14 --> Config Class Initialized
INFO - 2021-04-13 17:58:14 --> Hooks Class Initialized
DEBUG - 2021-04-13 17:58:14 --> UTF-8 Support Enabled
INFO - 2021-04-13 17:58:14 --> Utf8 Class Initialized
INFO - 2021-04-13 17:58:14 --> URI Class Initialized
INFO - 2021-04-13 17:58:14 --> Router Class Initialized
INFO - 2021-04-13 17:58:14 --> Output Class Initialized
INFO - 2021-04-13 17:58:14 --> Security Class Initialized
DEBUG - 2021-04-13 17:58:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 17:58:14 --> Input Class Initialized
INFO - 2021-04-13 17:58:14 --> Language Class Initialized
INFO - 2021-04-13 17:58:14 --> Loader Class Initialized
INFO - 2021-04-13 17:58:14 --> Helper loaded: url_helper
INFO - 2021-04-13 17:58:14 --> Helper loaded: form_helper
INFO - 2021-04-13 17:58:14 --> Helper loaded: common_helper
INFO - 2021-04-13 17:58:14 --> Helper loaded: util_helper
INFO - 2021-04-13 17:58:14 --> Database Driver Class Initialized
ERROR - 2021-04-13 17:58:14 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 17:58:14 --> Unable to connect to the database
DEBUG - 2021-04-13 17:58:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 17:58:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 17:58:14 --> Form Validation Class Initialized
INFO - 2021-04-13 17:58:14 --> Controller Class Initialized
INFO - 2021-04-13 17:58:14 --> Model Class Initialized
INFO - 2021-04-13 17:58:14 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 17:58:14 --> Final output sent to browser
DEBUG - 2021-04-13 17:58:14 --> Total execution time: 0.0312
INFO - 2021-04-13 18:00:55 --> Config Class Initialized
INFO - 2021-04-13 18:00:55 --> Hooks Class Initialized
DEBUG - 2021-04-13 18:00:55 --> UTF-8 Support Enabled
INFO - 2021-04-13 18:00:55 --> Utf8 Class Initialized
INFO - 2021-04-13 18:00:55 --> URI Class Initialized
INFO - 2021-04-13 18:00:55 --> Router Class Initialized
INFO - 2021-04-13 18:00:55 --> Output Class Initialized
INFO - 2021-04-13 18:00:55 --> Security Class Initialized
DEBUG - 2021-04-13 18:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 18:00:55 --> Input Class Initialized
INFO - 2021-04-13 18:00:55 --> Language Class Initialized
INFO - 2021-04-13 18:00:55 --> Loader Class Initialized
INFO - 2021-04-13 18:00:55 --> Helper loaded: url_helper
INFO - 2021-04-13 18:00:55 --> Helper loaded: form_helper
INFO - 2021-04-13 18:00:55 --> Helper loaded: common_helper
INFO - 2021-04-13 18:00:55 --> Helper loaded: util_helper
INFO - 2021-04-13 18:00:55 --> Database Driver Class Initialized
ERROR - 2021-04-13 18:00:55 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 18:00:55 --> Unable to connect to the database
DEBUG - 2021-04-13 18:00:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 18:00:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 18:00:55 --> Form Validation Class Initialized
INFO - 2021-04-13 18:00:55 --> Controller Class Initialized
INFO - 2021-04-13 18:00:55 --> Model Class Initialized
INFO - 2021-04-13 18:00:55 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 18:00:55 --> Final output sent to browser
DEBUG - 2021-04-13 18:00:55 --> Total execution time: 0.0365
INFO - 2021-04-13 18:00:55 --> Config Class Initialized
INFO - 2021-04-13 18:00:55 --> Hooks Class Initialized
INFO - 2021-04-13 18:00:55 --> Config Class Initialized
INFO - 2021-04-13 18:00:55 --> Hooks Class Initialized
DEBUG - 2021-04-13 18:00:55 --> UTF-8 Support Enabled
INFO - 2021-04-13 18:00:55 --> Utf8 Class Initialized
DEBUG - 2021-04-13 18:00:55 --> UTF-8 Support Enabled
INFO - 2021-04-13 18:00:55 --> Utf8 Class Initialized
INFO - 2021-04-13 18:00:55 --> URI Class Initialized
INFO - 2021-04-13 18:00:55 --> URI Class Initialized
INFO - 2021-04-13 18:00:55 --> Router Class Initialized
INFO - 2021-04-13 18:00:55 --> Router Class Initialized
INFO - 2021-04-13 18:00:55 --> Output Class Initialized
INFO - 2021-04-13 18:00:55 --> Output Class Initialized
INFO - 2021-04-13 18:00:55 --> Security Class Initialized
INFO - 2021-04-13 18:00:55 --> Security Class Initialized
DEBUG - 2021-04-13 18:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 18:00:55 --> Input Class Initialized
INFO - 2021-04-13 18:00:55 --> Language Class Initialized
DEBUG - 2021-04-13 18:00:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 18:00:55 --> Input Class Initialized
INFO - 2021-04-13 18:00:55 --> Language Class Initialized
ERROR - 2021-04-13 18:00:55 --> 404 Page Not Found: Fasset/img
ERROR - 2021-04-13 18:00:55 --> 404 Page Not Found: Fasset/img
INFO - 2021-04-13 18:01:16 --> Config Class Initialized
INFO - 2021-04-13 18:01:16 --> Hooks Class Initialized
DEBUG - 2021-04-13 18:01:16 --> UTF-8 Support Enabled
INFO - 2021-04-13 18:01:16 --> Utf8 Class Initialized
INFO - 2021-04-13 18:01:16 --> URI Class Initialized
INFO - 2021-04-13 18:01:16 --> Router Class Initialized
INFO - 2021-04-13 18:01:16 --> Output Class Initialized
INFO - 2021-04-13 18:01:16 --> Security Class Initialized
DEBUG - 2021-04-13 18:01:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 18:01:16 --> Input Class Initialized
INFO - 2021-04-13 18:01:16 --> Language Class Initialized
INFO - 2021-04-13 18:01:16 --> Loader Class Initialized
INFO - 2021-04-13 18:01:16 --> Helper loaded: url_helper
INFO - 2021-04-13 18:01:16 --> Helper loaded: form_helper
INFO - 2021-04-13 18:01:16 --> Helper loaded: common_helper
INFO - 2021-04-13 18:01:16 --> Helper loaded: util_helper
INFO - 2021-04-13 18:01:16 --> Database Driver Class Initialized
ERROR - 2021-04-13 18:01:16 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 18:01:16 --> Unable to connect to the database
DEBUG - 2021-04-13 18:01:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 18:01:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 18:01:16 --> Form Validation Class Initialized
INFO - 2021-04-13 18:01:16 --> Controller Class Initialized
INFO - 2021-04-13 18:01:16 --> Model Class Initialized
INFO - 2021-04-13 18:01:16 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-04-13 18:01:16 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 391
INFO - 2021-04-13 18:01:19 --> Config Class Initialized
INFO - 2021-04-13 18:01:19 --> Hooks Class Initialized
DEBUG - 2021-04-13 18:01:19 --> UTF-8 Support Enabled
INFO - 2021-04-13 18:01:19 --> Utf8 Class Initialized
INFO - 2021-04-13 18:01:19 --> URI Class Initialized
INFO - 2021-04-13 18:01:19 --> Router Class Initialized
INFO - 2021-04-13 18:01:19 --> Output Class Initialized
INFO - 2021-04-13 18:01:19 --> Security Class Initialized
DEBUG - 2021-04-13 18:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 18:01:19 --> Input Class Initialized
INFO - 2021-04-13 18:01:19 --> Language Class Initialized
INFO - 2021-04-13 18:01:19 --> Loader Class Initialized
INFO - 2021-04-13 18:01:19 --> Helper loaded: url_helper
INFO - 2021-04-13 18:01:19 --> Helper loaded: form_helper
INFO - 2021-04-13 18:01:19 --> Helper loaded: common_helper
INFO - 2021-04-13 18:01:19 --> Helper loaded: util_helper
INFO - 2021-04-13 18:01:19 --> Database Driver Class Initialized
ERROR - 2021-04-13 18:01:19 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 18:01:19 --> Unable to connect to the database
DEBUG - 2021-04-13 18:01:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 18:01:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 18:01:19 --> Form Validation Class Initialized
INFO - 2021-04-13 18:01:19 --> Controller Class Initialized
INFO - 2021-04-13 18:01:19 --> Model Class Initialized
INFO - 2021-04-13 18:01:19 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 18:01:19 --> Final output sent to browser
DEBUG - 2021-04-13 18:01:19 --> Total execution time: 0.0387
INFO - 2021-04-13 18:01:24 --> Config Class Initialized
INFO - 2021-04-13 18:01:24 --> Hooks Class Initialized
DEBUG - 2021-04-13 18:01:24 --> UTF-8 Support Enabled
INFO - 2021-04-13 18:01:24 --> Utf8 Class Initialized
INFO - 2021-04-13 18:01:24 --> URI Class Initialized
INFO - 2021-04-13 18:01:24 --> Router Class Initialized
INFO - 2021-04-13 18:01:24 --> Output Class Initialized
INFO - 2021-04-13 18:01:24 --> Security Class Initialized
DEBUG - 2021-04-13 18:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 18:01:24 --> Input Class Initialized
INFO - 2021-04-13 18:01:24 --> Language Class Initialized
INFO - 2021-04-13 18:01:24 --> Loader Class Initialized
INFO - 2021-04-13 18:01:24 --> Helper loaded: url_helper
INFO - 2021-04-13 18:01:24 --> Helper loaded: form_helper
INFO - 2021-04-13 18:01:24 --> Helper loaded: common_helper
INFO - 2021-04-13 18:01:24 --> Helper loaded: util_helper
INFO - 2021-04-13 18:01:24 --> Database Driver Class Initialized
ERROR - 2021-04-13 18:01:24 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 18:01:24 --> Unable to connect to the database
DEBUG - 2021-04-13 18:01:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 18:01:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 18:01:24 --> Form Validation Class Initialized
INFO - 2021-04-13 18:01:24 --> Controller Class Initialized
INFO - 2021-04-13 18:01:24 --> Model Class Initialized
INFO - 2021-04-13 18:01:24 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 18:01:24 --> Final output sent to browser
DEBUG - 2021-04-13 18:01:24 --> Total execution time: 0.0315
INFO - 2021-04-13 18:03:29 --> Config Class Initialized
INFO - 2021-04-13 18:03:29 --> Hooks Class Initialized
DEBUG - 2021-04-13 18:03:29 --> UTF-8 Support Enabled
INFO - 2021-04-13 18:03:29 --> Utf8 Class Initialized
INFO - 2021-04-13 18:03:29 --> URI Class Initialized
INFO - 2021-04-13 18:03:29 --> Router Class Initialized
INFO - 2021-04-13 18:03:29 --> Output Class Initialized
INFO - 2021-04-13 18:03:29 --> Security Class Initialized
DEBUG - 2021-04-13 18:03:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 18:03:29 --> Input Class Initialized
INFO - 2021-04-13 18:03:29 --> Language Class Initialized
INFO - 2021-04-13 18:03:29 --> Loader Class Initialized
INFO - 2021-04-13 18:03:29 --> Helper loaded: url_helper
INFO - 2021-04-13 18:03:29 --> Helper loaded: form_helper
INFO - 2021-04-13 18:03:29 --> Helper loaded: common_helper
INFO - 2021-04-13 18:03:29 --> Helper loaded: util_helper
INFO - 2021-04-13 18:03:29 --> Database Driver Class Initialized
ERROR - 2021-04-13 18:03:29 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 18:03:29 --> Unable to connect to the database
DEBUG - 2021-04-13 18:03:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 18:03:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 18:03:29 --> Form Validation Class Initialized
INFO - 2021-04-13 18:03:29 --> Controller Class Initialized
INFO - 2021-04-13 18:03:29 --> Model Class Initialized
INFO - 2021-04-13 18:03:29 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-04-13 18:03:29 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 391
INFO - 2021-04-13 18:03:35 --> Config Class Initialized
INFO - 2021-04-13 18:03:35 --> Hooks Class Initialized
DEBUG - 2021-04-13 18:03:35 --> UTF-8 Support Enabled
INFO - 2021-04-13 18:03:35 --> Utf8 Class Initialized
INFO - 2021-04-13 18:03:35 --> URI Class Initialized
INFO - 2021-04-13 18:03:35 --> Router Class Initialized
INFO - 2021-04-13 18:03:35 --> Output Class Initialized
INFO - 2021-04-13 18:03:35 --> Security Class Initialized
DEBUG - 2021-04-13 18:03:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 18:03:35 --> Input Class Initialized
INFO - 2021-04-13 18:03:35 --> Language Class Initialized
INFO - 2021-04-13 18:03:35 --> Loader Class Initialized
INFO - 2021-04-13 18:03:35 --> Helper loaded: url_helper
INFO - 2021-04-13 18:03:35 --> Helper loaded: form_helper
INFO - 2021-04-13 18:03:35 --> Helper loaded: common_helper
INFO - 2021-04-13 18:03:35 --> Helper loaded: util_helper
INFO - 2021-04-13 18:03:35 --> Database Driver Class Initialized
ERROR - 2021-04-13 18:03:35 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 18:03:35 --> Unable to connect to the database
DEBUG - 2021-04-13 18:03:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 18:03:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 18:03:35 --> Form Validation Class Initialized
INFO - 2021-04-13 18:03:35 --> Controller Class Initialized
INFO - 2021-04-13 18:03:35 --> Model Class Initialized
INFO - 2021-04-13 18:03:35 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 18:03:35 --> Final output sent to browser
DEBUG - 2021-04-13 18:03:35 --> Total execution time: 0.0405
INFO - 2021-04-13 18:03:47 --> Config Class Initialized
INFO - 2021-04-13 18:03:47 --> Hooks Class Initialized
DEBUG - 2021-04-13 18:03:47 --> UTF-8 Support Enabled
INFO - 2021-04-13 18:03:47 --> Utf8 Class Initialized
INFO - 2021-04-13 18:03:47 --> URI Class Initialized
INFO - 2021-04-13 18:03:47 --> Router Class Initialized
INFO - 2021-04-13 18:03:47 --> Output Class Initialized
INFO - 2021-04-13 18:03:47 --> Security Class Initialized
DEBUG - 2021-04-13 18:03:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 18:03:47 --> Input Class Initialized
INFO - 2021-04-13 18:03:47 --> Language Class Initialized
INFO - 2021-04-13 18:03:47 --> Loader Class Initialized
INFO - 2021-04-13 18:03:47 --> Helper loaded: url_helper
INFO - 2021-04-13 18:03:47 --> Helper loaded: form_helper
INFO - 2021-04-13 18:03:47 --> Helper loaded: common_helper
INFO - 2021-04-13 18:03:47 --> Helper loaded: util_helper
INFO - 2021-04-13 18:03:47 --> Database Driver Class Initialized
ERROR - 2021-04-13 18:03:47 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 18:03:47 --> Unable to connect to the database
DEBUG - 2021-04-13 18:03:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 18:03:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 18:03:47 --> Form Validation Class Initialized
INFO - 2021-04-13 18:03:47 --> Controller Class Initialized
INFO - 2021-04-13 18:03:47 --> Model Class Initialized
INFO - 2021-04-13 18:03:47 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-04-13 18:03:47 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 391
INFO - 2021-04-13 18:03:52 --> Config Class Initialized
INFO - 2021-04-13 18:03:52 --> Hooks Class Initialized
DEBUG - 2021-04-13 18:03:52 --> UTF-8 Support Enabled
INFO - 2021-04-13 18:03:52 --> Utf8 Class Initialized
INFO - 2021-04-13 18:03:52 --> URI Class Initialized
INFO - 2021-04-13 18:03:52 --> Router Class Initialized
INFO - 2021-04-13 18:03:52 --> Output Class Initialized
INFO - 2021-04-13 18:03:52 --> Security Class Initialized
DEBUG - 2021-04-13 18:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 18:03:52 --> Input Class Initialized
INFO - 2021-04-13 18:03:52 --> Language Class Initialized
INFO - 2021-04-13 18:03:52 --> Loader Class Initialized
INFO - 2021-04-13 18:03:52 --> Helper loaded: url_helper
INFO - 2021-04-13 18:03:52 --> Helper loaded: form_helper
INFO - 2021-04-13 18:03:52 --> Helper loaded: common_helper
INFO - 2021-04-13 18:03:52 --> Helper loaded: util_helper
INFO - 2021-04-13 18:03:52 --> Database Driver Class Initialized
ERROR - 2021-04-13 18:03:52 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 18:03:52 --> Unable to connect to the database
DEBUG - 2021-04-13 18:03:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 18:03:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 18:03:52 --> Form Validation Class Initialized
INFO - 2021-04-13 18:03:52 --> Controller Class Initialized
INFO - 2021-04-13 18:03:52 --> Model Class Initialized
INFO - 2021-04-13 18:03:52 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 18:03:52 --> Final output sent to browser
DEBUG - 2021-04-13 18:03:52 --> Total execution time: 0.0398
INFO - 2021-04-13 18:15:35 --> Config Class Initialized
INFO - 2021-04-13 18:15:35 --> Hooks Class Initialized
DEBUG - 2021-04-13 18:15:35 --> UTF-8 Support Enabled
INFO - 2021-04-13 18:15:35 --> Utf8 Class Initialized
INFO - 2021-04-13 18:15:35 --> URI Class Initialized
INFO - 2021-04-13 18:15:35 --> Router Class Initialized
INFO - 2021-04-13 18:15:35 --> Output Class Initialized
INFO - 2021-04-13 18:15:35 --> Security Class Initialized
DEBUG - 2021-04-13 18:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 18:15:35 --> Input Class Initialized
INFO - 2021-04-13 18:15:35 --> Language Class Initialized
INFO - 2021-04-13 18:15:35 --> Loader Class Initialized
INFO - 2021-04-13 18:15:35 --> Helper loaded: url_helper
INFO - 2021-04-13 18:15:35 --> Helper loaded: form_helper
INFO - 2021-04-13 18:15:35 --> Helper loaded: common_helper
INFO - 2021-04-13 18:15:35 --> Helper loaded: util_helper
INFO - 2021-04-13 18:15:35 --> Database Driver Class Initialized
ERROR - 2021-04-13 18:15:35 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 18:15:35 --> Unable to connect to the database
DEBUG - 2021-04-13 18:15:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 18:15:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 18:15:35 --> Form Validation Class Initialized
INFO - 2021-04-13 18:15:35 --> Controller Class Initialized
INFO - 2021-04-13 18:15:35 --> Model Class Initialized
INFO - 2021-04-13 18:15:35 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 18:15:35 --> Final output sent to browser
DEBUG - 2021-04-13 18:15:35 --> Total execution time: 0.0254
INFO - 2021-04-13 18:15:35 --> Config Class Initialized
INFO - 2021-04-13 18:15:35 --> Hooks Class Initialized
INFO - 2021-04-13 18:15:35 --> Config Class Initialized
INFO - 2021-04-13 18:15:35 --> Hooks Class Initialized
DEBUG - 2021-04-13 18:15:35 --> UTF-8 Support Enabled
INFO - 2021-04-13 18:15:35 --> Utf8 Class Initialized
DEBUG - 2021-04-13 18:15:35 --> UTF-8 Support Enabled
INFO - 2021-04-13 18:15:35 --> Utf8 Class Initialized
INFO - 2021-04-13 18:15:35 --> URI Class Initialized
INFO - 2021-04-13 18:15:35 --> URI Class Initialized
INFO - 2021-04-13 18:15:35 --> Router Class Initialized
INFO - 2021-04-13 18:15:35 --> Router Class Initialized
INFO - 2021-04-13 18:15:35 --> Output Class Initialized
INFO - 2021-04-13 18:15:35 --> Output Class Initialized
INFO - 2021-04-13 18:15:35 --> Security Class Initialized
INFO - 2021-04-13 18:15:35 --> Security Class Initialized
DEBUG - 2021-04-13 18:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 18:15:35 --> Input Class Initialized
DEBUG - 2021-04-13 18:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 18:15:35 --> Language Class Initialized
INFO - 2021-04-13 18:15:35 --> Input Class Initialized
ERROR - 2021-04-13 18:15:35 --> 404 Page Not Found: Fasset/img
INFO - 2021-04-13 18:15:35 --> Language Class Initialized
ERROR - 2021-04-13 18:15:35 --> 404 Page Not Found: Fasset/img
INFO - 2021-04-13 18:15:57 --> Config Class Initialized
INFO - 2021-04-13 18:15:57 --> Hooks Class Initialized
DEBUG - 2021-04-13 18:15:57 --> UTF-8 Support Enabled
INFO - 2021-04-13 18:15:57 --> Utf8 Class Initialized
INFO - 2021-04-13 18:15:57 --> URI Class Initialized
INFO - 2021-04-13 18:15:57 --> Router Class Initialized
INFO - 2021-04-13 18:15:57 --> Output Class Initialized
INFO - 2021-04-13 18:15:57 --> Security Class Initialized
DEBUG - 2021-04-13 18:15:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 18:15:57 --> Input Class Initialized
INFO - 2021-04-13 18:15:57 --> Language Class Initialized
INFO - 2021-04-13 18:15:57 --> Loader Class Initialized
INFO - 2021-04-13 18:15:57 --> Helper loaded: url_helper
INFO - 2021-04-13 18:15:57 --> Helper loaded: form_helper
INFO - 2021-04-13 18:15:57 --> Helper loaded: common_helper
INFO - 2021-04-13 18:15:57 --> Helper loaded: util_helper
INFO - 2021-04-13 18:15:57 --> Database Driver Class Initialized
ERROR - 2021-04-13 18:15:57 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 18:15:57 --> Unable to connect to the database
DEBUG - 2021-04-13 18:15:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 18:15:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 18:15:57 --> Form Validation Class Initialized
INFO - 2021-04-13 18:15:57 --> Controller Class Initialized
INFO - 2021-04-13 18:15:57 --> Model Class Initialized
INFO - 2021-04-13 18:15:57 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-04-13 18:15:57 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 391
INFO - 2021-04-13 18:16:03 --> Config Class Initialized
INFO - 2021-04-13 18:16:03 --> Hooks Class Initialized
DEBUG - 2021-04-13 18:16:03 --> UTF-8 Support Enabled
INFO - 2021-04-13 18:16:03 --> Utf8 Class Initialized
INFO - 2021-04-13 18:16:03 --> URI Class Initialized
INFO - 2021-04-13 18:16:03 --> Router Class Initialized
INFO - 2021-04-13 18:16:03 --> Output Class Initialized
INFO - 2021-04-13 18:16:03 --> Security Class Initialized
DEBUG - 2021-04-13 18:16:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 18:16:03 --> Input Class Initialized
INFO - 2021-04-13 18:16:03 --> Language Class Initialized
INFO - 2021-04-13 18:16:03 --> Loader Class Initialized
INFO - 2021-04-13 18:16:03 --> Helper loaded: url_helper
INFO - 2021-04-13 18:16:03 --> Helper loaded: form_helper
INFO - 2021-04-13 18:16:03 --> Helper loaded: common_helper
INFO - 2021-04-13 18:16:03 --> Helper loaded: util_helper
INFO - 2021-04-13 18:16:03 --> Database Driver Class Initialized
ERROR - 2021-04-13 18:16:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 18:16:03 --> Unable to connect to the database
DEBUG - 2021-04-13 18:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 18:16:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 18:16:03 --> Form Validation Class Initialized
INFO - 2021-04-13 18:16:03 --> Controller Class Initialized
INFO - 2021-04-13 18:16:03 --> Model Class Initialized
INFO - 2021-04-13 18:16:03 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 18:16:03 --> Final output sent to browser
DEBUG - 2021-04-13 18:16:03 --> Total execution time: 0.0298
INFO - 2021-04-13 18:16:14 --> Config Class Initialized
INFO - 2021-04-13 18:16:14 --> Hooks Class Initialized
DEBUG - 2021-04-13 18:16:14 --> UTF-8 Support Enabled
INFO - 2021-04-13 18:16:14 --> Utf8 Class Initialized
INFO - 2021-04-13 18:16:14 --> URI Class Initialized
INFO - 2021-04-13 18:16:14 --> Router Class Initialized
INFO - 2021-04-13 18:16:14 --> Output Class Initialized
INFO - 2021-04-13 18:16:14 --> Security Class Initialized
DEBUG - 2021-04-13 18:16:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 18:16:14 --> Input Class Initialized
INFO - 2021-04-13 18:16:14 --> Language Class Initialized
INFO - 2021-04-13 18:16:14 --> Loader Class Initialized
INFO - 2021-04-13 18:16:14 --> Helper loaded: url_helper
INFO - 2021-04-13 18:16:14 --> Helper loaded: form_helper
INFO - 2021-04-13 18:16:14 --> Helper loaded: common_helper
INFO - 2021-04-13 18:16:14 --> Helper loaded: util_helper
INFO - 2021-04-13 18:16:14 --> Database Driver Class Initialized
ERROR - 2021-04-13 18:16:14 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 18:16:14 --> Unable to connect to the database
DEBUG - 2021-04-13 18:16:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 18:16:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 18:16:14 --> Form Validation Class Initialized
INFO - 2021-04-13 18:16:14 --> Controller Class Initialized
INFO - 2021-04-13 18:16:14 --> Model Class Initialized
INFO - 2021-04-13 18:16:14 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 18:16:14 --> Final output sent to browser
DEBUG - 2021-04-13 18:16:14 --> Total execution time: 0.0307
INFO - 2021-04-13 18:17:23 --> Config Class Initialized
INFO - 2021-04-13 18:17:23 --> Hooks Class Initialized
DEBUG - 2021-04-13 18:17:23 --> UTF-8 Support Enabled
INFO - 2021-04-13 18:17:23 --> Utf8 Class Initialized
INFO - 2021-04-13 18:17:23 --> URI Class Initialized
INFO - 2021-04-13 18:17:23 --> Router Class Initialized
INFO - 2021-04-13 18:17:23 --> Output Class Initialized
INFO - 2021-04-13 18:17:23 --> Security Class Initialized
DEBUG - 2021-04-13 18:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 18:17:23 --> Input Class Initialized
INFO - 2021-04-13 18:17:23 --> Language Class Initialized
INFO - 2021-04-13 18:17:23 --> Loader Class Initialized
INFO - 2021-04-13 18:17:23 --> Helper loaded: url_helper
INFO - 2021-04-13 18:17:23 --> Helper loaded: form_helper
INFO - 2021-04-13 18:17:23 --> Helper loaded: common_helper
INFO - 2021-04-13 18:17:23 --> Helper loaded: util_helper
INFO - 2021-04-13 18:17:23 --> Database Driver Class Initialized
ERROR - 2021-04-13 18:17:23 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 18:17:23 --> Unable to connect to the database
DEBUG - 2021-04-13 18:17:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 18:17:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 18:17:23 --> Form Validation Class Initialized
INFO - 2021-04-13 18:17:23 --> Controller Class Initialized
INFO - 2021-04-13 18:17:23 --> Model Class Initialized
INFO - 2021-04-13 18:17:23 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 18:17:23 --> Final output sent to browser
DEBUG - 2021-04-13 18:17:23 --> Total execution time: 0.0263
INFO - 2021-04-13 18:17:23 --> Config Class Initialized
INFO - 2021-04-13 18:17:23 --> Hooks Class Initialized
INFO - 2021-04-13 18:17:23 --> Config Class Initialized
INFO - 2021-04-13 18:17:23 --> Hooks Class Initialized
DEBUG - 2021-04-13 18:17:23 --> UTF-8 Support Enabled
INFO - 2021-04-13 18:17:23 --> Utf8 Class Initialized
DEBUG - 2021-04-13 18:17:23 --> UTF-8 Support Enabled
INFO - 2021-04-13 18:17:23 --> Utf8 Class Initialized
INFO - 2021-04-13 18:17:23 --> URI Class Initialized
INFO - 2021-04-13 18:17:23 --> URI Class Initialized
INFO - 2021-04-13 18:17:23 --> Router Class Initialized
INFO - 2021-04-13 18:17:23 --> Router Class Initialized
INFO - 2021-04-13 18:17:23 --> Output Class Initialized
INFO - 2021-04-13 18:17:23 --> Output Class Initialized
INFO - 2021-04-13 18:17:23 --> Security Class Initialized
INFO - 2021-04-13 18:17:23 --> Security Class Initialized
DEBUG - 2021-04-13 18:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 18:17:23 --> Input Class Initialized
DEBUG - 2021-04-13 18:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 18:17:23 --> Input Class Initialized
INFO - 2021-04-13 18:17:23 --> Language Class Initialized
INFO - 2021-04-13 18:17:23 --> Language Class Initialized
ERROR - 2021-04-13 18:17:23 --> 404 Page Not Found: Fasset/img
ERROR - 2021-04-13 18:17:23 --> 404 Page Not Found: Fasset/img
INFO - 2021-04-13 18:17:56 --> Config Class Initialized
INFO - 2021-04-13 18:17:56 --> Hooks Class Initialized
DEBUG - 2021-04-13 18:17:56 --> UTF-8 Support Enabled
INFO - 2021-04-13 18:17:56 --> Utf8 Class Initialized
INFO - 2021-04-13 18:17:56 --> URI Class Initialized
INFO - 2021-04-13 18:17:56 --> Router Class Initialized
INFO - 2021-04-13 18:17:56 --> Output Class Initialized
INFO - 2021-04-13 18:17:56 --> Security Class Initialized
DEBUG - 2021-04-13 18:17:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 18:17:56 --> Input Class Initialized
INFO - 2021-04-13 18:17:56 --> Language Class Initialized
INFO - 2021-04-13 18:17:56 --> Loader Class Initialized
INFO - 2021-04-13 18:17:56 --> Helper loaded: url_helper
INFO - 2021-04-13 18:17:56 --> Helper loaded: form_helper
INFO - 2021-04-13 18:17:56 --> Helper loaded: common_helper
INFO - 2021-04-13 18:17:56 --> Helper loaded: util_helper
INFO - 2021-04-13 18:17:56 --> Database Driver Class Initialized
ERROR - 2021-04-13 18:17:56 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 18:17:56 --> Unable to connect to the database
DEBUG - 2021-04-13 18:17:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 18:17:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 18:17:56 --> Form Validation Class Initialized
INFO - 2021-04-13 18:17:56 --> Controller Class Initialized
INFO - 2021-04-13 18:17:56 --> Model Class Initialized
INFO - 2021-04-13 18:17:56 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-04-13 18:17:56 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 391
INFO - 2021-04-13 18:17:59 --> Config Class Initialized
INFO - 2021-04-13 18:17:59 --> Hooks Class Initialized
DEBUG - 2021-04-13 18:17:59 --> UTF-8 Support Enabled
INFO - 2021-04-13 18:17:59 --> Utf8 Class Initialized
INFO - 2021-04-13 18:17:59 --> URI Class Initialized
INFO - 2021-04-13 18:17:59 --> Router Class Initialized
INFO - 2021-04-13 18:17:59 --> Output Class Initialized
INFO - 2021-04-13 18:17:59 --> Security Class Initialized
DEBUG - 2021-04-13 18:17:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 18:17:59 --> Input Class Initialized
INFO - 2021-04-13 18:17:59 --> Language Class Initialized
INFO - 2021-04-13 18:17:59 --> Loader Class Initialized
INFO - 2021-04-13 18:17:59 --> Helper loaded: url_helper
INFO - 2021-04-13 18:17:59 --> Helper loaded: form_helper
INFO - 2021-04-13 18:17:59 --> Helper loaded: common_helper
INFO - 2021-04-13 18:17:59 --> Helper loaded: util_helper
INFO - 2021-04-13 18:17:59 --> Database Driver Class Initialized
ERROR - 2021-04-13 18:17:59 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 18:17:59 --> Unable to connect to the database
DEBUG - 2021-04-13 18:17:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 18:17:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 18:17:59 --> Form Validation Class Initialized
INFO - 2021-04-13 18:17:59 --> Controller Class Initialized
INFO - 2021-04-13 18:17:59 --> Model Class Initialized
INFO - 2021-04-13 18:17:59 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 18:17:59 --> Final output sent to browser
DEBUG - 2021-04-13 18:17:59 --> Total execution time: 0.0318
INFO - 2021-04-13 18:19:39 --> Config Class Initialized
INFO - 2021-04-13 18:19:39 --> Hooks Class Initialized
DEBUG - 2021-04-13 18:19:39 --> UTF-8 Support Enabled
INFO - 2021-04-13 18:19:39 --> Utf8 Class Initialized
INFO - 2021-04-13 18:19:39 --> URI Class Initialized
INFO - 2021-04-13 18:19:39 --> Router Class Initialized
INFO - 2021-04-13 18:19:39 --> Output Class Initialized
INFO - 2021-04-13 18:19:39 --> Security Class Initialized
DEBUG - 2021-04-13 18:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 18:19:39 --> Input Class Initialized
INFO - 2021-04-13 18:19:39 --> Language Class Initialized
INFO - 2021-04-13 18:19:39 --> Loader Class Initialized
INFO - 2021-04-13 18:19:39 --> Helper loaded: url_helper
INFO - 2021-04-13 18:19:39 --> Helper loaded: form_helper
INFO - 2021-04-13 18:19:39 --> Helper loaded: common_helper
INFO - 2021-04-13 18:19:39 --> Helper loaded: util_helper
INFO - 2021-04-13 18:19:39 --> Database Driver Class Initialized
ERROR - 2021-04-13 18:19:39 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 18:19:39 --> Unable to connect to the database
DEBUG - 2021-04-13 18:19:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 18:19:39 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 18:19:39 --> Form Validation Class Initialized
INFO - 2021-04-13 18:19:39 --> Controller Class Initialized
INFO - 2021-04-13 18:19:39 --> Model Class Initialized
INFO - 2021-04-13 18:19:39 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 18:19:39 --> Final output sent to browser
DEBUG - 2021-04-13 18:19:39 --> Total execution time: 0.0251
INFO - 2021-04-13 18:19:39 --> Config Class Initialized
INFO - 2021-04-13 18:19:39 --> Config Class Initialized
INFO - 2021-04-13 18:19:39 --> Hooks Class Initialized
INFO - 2021-04-13 18:19:39 --> Hooks Class Initialized
DEBUG - 2021-04-13 18:19:39 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 18:19:39 --> UTF-8 Support Enabled
INFO - 2021-04-13 18:19:39 --> Utf8 Class Initialized
INFO - 2021-04-13 18:19:39 --> Utf8 Class Initialized
INFO - 2021-04-13 18:19:39 --> URI Class Initialized
INFO - 2021-04-13 18:19:39 --> URI Class Initialized
INFO - 2021-04-13 18:19:39 --> Router Class Initialized
INFO - 2021-04-13 18:19:39 --> Router Class Initialized
INFO - 2021-04-13 18:19:39 --> Output Class Initialized
INFO - 2021-04-13 18:19:39 --> Output Class Initialized
INFO - 2021-04-13 18:19:39 --> Security Class Initialized
INFO - 2021-04-13 18:19:39 --> Security Class Initialized
DEBUG - 2021-04-13 18:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 18:19:39 --> Input Class Initialized
DEBUG - 2021-04-13 18:19:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 18:19:39 --> Language Class Initialized
INFO - 2021-04-13 18:19:39 --> Input Class Initialized
INFO - 2021-04-13 18:19:39 --> Language Class Initialized
ERROR - 2021-04-13 18:19:39 --> 404 Page Not Found: Fasset/img
ERROR - 2021-04-13 18:19:39 --> 404 Page Not Found: Fasset/img
INFO - 2021-04-13 18:20:02 --> Config Class Initialized
INFO - 2021-04-13 18:20:02 --> Hooks Class Initialized
DEBUG - 2021-04-13 18:20:02 --> UTF-8 Support Enabled
INFO - 2021-04-13 18:20:02 --> Utf8 Class Initialized
INFO - 2021-04-13 18:20:02 --> URI Class Initialized
INFO - 2021-04-13 18:20:02 --> Router Class Initialized
INFO - 2021-04-13 18:20:02 --> Output Class Initialized
INFO - 2021-04-13 18:20:02 --> Security Class Initialized
DEBUG - 2021-04-13 18:20:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 18:20:02 --> Input Class Initialized
INFO - 2021-04-13 18:20:02 --> Language Class Initialized
INFO - 2021-04-13 18:20:02 --> Loader Class Initialized
INFO - 2021-04-13 18:20:02 --> Helper loaded: url_helper
INFO - 2021-04-13 18:20:02 --> Helper loaded: form_helper
INFO - 2021-04-13 18:20:02 --> Helper loaded: common_helper
INFO - 2021-04-13 18:20:02 --> Helper loaded: util_helper
INFO - 2021-04-13 18:20:02 --> Database Driver Class Initialized
ERROR - 2021-04-13 18:20:02 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 18:20:02 --> Unable to connect to the database
DEBUG - 2021-04-13 18:20:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 18:20:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 18:20:02 --> Form Validation Class Initialized
INFO - 2021-04-13 18:20:02 --> Controller Class Initialized
INFO - 2021-04-13 18:20:02 --> Model Class Initialized
INFO - 2021-04-13 18:20:02 --> Language file loaded: language/english/form_validation_lang.php
ERROR - 2021-04-13 18:20:02 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 391
INFO - 2021-04-13 18:20:09 --> Config Class Initialized
INFO - 2021-04-13 18:20:09 --> Hooks Class Initialized
DEBUG - 2021-04-13 18:20:09 --> UTF-8 Support Enabled
INFO - 2021-04-13 18:20:09 --> Utf8 Class Initialized
INFO - 2021-04-13 18:20:09 --> URI Class Initialized
INFO - 2021-04-13 18:20:09 --> Router Class Initialized
INFO - 2021-04-13 18:20:09 --> Output Class Initialized
INFO - 2021-04-13 18:20:09 --> Security Class Initialized
DEBUG - 2021-04-13 18:20:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 18:20:09 --> Input Class Initialized
INFO - 2021-04-13 18:20:09 --> Language Class Initialized
INFO - 2021-04-13 18:20:09 --> Loader Class Initialized
INFO - 2021-04-13 18:20:09 --> Helper loaded: url_helper
INFO - 2021-04-13 18:20:09 --> Helper loaded: form_helper
INFO - 2021-04-13 18:20:09 --> Helper loaded: common_helper
INFO - 2021-04-13 18:20:09 --> Helper loaded: util_helper
INFO - 2021-04-13 18:20:09 --> Database Driver Class Initialized
ERROR - 2021-04-13 18:20:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 18:20:09 --> Unable to connect to the database
DEBUG - 2021-04-13 18:20:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 18:20:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 18:20:09 --> Form Validation Class Initialized
INFO - 2021-04-13 18:20:09 --> Controller Class Initialized
INFO - 2021-04-13 18:20:09 --> Model Class Initialized
INFO - 2021-04-13 18:20:09 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 18:20:09 --> Final output sent to browser
DEBUG - 2021-04-13 18:20:09 --> Total execution time: 0.0319
INFO - 2021-04-13 19:05:20 --> Config Class Initialized
INFO - 2021-04-13 19:05:20 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:05:20 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:05:20 --> Utf8 Class Initialized
INFO - 2021-04-13 19:05:20 --> URI Class Initialized
INFO - 2021-04-13 19:05:20 --> Router Class Initialized
INFO - 2021-04-13 19:05:20 --> Output Class Initialized
INFO - 2021-04-13 19:05:20 --> Security Class Initialized
DEBUG - 2021-04-13 19:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:05:20 --> Input Class Initialized
INFO - 2021-04-13 19:05:20 --> Language Class Initialized
INFO - 2021-04-13 19:05:20 --> Loader Class Initialized
INFO - 2021-04-13 19:05:20 --> Helper loaded: url_helper
INFO - 2021-04-13 19:05:20 --> Helper loaded: form_helper
INFO - 2021-04-13 19:05:20 --> Helper loaded: common_helper
INFO - 2021-04-13 19:05:20 --> Helper loaded: util_helper
INFO - 2021-04-13 19:05:20 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:05:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:05:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:05:20 --> Form Validation Class Initialized
INFO - 2021-04-13 19:05:20 --> Controller Class Initialized
INFO - 2021-04-13 19:05:20 --> Model Class Initialized
INFO - 2021-04-13 19:05:20 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 19:05:20 --> Final output sent to browser
DEBUG - 2021-04-13 19:05:20 --> Total execution time: 0.0359
INFO - 2021-04-13 19:05:20 --> Config Class Initialized
INFO - 2021-04-13 19:05:20 --> Hooks Class Initialized
INFO - 2021-04-13 19:05:20 --> Config Class Initialized
INFO - 2021-04-13 19:05:20 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:05:20 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:05:20 --> Utf8 Class Initialized
DEBUG - 2021-04-13 19:05:20 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:05:20 --> Utf8 Class Initialized
INFO - 2021-04-13 19:05:20 --> URI Class Initialized
INFO - 2021-04-13 19:05:20 --> URI Class Initialized
INFO - 2021-04-13 19:05:20 --> Router Class Initialized
INFO - 2021-04-13 19:05:20 --> Router Class Initialized
INFO - 2021-04-13 19:05:20 --> Output Class Initialized
INFO - 2021-04-13 19:05:20 --> Output Class Initialized
INFO - 2021-04-13 19:05:20 --> Security Class Initialized
INFO - 2021-04-13 19:05:20 --> Security Class Initialized
DEBUG - 2021-04-13 19:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 19:05:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:05:20 --> Input Class Initialized
INFO - 2021-04-13 19:05:20 --> Input Class Initialized
INFO - 2021-04-13 19:05:20 --> Language Class Initialized
INFO - 2021-04-13 19:05:20 --> Language Class Initialized
ERROR - 2021-04-13 19:05:20 --> 404 Page Not Found: Fasset/img
ERROR - 2021-04-13 19:05:20 --> 404 Page Not Found: Fasset/img
INFO - 2021-04-13 19:05:37 --> Config Class Initialized
INFO - 2021-04-13 19:05:37 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:05:37 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:05:37 --> Utf8 Class Initialized
INFO - 2021-04-13 19:05:37 --> URI Class Initialized
INFO - 2021-04-13 19:05:37 --> Router Class Initialized
INFO - 2021-04-13 19:05:37 --> Output Class Initialized
INFO - 2021-04-13 19:05:37 --> Security Class Initialized
DEBUG - 2021-04-13 19:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:05:37 --> Input Class Initialized
INFO - 2021-04-13 19:05:37 --> Language Class Initialized
INFO - 2021-04-13 19:05:37 --> Loader Class Initialized
INFO - 2021-04-13 19:05:37 --> Helper loaded: url_helper
INFO - 2021-04-13 19:05:37 --> Helper loaded: form_helper
INFO - 2021-04-13 19:05:37 --> Helper loaded: common_helper
INFO - 2021-04-13 19:05:37 --> Helper loaded: util_helper
INFO - 2021-04-13 19:05:37 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:05:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:05:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:05:37 --> Form Validation Class Initialized
INFO - 2021-04-13 19:05:37 --> Controller Class Initialized
INFO - 2021-04-13 19:05:37 --> Model Class Initialized
INFO - 2021-04-13 19:05:37 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-04-13 19:05:37 --> Config Class Initialized
INFO - 2021-04-13 19:05:37 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:05:37 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:05:37 --> Utf8 Class Initialized
INFO - 2021-04-13 19:05:37 --> URI Class Initialized
INFO - 2021-04-13 19:05:37 --> Router Class Initialized
INFO - 2021-04-13 19:05:37 --> Output Class Initialized
INFO - 2021-04-13 19:05:37 --> Security Class Initialized
DEBUG - 2021-04-13 19:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:05:37 --> Input Class Initialized
INFO - 2021-04-13 19:05:37 --> Language Class Initialized
ERROR - 2021-04-13 19:05:37 --> Severity: error --> Exception: syntax error, unexpected '/' C:\xampp1\htdocs\FoodTruck\php\application\controllers\user\Dashboard.php 48
INFO - 2021-04-13 19:07:02 --> Config Class Initialized
INFO - 2021-04-13 19:07:02 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:07:02 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:07:02 --> Utf8 Class Initialized
INFO - 2021-04-13 19:07:02 --> URI Class Initialized
INFO - 2021-04-13 19:07:02 --> Router Class Initialized
INFO - 2021-04-13 19:07:02 --> Output Class Initialized
INFO - 2021-04-13 19:07:02 --> Security Class Initialized
DEBUG - 2021-04-13 19:07:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:07:02 --> Input Class Initialized
INFO - 2021-04-13 19:07:02 --> Language Class Initialized
INFO - 2021-04-13 19:07:02 --> Loader Class Initialized
INFO - 2021-04-13 19:07:02 --> Helper loaded: url_helper
INFO - 2021-04-13 19:07:02 --> Helper loaded: form_helper
INFO - 2021-04-13 19:07:02 --> Helper loaded: common_helper
INFO - 2021-04-13 19:07:02 --> Helper loaded: util_helper
INFO - 2021-04-13 19:07:02 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:07:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:07:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:07:02 --> Form Validation Class Initialized
INFO - 2021-04-13 19:07:02 --> Controller Class Initialized
INFO - 2021-04-13 19:07:02 --> Model Class Initialized
INFO - 2021-04-13 19:07:02 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 19:07:02 --> Final output sent to browser
DEBUG - 2021-04-13 19:07:02 --> Total execution time: 0.0313
INFO - 2021-04-13 19:07:47 --> Config Class Initialized
INFO - 2021-04-13 19:07:47 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:07:47 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:07:47 --> Utf8 Class Initialized
INFO - 2021-04-13 19:07:47 --> URI Class Initialized
INFO - 2021-04-13 19:07:47 --> Router Class Initialized
INFO - 2021-04-13 19:07:47 --> Output Class Initialized
INFO - 2021-04-13 19:07:47 --> Security Class Initialized
DEBUG - 2021-04-13 19:07:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:07:47 --> Input Class Initialized
INFO - 2021-04-13 19:07:47 --> Language Class Initialized
INFO - 2021-04-13 19:07:47 --> Loader Class Initialized
INFO - 2021-04-13 19:07:47 --> Helper loaded: url_helper
INFO - 2021-04-13 19:07:47 --> Helper loaded: form_helper
INFO - 2021-04-13 19:07:47 --> Helper loaded: common_helper
INFO - 2021-04-13 19:07:47 --> Helper loaded: util_helper
INFO - 2021-04-13 19:07:47 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:07:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:07:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:07:47 --> Form Validation Class Initialized
INFO - 2021-04-13 19:07:47 --> Controller Class Initialized
ERROR - 2021-04-13 19:07:47 --> Severity: error --> Exception: Call to a member function login_check() on null C:\xampp1\htdocs\FoodTruck\php\application\controllers\user\Dashboard.php 25
INFO - 2021-04-13 19:07:48 --> Config Class Initialized
INFO - 2021-04-13 19:07:48 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:07:48 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:07:48 --> Utf8 Class Initialized
INFO - 2021-04-13 19:07:48 --> URI Class Initialized
INFO - 2021-04-13 19:07:48 --> Router Class Initialized
INFO - 2021-04-13 19:07:48 --> Output Class Initialized
INFO - 2021-04-13 19:07:48 --> Security Class Initialized
DEBUG - 2021-04-13 19:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:07:48 --> Input Class Initialized
INFO - 2021-04-13 19:07:48 --> Language Class Initialized
INFO - 2021-04-13 19:07:48 --> Loader Class Initialized
INFO - 2021-04-13 19:07:48 --> Helper loaded: url_helper
INFO - 2021-04-13 19:07:48 --> Helper loaded: form_helper
INFO - 2021-04-13 19:07:48 --> Helper loaded: common_helper
INFO - 2021-04-13 19:07:48 --> Helper loaded: util_helper
INFO - 2021-04-13 19:07:48 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:07:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:07:48 --> Form Validation Class Initialized
INFO - 2021-04-13 19:07:48 --> Controller Class Initialized
ERROR - 2021-04-13 19:07:48 --> Severity: error --> Exception: Call to a member function login_check() on null C:\xampp1\htdocs\FoodTruck\php\application\controllers\user\Dashboard.php 25
INFO - 2021-04-13 19:07:48 --> Config Class Initialized
INFO - 2021-04-13 19:07:48 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:07:48 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:07:48 --> Utf8 Class Initialized
INFO - 2021-04-13 19:07:48 --> URI Class Initialized
INFO - 2021-04-13 19:07:48 --> Router Class Initialized
INFO - 2021-04-13 19:07:48 --> Output Class Initialized
INFO - 2021-04-13 19:07:48 --> Security Class Initialized
DEBUG - 2021-04-13 19:07:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:07:48 --> Input Class Initialized
INFO - 2021-04-13 19:07:48 --> Language Class Initialized
INFO - 2021-04-13 19:07:48 --> Loader Class Initialized
INFO - 2021-04-13 19:07:48 --> Helper loaded: url_helper
INFO - 2021-04-13 19:07:48 --> Helper loaded: form_helper
INFO - 2021-04-13 19:07:48 --> Helper loaded: common_helper
INFO - 2021-04-13 19:07:48 --> Helper loaded: util_helper
INFO - 2021-04-13 19:07:48 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:07:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:07:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:07:48 --> Form Validation Class Initialized
INFO - 2021-04-13 19:07:48 --> Controller Class Initialized
ERROR - 2021-04-13 19:07:48 --> Severity: error --> Exception: Call to a member function login_check() on null C:\xampp1\htdocs\FoodTruck\php\application\controllers\user\Dashboard.php 25
INFO - 2021-04-13 19:07:49 --> Config Class Initialized
INFO - 2021-04-13 19:07:49 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:07:49 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:07:49 --> Utf8 Class Initialized
INFO - 2021-04-13 19:07:49 --> URI Class Initialized
INFO - 2021-04-13 19:07:49 --> Router Class Initialized
INFO - 2021-04-13 19:07:49 --> Output Class Initialized
INFO - 2021-04-13 19:07:49 --> Security Class Initialized
DEBUG - 2021-04-13 19:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:07:49 --> Input Class Initialized
INFO - 2021-04-13 19:07:49 --> Language Class Initialized
INFO - 2021-04-13 19:07:49 --> Loader Class Initialized
INFO - 2021-04-13 19:07:49 --> Helper loaded: url_helper
INFO - 2021-04-13 19:07:49 --> Helper loaded: form_helper
INFO - 2021-04-13 19:07:49 --> Helper loaded: common_helper
INFO - 2021-04-13 19:07:49 --> Helper loaded: util_helper
INFO - 2021-04-13 19:07:49 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:07:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:07:49 --> Form Validation Class Initialized
INFO - 2021-04-13 19:07:49 --> Controller Class Initialized
ERROR - 2021-04-13 19:07:49 --> Severity: error --> Exception: Call to a member function login_check() on null C:\xampp1\htdocs\FoodTruck\php\application\controllers\user\Dashboard.php 25
INFO - 2021-04-13 19:07:49 --> Config Class Initialized
INFO - 2021-04-13 19:07:49 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:07:49 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:07:49 --> Utf8 Class Initialized
INFO - 2021-04-13 19:07:49 --> URI Class Initialized
INFO - 2021-04-13 19:07:49 --> Router Class Initialized
INFO - 2021-04-13 19:07:49 --> Output Class Initialized
INFO - 2021-04-13 19:07:49 --> Security Class Initialized
DEBUG - 2021-04-13 19:07:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:07:49 --> Input Class Initialized
INFO - 2021-04-13 19:07:49 --> Language Class Initialized
INFO - 2021-04-13 19:07:49 --> Loader Class Initialized
INFO - 2021-04-13 19:07:49 --> Helper loaded: url_helper
INFO - 2021-04-13 19:07:49 --> Helper loaded: form_helper
INFO - 2021-04-13 19:07:49 --> Helper loaded: common_helper
INFO - 2021-04-13 19:07:49 --> Helper loaded: util_helper
INFO - 2021-04-13 19:07:49 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:07:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:07:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:07:49 --> Form Validation Class Initialized
INFO - 2021-04-13 19:07:49 --> Controller Class Initialized
ERROR - 2021-04-13 19:07:49 --> Severity: error --> Exception: Call to a member function login_check() on null C:\xampp1\htdocs\FoodTruck\php\application\controllers\user\Dashboard.php 25
INFO - 2021-04-13 19:07:51 --> Config Class Initialized
INFO - 2021-04-13 19:07:51 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:07:51 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:07:51 --> Utf8 Class Initialized
INFO - 2021-04-13 19:07:51 --> URI Class Initialized
INFO - 2021-04-13 19:07:51 --> Router Class Initialized
INFO - 2021-04-13 19:07:51 --> Output Class Initialized
INFO - 2021-04-13 19:07:51 --> Security Class Initialized
DEBUG - 2021-04-13 19:07:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:07:51 --> Input Class Initialized
INFO - 2021-04-13 19:07:51 --> Language Class Initialized
INFO - 2021-04-13 19:07:51 --> Loader Class Initialized
INFO - 2021-04-13 19:07:51 --> Helper loaded: url_helper
INFO - 2021-04-13 19:07:51 --> Helper loaded: form_helper
INFO - 2021-04-13 19:07:51 --> Helper loaded: common_helper
INFO - 2021-04-13 19:07:51 --> Helper loaded: util_helper
INFO - 2021-04-13 19:07:51 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:07:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:07:51 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:07:51 --> Form Validation Class Initialized
INFO - 2021-04-13 19:07:51 --> Controller Class Initialized
ERROR - 2021-04-13 19:07:51 --> Severity: error --> Exception: Call to a member function login_check() on null C:\xampp1\htdocs\FoodTruck\php\application\controllers\user\Dashboard.php 25
INFO - 2021-04-13 19:08:11 --> Config Class Initialized
INFO - 2021-04-13 19:08:11 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:08:11 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:08:11 --> Utf8 Class Initialized
INFO - 2021-04-13 19:08:11 --> URI Class Initialized
INFO - 2021-04-13 19:08:11 --> Router Class Initialized
INFO - 2021-04-13 19:08:11 --> Output Class Initialized
INFO - 2021-04-13 19:08:11 --> Security Class Initialized
DEBUG - 2021-04-13 19:08:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:08:11 --> Input Class Initialized
INFO - 2021-04-13 19:08:11 --> Language Class Initialized
INFO - 2021-04-13 19:08:11 --> Loader Class Initialized
INFO - 2021-04-13 19:08:11 --> Helper loaded: url_helper
INFO - 2021-04-13 19:08:11 --> Helper loaded: form_helper
INFO - 2021-04-13 19:08:11 --> Helper loaded: common_helper
INFO - 2021-04-13 19:08:11 --> Helper loaded: util_helper
INFO - 2021-04-13 19:08:11 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:08:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:08:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:08:11 --> Form Validation Class Initialized
INFO - 2021-04-13 19:08:11 --> Controller Class Initialized
INFO - 2021-04-13 19:08:11 --> Model Class Initialized
INFO - 2021-04-13 19:08:11 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 19:08:11 --> Final output sent to browser
DEBUG - 2021-04-13 19:08:11 --> Total execution time: 0.0300
INFO - 2021-04-13 19:08:13 --> Config Class Initialized
INFO - 2021-04-13 19:08:13 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:08:13 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:08:13 --> Utf8 Class Initialized
INFO - 2021-04-13 19:08:13 --> URI Class Initialized
INFO - 2021-04-13 19:08:13 --> Router Class Initialized
INFO - 2021-04-13 19:08:13 --> Output Class Initialized
INFO - 2021-04-13 19:08:13 --> Security Class Initialized
DEBUG - 2021-04-13 19:08:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:08:13 --> Input Class Initialized
INFO - 2021-04-13 19:08:13 --> Language Class Initialized
INFO - 2021-04-13 19:08:13 --> Loader Class Initialized
INFO - 2021-04-13 19:08:13 --> Helper loaded: url_helper
INFO - 2021-04-13 19:08:13 --> Helper loaded: form_helper
INFO - 2021-04-13 19:08:13 --> Helper loaded: common_helper
INFO - 2021-04-13 19:08:13 --> Helper loaded: util_helper
INFO - 2021-04-13 19:08:13 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:08:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:08:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:08:13 --> Form Validation Class Initialized
INFO - 2021-04-13 19:08:13 --> Controller Class Initialized
INFO - 2021-04-13 19:08:13 --> Model Class Initialized
INFO - 2021-04-13 19:08:13 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 19:08:13 --> Final output sent to browser
DEBUG - 2021-04-13 19:08:13 --> Total execution time: 0.0243
INFO - 2021-04-13 19:08:34 --> Config Class Initialized
INFO - 2021-04-13 19:08:34 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:08:34 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:08:34 --> Utf8 Class Initialized
INFO - 2021-04-13 19:08:34 --> URI Class Initialized
INFO - 2021-04-13 19:08:34 --> Router Class Initialized
INFO - 2021-04-13 19:08:34 --> Output Class Initialized
INFO - 2021-04-13 19:08:34 --> Security Class Initialized
DEBUG - 2021-04-13 19:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:08:34 --> Input Class Initialized
INFO - 2021-04-13 19:08:34 --> Language Class Initialized
INFO - 2021-04-13 19:08:34 --> Loader Class Initialized
INFO - 2021-04-13 19:08:34 --> Helper loaded: url_helper
INFO - 2021-04-13 19:08:34 --> Helper loaded: form_helper
INFO - 2021-04-13 19:08:34 --> Helper loaded: common_helper
INFO - 2021-04-13 19:08:34 --> Helper loaded: util_helper
INFO - 2021-04-13 19:08:34 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:08:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:08:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:08:34 --> Form Validation Class Initialized
INFO - 2021-04-13 19:08:34 --> Controller Class Initialized
INFO - 2021-04-13 19:08:34 --> Model Class Initialized
INFO - 2021-04-13 19:08:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-04-13 19:08:34 --> Config Class Initialized
INFO - 2021-04-13 19:08:34 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:08:34 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:08:34 --> Utf8 Class Initialized
INFO - 2021-04-13 19:08:34 --> URI Class Initialized
INFO - 2021-04-13 19:08:34 --> Router Class Initialized
INFO - 2021-04-13 19:08:34 --> Output Class Initialized
INFO - 2021-04-13 19:08:34 --> Security Class Initialized
DEBUG - 2021-04-13 19:08:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:08:34 --> Input Class Initialized
INFO - 2021-04-13 19:08:34 --> Language Class Initialized
ERROR - 2021-04-13 19:08:34 --> 404 Page Not Found: user/Dashboard/index
INFO - 2021-04-13 19:08:54 --> Config Class Initialized
INFO - 2021-04-13 19:08:54 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:08:54 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:08:54 --> Utf8 Class Initialized
INFO - 2021-04-13 19:08:54 --> URI Class Initialized
INFO - 2021-04-13 19:08:54 --> Router Class Initialized
INFO - 2021-04-13 19:08:54 --> Output Class Initialized
INFO - 2021-04-13 19:08:54 --> Security Class Initialized
DEBUG - 2021-04-13 19:08:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:08:54 --> Input Class Initialized
INFO - 2021-04-13 19:08:54 --> Language Class Initialized
ERROR - 2021-04-13 19:08:54 --> Severity: error --> Exception: syntax error, unexpected '/' C:\xampp1\htdocs\FoodTruck\php\application\controllers\user\Dashboard.php 48
INFO - 2021-04-13 19:11:35 --> Config Class Initialized
INFO - 2021-04-13 19:11:35 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:11:35 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:11:35 --> Utf8 Class Initialized
INFO - 2021-04-13 19:11:35 --> URI Class Initialized
INFO - 2021-04-13 19:11:35 --> Router Class Initialized
INFO - 2021-04-13 19:11:35 --> Output Class Initialized
INFO - 2021-04-13 19:11:35 --> Security Class Initialized
DEBUG - 2021-04-13 19:11:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:11:35 --> Input Class Initialized
INFO - 2021-04-13 19:11:35 --> Language Class Initialized
ERROR - 2021-04-13 19:11:35 --> Severity: error --> Exception: syntax error, unexpected '/' C:\xampp1\htdocs\FoodTruck\php\application\controllers\user\Dashboard.php 48
INFO - 2021-04-13 19:11:37 --> Config Class Initialized
INFO - 2021-04-13 19:11:37 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:11:37 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:11:37 --> Utf8 Class Initialized
INFO - 2021-04-13 19:11:37 --> URI Class Initialized
INFO - 2021-04-13 19:11:37 --> Router Class Initialized
INFO - 2021-04-13 19:11:37 --> Output Class Initialized
INFO - 2021-04-13 19:11:37 --> Security Class Initialized
DEBUG - 2021-04-13 19:11:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:11:37 --> Input Class Initialized
INFO - 2021-04-13 19:11:37 --> Language Class Initialized
INFO - 2021-04-13 19:11:37 --> Loader Class Initialized
INFO - 2021-04-13 19:11:37 --> Helper loaded: url_helper
INFO - 2021-04-13 19:11:37 --> Helper loaded: form_helper
INFO - 2021-04-13 19:11:37 --> Helper loaded: common_helper
INFO - 2021-04-13 19:11:37 --> Helper loaded: util_helper
INFO - 2021-04-13 19:11:37 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:11:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:11:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:11:37 --> Form Validation Class Initialized
INFO - 2021-04-13 19:11:37 --> Controller Class Initialized
INFO - 2021-04-13 19:11:37 --> Model Class Initialized
INFO - 2021-04-13 19:11:37 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 19:11:37 --> Final output sent to browser
DEBUG - 2021-04-13 19:11:37 --> Total execution time: 0.0407
INFO - 2021-04-13 19:12:01 --> Config Class Initialized
INFO - 2021-04-13 19:12:01 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:12:01 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:12:01 --> Utf8 Class Initialized
INFO - 2021-04-13 19:12:01 --> URI Class Initialized
INFO - 2021-04-13 19:12:01 --> Router Class Initialized
INFO - 2021-04-13 19:12:01 --> Output Class Initialized
INFO - 2021-04-13 19:12:01 --> Security Class Initialized
DEBUG - 2021-04-13 19:12:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:12:01 --> Input Class Initialized
INFO - 2021-04-13 19:12:01 --> Language Class Initialized
INFO - 2021-04-13 19:12:01 --> Loader Class Initialized
INFO - 2021-04-13 19:12:01 --> Helper loaded: url_helper
INFO - 2021-04-13 19:12:01 --> Helper loaded: form_helper
INFO - 2021-04-13 19:12:01 --> Helper loaded: common_helper
INFO - 2021-04-13 19:12:01 --> Helper loaded: util_helper
INFO - 2021-04-13 19:12:01 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:12:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:12:01 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:12:01 --> Form Validation Class Initialized
INFO - 2021-04-13 19:12:01 --> Controller Class Initialized
INFO - 2021-04-13 19:12:01 --> Model Class Initialized
INFO - 2021-04-13 19:12:01 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-04-13 19:12:02 --> Config Class Initialized
INFO - 2021-04-13 19:12:02 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:12:02 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:12:02 --> Utf8 Class Initialized
INFO - 2021-04-13 19:12:02 --> URI Class Initialized
INFO - 2021-04-13 19:12:02 --> Router Class Initialized
INFO - 2021-04-13 19:12:02 --> Output Class Initialized
INFO - 2021-04-13 19:12:02 --> Security Class Initialized
DEBUG - 2021-04-13 19:12:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:12:02 --> Input Class Initialized
INFO - 2021-04-13 19:12:02 --> Language Class Initialized
INFO - 2021-04-13 19:12:02 --> Loader Class Initialized
INFO - 2021-04-13 19:12:02 --> Helper loaded: url_helper
INFO - 2021-04-13 19:12:02 --> Helper loaded: form_helper
INFO - 2021-04-13 19:12:02 --> Helper loaded: common_helper
INFO - 2021-04-13 19:12:02 --> Helper loaded: util_helper
INFO - 2021-04-13 19:12:02 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:12:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:12:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:12:02 --> Form Validation Class Initialized
INFO - 2021-04-13 19:12:02 --> Controller Class Initialized
INFO - 2021-04-13 19:12:02 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-13 19:12:02 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 19:12:02 --> Final output sent to browser
DEBUG - 2021-04-13 19:12:02 --> Total execution time: 0.0270
INFO - 2021-04-13 19:12:07 --> Config Class Initialized
INFO - 2021-04-13 19:12:07 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:12:07 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:12:07 --> Utf8 Class Initialized
INFO - 2021-04-13 19:12:07 --> URI Class Initialized
INFO - 2021-04-13 19:12:07 --> Router Class Initialized
INFO - 2021-04-13 19:12:07 --> Output Class Initialized
INFO - 2021-04-13 19:12:07 --> Security Class Initialized
DEBUG - 2021-04-13 19:12:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:12:07 --> Input Class Initialized
INFO - 2021-04-13 19:12:07 --> Language Class Initialized
INFO - 2021-04-13 19:12:07 --> Loader Class Initialized
INFO - 2021-04-13 19:12:07 --> Helper loaded: url_helper
INFO - 2021-04-13 19:12:07 --> Helper loaded: form_helper
INFO - 2021-04-13 19:12:07 --> Helper loaded: common_helper
INFO - 2021-04-13 19:12:07 --> Helper loaded: util_helper
INFO - 2021-04-13 19:12:07 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:12:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:12:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:12:07 --> Form Validation Class Initialized
INFO - 2021-04-13 19:12:07 --> Controller Class Initialized
INFO - 2021-04-13 19:12:07 --> Model Class Initialized
INFO - 2021-04-13 19:12:07 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 19:12:07 --> Final output sent to browser
DEBUG - 2021-04-13 19:12:07 --> Total execution time: 0.0251
INFO - 2021-04-13 19:15:12 --> Config Class Initialized
INFO - 2021-04-13 19:15:12 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:15:12 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:15:12 --> Utf8 Class Initialized
INFO - 2021-04-13 19:15:12 --> URI Class Initialized
INFO - 2021-04-13 19:15:12 --> Router Class Initialized
INFO - 2021-04-13 19:15:12 --> Output Class Initialized
INFO - 2021-04-13 19:15:12 --> Security Class Initialized
DEBUG - 2021-04-13 19:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:15:12 --> Input Class Initialized
INFO - 2021-04-13 19:15:12 --> Language Class Initialized
INFO - 2021-04-13 19:15:12 --> Loader Class Initialized
INFO - 2021-04-13 19:15:12 --> Helper loaded: url_helper
INFO - 2021-04-13 19:15:12 --> Helper loaded: form_helper
INFO - 2021-04-13 19:15:12 --> Helper loaded: common_helper
INFO - 2021-04-13 19:15:12 --> Helper loaded: util_helper
INFO - 2021-04-13 19:15:12 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:15:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:15:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:15:12 --> Form Validation Class Initialized
INFO - 2021-04-13 19:15:12 --> Controller Class Initialized
INFO - 2021-04-13 19:15:12 --> Model Class Initialized
INFO - 2021-04-13 19:15:12 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 19:15:12 --> Final output sent to browser
DEBUG - 2021-04-13 19:15:12 --> Total execution time: 0.0349
INFO - 2021-04-13 19:15:12 --> Config Class Initialized
INFO - 2021-04-13 19:15:12 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:15:12 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:15:12 --> Utf8 Class Initialized
INFO - 2021-04-13 19:15:12 --> Config Class Initialized
INFO - 2021-04-13 19:15:12 --> Hooks Class Initialized
INFO - 2021-04-13 19:15:12 --> URI Class Initialized
INFO - 2021-04-13 19:15:12 --> Router Class Initialized
DEBUG - 2021-04-13 19:15:12 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:15:12 --> Output Class Initialized
INFO - 2021-04-13 19:15:12 --> Utf8 Class Initialized
INFO - 2021-04-13 19:15:12 --> Security Class Initialized
INFO - 2021-04-13 19:15:12 --> URI Class Initialized
DEBUG - 2021-04-13 19:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:15:12 --> Input Class Initialized
INFO - 2021-04-13 19:15:12 --> Router Class Initialized
INFO - 2021-04-13 19:15:12 --> Language Class Initialized
INFO - 2021-04-13 19:15:12 --> Output Class Initialized
ERROR - 2021-04-13 19:15:12 --> 404 Page Not Found: Fasset/img
INFO - 2021-04-13 19:15:12 --> Security Class Initialized
DEBUG - 2021-04-13 19:15:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:15:12 --> Input Class Initialized
INFO - 2021-04-13 19:15:12 --> Language Class Initialized
ERROR - 2021-04-13 19:15:12 --> 404 Page Not Found: Fasset/img
INFO - 2021-04-13 19:15:29 --> Config Class Initialized
INFO - 2021-04-13 19:15:29 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:15:29 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:15:29 --> Utf8 Class Initialized
INFO - 2021-04-13 19:15:29 --> URI Class Initialized
INFO - 2021-04-13 19:15:29 --> Router Class Initialized
INFO - 2021-04-13 19:15:29 --> Output Class Initialized
INFO - 2021-04-13 19:15:29 --> Security Class Initialized
DEBUG - 2021-04-13 19:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:15:29 --> Input Class Initialized
INFO - 2021-04-13 19:15:29 --> Language Class Initialized
INFO - 2021-04-13 19:15:29 --> Loader Class Initialized
INFO - 2021-04-13 19:15:29 --> Helper loaded: url_helper
INFO - 2021-04-13 19:15:29 --> Helper loaded: form_helper
INFO - 2021-04-13 19:15:29 --> Helper loaded: common_helper
INFO - 2021-04-13 19:15:29 --> Helper loaded: util_helper
INFO - 2021-04-13 19:15:29 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:15:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:15:29 --> Form Validation Class Initialized
INFO - 2021-04-13 19:15:29 --> Controller Class Initialized
INFO - 2021-04-13 19:15:29 --> Model Class Initialized
INFO - 2021-04-13 19:15:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-04-13 19:15:29 --> Config Class Initialized
INFO - 2021-04-13 19:15:29 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:15:29 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:15:29 --> Utf8 Class Initialized
INFO - 2021-04-13 19:15:29 --> URI Class Initialized
INFO - 2021-04-13 19:15:29 --> Router Class Initialized
INFO - 2021-04-13 19:15:29 --> Output Class Initialized
INFO - 2021-04-13 19:15:29 --> Security Class Initialized
DEBUG - 2021-04-13 19:15:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:15:29 --> Input Class Initialized
INFO - 2021-04-13 19:15:29 --> Language Class Initialized
ERROR - 2021-04-13 19:15:29 --> Severity: error --> Exception: syntax error, unexpected '/' C:\xampp1\htdocs\FoodTruck\php\application\controllers\user\Dashboard.php 48
INFO - 2021-04-13 19:15:35 --> Config Class Initialized
INFO - 2021-04-13 19:15:35 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:15:35 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:15:35 --> Utf8 Class Initialized
INFO - 2021-04-13 19:15:35 --> URI Class Initialized
INFO - 2021-04-13 19:15:35 --> Router Class Initialized
INFO - 2021-04-13 19:15:35 --> Output Class Initialized
INFO - 2021-04-13 19:15:35 --> Security Class Initialized
DEBUG - 2021-04-13 19:15:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:15:35 --> Input Class Initialized
INFO - 2021-04-13 19:15:35 --> Language Class Initialized
INFO - 2021-04-13 19:15:35 --> Loader Class Initialized
INFO - 2021-04-13 19:15:35 --> Helper loaded: url_helper
INFO - 2021-04-13 19:15:35 --> Helper loaded: form_helper
INFO - 2021-04-13 19:15:35 --> Helper loaded: common_helper
INFO - 2021-04-13 19:15:35 --> Helper loaded: util_helper
INFO - 2021-04-13 19:15:35 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:15:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:15:35 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:15:35 --> Form Validation Class Initialized
INFO - 2021-04-13 19:15:35 --> Controller Class Initialized
INFO - 2021-04-13 19:15:35 --> Model Class Initialized
INFO - 2021-04-13 19:15:35 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 19:15:35 --> Final output sent to browser
DEBUG - 2021-04-13 19:15:35 --> Total execution time: 0.0307
INFO - 2021-04-13 19:17:34 --> Config Class Initialized
INFO - 2021-04-13 19:17:34 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:17:34 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:17:34 --> Utf8 Class Initialized
INFO - 2021-04-13 19:17:34 --> URI Class Initialized
INFO - 2021-04-13 19:17:34 --> Router Class Initialized
INFO - 2021-04-13 19:17:34 --> Output Class Initialized
INFO - 2021-04-13 19:17:34 --> Security Class Initialized
DEBUG - 2021-04-13 19:17:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:17:34 --> Input Class Initialized
INFO - 2021-04-13 19:17:34 --> Language Class Initialized
INFO - 2021-04-13 19:17:34 --> Loader Class Initialized
INFO - 2021-04-13 19:17:34 --> Helper loaded: url_helper
INFO - 2021-04-13 19:17:34 --> Helper loaded: form_helper
INFO - 2021-04-13 19:17:34 --> Helper loaded: common_helper
INFO - 2021-04-13 19:17:34 --> Helper loaded: util_helper
INFO - 2021-04-13 19:17:34 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:17:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:17:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:17:34 --> Form Validation Class Initialized
INFO - 2021-04-13 19:17:34 --> Controller Class Initialized
INFO - 2021-04-13 19:23:30 --> Config Class Initialized
INFO - 2021-04-13 19:23:30 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:23:30 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:23:30 --> Utf8 Class Initialized
INFO - 2021-04-13 19:23:30 --> URI Class Initialized
INFO - 2021-04-13 19:23:30 --> Router Class Initialized
INFO - 2021-04-13 19:23:30 --> Output Class Initialized
INFO - 2021-04-13 19:23:30 --> Security Class Initialized
DEBUG - 2021-04-13 19:23:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:23:30 --> Input Class Initialized
INFO - 2021-04-13 19:23:30 --> Language Class Initialized
INFO - 2021-04-13 19:23:30 --> Loader Class Initialized
INFO - 2021-04-13 19:23:30 --> Helper loaded: url_helper
INFO - 2021-04-13 19:23:30 --> Helper loaded: form_helper
INFO - 2021-04-13 19:23:30 --> Helper loaded: common_helper
INFO - 2021-04-13 19:23:30 --> Helper loaded: util_helper
INFO - 2021-04-13 19:23:30 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:23:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:23:30 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:23:31 --> Form Validation Class Initialized
INFO - 2021-04-13 19:23:31 --> Controller Class Initialized
INFO - 2021-04-13 19:25:50 --> Config Class Initialized
INFO - 2021-04-13 19:25:50 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:25:50 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:25:50 --> Utf8 Class Initialized
INFO - 2021-04-13 19:25:50 --> URI Class Initialized
INFO - 2021-04-13 19:25:50 --> Router Class Initialized
INFO - 2021-04-13 19:25:50 --> Output Class Initialized
INFO - 2021-04-13 19:25:50 --> Security Class Initialized
DEBUG - 2021-04-13 19:25:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:25:50 --> Input Class Initialized
INFO - 2021-04-13 19:25:50 --> Language Class Initialized
INFO - 2021-04-13 19:25:50 --> Loader Class Initialized
INFO - 2021-04-13 19:25:50 --> Helper loaded: url_helper
INFO - 2021-04-13 19:25:50 --> Helper loaded: form_helper
INFO - 2021-04-13 19:25:50 --> Helper loaded: common_helper
INFO - 2021-04-13 19:25:50 --> Helper loaded: util_helper
INFO - 2021-04-13 19:25:50 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:25:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:25:50 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:25:50 --> Form Validation Class Initialized
INFO - 2021-04-13 19:25:50 --> Controller Class Initialized
INFO - 2021-04-13 19:25:50 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-13 19:25:50 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 19:25:50 --> Final output sent to browser
DEBUG - 2021-04-13 19:25:50 --> Total execution time: 0.0344
INFO - 2021-04-13 19:26:28 --> Config Class Initialized
INFO - 2021-04-13 19:26:28 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:26:28 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:26:28 --> Utf8 Class Initialized
INFO - 2021-04-13 19:26:28 --> URI Class Initialized
INFO - 2021-04-13 19:26:28 --> Router Class Initialized
INFO - 2021-04-13 19:26:28 --> Output Class Initialized
INFO - 2021-04-13 19:26:28 --> Security Class Initialized
DEBUG - 2021-04-13 19:26:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:26:28 --> Input Class Initialized
INFO - 2021-04-13 19:26:28 --> Language Class Initialized
INFO - 2021-04-13 19:26:28 --> Loader Class Initialized
INFO - 2021-04-13 19:26:28 --> Helper loaded: url_helper
INFO - 2021-04-13 19:26:28 --> Helper loaded: form_helper
INFO - 2021-04-13 19:26:28 --> Helper loaded: common_helper
INFO - 2021-04-13 19:26:28 --> Helper loaded: util_helper
INFO - 2021-04-13 19:26:28 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:26:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:26:28 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:26:28 --> Form Validation Class Initialized
INFO - 2021-04-13 19:26:28 --> Controller Class Initialized
INFO - 2021-04-13 19:26:28 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-13 19:26:28 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 19:26:28 --> Final output sent to browser
DEBUG - 2021-04-13 19:26:28 --> Total execution time: 0.0240
INFO - 2021-04-13 19:26:58 --> Config Class Initialized
INFO - 2021-04-13 19:26:58 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:26:58 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:26:58 --> Utf8 Class Initialized
INFO - 2021-04-13 19:26:58 --> URI Class Initialized
INFO - 2021-04-13 19:26:58 --> Router Class Initialized
INFO - 2021-04-13 19:26:58 --> Output Class Initialized
INFO - 2021-04-13 19:26:58 --> Security Class Initialized
DEBUG - 2021-04-13 19:26:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:26:58 --> Input Class Initialized
INFO - 2021-04-13 19:26:58 --> Language Class Initialized
INFO - 2021-04-13 19:26:58 --> Loader Class Initialized
INFO - 2021-04-13 19:26:58 --> Helper loaded: url_helper
INFO - 2021-04-13 19:26:58 --> Helper loaded: form_helper
INFO - 2021-04-13 19:26:58 --> Helper loaded: common_helper
INFO - 2021-04-13 19:26:58 --> Helper loaded: util_helper
INFO - 2021-04-13 19:26:58 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:26:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:26:58 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:26:58 --> Form Validation Class Initialized
INFO - 2021-04-13 19:26:58 --> Controller Class Initialized
INFO - 2021-04-13 19:26:58 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-13 19:26:58 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 19:26:58 --> Final output sent to browser
DEBUG - 2021-04-13 19:26:58 --> Total execution time: 0.0241
INFO - 2021-04-13 19:28:33 --> Config Class Initialized
INFO - 2021-04-13 19:28:33 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:28:33 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:28:33 --> Utf8 Class Initialized
INFO - 2021-04-13 19:28:33 --> URI Class Initialized
INFO - 2021-04-13 19:28:33 --> Router Class Initialized
INFO - 2021-04-13 19:28:33 --> Output Class Initialized
INFO - 2021-04-13 19:28:33 --> Security Class Initialized
DEBUG - 2021-04-13 19:28:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:28:33 --> Input Class Initialized
INFO - 2021-04-13 19:28:33 --> Language Class Initialized
INFO - 2021-04-13 19:28:33 --> Loader Class Initialized
INFO - 2021-04-13 19:28:33 --> Helper loaded: url_helper
INFO - 2021-04-13 19:28:33 --> Helper loaded: form_helper
INFO - 2021-04-13 19:28:33 --> Helper loaded: common_helper
INFO - 2021-04-13 19:28:33 --> Helper loaded: util_helper
INFO - 2021-04-13 19:28:33 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:28:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:28:33 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:28:33 --> Form Validation Class Initialized
INFO - 2021-04-13 19:28:33 --> Controller Class Initialized
INFO - 2021-04-13 19:29:02 --> Config Class Initialized
INFO - 2021-04-13 19:29:02 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:29:02 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:29:02 --> Utf8 Class Initialized
INFO - 2021-04-13 19:29:02 --> URI Class Initialized
INFO - 2021-04-13 19:29:02 --> Router Class Initialized
INFO - 2021-04-13 19:29:02 --> Output Class Initialized
INFO - 2021-04-13 19:29:02 --> Security Class Initialized
DEBUG - 2021-04-13 19:29:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:29:02 --> Input Class Initialized
INFO - 2021-04-13 19:29:02 --> Language Class Initialized
INFO - 2021-04-13 19:29:02 --> Loader Class Initialized
INFO - 2021-04-13 19:29:02 --> Helper loaded: url_helper
INFO - 2021-04-13 19:29:02 --> Helper loaded: form_helper
INFO - 2021-04-13 19:29:02 --> Helper loaded: common_helper
INFO - 2021-04-13 19:29:02 --> Helper loaded: util_helper
INFO - 2021-04-13 19:29:02 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:29:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:29:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:29:02 --> Form Validation Class Initialized
INFO - 2021-04-13 19:29:02 --> Controller Class Initialized
INFO - 2021-04-13 19:29:03 --> Config Class Initialized
INFO - 2021-04-13 19:29:03 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:29:03 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:29:03 --> Utf8 Class Initialized
INFO - 2021-04-13 19:29:03 --> URI Class Initialized
INFO - 2021-04-13 19:29:03 --> Router Class Initialized
INFO - 2021-04-13 19:29:03 --> Output Class Initialized
INFO - 2021-04-13 19:29:03 --> Security Class Initialized
DEBUG - 2021-04-13 19:29:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:29:03 --> Input Class Initialized
INFO - 2021-04-13 19:29:03 --> Language Class Initialized
INFO - 2021-04-13 19:29:03 --> Loader Class Initialized
INFO - 2021-04-13 19:29:03 --> Helper loaded: url_helper
INFO - 2021-04-13 19:29:03 --> Helper loaded: form_helper
INFO - 2021-04-13 19:29:03 --> Helper loaded: common_helper
INFO - 2021-04-13 19:29:03 --> Helper loaded: util_helper
INFO - 2021-04-13 19:29:03 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:29:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:29:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:29:03 --> Form Validation Class Initialized
INFO - 2021-04-13 19:29:03 --> Controller Class Initialized
INFO - 2021-04-13 19:29:05 --> Config Class Initialized
INFO - 2021-04-13 19:29:05 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:29:05 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:29:05 --> Utf8 Class Initialized
INFO - 2021-04-13 19:29:05 --> URI Class Initialized
INFO - 2021-04-13 19:29:05 --> Router Class Initialized
INFO - 2021-04-13 19:29:05 --> Output Class Initialized
INFO - 2021-04-13 19:29:05 --> Security Class Initialized
DEBUG - 2021-04-13 19:29:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:29:05 --> Input Class Initialized
INFO - 2021-04-13 19:29:05 --> Language Class Initialized
INFO - 2021-04-13 19:29:05 --> Loader Class Initialized
INFO - 2021-04-13 19:29:05 --> Helper loaded: url_helper
INFO - 2021-04-13 19:29:05 --> Helper loaded: form_helper
INFO - 2021-04-13 19:29:05 --> Helper loaded: common_helper
INFO - 2021-04-13 19:29:05 --> Helper loaded: util_helper
INFO - 2021-04-13 19:29:05 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:29:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:29:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:29:05 --> Form Validation Class Initialized
INFO - 2021-04-13 19:29:05 --> Controller Class Initialized
INFO - 2021-04-13 19:29:19 --> Config Class Initialized
INFO - 2021-04-13 19:29:19 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:29:19 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:29:19 --> Utf8 Class Initialized
INFO - 2021-04-13 19:29:19 --> URI Class Initialized
INFO - 2021-04-13 19:29:19 --> Router Class Initialized
INFO - 2021-04-13 19:29:19 --> Output Class Initialized
INFO - 2021-04-13 19:29:19 --> Security Class Initialized
DEBUG - 2021-04-13 19:29:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:29:19 --> Input Class Initialized
INFO - 2021-04-13 19:29:19 --> Language Class Initialized
INFO - 2021-04-13 19:29:19 --> Loader Class Initialized
INFO - 2021-04-13 19:29:19 --> Helper loaded: url_helper
INFO - 2021-04-13 19:29:19 --> Helper loaded: form_helper
INFO - 2021-04-13 19:29:19 --> Helper loaded: common_helper
INFO - 2021-04-13 19:29:19 --> Helper loaded: util_helper
INFO - 2021-04-13 19:29:19 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:29:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:29:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:29:19 --> Form Validation Class Initialized
INFO - 2021-04-13 19:29:19 --> Controller Class Initialized
INFO - 2021-04-13 19:29:49 --> Config Class Initialized
INFO - 2021-04-13 19:29:49 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:29:49 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:29:49 --> Utf8 Class Initialized
INFO - 2021-04-13 19:29:49 --> URI Class Initialized
INFO - 2021-04-13 19:29:49 --> Router Class Initialized
INFO - 2021-04-13 19:29:49 --> Output Class Initialized
INFO - 2021-04-13 19:29:49 --> Security Class Initialized
DEBUG - 2021-04-13 19:29:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:29:49 --> Input Class Initialized
INFO - 2021-04-13 19:29:49 --> Language Class Initialized
INFO - 2021-04-13 19:29:49 --> Loader Class Initialized
INFO - 2021-04-13 19:29:49 --> Helper loaded: url_helper
INFO - 2021-04-13 19:29:49 --> Helper loaded: form_helper
INFO - 2021-04-13 19:29:49 --> Helper loaded: common_helper
INFO - 2021-04-13 19:29:49 --> Helper loaded: util_helper
INFO - 2021-04-13 19:29:49 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:29:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:29:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:29:49 --> Form Validation Class Initialized
INFO - 2021-04-13 19:29:49 --> Controller Class Initialized
INFO - 2021-04-13 19:29:49 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-13 19:29:49 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 19:29:49 --> Final output sent to browser
DEBUG - 2021-04-13 19:29:49 --> Total execution time: 0.0240
INFO - 2021-04-13 19:30:03 --> Config Class Initialized
INFO - 2021-04-13 19:30:03 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:30:03 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:30:03 --> Utf8 Class Initialized
INFO - 2021-04-13 19:30:03 --> URI Class Initialized
INFO - 2021-04-13 19:30:03 --> Router Class Initialized
INFO - 2021-04-13 19:30:03 --> Output Class Initialized
INFO - 2021-04-13 19:30:03 --> Security Class Initialized
DEBUG - 2021-04-13 19:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:30:03 --> Input Class Initialized
INFO - 2021-04-13 19:30:03 --> Language Class Initialized
INFO - 2021-04-13 19:30:03 --> Loader Class Initialized
INFO - 2021-04-13 19:30:03 --> Helper loaded: url_helper
INFO - 2021-04-13 19:30:03 --> Helper loaded: form_helper
INFO - 2021-04-13 19:30:03 --> Helper loaded: common_helper
INFO - 2021-04-13 19:30:03 --> Helper loaded: util_helper
INFO - 2021-04-13 19:30:03 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:30:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:30:03 --> Form Validation Class Initialized
INFO - 2021-04-13 19:30:03 --> Controller Class Initialized
INFO - 2021-04-13 19:30:03 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-13 19:30:03 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 19:30:03 --> Final output sent to browser
DEBUG - 2021-04-13 19:30:03 --> Total execution time: 0.0255
INFO - 2021-04-13 19:30:03 --> Config Class Initialized
INFO - 2021-04-13 19:30:03 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:30:03 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:30:03 --> Utf8 Class Initialized
INFO - 2021-04-13 19:30:03 --> URI Class Initialized
INFO - 2021-04-13 19:30:03 --> Router Class Initialized
INFO - 2021-04-13 19:30:03 --> Output Class Initialized
INFO - 2021-04-13 19:30:03 --> Security Class Initialized
DEBUG - 2021-04-13 19:30:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:30:03 --> Input Class Initialized
INFO - 2021-04-13 19:30:03 --> Language Class Initialized
INFO - 2021-04-13 19:30:03 --> Loader Class Initialized
INFO - 2021-04-13 19:30:03 --> Helper loaded: url_helper
INFO - 2021-04-13 19:30:03 --> Helper loaded: form_helper
INFO - 2021-04-13 19:30:03 --> Helper loaded: common_helper
INFO - 2021-04-13 19:30:03 --> Helper loaded: util_helper
INFO - 2021-04-13 19:30:03 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:30:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:30:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:30:03 --> Form Validation Class Initialized
INFO - 2021-04-13 19:30:03 --> Controller Class Initialized
INFO - 2021-04-13 19:30:03 --> Model Class Initialized
INFO - 2021-04-13 19:30:03 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 19:30:03 --> Final output sent to browser
DEBUG - 2021-04-13 19:30:03 --> Total execution time: 0.0344
INFO - 2021-04-13 19:30:04 --> Config Class Initialized
INFO - 2021-04-13 19:30:04 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:30:04 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:30:04 --> Utf8 Class Initialized
INFO - 2021-04-13 19:30:04 --> URI Class Initialized
DEBUG - 2021-04-13 19:30:04 --> No URI present. Default controller set.
INFO - 2021-04-13 19:30:04 --> Router Class Initialized
INFO - 2021-04-13 19:30:04 --> Output Class Initialized
INFO - 2021-04-13 19:30:04 --> Security Class Initialized
DEBUG - 2021-04-13 19:30:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:30:04 --> Input Class Initialized
INFO - 2021-04-13 19:30:04 --> Language Class Initialized
INFO - 2021-04-13 19:30:04 --> Loader Class Initialized
INFO - 2021-04-13 19:30:04 --> Helper loaded: url_helper
INFO - 2021-04-13 19:30:04 --> Helper loaded: form_helper
INFO - 2021-04-13 19:30:04 --> Helper loaded: common_helper
INFO - 2021-04-13 19:30:04 --> Helper loaded: util_helper
INFO - 2021-04-13 19:30:04 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:30:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:30:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:30:04 --> Form Validation Class Initialized
INFO - 2021-04-13 19:30:04 --> Controller Class Initialized
INFO - 2021-04-13 19:30:04 --> Model Class Initialized
INFO - 2021-04-13 19:30:04 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-13 19:30:04 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 19:30:04 --> Final output sent to browser
DEBUG - 2021-04-13 19:30:04 --> Total execution time: 0.0289
INFO - 2021-04-13 19:30:09 --> Config Class Initialized
INFO - 2021-04-13 19:30:09 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:30:09 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:30:09 --> Utf8 Class Initialized
INFO - 2021-04-13 19:30:09 --> URI Class Initialized
INFO - 2021-04-13 19:30:09 --> Router Class Initialized
INFO - 2021-04-13 19:30:09 --> Output Class Initialized
INFO - 2021-04-13 19:30:09 --> Security Class Initialized
DEBUG - 2021-04-13 19:30:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:30:09 --> Input Class Initialized
INFO - 2021-04-13 19:30:09 --> Language Class Initialized
INFO - 2021-04-13 19:30:09 --> Loader Class Initialized
INFO - 2021-04-13 19:30:09 --> Helper loaded: url_helper
INFO - 2021-04-13 19:30:09 --> Helper loaded: form_helper
INFO - 2021-04-13 19:30:09 --> Helper loaded: common_helper
INFO - 2021-04-13 19:30:09 --> Helper loaded: util_helper
INFO - 2021-04-13 19:30:09 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:30:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:30:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:30:09 --> Form Validation Class Initialized
INFO - 2021-04-13 19:30:09 --> Controller Class Initialized
INFO - 2021-04-13 19:30:09 --> Model Class Initialized
INFO - 2021-04-13 19:30:09 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 19:30:09 --> Final output sent to browser
DEBUG - 2021-04-13 19:30:09 --> Total execution time: 0.0250
INFO - 2021-04-13 19:30:10 --> Config Class Initialized
INFO - 2021-04-13 19:30:10 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:30:10 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:30:10 --> Utf8 Class Initialized
INFO - 2021-04-13 19:30:10 --> URI Class Initialized
INFO - 2021-04-13 19:30:10 --> Router Class Initialized
INFO - 2021-04-13 19:30:10 --> Output Class Initialized
INFO - 2021-04-13 19:30:10 --> Security Class Initialized
DEBUG - 2021-04-13 19:30:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:30:10 --> Input Class Initialized
INFO - 2021-04-13 19:30:10 --> Language Class Initialized
INFO - 2021-04-13 19:30:10 --> Loader Class Initialized
INFO - 2021-04-13 19:30:10 --> Helper loaded: url_helper
INFO - 2021-04-13 19:30:10 --> Helper loaded: form_helper
INFO - 2021-04-13 19:30:10 --> Helper loaded: common_helper
INFO - 2021-04-13 19:30:10 --> Helper loaded: util_helper
INFO - 2021-04-13 19:30:10 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:30:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:30:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:30:10 --> Form Validation Class Initialized
INFO - 2021-04-13 19:30:10 --> Controller Class Initialized
INFO - 2021-04-13 19:30:10 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-13 19:30:10 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 19:30:10 --> Final output sent to browser
DEBUG - 2021-04-13 19:30:10 --> Total execution time: 0.0347
INFO - 2021-04-13 19:30:15 --> Config Class Initialized
INFO - 2021-04-13 19:30:15 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:30:15 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:30:15 --> Utf8 Class Initialized
INFO - 2021-04-13 19:30:15 --> URI Class Initialized
INFO - 2021-04-13 19:30:15 --> Router Class Initialized
INFO - 2021-04-13 19:30:15 --> Output Class Initialized
INFO - 2021-04-13 19:30:15 --> Security Class Initialized
DEBUG - 2021-04-13 19:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:30:15 --> Input Class Initialized
INFO - 2021-04-13 19:30:15 --> Language Class Initialized
INFO - 2021-04-13 19:30:15 --> Loader Class Initialized
INFO - 2021-04-13 19:30:15 --> Helper loaded: url_helper
INFO - 2021-04-13 19:30:15 --> Helper loaded: form_helper
INFO - 2021-04-13 19:30:15 --> Helper loaded: common_helper
INFO - 2021-04-13 19:30:15 --> Helper loaded: util_helper
INFO - 2021-04-13 19:30:15 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:30:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:30:15 --> Form Validation Class Initialized
INFO - 2021-04-13 19:30:15 --> Controller Class Initialized
INFO - 2021-04-13 19:30:15 --> Model Class Initialized
INFO - 2021-04-13 19:30:15 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 19:30:15 --> Final output sent to browser
DEBUG - 2021-04-13 19:30:15 --> Total execution time: 0.0350
INFO - 2021-04-13 19:30:15 --> Config Class Initialized
INFO - 2021-04-13 19:30:15 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:30:15 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:30:15 --> Utf8 Class Initialized
INFO - 2021-04-13 19:30:15 --> URI Class Initialized
DEBUG - 2021-04-13 19:30:15 --> No URI present. Default controller set.
INFO - 2021-04-13 19:30:15 --> Router Class Initialized
INFO - 2021-04-13 19:30:15 --> Output Class Initialized
INFO - 2021-04-13 19:30:15 --> Security Class Initialized
DEBUG - 2021-04-13 19:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:30:15 --> Input Class Initialized
INFO - 2021-04-13 19:30:15 --> Language Class Initialized
INFO - 2021-04-13 19:30:15 --> Loader Class Initialized
INFO - 2021-04-13 19:30:15 --> Helper loaded: url_helper
INFO - 2021-04-13 19:30:15 --> Helper loaded: form_helper
INFO - 2021-04-13 19:30:15 --> Helper loaded: common_helper
INFO - 2021-04-13 19:30:15 --> Helper loaded: util_helper
INFO - 2021-04-13 19:30:15 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:30:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:30:15 --> Form Validation Class Initialized
INFO - 2021-04-13 19:30:15 --> Controller Class Initialized
INFO - 2021-04-13 19:30:15 --> Model Class Initialized
INFO - 2021-04-13 19:30:15 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-13 19:30:15 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 19:30:15 --> Final output sent to browser
DEBUG - 2021-04-13 19:30:15 --> Total execution time: 0.0254
INFO - 2021-04-13 19:30:19 --> Config Class Initialized
INFO - 2021-04-13 19:30:19 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:30:19 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:30:19 --> Utf8 Class Initialized
INFO - 2021-04-13 19:30:19 --> URI Class Initialized
INFO - 2021-04-13 19:30:19 --> Router Class Initialized
INFO - 2021-04-13 19:30:19 --> Output Class Initialized
INFO - 2021-04-13 19:30:19 --> Security Class Initialized
DEBUG - 2021-04-13 19:30:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:30:19 --> Input Class Initialized
INFO - 2021-04-13 19:30:19 --> Language Class Initialized
INFO - 2021-04-13 19:30:19 --> Loader Class Initialized
INFO - 2021-04-13 19:30:19 --> Helper loaded: url_helper
INFO - 2021-04-13 19:30:19 --> Helper loaded: form_helper
INFO - 2021-04-13 19:30:19 --> Helper loaded: common_helper
INFO - 2021-04-13 19:30:19 --> Helper loaded: util_helper
INFO - 2021-04-13 19:30:19 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:30:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:30:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:30:19 --> Form Validation Class Initialized
INFO - 2021-04-13 19:30:19 --> Controller Class Initialized
INFO - 2021-04-13 19:30:19 --> Model Class Initialized
INFO - 2021-04-13 19:30:19 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 19:30:19 --> Final output sent to browser
DEBUG - 2021-04-13 19:30:19 --> Total execution time: 0.0252
INFO - 2021-04-13 19:30:20 --> Config Class Initialized
INFO - 2021-04-13 19:30:20 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:30:20 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:30:20 --> Utf8 Class Initialized
INFO - 2021-04-13 19:30:20 --> URI Class Initialized
INFO - 2021-04-13 19:30:20 --> Router Class Initialized
INFO - 2021-04-13 19:30:20 --> Output Class Initialized
INFO - 2021-04-13 19:30:20 --> Security Class Initialized
DEBUG - 2021-04-13 19:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:30:20 --> Input Class Initialized
INFO - 2021-04-13 19:30:20 --> Language Class Initialized
INFO - 2021-04-13 19:30:20 --> Loader Class Initialized
INFO - 2021-04-13 19:30:20 --> Helper loaded: url_helper
INFO - 2021-04-13 19:30:20 --> Helper loaded: form_helper
INFO - 2021-04-13 19:30:20 --> Helper loaded: common_helper
INFO - 2021-04-13 19:30:20 --> Helper loaded: util_helper
INFO - 2021-04-13 19:30:20 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:30:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:30:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:30:20 --> Form Validation Class Initialized
INFO - 2021-04-13 19:30:20 --> Controller Class Initialized
INFO - 2021-04-13 19:30:20 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-13 19:30:20 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 19:30:20 --> Final output sent to browser
DEBUG - 2021-04-13 19:30:20 --> Total execution time: 0.0245
INFO - 2021-04-13 19:30:20 --> Config Class Initialized
INFO - 2021-04-13 19:30:20 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:30:20 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:30:20 --> Utf8 Class Initialized
INFO - 2021-04-13 19:30:20 --> URI Class Initialized
INFO - 2021-04-13 19:30:20 --> Router Class Initialized
INFO - 2021-04-13 19:30:20 --> Output Class Initialized
INFO - 2021-04-13 19:30:20 --> Security Class Initialized
DEBUG - 2021-04-13 19:30:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:30:20 --> Input Class Initialized
INFO - 2021-04-13 19:30:20 --> Language Class Initialized
INFO - 2021-04-13 19:30:20 --> Loader Class Initialized
INFO - 2021-04-13 19:30:20 --> Helper loaded: url_helper
INFO - 2021-04-13 19:30:20 --> Helper loaded: form_helper
INFO - 2021-04-13 19:30:20 --> Helper loaded: common_helper
INFO - 2021-04-13 19:30:20 --> Helper loaded: util_helper
INFO - 2021-04-13 19:30:20 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:30:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:30:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:30:20 --> Form Validation Class Initialized
INFO - 2021-04-13 19:30:20 --> Controller Class Initialized
INFO - 2021-04-13 19:30:20 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-13 19:30:20 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 19:30:20 --> Final output sent to browser
DEBUG - 2021-04-13 19:30:20 --> Total execution time: 0.0251
INFO - 2021-04-13 19:30:32 --> Config Class Initialized
INFO - 2021-04-13 19:30:32 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:30:32 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:30:32 --> Utf8 Class Initialized
INFO - 2021-04-13 19:30:32 --> URI Class Initialized
INFO - 2021-04-13 19:30:32 --> Router Class Initialized
INFO - 2021-04-13 19:30:32 --> Output Class Initialized
INFO - 2021-04-13 19:30:32 --> Security Class Initialized
DEBUG - 2021-04-13 19:30:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:30:32 --> Input Class Initialized
INFO - 2021-04-13 19:30:32 --> Language Class Initialized
INFO - 2021-04-13 19:30:32 --> Loader Class Initialized
INFO - 2021-04-13 19:30:32 --> Helper loaded: url_helper
INFO - 2021-04-13 19:30:32 --> Helper loaded: form_helper
INFO - 2021-04-13 19:30:32 --> Helper loaded: common_helper
INFO - 2021-04-13 19:30:32 --> Helper loaded: util_helper
INFO - 2021-04-13 19:30:32 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:30:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:30:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:30:32 --> Form Validation Class Initialized
INFO - 2021-04-13 19:30:32 --> Controller Class Initialized
INFO - 2021-04-13 19:33:15 --> Config Class Initialized
INFO - 2021-04-13 19:33:15 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:33:15 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:33:15 --> Utf8 Class Initialized
INFO - 2021-04-13 19:33:15 --> URI Class Initialized
INFO - 2021-04-13 19:33:15 --> Router Class Initialized
INFO - 2021-04-13 19:33:15 --> Output Class Initialized
INFO - 2021-04-13 19:33:15 --> Security Class Initialized
DEBUG - 2021-04-13 19:33:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:33:15 --> Input Class Initialized
INFO - 2021-04-13 19:33:15 --> Language Class Initialized
INFO - 2021-04-13 19:33:15 --> Loader Class Initialized
INFO - 2021-04-13 19:33:15 --> Helper loaded: url_helper
INFO - 2021-04-13 19:33:15 --> Helper loaded: form_helper
INFO - 2021-04-13 19:33:15 --> Helper loaded: common_helper
INFO - 2021-04-13 19:33:15 --> Helper loaded: util_helper
INFO - 2021-04-13 19:33:15 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:33:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:33:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:33:15 --> Form Validation Class Initialized
INFO - 2021-04-13 19:33:15 --> Controller Class Initialized
INFO - 2021-04-13 19:33:21 --> Config Class Initialized
INFO - 2021-04-13 19:33:21 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:33:21 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:33:21 --> Utf8 Class Initialized
INFO - 2021-04-13 19:33:21 --> URI Class Initialized
INFO - 2021-04-13 19:33:21 --> Router Class Initialized
INFO - 2021-04-13 19:33:21 --> Output Class Initialized
INFO - 2021-04-13 19:33:21 --> Security Class Initialized
DEBUG - 2021-04-13 19:33:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:33:21 --> Input Class Initialized
INFO - 2021-04-13 19:33:21 --> Language Class Initialized
INFO - 2021-04-13 19:33:21 --> Loader Class Initialized
INFO - 2021-04-13 19:33:21 --> Helper loaded: url_helper
INFO - 2021-04-13 19:33:21 --> Helper loaded: form_helper
INFO - 2021-04-13 19:33:21 --> Helper loaded: common_helper
INFO - 2021-04-13 19:33:21 --> Helper loaded: util_helper
INFO - 2021-04-13 19:33:21 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:33:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:33:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:33:21 --> Form Validation Class Initialized
INFO - 2021-04-13 19:33:21 --> Controller Class Initialized
INFO - 2021-04-13 19:40:54 --> Config Class Initialized
INFO - 2021-04-13 19:40:54 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:40:54 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:40:54 --> Utf8 Class Initialized
INFO - 2021-04-13 19:40:54 --> URI Class Initialized
INFO - 2021-04-13 19:40:54 --> Router Class Initialized
INFO - 2021-04-13 19:40:54 --> Output Class Initialized
INFO - 2021-04-13 19:40:54 --> Security Class Initialized
DEBUG - 2021-04-13 19:40:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:40:54 --> Input Class Initialized
INFO - 2021-04-13 19:40:54 --> Language Class Initialized
INFO - 2021-04-13 19:40:54 --> Loader Class Initialized
INFO - 2021-04-13 19:40:54 --> Helper loaded: url_helper
INFO - 2021-04-13 19:40:54 --> Helper loaded: form_helper
INFO - 2021-04-13 19:40:54 --> Helper loaded: common_helper
INFO - 2021-04-13 19:40:54 --> Helper loaded: util_helper
INFO - 2021-04-13 19:40:54 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:40:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:40:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:40:54 --> Form Validation Class Initialized
INFO - 2021-04-13 19:40:54 --> Controller Class Initialized
INFO - 2021-04-13 19:42:41 --> Config Class Initialized
INFO - 2021-04-13 19:42:41 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:42:41 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:42:41 --> Utf8 Class Initialized
INFO - 2021-04-13 19:42:41 --> URI Class Initialized
INFO - 2021-04-13 19:42:41 --> Router Class Initialized
INFO - 2021-04-13 19:42:41 --> Output Class Initialized
INFO - 2021-04-13 19:42:41 --> Security Class Initialized
DEBUG - 2021-04-13 19:42:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:42:41 --> Input Class Initialized
INFO - 2021-04-13 19:42:41 --> Language Class Initialized
INFO - 2021-04-13 19:42:41 --> Loader Class Initialized
INFO - 2021-04-13 19:42:41 --> Helper loaded: url_helper
INFO - 2021-04-13 19:42:41 --> Helper loaded: form_helper
INFO - 2021-04-13 19:42:41 --> Helper loaded: common_helper
INFO - 2021-04-13 19:42:41 --> Helper loaded: util_helper
INFO - 2021-04-13 19:42:41 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:42:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:42:41 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:42:41 --> Form Validation Class Initialized
INFO - 2021-04-13 19:42:41 --> Controller Class Initialized
INFO - 2021-04-13 19:42:41 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-13 19:42:41 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 19:42:41 --> Final output sent to browser
DEBUG - 2021-04-13 19:42:41 --> Total execution time: 0.0350
INFO - 2021-04-13 19:42:56 --> Config Class Initialized
INFO - 2021-04-13 19:42:56 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:42:56 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:42:56 --> Utf8 Class Initialized
INFO - 2021-04-13 19:42:56 --> URI Class Initialized
INFO - 2021-04-13 19:42:56 --> Router Class Initialized
INFO - 2021-04-13 19:42:56 --> Output Class Initialized
INFO - 2021-04-13 19:42:56 --> Security Class Initialized
DEBUG - 2021-04-13 19:42:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:42:56 --> Input Class Initialized
INFO - 2021-04-13 19:42:56 --> Language Class Initialized
INFO - 2021-04-13 19:42:56 --> Loader Class Initialized
INFO - 2021-04-13 19:42:56 --> Helper loaded: url_helper
INFO - 2021-04-13 19:42:56 --> Helper loaded: form_helper
INFO - 2021-04-13 19:42:56 --> Helper loaded: common_helper
INFO - 2021-04-13 19:42:56 --> Helper loaded: util_helper
INFO - 2021-04-13 19:42:56 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:42:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:42:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:42:56 --> Form Validation Class Initialized
INFO - 2021-04-13 19:42:56 --> Controller Class Initialized
INFO - 2021-04-13 19:43:44 --> Config Class Initialized
INFO - 2021-04-13 19:43:44 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:43:44 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:43:44 --> Utf8 Class Initialized
INFO - 2021-04-13 19:43:44 --> URI Class Initialized
INFO - 2021-04-13 19:43:44 --> Router Class Initialized
INFO - 2021-04-13 19:43:44 --> Output Class Initialized
INFO - 2021-04-13 19:43:44 --> Security Class Initialized
DEBUG - 2021-04-13 19:43:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:43:44 --> Input Class Initialized
INFO - 2021-04-13 19:43:44 --> Language Class Initialized
INFO - 2021-04-13 19:43:44 --> Loader Class Initialized
INFO - 2021-04-13 19:43:44 --> Helper loaded: url_helper
INFO - 2021-04-13 19:43:44 --> Helper loaded: form_helper
INFO - 2021-04-13 19:43:44 --> Helper loaded: common_helper
INFO - 2021-04-13 19:43:44 --> Helper loaded: util_helper
INFO - 2021-04-13 19:43:44 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:43:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:43:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:43:44 --> Form Validation Class Initialized
INFO - 2021-04-13 19:43:44 --> Controller Class Initialized
INFO - 2021-04-13 19:43:44 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-13 19:43:44 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 19:43:44 --> Final output sent to browser
DEBUG - 2021-04-13 19:43:44 --> Total execution time: 0.0240
INFO - 2021-04-13 19:50:25 --> Config Class Initialized
INFO - 2021-04-13 19:50:25 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:50:25 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:50:25 --> Utf8 Class Initialized
INFO - 2021-04-13 19:50:25 --> URI Class Initialized
INFO - 2021-04-13 19:50:25 --> Router Class Initialized
INFO - 2021-04-13 19:50:25 --> Output Class Initialized
INFO - 2021-04-13 19:50:25 --> Security Class Initialized
DEBUG - 2021-04-13 19:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:50:25 --> Input Class Initialized
INFO - 2021-04-13 19:50:25 --> Language Class Initialized
INFO - 2021-04-13 19:50:25 --> Loader Class Initialized
INFO - 2021-04-13 19:50:25 --> Helper loaded: url_helper
INFO - 2021-04-13 19:50:25 --> Helper loaded: form_helper
INFO - 2021-04-13 19:50:25 --> Helper loaded: common_helper
INFO - 2021-04-13 19:50:25 --> Helper loaded: util_helper
INFO - 2021-04-13 19:50:25 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:50:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:50:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:50:25 --> Form Validation Class Initialized
INFO - 2021-04-13 19:50:25 --> Controller Class Initialized
INFO - 2021-04-13 19:50:25 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\account.php
INFO - 2021-04-13 19:50:25 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 19:50:25 --> Final output sent to browser
DEBUG - 2021-04-13 19:50:25 --> Total execution time: 0.0273
INFO - 2021-04-13 19:50:25 --> Config Class Initialized
INFO - 2021-04-13 19:50:25 --> Hooks Class Initialized
INFO - 2021-04-13 19:50:25 --> Config Class Initialized
INFO - 2021-04-13 19:50:25 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:50:25 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:50:25 --> Utf8 Class Initialized
INFO - 2021-04-13 19:50:25 --> Config Class Initialized
INFO - 2021-04-13 19:50:25 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:50:25 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:50:25 --> Utf8 Class Initialized
INFO - 2021-04-13 19:50:25 --> URI Class Initialized
INFO - 2021-04-13 19:50:25 --> URI Class Initialized
DEBUG - 2021-04-13 19:50:25 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:50:25 --> Utf8 Class Initialized
INFO - 2021-04-13 19:50:25 --> Config Class Initialized
INFO - 2021-04-13 19:50:25 --> Hooks Class Initialized
INFO - 2021-04-13 19:50:25 --> Router Class Initialized
INFO - 2021-04-13 19:50:25 --> URI Class Initialized
INFO - 2021-04-13 19:50:25 --> Output Class Initialized
INFO - 2021-04-13 19:50:25 --> Router Class Initialized
INFO - 2021-04-13 19:50:25 --> Router Class Initialized
DEBUG - 2021-04-13 19:50:25 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:50:25 --> Utf8 Class Initialized
INFO - 2021-04-13 19:50:25 --> Security Class Initialized
INFO - 2021-04-13 19:50:25 --> Output Class Initialized
INFO - 2021-04-13 19:50:25 --> URI Class Initialized
DEBUG - 2021-04-13 19:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:50:25 --> Input Class Initialized
INFO - 2021-04-13 19:50:25 --> Security Class Initialized
INFO - 2021-04-13 19:50:25 --> Router Class Initialized
INFO - 2021-04-13 19:50:25 --> Language Class Initialized
DEBUG - 2021-04-13 19:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:50:25 --> Input Class Initialized
INFO - 2021-04-13 19:50:25 --> Output Class Initialized
INFO - 2021-04-13 19:50:25 --> Language Class Initialized
ERROR - 2021-04-13 19:50:25 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:50:25 --> Security Class Initialized
INFO - 2021-04-13 19:50:25 --> Output Class Initialized
ERROR - 2021-04-13 19:50:25 --> 404 Page Not Found: user/Assets/css
DEBUG - 2021-04-13 19:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:50:25 --> Input Class Initialized
INFO - 2021-04-13 19:50:25 --> Security Class Initialized
INFO - 2021-04-13 19:50:25 --> Language Class Initialized
DEBUG - 2021-04-13 19:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:50:25 --> Input Class Initialized
ERROR - 2021-04-13 19:50:25 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:50:25 --> Language Class Initialized
ERROR - 2021-04-13 19:50:25 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:50:25 --> Config Class Initialized
INFO - 2021-04-13 19:50:25 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:50:25 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:50:25 --> Utf8 Class Initialized
INFO - 2021-04-13 19:50:25 --> URI Class Initialized
INFO - 2021-04-13 19:50:25 --> Router Class Initialized
INFO - 2021-04-13 19:50:25 --> Output Class Initialized
INFO - 2021-04-13 19:50:25 --> Security Class Initialized
DEBUG - 2021-04-13 19:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:50:25 --> Input Class Initialized
INFO - 2021-04-13 19:50:25 --> Language Class Initialized
INFO - 2021-04-13 19:50:25 --> Config Class Initialized
INFO - 2021-04-13 19:50:25 --> Config Class Initialized
INFO - 2021-04-13 19:50:25 --> Hooks Class Initialized
INFO - 2021-04-13 19:50:25 --> Hooks Class Initialized
ERROR - 2021-04-13 19:50:25 --> 404 Page Not Found: user/Assets/css
DEBUG - 2021-04-13 19:50:25 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 19:50:25 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:50:25 --> Utf8 Class Initialized
INFO - 2021-04-13 19:50:25 --> URI Class Initialized
INFO - 2021-04-13 19:50:25 --> Utf8 Class Initialized
INFO - 2021-04-13 19:50:25 --> Router Class Initialized
INFO - 2021-04-13 19:50:25 --> URI Class Initialized
INFO - 2021-04-13 19:50:25 --> Output Class Initialized
INFO - 2021-04-13 19:50:25 --> Router Class Initialized
INFO - 2021-04-13 19:50:25 --> Security Class Initialized
INFO - 2021-04-13 19:50:25 --> Output Class Initialized
DEBUG - 2021-04-13 19:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:50:25 --> Input Class Initialized
INFO - 2021-04-13 19:50:25 --> Language Class Initialized
INFO - 2021-04-13 19:50:25 --> Security Class Initialized
ERROR - 2021-04-13 19:50:25 --> 404 Page Not Found: user/Assets/js
DEBUG - 2021-04-13 19:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:50:25 --> Input Class Initialized
INFO - 2021-04-13 19:50:25 --> Language Class Initialized
ERROR - 2021-04-13 19:50:25 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 19:50:25 --> Config Class Initialized
INFO - 2021-04-13 19:50:25 --> Hooks Class Initialized
INFO - 2021-04-13 19:50:25 --> Config Class Initialized
INFO - 2021-04-13 19:50:25 --> Hooks Class Initialized
INFO - 2021-04-13 19:50:25 --> Config Class Initialized
INFO - 2021-04-13 19:50:25 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:50:25 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:50:25 --> Utf8 Class Initialized
DEBUG - 2021-04-13 19:50:25 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:50:25 --> Utf8 Class Initialized
DEBUG - 2021-04-13 19:50:25 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:50:25 --> Utf8 Class Initialized
INFO - 2021-04-13 19:50:25 --> URI Class Initialized
INFO - 2021-04-13 19:50:25 --> URI Class Initialized
INFO - 2021-04-13 19:50:25 --> URI Class Initialized
INFO - 2021-04-13 19:50:25 --> Router Class Initialized
INFO - 2021-04-13 19:50:25 --> Config Class Initialized
INFO - 2021-04-13 19:50:25 --> Router Class Initialized
INFO - 2021-04-13 19:50:25 --> Hooks Class Initialized
INFO - 2021-04-13 19:50:25 --> Output Class Initialized
INFO - 2021-04-13 19:50:25 --> Output Class Initialized
INFO - 2021-04-13 19:50:25 --> Security Class Initialized
DEBUG - 2021-04-13 19:50:25 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:50:25 --> Utf8 Class Initialized
INFO - 2021-04-13 19:50:25 --> Security Class Initialized
DEBUG - 2021-04-13 19:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:50:25 --> Input Class Initialized
INFO - 2021-04-13 19:50:25 --> URI Class Initialized
INFO - 2021-04-13 19:50:25 --> Language Class Initialized
DEBUG - 2021-04-13 19:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:50:25 --> Input Class Initialized
INFO - 2021-04-13 19:50:25 --> Language Class Initialized
INFO - 2021-04-13 19:50:25 --> Router Class Initialized
ERROR - 2021-04-13 19:50:25 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 19:50:25 --> Router Class Initialized
ERROR - 2021-04-13 19:50:25 --> 404 Page Not Found: user/Assets/img
INFO - 2021-04-13 19:50:25 --> Output Class Initialized
INFO - 2021-04-13 19:50:25 --> Security Class Initialized
INFO - 2021-04-13 19:50:25 --> Output Class Initialized
DEBUG - 2021-04-13 19:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:50:25 --> Input Class Initialized
INFO - 2021-04-13 19:50:25 --> Security Class Initialized
INFO - 2021-04-13 19:50:25 --> Language Class Initialized
DEBUG - 2021-04-13 19:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:50:25 --> Input Class Initialized
ERROR - 2021-04-13 19:50:25 --> 404 Page Not Found: user/Assets/img
INFO - 2021-04-13 19:50:25 --> Language Class Initialized
ERROR - 2021-04-13 19:50:25 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 19:50:25 --> Config Class Initialized
INFO - 2021-04-13 19:50:25 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:50:25 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:50:25 --> Utf8 Class Initialized
INFO - 2021-04-13 19:50:25 --> URI Class Initialized
INFO - 2021-04-13 19:50:25 --> Router Class Initialized
INFO - 2021-04-13 19:50:25 --> Output Class Initialized
INFO - 2021-04-13 19:50:25 --> Security Class Initialized
DEBUG - 2021-04-13 19:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:50:25 --> Input Class Initialized
INFO - 2021-04-13 19:50:25 --> Language Class Initialized
ERROR - 2021-04-13 19:50:25 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:50:25 --> Config Class Initialized
INFO - 2021-04-13 19:50:25 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:50:25 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:50:25 --> Utf8 Class Initialized
INFO - 2021-04-13 19:50:25 --> URI Class Initialized
INFO - 2021-04-13 19:50:25 --> Router Class Initialized
INFO - 2021-04-13 19:50:25 --> Output Class Initialized
INFO - 2021-04-13 19:50:25 --> Security Class Initialized
DEBUG - 2021-04-13 19:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:50:25 --> Input Class Initialized
INFO - 2021-04-13 19:50:25 --> Language Class Initialized
ERROR - 2021-04-13 19:50:25 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:50:25 --> Config Class Initialized
INFO - 2021-04-13 19:50:25 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:50:25 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:50:25 --> Utf8 Class Initialized
INFO - 2021-04-13 19:50:25 --> URI Class Initialized
INFO - 2021-04-13 19:50:25 --> Router Class Initialized
INFO - 2021-04-13 19:50:25 --> Output Class Initialized
INFO - 2021-04-13 19:50:25 --> Security Class Initialized
DEBUG - 2021-04-13 19:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:50:25 --> Input Class Initialized
INFO - 2021-04-13 19:50:25 --> Language Class Initialized
ERROR - 2021-04-13 19:50:25 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:50:25 --> Config Class Initialized
INFO - 2021-04-13 19:50:25 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:50:25 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:50:25 --> Utf8 Class Initialized
INFO - 2021-04-13 19:50:25 --> URI Class Initialized
INFO - 2021-04-13 19:50:25 --> Router Class Initialized
INFO - 2021-04-13 19:50:25 --> Output Class Initialized
INFO - 2021-04-13 19:50:25 --> Security Class Initialized
DEBUG - 2021-04-13 19:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:50:25 --> Input Class Initialized
INFO - 2021-04-13 19:50:25 --> Language Class Initialized
ERROR - 2021-04-13 19:50:25 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:50:25 --> Config Class Initialized
INFO - 2021-04-13 19:50:25 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:50:25 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:50:25 --> Utf8 Class Initialized
INFO - 2021-04-13 19:50:25 --> URI Class Initialized
INFO - 2021-04-13 19:50:25 --> Router Class Initialized
INFO - 2021-04-13 19:50:25 --> Output Class Initialized
INFO - 2021-04-13 19:50:25 --> Security Class Initialized
DEBUG - 2021-04-13 19:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:50:25 --> Input Class Initialized
INFO - 2021-04-13 19:50:25 --> Language Class Initialized
ERROR - 2021-04-13 19:50:25 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:50:25 --> Config Class Initialized
INFO - 2021-04-13 19:50:25 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:50:25 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:50:25 --> Utf8 Class Initialized
INFO - 2021-04-13 19:50:25 --> URI Class Initialized
INFO - 2021-04-13 19:50:25 --> Router Class Initialized
INFO - 2021-04-13 19:50:25 --> Output Class Initialized
INFO - 2021-04-13 19:50:25 --> Security Class Initialized
DEBUG - 2021-04-13 19:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:50:25 --> Input Class Initialized
INFO - 2021-04-13 19:50:25 --> Language Class Initialized
ERROR - 2021-04-13 19:50:25 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 19:50:25 --> Config Class Initialized
INFO - 2021-04-13 19:50:25 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:50:25 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:50:25 --> Utf8 Class Initialized
INFO - 2021-04-13 19:50:25 --> URI Class Initialized
INFO - 2021-04-13 19:50:25 --> Router Class Initialized
INFO - 2021-04-13 19:50:25 --> Output Class Initialized
INFO - 2021-04-13 19:50:25 --> Security Class Initialized
DEBUG - 2021-04-13 19:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:50:25 --> Input Class Initialized
INFO - 2021-04-13 19:50:25 --> Language Class Initialized
ERROR - 2021-04-13 19:50:25 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 19:50:25 --> Config Class Initialized
INFO - 2021-04-13 19:50:25 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:50:25 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:50:25 --> Utf8 Class Initialized
INFO - 2021-04-13 19:50:25 --> URI Class Initialized
INFO - 2021-04-13 19:50:25 --> Router Class Initialized
INFO - 2021-04-13 19:50:25 --> Output Class Initialized
INFO - 2021-04-13 19:50:25 --> Security Class Initialized
DEBUG - 2021-04-13 19:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:50:25 --> Input Class Initialized
INFO - 2021-04-13 19:50:25 --> Language Class Initialized
ERROR - 2021-04-13 19:50:25 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 19:50:25 --> Config Class Initialized
INFO - 2021-04-13 19:50:25 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:50:25 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:50:25 --> Utf8 Class Initialized
INFO - 2021-04-13 19:50:25 --> URI Class Initialized
INFO - 2021-04-13 19:50:25 --> Router Class Initialized
INFO - 2021-04-13 19:50:25 --> Output Class Initialized
INFO - 2021-04-13 19:50:25 --> Security Class Initialized
DEBUG - 2021-04-13 19:50:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:50:25 --> Input Class Initialized
INFO - 2021-04-13 19:50:25 --> Language Class Initialized
ERROR - 2021-04-13 19:50:25 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 19:52:40 --> Config Class Initialized
INFO - 2021-04-13 19:52:40 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:52:40 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:52:40 --> Utf8 Class Initialized
INFO - 2021-04-13 19:52:40 --> URI Class Initialized
INFO - 2021-04-13 19:52:40 --> Router Class Initialized
INFO - 2021-04-13 19:52:40 --> Output Class Initialized
INFO - 2021-04-13 19:52:40 --> Security Class Initialized
DEBUG - 2021-04-13 19:52:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:52:40 --> Input Class Initialized
INFO - 2021-04-13 19:52:40 --> Language Class Initialized
INFO - 2021-04-13 19:52:40 --> Loader Class Initialized
INFO - 2021-04-13 19:52:40 --> Helper loaded: url_helper
INFO - 2021-04-13 19:52:40 --> Helper loaded: form_helper
INFO - 2021-04-13 19:52:40 --> Helper loaded: common_helper
INFO - 2021-04-13 19:52:40 --> Helper loaded: util_helper
INFO - 2021-04-13 19:52:40 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:52:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:52:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:52:40 --> Form Validation Class Initialized
INFO - 2021-04-13 19:52:40 --> Controller Class Initialized
INFO - 2021-04-13 19:52:40 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-13 19:52:40 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 19:52:40 --> Final output sent to browser
DEBUG - 2021-04-13 19:52:40 --> Total execution time: 0.0240
INFO - 2021-04-13 19:52:41 --> Config Class Initialized
INFO - 2021-04-13 19:52:41 --> Hooks Class Initialized
INFO - 2021-04-13 19:52:41 --> Config Class Initialized
DEBUG - 2021-04-13 19:52:41 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:52:41 --> Hooks Class Initialized
INFO - 2021-04-13 19:52:41 --> Utf8 Class Initialized
INFO - 2021-04-13 19:52:41 --> URI Class Initialized
DEBUG - 2021-04-13 19:52:41 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:52:41 --> Router Class Initialized
INFO - 2021-04-13 19:52:41 --> Utf8 Class Initialized
INFO - 2021-04-13 19:52:41 --> URI Class Initialized
INFO - 2021-04-13 19:52:41 --> Output Class Initialized
INFO - 2021-04-13 19:52:41 --> Router Class Initialized
INFO - 2021-04-13 19:52:41 --> Security Class Initialized
INFO - 2021-04-13 19:52:41 --> Output Class Initialized
DEBUG - 2021-04-13 19:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:52:41 --> Input Class Initialized
INFO - 2021-04-13 19:52:41 --> Language Class Initialized
INFO - 2021-04-13 19:52:41 --> Security Class Initialized
DEBUG - 2021-04-13 19:52:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 19:52:41 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:52:41 --> Input Class Initialized
INFO - 2021-04-13 19:52:41 --> Language Class Initialized
ERROR - 2021-04-13 19:52:41 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:52:41 --> Config Class Initialized
INFO - 2021-04-13 19:52:41 --> Hooks Class Initialized
INFO - 2021-04-13 19:52:41 --> Config Class Initialized
INFO - 2021-04-13 19:52:41 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:52:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 19:52:41 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:52:41 --> Utf8 Class Initialized
INFO - 2021-04-13 19:52:41 --> Utf8 Class Initialized
INFO - 2021-04-13 19:52:41 --> URI Class Initialized
INFO - 2021-04-13 19:52:41 --> URI Class Initialized
INFO - 2021-04-13 19:52:41 --> Config Class Initialized
INFO - 2021-04-13 19:52:41 --> Hooks Class Initialized
INFO - 2021-04-13 19:52:41 --> Router Class Initialized
INFO - 2021-04-13 19:52:41 --> Router Class Initialized
INFO - 2021-04-13 19:52:41 --> Output Class Initialized
INFO - 2021-04-13 19:52:41 --> Output Class Initialized
INFO - 2021-04-13 19:52:41 --> Config Class Initialized
INFO - 2021-04-13 19:52:41 --> Hooks Class Initialized
INFO - 2021-04-13 19:52:41 --> Security Class Initialized
INFO - 2021-04-13 19:52:41 --> Security Class Initialized
DEBUG - 2021-04-13 19:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:52:41 --> Input Class Initialized
DEBUG - 2021-04-13 19:52:41 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:52:41 --> Utf8 Class Initialized
DEBUG - 2021-04-13 19:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:52:41 --> Language Class Initialized
INFO - 2021-04-13 19:52:41 --> Input Class Initialized
INFO - 2021-04-13 19:52:41 --> URI Class Initialized
INFO - 2021-04-13 19:52:41 --> Language Class Initialized
INFO - 2021-04-13 19:52:41 --> Router Class Initialized
ERROR - 2021-04-13 19:52:41 --> 404 Page Not Found: user/Assets/css
ERROR - 2021-04-13 19:52:41 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:52:41 --> Config Class Initialized
INFO - 2021-04-13 19:52:41 --> Output Class Initialized
INFO - 2021-04-13 19:52:41 --> Hooks Class Initialized
INFO - 2021-04-13 19:52:41 --> Security Class Initialized
DEBUG - 2021-04-13 19:52:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 19:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:52:41 --> Utf8 Class Initialized
INFO - 2021-04-13 19:52:41 --> Input Class Initialized
INFO - 2021-04-13 19:52:41 --> Config Class Initialized
INFO - 2021-04-13 19:52:41 --> Hooks Class Initialized
INFO - 2021-04-13 19:52:41 --> Language Class Initialized
INFO - 2021-04-13 19:52:41 --> URI Class Initialized
ERROR - 2021-04-13 19:52:41 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 19:52:41 --> Router Class Initialized
DEBUG - 2021-04-13 19:52:41 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:52:41 --> Output Class Initialized
INFO - 2021-04-13 19:52:41 --> Utf8 Class Initialized
DEBUG - 2021-04-13 19:52:41 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:52:41 --> Security Class Initialized
INFO - 2021-04-13 19:52:41 --> URI Class Initialized
DEBUG - 2021-04-13 19:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:52:41 --> Input Class Initialized
INFO - 2021-04-13 19:52:41 --> Language Class Initialized
ERROR - 2021-04-13 19:52:41 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 19:52:41 --> Config Class Initialized
INFO - 2021-04-13 19:52:41 --> Hooks Class Initialized
INFO - 2021-04-13 19:52:41 --> Config Class Initialized
INFO - 2021-04-13 19:52:41 --> Hooks Class Initialized
INFO - 2021-04-13 19:52:41 --> Utf8 Class Initialized
INFO - 2021-04-13 19:52:41 --> Router Class Initialized
DEBUG - 2021-04-13 19:52:41 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:52:41 --> Utf8 Class Initialized
INFO - 2021-04-13 19:52:41 --> URI Class Initialized
DEBUG - 2021-04-13 19:52:41 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:52:41 --> Utf8 Class Initialized
INFO - 2021-04-13 19:52:41 --> URI Class Initialized
INFO - 2021-04-13 19:52:41 --> URI Class Initialized
INFO - 2021-04-13 19:52:41 --> Router Class Initialized
INFO - 2021-04-13 19:52:41 --> Output Class Initialized
INFO - 2021-04-13 19:52:41 --> Router Class Initialized
INFO - 2021-04-13 19:52:41 --> Router Class Initialized
INFO - 2021-04-13 19:52:41 --> Output Class Initialized
INFO - 2021-04-13 19:52:41 --> Output Class Initialized
INFO - 2021-04-13 19:52:41 --> Output Class Initialized
INFO - 2021-04-13 19:52:41 --> Security Class Initialized
INFO - 2021-04-13 19:52:41 --> Security Class Initialized
INFO - 2021-04-13 19:52:41 --> Security Class Initialized
INFO - 2021-04-13 19:52:41 --> Security Class Initialized
INFO - 2021-04-13 19:52:41 --> Config Class Initialized
INFO - 2021-04-13 19:52:41 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:52:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 19:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:52:41 --> Input Class Initialized
INFO - 2021-04-13 19:52:41 --> Input Class Initialized
INFO - 2021-04-13 19:52:41 --> Language Class Initialized
INFO - 2021-04-13 19:52:41 --> Language Class Initialized
DEBUG - 2021-04-13 19:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:52:41 --> Input Class Initialized
DEBUG - 2021-04-13 19:52:41 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:52:41 --> Language Class Initialized
INFO - 2021-04-13 19:52:41 --> Utf8 Class Initialized
ERROR - 2021-04-13 19:52:41 --> 404 Page Not Found: user/Assets/css
ERROR - 2021-04-13 19:52:41 --> 404 Page Not Found: user/Assets/js
ERROR - 2021-04-13 19:52:41 --> 404 Page Not Found: user/Assets/js
DEBUG - 2021-04-13 19:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:52:41 --> URI Class Initialized
INFO - 2021-04-13 19:52:41 --> Input Class Initialized
INFO - 2021-04-13 19:52:41 --> Router Class Initialized
INFO - 2021-04-13 19:52:41 --> Language Class Initialized
INFO - 2021-04-13 19:52:41 --> Output Class Initialized
ERROR - 2021-04-13 19:52:41 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:52:41 --> Security Class Initialized
DEBUG - 2021-04-13 19:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:52:41 --> Input Class Initialized
INFO - 2021-04-13 19:52:41 --> Config Class Initialized
INFO - 2021-04-13 19:52:41 --> Language Class Initialized
INFO - 2021-04-13 19:52:41 --> Hooks Class Initialized
ERROR - 2021-04-13 19:52:41 --> 404 Page Not Found: user/Assets/img
DEBUG - 2021-04-13 19:52:41 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:52:41 --> Utf8 Class Initialized
INFO - 2021-04-13 19:52:41 --> URI Class Initialized
INFO - 2021-04-13 19:52:41 --> Router Class Initialized
INFO - 2021-04-13 19:52:41 --> Output Class Initialized
INFO - 2021-04-13 19:52:41 --> Security Class Initialized
DEBUG - 2021-04-13 19:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:52:41 --> Input Class Initialized
INFO - 2021-04-13 19:52:41 --> Language Class Initialized
INFO - 2021-04-13 19:52:41 --> Config Class Initialized
INFO - 2021-04-13 19:52:41 --> Hooks Class Initialized
ERROR - 2021-04-13 19:52:41 --> 404 Page Not Found: user/Assets/img
DEBUG - 2021-04-13 19:52:41 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:52:41 --> Utf8 Class Initialized
INFO - 2021-04-13 19:52:41 --> URI Class Initialized
INFO - 2021-04-13 19:52:41 --> Router Class Initialized
INFO - 2021-04-13 19:52:41 --> Output Class Initialized
INFO - 2021-04-13 19:52:41 --> Security Class Initialized
DEBUG - 2021-04-13 19:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:52:41 --> Input Class Initialized
INFO - 2021-04-13 19:52:41 --> Language Class Initialized
ERROR - 2021-04-13 19:52:41 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 19:52:41 --> Config Class Initialized
INFO - 2021-04-13 19:52:41 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:52:41 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:52:41 --> Utf8 Class Initialized
INFO - 2021-04-13 19:52:41 --> URI Class Initialized
INFO - 2021-04-13 19:52:41 --> Router Class Initialized
INFO - 2021-04-13 19:52:41 --> Output Class Initialized
INFO - 2021-04-13 19:52:41 --> Security Class Initialized
DEBUG - 2021-04-13 19:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:52:41 --> Input Class Initialized
INFO - 2021-04-13 19:52:41 --> Language Class Initialized
ERROR - 2021-04-13 19:52:41 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 19:52:41 --> Config Class Initialized
INFO - 2021-04-13 19:52:41 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:52:41 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:52:41 --> Utf8 Class Initialized
INFO - 2021-04-13 19:52:41 --> URI Class Initialized
INFO - 2021-04-13 19:52:41 --> Router Class Initialized
INFO - 2021-04-13 19:52:41 --> Output Class Initialized
INFO - 2021-04-13 19:52:41 --> Security Class Initialized
DEBUG - 2021-04-13 19:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:52:41 --> Input Class Initialized
INFO - 2021-04-13 19:52:41 --> Language Class Initialized
ERROR - 2021-04-13 19:52:41 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 19:52:41 --> Config Class Initialized
INFO - 2021-04-13 19:52:41 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:52:41 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:52:41 --> Utf8 Class Initialized
INFO - 2021-04-13 19:52:41 --> URI Class Initialized
INFO - 2021-04-13 19:52:41 --> Router Class Initialized
INFO - 2021-04-13 19:52:41 --> Output Class Initialized
INFO - 2021-04-13 19:52:41 --> Security Class Initialized
DEBUG - 2021-04-13 19:52:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:52:41 --> Input Class Initialized
INFO - 2021-04-13 19:52:41 --> Language Class Initialized
ERROR - 2021-04-13 19:52:41 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 19:53:12 --> Config Class Initialized
INFO - 2021-04-13 19:53:12 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:53:12 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:53:12 --> Utf8 Class Initialized
INFO - 2021-04-13 19:53:12 --> URI Class Initialized
INFO - 2021-04-13 19:53:12 --> Router Class Initialized
INFO - 2021-04-13 19:53:12 --> Output Class Initialized
INFO - 2021-04-13 19:53:12 --> Security Class Initialized
DEBUG - 2021-04-13 19:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:53:12 --> Input Class Initialized
INFO - 2021-04-13 19:53:12 --> Language Class Initialized
INFO - 2021-04-13 19:53:12 --> Loader Class Initialized
INFO - 2021-04-13 19:53:12 --> Helper loaded: url_helper
INFO - 2021-04-13 19:53:12 --> Helper loaded: form_helper
INFO - 2021-04-13 19:53:12 --> Helper loaded: common_helper
INFO - 2021-04-13 19:53:12 --> Helper loaded: util_helper
INFO - 2021-04-13 19:53:12 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:53:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:53:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:53:12 --> Form Validation Class Initialized
INFO - 2021-04-13 19:53:12 --> Controller Class Initialized
INFO - 2021-04-13 19:53:12 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\account.php
INFO - 2021-04-13 19:53:12 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 19:53:12 --> Final output sent to browser
DEBUG - 2021-04-13 19:53:12 --> Total execution time: 0.0241
INFO - 2021-04-13 19:53:12 --> Config Class Initialized
INFO - 2021-04-13 19:53:12 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:53:12 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:53:12 --> Utf8 Class Initialized
INFO - 2021-04-13 19:53:12 --> URI Class Initialized
INFO - 2021-04-13 19:53:12 --> Router Class Initialized
INFO - 2021-04-13 19:53:12 --> Output Class Initialized
INFO - 2021-04-13 19:53:12 --> Security Class Initialized
INFO - 2021-04-13 19:53:12 --> Config Class Initialized
DEBUG - 2021-04-13 19:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:53:12 --> Hooks Class Initialized
INFO - 2021-04-13 19:53:12 --> Input Class Initialized
INFO - 2021-04-13 19:53:12 --> Language Class Initialized
INFO - 2021-04-13 19:53:12 --> Config Class Initialized
INFO - 2021-04-13 19:53:12 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:53:12 --> UTF-8 Support Enabled
ERROR - 2021-04-13 19:53:12 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:53:12 --> Utf8 Class Initialized
INFO - 2021-04-13 19:53:12 --> URI Class Initialized
DEBUG - 2021-04-13 19:53:12 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:53:12 --> Utf8 Class Initialized
INFO - 2021-04-13 19:53:12 --> Router Class Initialized
INFO - 2021-04-13 19:53:12 --> URI Class Initialized
INFO - 2021-04-13 19:53:12 --> Output Class Initialized
INFO - 2021-04-13 19:53:12 --> Router Class Initialized
INFO - 2021-04-13 19:53:12 --> Security Class Initialized
INFO - 2021-04-13 19:53:12 --> Output Class Initialized
DEBUG - 2021-04-13 19:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:53:12 --> Input Class Initialized
INFO - 2021-04-13 19:53:12 --> Security Class Initialized
INFO - 2021-04-13 19:53:12 --> Language Class Initialized
DEBUG - 2021-04-13 19:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:53:12 --> Input Class Initialized
INFO - 2021-04-13 19:53:12 --> Language Class Initialized
ERROR - 2021-04-13 19:53:12 --> 404 Page Not Found: user/Assets/css
ERROR - 2021-04-13 19:53:12 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:53:12 --> Config Class Initialized
INFO - 2021-04-13 19:53:12 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:53:12 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:53:12 --> Utf8 Class Initialized
INFO - 2021-04-13 19:53:12 --> URI Class Initialized
INFO - 2021-04-13 19:53:12 --> Config Class Initialized
INFO - 2021-04-13 19:53:12 --> Hooks Class Initialized
INFO - 2021-04-13 19:53:12 --> Router Class Initialized
INFO - 2021-04-13 19:53:12 --> Output Class Initialized
DEBUG - 2021-04-13 19:53:12 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:53:12 --> Utf8 Class Initialized
INFO - 2021-04-13 19:53:12 --> Security Class Initialized
INFO - 2021-04-13 19:53:12 --> Config Class Initialized
INFO - 2021-04-13 19:53:12 --> Hooks Class Initialized
INFO - 2021-04-13 19:53:12 --> URI Class Initialized
DEBUG - 2021-04-13 19:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:53:12 --> Input Class Initialized
INFO - 2021-04-13 19:53:12 --> Language Class Initialized
INFO - 2021-04-13 19:53:12 --> Router Class Initialized
DEBUG - 2021-04-13 19:53:12 --> UTF-8 Support Enabled
ERROR - 2021-04-13 19:53:12 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:53:12 --> Utf8 Class Initialized
INFO - 2021-04-13 19:53:12 --> Output Class Initialized
INFO - 2021-04-13 19:53:12 --> URI Class Initialized
INFO - 2021-04-13 19:53:12 --> Router Class Initialized
INFO - 2021-04-13 19:53:12 --> Security Class Initialized
INFO - 2021-04-13 19:53:12 --> Output Class Initialized
DEBUG - 2021-04-13 19:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:53:12 --> Input Class Initialized
INFO - 2021-04-13 19:53:12 --> Security Class Initialized
INFO - 2021-04-13 19:53:12 --> Language Class Initialized
DEBUG - 2021-04-13 19:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:53:12 --> Input Class Initialized
INFO - 2021-04-13 19:53:12 --> Language Class Initialized
ERROR - 2021-04-13 19:53:12 --> 404 Page Not Found: user/Assets/css
ERROR - 2021-04-13 19:53:12 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 19:53:12 --> Config Class Initialized
INFO - 2021-04-13 19:53:12 --> Hooks Class Initialized
INFO - 2021-04-13 19:53:12 --> Config Class Initialized
INFO - 2021-04-13 19:53:12 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:53:12 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:53:12 --> Utf8 Class Initialized
DEBUG - 2021-04-13 19:53:12 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:53:12 --> Utf8 Class Initialized
INFO - 2021-04-13 19:53:12 --> URI Class Initialized
INFO - 2021-04-13 19:53:12 --> URI Class Initialized
INFO - 2021-04-13 19:53:12 --> Router Class Initialized
INFO - 2021-04-13 19:53:12 --> Router Class Initialized
INFO - 2021-04-13 19:53:12 --> Output Class Initialized
INFO - 2021-04-13 19:53:12 --> Output Class Initialized
INFO - 2021-04-13 19:53:12 --> Config Class Initialized
INFO - 2021-04-13 19:53:12 --> Hooks Class Initialized
INFO - 2021-04-13 19:53:12 --> Security Class Initialized
INFO - 2021-04-13 19:53:12 --> Security Class Initialized
DEBUG - 2021-04-13 19:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:53:12 --> Input Class Initialized
INFO - 2021-04-13 19:53:12 --> Config Class Initialized
INFO - 2021-04-13 19:53:12 --> Hooks Class Initialized
INFO - 2021-04-13 19:53:12 --> Language Class Initialized
DEBUG - 2021-04-13 19:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 19:53:12 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:53:12 --> Input Class Initialized
INFO - 2021-04-13 19:53:12 --> Utf8 Class Initialized
INFO - 2021-04-13 19:53:12 --> Language Class Initialized
INFO - 2021-04-13 19:53:12 --> URI Class Initialized
ERROR - 2021-04-13 19:53:12 --> 404 Page Not Found: user/Assets/js
DEBUG - 2021-04-13 19:53:12 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:53:12 --> Utf8 Class Initialized
INFO - 2021-04-13 19:53:12 --> Router Class Initialized
ERROR - 2021-04-13 19:53:12 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 19:53:12 --> URI Class Initialized
INFO - 2021-04-13 19:53:12 --> Output Class Initialized
INFO - 2021-04-13 19:53:12 --> Router Class Initialized
INFO - 2021-04-13 19:53:12 --> Security Class Initialized
INFO - 2021-04-13 19:53:12 --> Output Class Initialized
DEBUG - 2021-04-13 19:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:53:12 --> Input Class Initialized
INFO - 2021-04-13 19:53:12 --> Security Class Initialized
INFO - 2021-04-13 19:53:12 --> Language Class Initialized
DEBUG - 2021-04-13 19:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:53:12 --> Input Class Initialized
INFO - 2021-04-13 19:53:12 --> Language Class Initialized
ERROR - 2021-04-13 19:53:12 --> 404 Page Not Found: user/Assets/js
ERROR - 2021-04-13 19:53:12 --> 404 Page Not Found: user/Assets/img
INFO - 2021-04-13 19:53:12 --> Config Class Initialized
INFO - 2021-04-13 19:53:12 --> Hooks Class Initialized
INFO - 2021-04-13 19:53:12 --> Config Class Initialized
INFO - 2021-04-13 19:53:12 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:53:12 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:53:12 --> Utf8 Class Initialized
DEBUG - 2021-04-13 19:53:12 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:53:12 --> Utf8 Class Initialized
INFO - 2021-04-13 19:53:12 --> URI Class Initialized
INFO - 2021-04-13 19:53:12 --> URI Class Initialized
INFO - 2021-04-13 19:53:12 --> Router Class Initialized
INFO - 2021-04-13 19:53:12 --> Router Class Initialized
INFO - 2021-04-13 19:53:12 --> Output Class Initialized
INFO - 2021-04-13 19:53:12 --> Output Class Initialized
INFO - 2021-04-13 19:53:12 --> Security Class Initialized
INFO - 2021-04-13 19:53:12 --> Security Class Initialized
DEBUG - 2021-04-13 19:53:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 19:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:53:12 --> Input Class Initialized
INFO - 2021-04-13 19:53:12 --> Input Class Initialized
INFO - 2021-04-13 19:53:12 --> Language Class Initialized
INFO - 2021-04-13 19:53:12 --> Language Class Initialized
ERROR - 2021-04-13 19:53:12 --> 404 Page Not Found: user/Assets/img
ERROR - 2021-04-13 19:53:12 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:53:12 --> Config Class Initialized
INFO - 2021-04-13 19:53:12 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:53:12 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:53:12 --> Utf8 Class Initialized
INFO - 2021-04-13 19:53:12 --> URI Class Initialized
INFO - 2021-04-13 19:53:12 --> Router Class Initialized
INFO - 2021-04-13 19:53:12 --> Output Class Initialized
INFO - 2021-04-13 19:53:12 --> Security Class Initialized
DEBUG - 2021-04-13 19:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:53:12 --> Input Class Initialized
INFO - 2021-04-13 19:53:12 --> Language Class Initialized
ERROR - 2021-04-13 19:53:12 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:53:12 --> Config Class Initialized
INFO - 2021-04-13 19:53:12 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:53:12 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:53:12 --> Utf8 Class Initialized
INFO - 2021-04-13 19:53:12 --> URI Class Initialized
INFO - 2021-04-13 19:53:12 --> Router Class Initialized
INFO - 2021-04-13 19:53:12 --> Output Class Initialized
INFO - 2021-04-13 19:53:12 --> Security Class Initialized
DEBUG - 2021-04-13 19:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:53:12 --> Input Class Initialized
INFO - 2021-04-13 19:53:12 --> Language Class Initialized
ERROR - 2021-04-13 19:53:12 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:53:12 --> Config Class Initialized
INFO - 2021-04-13 19:53:12 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:53:12 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:53:12 --> Utf8 Class Initialized
INFO - 2021-04-13 19:53:12 --> URI Class Initialized
INFO - 2021-04-13 19:53:12 --> Router Class Initialized
INFO - 2021-04-13 19:53:12 --> Output Class Initialized
INFO - 2021-04-13 19:53:12 --> Security Class Initialized
DEBUG - 2021-04-13 19:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:53:12 --> Input Class Initialized
INFO - 2021-04-13 19:53:12 --> Language Class Initialized
ERROR - 2021-04-13 19:53:12 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 19:53:12 --> Config Class Initialized
INFO - 2021-04-13 19:53:12 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:53:12 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:53:12 --> Utf8 Class Initialized
INFO - 2021-04-13 19:53:12 --> URI Class Initialized
INFO - 2021-04-13 19:53:12 --> Router Class Initialized
INFO - 2021-04-13 19:53:12 --> Output Class Initialized
INFO - 2021-04-13 19:53:12 --> Security Class Initialized
DEBUG - 2021-04-13 19:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:53:12 --> Input Class Initialized
INFO - 2021-04-13 19:53:12 --> Language Class Initialized
ERROR - 2021-04-13 19:53:12 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 19:53:12 --> Config Class Initialized
INFO - 2021-04-13 19:53:12 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:53:12 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:53:12 --> Utf8 Class Initialized
INFO - 2021-04-13 19:53:12 --> URI Class Initialized
INFO - 2021-04-13 19:53:12 --> Router Class Initialized
INFO - 2021-04-13 19:53:12 --> Output Class Initialized
INFO - 2021-04-13 19:53:12 --> Security Class Initialized
DEBUG - 2021-04-13 19:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:53:12 --> Input Class Initialized
INFO - 2021-04-13 19:53:12 --> Language Class Initialized
ERROR - 2021-04-13 19:53:12 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 19:53:12 --> Config Class Initialized
INFO - 2021-04-13 19:53:12 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:53:12 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:53:12 --> Utf8 Class Initialized
INFO - 2021-04-13 19:53:12 --> URI Class Initialized
INFO - 2021-04-13 19:53:12 --> Router Class Initialized
INFO - 2021-04-13 19:53:12 --> Output Class Initialized
INFO - 2021-04-13 19:53:12 --> Security Class Initialized
DEBUG - 2021-04-13 19:53:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:53:12 --> Input Class Initialized
INFO - 2021-04-13 19:53:12 --> Language Class Initialized
ERROR - 2021-04-13 19:53:12 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 19:53:31 --> Config Class Initialized
INFO - 2021-04-13 19:53:31 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:53:31 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:53:31 --> Utf8 Class Initialized
INFO - 2021-04-13 19:53:31 --> URI Class Initialized
INFO - 2021-04-13 19:53:31 --> Router Class Initialized
INFO - 2021-04-13 19:53:31 --> Output Class Initialized
INFO - 2021-04-13 19:53:31 --> Security Class Initialized
DEBUG - 2021-04-13 19:53:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:53:31 --> Input Class Initialized
INFO - 2021-04-13 19:53:31 --> Language Class Initialized
INFO - 2021-04-13 19:53:31 --> Loader Class Initialized
INFO - 2021-04-13 19:53:31 --> Helper loaded: url_helper
INFO - 2021-04-13 19:53:31 --> Helper loaded: form_helper
INFO - 2021-04-13 19:53:31 --> Helper loaded: common_helper
INFO - 2021-04-13 19:53:31 --> Helper loaded: util_helper
INFO - 2021-04-13 19:53:31 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:53:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:53:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:53:31 --> Form Validation Class Initialized
INFO - 2021-04-13 19:53:31 --> Controller Class Initialized
INFO - 2021-04-13 19:53:31 --> Final output sent to browser
DEBUG - 2021-04-13 19:53:31 --> Total execution time: 0.0342
INFO - 2021-04-13 19:53:42 --> Config Class Initialized
INFO - 2021-04-13 19:53:42 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:53:42 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:53:42 --> Utf8 Class Initialized
INFO - 2021-04-13 19:53:42 --> URI Class Initialized
INFO - 2021-04-13 19:53:42 --> Router Class Initialized
INFO - 2021-04-13 19:53:42 --> Output Class Initialized
INFO - 2021-04-13 19:53:42 --> Security Class Initialized
DEBUG - 2021-04-13 19:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:53:42 --> Input Class Initialized
INFO - 2021-04-13 19:53:42 --> Language Class Initialized
INFO - 2021-04-13 19:53:42 --> Loader Class Initialized
INFO - 2021-04-13 19:53:42 --> Helper loaded: url_helper
INFO - 2021-04-13 19:53:42 --> Helper loaded: form_helper
INFO - 2021-04-13 19:53:42 --> Helper loaded: common_helper
INFO - 2021-04-13 19:53:42 --> Helper loaded: util_helper
INFO - 2021-04-13 19:53:42 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:53:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:53:42 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:53:42 --> Form Validation Class Initialized
INFO - 2021-04-13 19:53:42 --> Controller Class Initialized
INFO - 2021-04-13 19:53:42 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-13 19:53:42 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 19:53:42 --> Final output sent to browser
DEBUG - 2021-04-13 19:53:42 --> Total execution time: 0.0259
INFO - 2021-04-13 19:53:42 --> Config Class Initialized
INFO - 2021-04-13 19:53:42 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:53:42 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:53:42 --> Utf8 Class Initialized
INFO - 2021-04-13 19:53:42 --> URI Class Initialized
INFO - 2021-04-13 19:53:42 --> Router Class Initialized
INFO - 2021-04-13 19:53:42 --> Output Class Initialized
INFO - 2021-04-13 19:53:42 --> Security Class Initialized
DEBUG - 2021-04-13 19:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:53:42 --> Input Class Initialized
INFO - 2021-04-13 19:53:42 --> Language Class Initialized
ERROR - 2021-04-13 19:53:42 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:53:42 --> Config Class Initialized
INFO - 2021-04-13 19:53:42 --> Hooks Class Initialized
INFO - 2021-04-13 19:53:42 --> Config Class Initialized
DEBUG - 2021-04-13 19:53:42 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:53:42 --> Config Class Initialized
INFO - 2021-04-13 19:53:42 --> Utf8 Class Initialized
INFO - 2021-04-13 19:53:42 --> Hooks Class Initialized
INFO - 2021-04-13 19:53:42 --> URI Class Initialized
DEBUG - 2021-04-13 19:53:42 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:53:42 --> Router Class Initialized
INFO - 2021-04-13 19:53:42 --> Utf8 Class Initialized
INFO - 2021-04-13 19:53:42 --> Config Class Initialized
INFO - 2021-04-13 19:53:42 --> Hooks Class Initialized
INFO - 2021-04-13 19:53:42 --> Output Class Initialized
INFO - 2021-04-13 19:53:42 --> Security Class Initialized
DEBUG - 2021-04-13 19:53:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 19:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:53:42 --> Utf8 Class Initialized
INFO - 2021-04-13 19:53:42 --> Input Class Initialized
INFO - 2021-04-13 19:53:42 --> Language Class Initialized
INFO - 2021-04-13 19:53:42 --> URI Class Initialized
INFO - 2021-04-13 19:53:42 --> URI Class Initialized
INFO - 2021-04-13 19:53:42 --> Router Class Initialized
INFO - 2021-04-13 19:53:42 --> Router Class Initialized
INFO - 2021-04-13 19:53:42 --> Config Class Initialized
INFO - 2021-04-13 19:53:42 --> Hooks Class Initialized
INFO - 2021-04-13 19:53:42 --> Output Class Initialized
INFO - 2021-04-13 19:53:42 --> Output Class Initialized
INFO - 2021-04-13 19:53:42 --> Security Class Initialized
DEBUG - 2021-04-13 19:53:42 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:53:42 --> Security Class Initialized
INFO - 2021-04-13 19:53:42 --> Utf8 Class Initialized
DEBUG - 2021-04-13 19:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:53:42 --> Input Class Initialized
DEBUG - 2021-04-13 19:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:53:42 --> Input Class Initialized
INFO - 2021-04-13 19:53:42 --> Language Class Initialized
INFO - 2021-04-13 19:53:42 --> URI Class Initialized
INFO - 2021-04-13 19:53:42 --> Hooks Class Initialized
INFO - 2021-04-13 19:53:42 --> Language Class Initialized
INFO - 2021-04-13 19:53:42 --> Router Class Initialized
ERROR - 2021-04-13 19:53:42 --> 404 Page Not Found: user/Assets/css
DEBUG - 2021-04-13 19:53:42 --> UTF-8 Support Enabled
ERROR - 2021-04-13 19:53:42 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:53:42 --> Output Class Initialized
INFO - 2021-04-13 19:53:42 --> Utf8 Class Initialized
INFO - 2021-04-13 19:53:42 --> URI Class Initialized
INFO - 2021-04-13 19:53:42 --> Security Class Initialized
INFO - 2021-04-13 19:53:42 --> Router Class Initialized
ERROR - 2021-04-13 19:53:42 --> 404 Page Not Found: user/Assets/css
DEBUG - 2021-04-13 19:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:53:42 --> Input Class Initialized
INFO - 2021-04-13 19:53:42 --> Language Class Initialized
INFO - 2021-04-13 19:53:42 --> Output Class Initialized
INFO - 2021-04-13 19:53:42 --> Config Class Initialized
INFO - 2021-04-13 19:53:42 --> Hooks Class Initialized
ERROR - 2021-04-13 19:53:42 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 19:53:42 --> Security Class Initialized
DEBUG - 2021-04-13 19:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:53:42 --> Input Class Initialized
DEBUG - 2021-04-13 19:53:42 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:53:42 --> Utf8 Class Initialized
INFO - 2021-04-13 19:53:42 --> Language Class Initialized
INFO - 2021-04-13 19:53:42 --> URI Class Initialized
ERROR - 2021-04-13 19:53:42 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:53:42 --> Router Class Initialized
INFO - 2021-04-13 19:53:42 --> Output Class Initialized
INFO - 2021-04-13 19:53:42 --> Security Class Initialized
INFO - 2021-04-13 19:53:42 --> Config Class Initialized
INFO - 2021-04-13 19:53:42 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:53:42 --> Input Class Initialized
INFO - 2021-04-13 19:53:42 --> Config Class Initialized
INFO - 2021-04-13 19:53:42 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:53:42 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:53:42 --> Utf8 Class Initialized
INFO - 2021-04-13 19:53:42 --> Language Class Initialized
INFO - 2021-04-13 19:53:42 --> URI Class Initialized
DEBUG - 2021-04-13 19:53:42 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:53:42 --> Utf8 Class Initialized
INFO - 2021-04-13 19:53:42 --> Router Class Initialized
ERROR - 2021-04-13 19:53:42 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 19:53:42 --> URI Class Initialized
INFO - 2021-04-13 19:53:42 --> Router Class Initialized
INFO - 2021-04-13 19:53:42 --> Output Class Initialized
INFO - 2021-04-13 19:53:42 --> Output Class Initialized
INFO - 2021-04-13 19:53:42 --> Security Class Initialized
INFO - 2021-04-13 19:53:42 --> Security Class Initialized
DEBUG - 2021-04-13 19:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:53:42 --> Input Class Initialized
DEBUG - 2021-04-13 19:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:53:42 --> Language Class Initialized
INFO - 2021-04-13 19:53:42 --> Input Class Initialized
ERROR - 2021-04-13 19:53:42 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 19:53:42 --> Language Class Initialized
INFO - 2021-04-13 19:53:42 --> Config Class Initialized
INFO - 2021-04-13 19:53:42 --> Hooks Class Initialized
INFO - 2021-04-13 19:53:42 --> Config Class Initialized
INFO - 2021-04-13 19:53:42 --> Hooks Class Initialized
ERROR - 2021-04-13 19:53:42 --> 404 Page Not Found: user/Assets/js
DEBUG - 2021-04-13 19:53:42 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:53:42 --> Utf8 Class Initialized
DEBUG - 2021-04-13 19:53:42 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:53:42 --> Utf8 Class Initialized
INFO - 2021-04-13 19:53:42 --> URI Class Initialized
INFO - 2021-04-13 19:53:42 --> URI Class Initialized
INFO - 2021-04-13 19:53:42 --> Router Class Initialized
INFO - 2021-04-13 19:53:42 --> Router Class Initialized
INFO - 2021-04-13 19:53:42 --> Output Class Initialized
INFO - 2021-04-13 19:53:42 --> Output Class Initialized
INFO - 2021-04-13 19:53:42 --> Config Class Initialized
INFO - 2021-04-13 19:53:42 --> Hooks Class Initialized
INFO - 2021-04-13 19:53:42 --> Security Class Initialized
INFO - 2021-04-13 19:53:42 --> Security Class Initialized
DEBUG - 2021-04-13 19:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:53:42 --> Input Class Initialized
DEBUG - 2021-04-13 19:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:53:42 --> Input Class Initialized
DEBUG - 2021-04-13 19:53:42 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:53:42 --> Language Class Initialized
INFO - 2021-04-13 19:53:42 --> Utf8 Class Initialized
INFO - 2021-04-13 19:53:42 --> Language Class Initialized
INFO - 2021-04-13 19:53:42 --> URI Class Initialized
ERROR - 2021-04-13 19:53:42 --> 404 Page Not Found: user/Assets/img
ERROR - 2021-04-13 19:53:42 --> 404 Page Not Found: user/Assets/img
INFO - 2021-04-13 19:53:42 --> Router Class Initialized
INFO - 2021-04-13 19:53:42 --> Output Class Initialized
INFO - 2021-04-13 19:53:42 --> Security Class Initialized
DEBUG - 2021-04-13 19:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:53:42 --> Input Class Initialized
INFO - 2021-04-13 19:53:42 --> Language Class Initialized
ERROR - 2021-04-13 19:53:42 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:53:42 --> Config Class Initialized
INFO - 2021-04-13 19:53:42 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:53:42 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:53:42 --> Utf8 Class Initialized
INFO - 2021-04-13 19:53:42 --> URI Class Initialized
INFO - 2021-04-13 19:53:42 --> Router Class Initialized
INFO - 2021-04-13 19:53:42 --> Output Class Initialized
INFO - 2021-04-13 19:53:42 --> Security Class Initialized
DEBUG - 2021-04-13 19:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:53:42 --> Input Class Initialized
INFO - 2021-04-13 19:53:42 --> Language Class Initialized
ERROR - 2021-04-13 19:53:42 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:53:42 --> Config Class Initialized
INFO - 2021-04-13 19:53:42 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:53:42 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:53:42 --> Utf8 Class Initialized
INFO - 2021-04-13 19:53:42 --> URI Class Initialized
INFO - 2021-04-13 19:53:42 --> Router Class Initialized
INFO - 2021-04-13 19:53:42 --> Output Class Initialized
INFO - 2021-04-13 19:53:42 --> Security Class Initialized
DEBUG - 2021-04-13 19:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:53:42 --> Input Class Initialized
INFO - 2021-04-13 19:53:42 --> Language Class Initialized
ERROR - 2021-04-13 19:53:42 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:53:42 --> Config Class Initialized
INFO - 2021-04-13 19:53:42 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:53:42 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:53:42 --> Utf8 Class Initialized
INFO - 2021-04-13 19:53:42 --> URI Class Initialized
INFO - 2021-04-13 19:53:42 --> Router Class Initialized
INFO - 2021-04-13 19:53:42 --> Output Class Initialized
INFO - 2021-04-13 19:53:42 --> Security Class Initialized
DEBUG - 2021-04-13 19:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:53:42 --> Input Class Initialized
INFO - 2021-04-13 19:53:42 --> Language Class Initialized
ERROR - 2021-04-13 19:53:42 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:53:42 --> Config Class Initialized
INFO - 2021-04-13 19:53:42 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:53:42 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:53:42 --> Utf8 Class Initialized
INFO - 2021-04-13 19:53:42 --> URI Class Initialized
INFO - 2021-04-13 19:53:42 --> Router Class Initialized
INFO - 2021-04-13 19:53:42 --> Output Class Initialized
INFO - 2021-04-13 19:53:42 --> Security Class Initialized
DEBUG - 2021-04-13 19:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:53:42 --> Input Class Initialized
INFO - 2021-04-13 19:53:42 --> Language Class Initialized
ERROR - 2021-04-13 19:53:42 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 19:53:42 --> Config Class Initialized
INFO - 2021-04-13 19:53:42 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:53:42 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:53:42 --> Utf8 Class Initialized
INFO - 2021-04-13 19:53:42 --> URI Class Initialized
INFO - 2021-04-13 19:53:42 --> Router Class Initialized
INFO - 2021-04-13 19:53:42 --> Output Class Initialized
INFO - 2021-04-13 19:53:42 --> Security Class Initialized
DEBUG - 2021-04-13 19:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:53:42 --> Input Class Initialized
INFO - 2021-04-13 19:53:42 --> Language Class Initialized
ERROR - 2021-04-13 19:53:42 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 19:53:42 --> Config Class Initialized
INFO - 2021-04-13 19:53:42 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:53:42 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:53:42 --> Utf8 Class Initialized
INFO - 2021-04-13 19:53:42 --> URI Class Initialized
INFO - 2021-04-13 19:53:42 --> Router Class Initialized
INFO - 2021-04-13 19:53:42 --> Output Class Initialized
INFO - 2021-04-13 19:53:42 --> Security Class Initialized
DEBUG - 2021-04-13 19:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:53:42 --> Input Class Initialized
INFO - 2021-04-13 19:53:42 --> Language Class Initialized
ERROR - 2021-04-13 19:53:42 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 19:53:42 --> Config Class Initialized
INFO - 2021-04-13 19:53:42 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:53:42 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:53:42 --> Utf8 Class Initialized
INFO - 2021-04-13 19:53:42 --> URI Class Initialized
INFO - 2021-04-13 19:53:42 --> Router Class Initialized
INFO - 2021-04-13 19:53:42 --> Output Class Initialized
INFO - 2021-04-13 19:53:42 --> Security Class Initialized
DEBUG - 2021-04-13 19:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:53:42 --> Input Class Initialized
INFO - 2021-04-13 19:53:42 --> Language Class Initialized
ERROR - 2021-04-13 19:53:42 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 19:54:22 --> Config Class Initialized
INFO - 2021-04-13 19:54:22 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:54:22 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:54:22 --> Utf8 Class Initialized
INFO - 2021-04-13 19:54:22 --> URI Class Initialized
INFO - 2021-04-13 19:54:22 --> Router Class Initialized
INFO - 2021-04-13 19:54:22 --> Output Class Initialized
INFO - 2021-04-13 19:54:22 --> Security Class Initialized
DEBUG - 2021-04-13 19:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:54:22 --> Input Class Initialized
INFO - 2021-04-13 19:54:22 --> Language Class Initialized
INFO - 2021-04-13 19:54:22 --> Loader Class Initialized
INFO - 2021-04-13 19:54:22 --> Helper loaded: url_helper
INFO - 2021-04-13 19:54:22 --> Helper loaded: form_helper
INFO - 2021-04-13 19:54:22 --> Helper loaded: common_helper
INFO - 2021-04-13 19:54:22 --> Helper loaded: util_helper
INFO - 2021-04-13 19:54:22 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:54:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:54:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:54:22 --> Form Validation Class Initialized
INFO - 2021-04-13 19:54:22 --> Controller Class Initialized
INFO - 2021-04-13 19:54:22 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-13 19:54:22 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 19:54:22 --> Final output sent to browser
DEBUG - 2021-04-13 19:54:22 --> Total execution time: 0.0241
INFO - 2021-04-13 19:54:22 --> Config Class Initialized
INFO - 2021-04-13 19:54:22 --> Hooks Class Initialized
INFO - 2021-04-13 19:54:22 --> Config Class Initialized
INFO - 2021-04-13 19:54:22 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:54:22 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:54:22 --> Utf8 Class Initialized
INFO - 2021-04-13 19:54:22 --> Config Class Initialized
INFO - 2021-04-13 19:54:22 --> Hooks Class Initialized
INFO - 2021-04-13 19:54:22 --> URI Class Initialized
INFO - 2021-04-13 19:54:22 --> Config Class Initialized
INFO - 2021-04-13 19:54:22 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:54:22 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:54:22 --> Router Class Initialized
INFO - 2021-04-13 19:54:22 --> Utf8 Class Initialized
DEBUG - 2021-04-13 19:54:22 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:54:22 --> Utf8 Class Initialized
INFO - 2021-04-13 19:54:22 --> URI Class Initialized
DEBUG - 2021-04-13 19:54:22 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:54:22 --> Utf8 Class Initialized
INFO - 2021-04-13 19:54:22 --> Output Class Initialized
INFO - 2021-04-13 19:54:22 --> URI Class Initialized
INFO - 2021-04-13 19:54:22 --> Router Class Initialized
INFO - 2021-04-13 19:54:22 --> URI Class Initialized
INFO - 2021-04-13 19:54:22 --> Security Class Initialized
INFO - 2021-04-13 19:54:22 --> Router Class Initialized
INFO - 2021-04-13 19:54:22 --> Router Class Initialized
INFO - 2021-04-13 19:54:22 --> Output Class Initialized
DEBUG - 2021-04-13 19:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:54:22 --> Input Class Initialized
INFO - 2021-04-13 19:54:22 --> Language Class Initialized
INFO - 2021-04-13 19:54:22 --> Output Class Initialized
INFO - 2021-04-13 19:54:22 --> Security Class Initialized
INFO - 2021-04-13 19:54:22 --> Output Class Initialized
DEBUG - 2021-04-13 19:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:54:22 --> Security Class Initialized
INFO - 2021-04-13 19:54:22 --> Input Class Initialized
ERROR - 2021-04-13 19:54:22 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:54:22 --> Security Class Initialized
DEBUG - 2021-04-13 19:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:54:22 --> Language Class Initialized
INFO - 2021-04-13 19:54:22 --> Input Class Initialized
INFO - 2021-04-13 19:54:22 --> Language Class Initialized
DEBUG - 2021-04-13 19:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:54:22 --> Input Class Initialized
ERROR - 2021-04-13 19:54:22 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:54:22 --> Language Class Initialized
ERROR - 2021-04-13 19:54:22 --> 404 Page Not Found: user/Assets/css
ERROR - 2021-04-13 19:54:22 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:54:22 --> Config Class Initialized
INFO - 2021-04-13 19:54:22 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:54:22 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:54:22 --> Utf8 Class Initialized
INFO - 2021-04-13 19:54:22 --> Config Class Initialized
INFO - 2021-04-13 19:54:22 --> Hooks Class Initialized
INFO - 2021-04-13 19:54:22 --> URI Class Initialized
DEBUG - 2021-04-13 19:54:22 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:54:22 --> Utf8 Class Initialized
INFO - 2021-04-13 19:54:22 --> Router Class Initialized
INFO - 2021-04-13 19:54:22 --> URI Class Initialized
INFO - 2021-04-13 19:54:22 --> Output Class Initialized
INFO - 2021-04-13 19:54:22 --> Config Class Initialized
INFO - 2021-04-13 19:54:22 --> Hooks Class Initialized
INFO - 2021-04-13 19:54:22 --> Router Class Initialized
INFO - 2021-04-13 19:54:22 --> Security Class Initialized
DEBUG - 2021-04-13 19:54:22 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:54:22 --> Utf8 Class Initialized
INFO - 2021-04-13 19:54:22 --> Output Class Initialized
DEBUG - 2021-04-13 19:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:54:22 --> URI Class Initialized
INFO - 2021-04-13 19:54:22 --> Input Class Initialized
INFO - 2021-04-13 19:54:22 --> Security Class Initialized
INFO - 2021-04-13 19:54:22 --> Language Class Initialized
INFO - 2021-04-13 19:54:22 --> Router Class Initialized
DEBUG - 2021-04-13 19:54:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 19:54:22 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:54:22 --> Input Class Initialized
INFO - 2021-04-13 19:54:22 --> Output Class Initialized
INFO - 2021-04-13 19:54:22 --> Language Class Initialized
INFO - 2021-04-13 19:54:22 --> Security Class Initialized
ERROR - 2021-04-13 19:54:22 --> 404 Page Not Found: user/Assets/js
DEBUG - 2021-04-13 19:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:54:22 --> Input Class Initialized
INFO - 2021-04-13 19:54:22 --> Language Class Initialized
INFO - 2021-04-13 19:54:22 --> Config Class Initialized
INFO - 2021-04-13 19:54:22 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:54:22 --> UTF-8 Support Enabled
ERROR - 2021-04-13 19:54:22 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 19:54:22 --> Utf8 Class Initialized
INFO - 2021-04-13 19:54:22 --> URI Class Initialized
INFO - 2021-04-13 19:54:22 --> Config Class Initialized
INFO - 2021-04-13 19:54:22 --> Hooks Class Initialized
INFO - 2021-04-13 19:54:22 --> Router Class Initialized
INFO - 2021-04-13 19:54:22 --> Config Class Initialized
INFO - 2021-04-13 19:54:22 --> Hooks Class Initialized
INFO - 2021-04-13 19:54:22 --> Output Class Initialized
DEBUG - 2021-04-13 19:54:22 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:54:22 --> Utf8 Class Initialized
INFO - 2021-04-13 19:54:22 --> URI Class Initialized
INFO - 2021-04-13 19:54:22 --> Security Class Initialized
DEBUG - 2021-04-13 19:54:22 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:54:22 --> Utf8 Class Initialized
DEBUG - 2021-04-13 19:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:54:22 --> Router Class Initialized
INFO - 2021-04-13 19:54:22 --> Input Class Initialized
INFO - 2021-04-13 19:54:22 --> URI Class Initialized
INFO - 2021-04-13 19:54:22 --> Language Class Initialized
INFO - 2021-04-13 19:54:22 --> Output Class Initialized
INFO - 2021-04-13 19:54:22 --> Router Class Initialized
ERROR - 2021-04-13 19:54:22 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 19:54:22 --> Security Class Initialized
INFO - 2021-04-13 19:54:22 --> Output Class Initialized
DEBUG - 2021-04-13 19:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:54:22 --> Input Class Initialized
INFO - 2021-04-13 19:54:22 --> Language Class Initialized
INFO - 2021-04-13 19:54:22 --> Security Class Initialized
ERROR - 2021-04-13 19:54:22 --> 404 Page Not Found: user/Assets/img
DEBUG - 2021-04-13 19:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:54:22 --> Input Class Initialized
INFO - 2021-04-13 19:54:22 --> Language Class Initialized
INFO - 2021-04-13 19:54:22 --> Config Class Initialized
INFO - 2021-04-13 19:54:22 --> Hooks Class Initialized
ERROR - 2021-04-13 19:54:22 --> 404 Page Not Found: user/Assets/css
DEBUG - 2021-04-13 19:54:22 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:54:22 --> Utf8 Class Initialized
INFO - 2021-04-13 19:54:22 --> URI Class Initialized
INFO - 2021-04-13 19:54:22 --> Config Class Initialized
INFO - 2021-04-13 19:54:22 --> Hooks Class Initialized
INFO - 2021-04-13 19:54:22 --> Router Class Initialized
DEBUG - 2021-04-13 19:54:22 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:54:22 --> Utf8 Class Initialized
INFO - 2021-04-13 19:54:22 --> Output Class Initialized
INFO - 2021-04-13 19:54:22 --> URI Class Initialized
INFO - 2021-04-13 19:54:22 --> Security Class Initialized
INFO - 2021-04-13 19:54:22 --> Router Class Initialized
DEBUG - 2021-04-13 19:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:54:22 --> Input Class Initialized
INFO - 2021-04-13 19:54:22 --> Language Class Initialized
INFO - 2021-04-13 19:54:22 --> Output Class Initialized
ERROR - 2021-04-13 19:54:22 --> 404 Page Not Found: user/Assets/img
INFO - 2021-04-13 19:54:22 --> Security Class Initialized
INFO - 2021-04-13 19:54:22 --> Config Class Initialized
INFO - 2021-04-13 19:54:22 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:54:22 --> Input Class Initialized
INFO - 2021-04-13 19:54:22 --> Language Class Initialized
DEBUG - 2021-04-13 19:54:22 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:54:22 --> Utf8 Class Initialized
ERROR - 2021-04-13 19:54:22 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 19:54:22 --> URI Class Initialized
INFO - 2021-04-13 19:54:22 --> Router Class Initialized
INFO - 2021-04-13 19:54:22 --> Output Class Initialized
INFO - 2021-04-13 19:54:22 --> Security Class Initialized
DEBUG - 2021-04-13 19:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:54:22 --> Input Class Initialized
INFO - 2021-04-13 19:54:22 --> Language Class Initialized
ERROR - 2021-04-13 19:54:22 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:54:22 --> Config Class Initialized
INFO - 2021-04-13 19:54:22 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:54:22 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:54:22 --> Utf8 Class Initialized
INFO - 2021-04-13 19:54:22 --> URI Class Initialized
INFO - 2021-04-13 19:54:22 --> Router Class Initialized
INFO - 2021-04-13 19:54:22 --> Output Class Initialized
INFO - 2021-04-13 19:54:22 --> Security Class Initialized
DEBUG - 2021-04-13 19:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:54:22 --> Input Class Initialized
INFO - 2021-04-13 19:54:22 --> Language Class Initialized
ERROR - 2021-04-13 19:54:22 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:54:22 --> Config Class Initialized
INFO - 2021-04-13 19:54:22 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:54:22 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:54:22 --> Utf8 Class Initialized
INFO - 2021-04-13 19:54:22 --> URI Class Initialized
INFO - 2021-04-13 19:54:22 --> Router Class Initialized
INFO - 2021-04-13 19:54:22 --> Output Class Initialized
INFO - 2021-04-13 19:54:22 --> Security Class Initialized
DEBUG - 2021-04-13 19:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:54:22 --> Input Class Initialized
INFO - 2021-04-13 19:54:22 --> Language Class Initialized
ERROR - 2021-04-13 19:54:22 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:54:22 --> Config Class Initialized
INFO - 2021-04-13 19:54:22 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:54:22 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:54:22 --> Utf8 Class Initialized
INFO - 2021-04-13 19:54:22 --> URI Class Initialized
INFO - 2021-04-13 19:54:22 --> Router Class Initialized
INFO - 2021-04-13 19:54:22 --> Output Class Initialized
INFO - 2021-04-13 19:54:22 --> Security Class Initialized
DEBUG - 2021-04-13 19:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:54:22 --> Input Class Initialized
INFO - 2021-04-13 19:54:22 --> Language Class Initialized
ERROR - 2021-04-13 19:54:22 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:54:22 --> Config Class Initialized
INFO - 2021-04-13 19:54:22 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:54:22 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:54:22 --> Utf8 Class Initialized
INFO - 2021-04-13 19:54:22 --> URI Class Initialized
INFO - 2021-04-13 19:54:22 --> Router Class Initialized
INFO - 2021-04-13 19:54:22 --> Output Class Initialized
INFO - 2021-04-13 19:54:22 --> Security Class Initialized
DEBUG - 2021-04-13 19:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:54:22 --> Input Class Initialized
INFO - 2021-04-13 19:54:22 --> Language Class Initialized
ERROR - 2021-04-13 19:54:22 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 19:54:22 --> Config Class Initialized
INFO - 2021-04-13 19:54:22 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:54:22 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:54:22 --> Utf8 Class Initialized
INFO - 2021-04-13 19:54:22 --> URI Class Initialized
INFO - 2021-04-13 19:54:22 --> Router Class Initialized
INFO - 2021-04-13 19:54:22 --> Output Class Initialized
INFO - 2021-04-13 19:54:22 --> Security Class Initialized
DEBUG - 2021-04-13 19:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:54:22 --> Input Class Initialized
INFO - 2021-04-13 19:54:22 --> Language Class Initialized
ERROR - 2021-04-13 19:54:22 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 19:54:22 --> Config Class Initialized
INFO - 2021-04-13 19:54:22 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:54:22 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:54:22 --> Utf8 Class Initialized
INFO - 2021-04-13 19:54:22 --> URI Class Initialized
INFO - 2021-04-13 19:54:22 --> Router Class Initialized
INFO - 2021-04-13 19:54:22 --> Output Class Initialized
INFO - 2021-04-13 19:54:22 --> Security Class Initialized
DEBUG - 2021-04-13 19:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:54:22 --> Input Class Initialized
INFO - 2021-04-13 19:54:22 --> Language Class Initialized
ERROR - 2021-04-13 19:54:22 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 19:54:22 --> Config Class Initialized
INFO - 2021-04-13 19:54:22 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:54:22 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:54:22 --> Utf8 Class Initialized
INFO - 2021-04-13 19:54:22 --> URI Class Initialized
INFO - 2021-04-13 19:54:22 --> Router Class Initialized
INFO - 2021-04-13 19:54:22 --> Output Class Initialized
INFO - 2021-04-13 19:54:22 --> Security Class Initialized
DEBUG - 2021-04-13 19:54:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:54:22 --> Input Class Initialized
INFO - 2021-04-13 19:54:22 --> Language Class Initialized
ERROR - 2021-04-13 19:54:22 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 19:55:07 --> Config Class Initialized
INFO - 2021-04-13 19:55:07 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:55:07 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:55:07 --> Utf8 Class Initialized
INFO - 2021-04-13 19:55:07 --> URI Class Initialized
INFO - 2021-04-13 19:55:07 --> Router Class Initialized
INFO - 2021-04-13 19:55:07 --> Output Class Initialized
INFO - 2021-04-13 19:55:07 --> Security Class Initialized
DEBUG - 2021-04-13 19:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:55:07 --> Input Class Initialized
INFO - 2021-04-13 19:55:07 --> Language Class Initialized
INFO - 2021-04-13 19:55:07 --> Loader Class Initialized
INFO - 2021-04-13 19:55:07 --> Helper loaded: url_helper
INFO - 2021-04-13 19:55:07 --> Helper loaded: form_helper
INFO - 2021-04-13 19:55:07 --> Helper loaded: common_helper
INFO - 2021-04-13 19:55:07 --> Helper loaded: util_helper
INFO - 2021-04-13 19:55:07 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:55:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:55:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:55:07 --> Form Validation Class Initialized
INFO - 2021-04-13 19:55:07 --> Controller Class Initialized
INFO - 2021-04-13 19:55:07 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-13 19:55:07 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 19:55:07 --> Final output sent to browser
DEBUG - 2021-04-13 19:55:07 --> Total execution time: 0.0348
INFO - 2021-04-13 19:55:07 --> Config Class Initialized
INFO - 2021-04-13 19:55:07 --> Hooks Class Initialized
INFO - 2021-04-13 19:55:07 --> Config Class Initialized
INFO - 2021-04-13 19:55:07 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:55:07 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:55:07 --> Utf8 Class Initialized
DEBUG - 2021-04-13 19:55:07 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:55:07 --> Utf8 Class Initialized
INFO - 2021-04-13 19:55:07 --> URI Class Initialized
INFO - 2021-04-13 19:55:07 --> URI Class Initialized
INFO - 2021-04-13 19:55:07 --> Config Class Initialized
INFO - 2021-04-13 19:55:07 --> Hooks Class Initialized
INFO - 2021-04-13 19:55:07 --> Router Class Initialized
INFO - 2021-04-13 19:55:07 --> Config Class Initialized
INFO - 2021-04-13 19:55:07 --> Router Class Initialized
INFO - 2021-04-13 19:55:07 --> Hooks Class Initialized
INFO - 2021-04-13 19:55:07 --> Output Class Initialized
INFO - 2021-04-13 19:55:07 --> Output Class Initialized
DEBUG - 2021-04-13 19:55:07 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:55:07 --> Utf8 Class Initialized
INFO - 2021-04-13 19:55:07 --> Security Class Initialized
INFO - 2021-04-13 19:55:07 --> URI Class Initialized
DEBUG - 2021-04-13 19:55:07 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:55:07 --> Utf8 Class Initialized
INFO - 2021-04-13 19:55:07 --> Config Class Initialized
DEBUG - 2021-04-13 19:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:55:07 --> Router Class Initialized
INFO - 2021-04-13 19:55:07 --> URI Class Initialized
INFO - 2021-04-13 19:55:07 --> Input Class Initialized
INFO - 2021-04-13 19:55:07 --> Language Class Initialized
INFO - 2021-04-13 19:55:07 --> Hooks Class Initialized
INFO - 2021-04-13 19:55:07 --> Router Class Initialized
INFO - 2021-04-13 19:55:07 --> Output Class Initialized
ERROR - 2021-04-13 19:55:07 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:55:07 --> Security Class Initialized
INFO - 2021-04-13 19:55:07 --> Output Class Initialized
DEBUG - 2021-04-13 19:55:07 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 19:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:55:07 --> Security Class Initialized
INFO - 2021-04-13 19:55:07 --> Input Class Initialized
INFO - 2021-04-13 19:55:07 --> Utf8 Class Initialized
INFO - 2021-04-13 19:55:07 --> Language Class Initialized
DEBUG - 2021-04-13 19:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:55:07 --> Input Class Initialized
ERROR - 2021-04-13 19:55:07 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 19:55:07 --> Security Class Initialized
INFO - 2021-04-13 19:55:07 --> URI Class Initialized
INFO - 2021-04-13 19:55:07 --> Language Class Initialized
INFO - 2021-04-13 19:55:07 --> Config Class Initialized
INFO - 2021-04-13 19:55:07 --> Router Class Initialized
INFO - 2021-04-13 19:55:07 --> Output Class Initialized
ERROR - 2021-04-13 19:55:07 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:55:07 --> Security Class Initialized
DEBUG - 2021-04-13 19:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:55:07 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:55:07 --> Input Class Initialized
INFO - 2021-04-13 19:55:07 --> Input Class Initialized
INFO - 2021-04-13 19:55:07 --> Language Class Initialized
INFO - 2021-04-13 19:55:07 --> Config Class Initialized
INFO - 2021-04-13 19:55:07 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:55:07 --> UTF-8 Support Enabled
ERROR - 2021-04-13 19:55:07 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:55:07 --> Utf8 Class Initialized
DEBUG - 2021-04-13 19:55:07 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:55:07 --> Utf8 Class Initialized
INFO - 2021-04-13 19:55:07 --> URI Class Initialized
INFO - 2021-04-13 19:55:07 --> URI Class Initialized
INFO - 2021-04-13 19:55:07 --> Router Class Initialized
INFO - 2021-04-13 19:55:07 --> Router Class Initialized
INFO - 2021-04-13 19:55:07 --> Output Class Initialized
INFO - 2021-04-13 19:55:07 --> Config Class Initialized
INFO - 2021-04-13 19:55:07 --> Hooks Class Initialized
INFO - 2021-04-13 19:55:07 --> Security Class Initialized
INFO - 2021-04-13 19:55:07 --> Output Class Initialized
DEBUG - 2021-04-13 19:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:55:07 --> Input Class Initialized
INFO - 2021-04-13 19:55:07 --> Language Class Initialized
DEBUG - 2021-04-13 19:55:07 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:55:07 --> Utf8 Class Initialized
INFO - 2021-04-13 19:55:07 --> Security Class Initialized
INFO - 2021-04-13 19:55:07 --> URI Class Initialized
ERROR - 2021-04-13 19:55:07 --> 404 Page Not Found: user/Assets/js
DEBUG - 2021-04-13 19:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:55:07 --> Router Class Initialized
INFO - 2021-04-13 19:55:07 --> Input Class Initialized
INFO - 2021-04-13 19:55:07 --> Output Class Initialized
INFO - 2021-04-13 19:55:07 --> Language Class Initialized
INFO - 2021-04-13 19:55:07 --> Security Class Initialized
ERROR - 2021-04-13 19:55:07 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:55:07 --> Config Class Initialized
DEBUG - 2021-04-13 19:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:55:07 --> Input Class Initialized
INFO - 2021-04-13 19:55:07 --> Hooks Class Initialized
INFO - 2021-04-13 19:55:07 --> Language Class Initialized
INFO - 2021-04-13 19:55:07 --> Config Class Initialized
ERROR - 2021-04-13 19:55:07 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 19:55:07 --> Language Class Initialized
DEBUG - 2021-04-13 19:55:07 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:55:07 --> Utf8 Class Initialized
ERROR - 2021-04-13 19:55:07 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:55:07 --> URI Class Initialized
INFO - 2021-04-13 19:55:07 --> Hooks Class Initialized
INFO - 2021-04-13 19:55:07 --> Router Class Initialized
DEBUG - 2021-04-13 19:55:07 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:55:07 --> Utf8 Class Initialized
INFO - 2021-04-13 19:55:07 --> Config Class Initialized
INFO - 2021-04-13 19:55:07 --> Output Class Initialized
INFO - 2021-04-13 19:55:07 --> Hooks Class Initialized
INFO - 2021-04-13 19:55:07 --> URI Class Initialized
INFO - 2021-04-13 19:55:07 --> Security Class Initialized
INFO - 2021-04-13 19:55:07 --> Router Class Initialized
DEBUG - 2021-04-13 19:55:07 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:55:07 --> Utf8 Class Initialized
DEBUG - 2021-04-13 19:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:55:07 --> Input Class Initialized
INFO - 2021-04-13 19:55:07 --> Output Class Initialized
INFO - 2021-04-13 19:55:07 --> Language Class Initialized
INFO - 2021-04-13 19:55:07 --> URI Class Initialized
INFO - 2021-04-13 19:55:07 --> Security Class Initialized
ERROR - 2021-04-13 19:55:07 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 19:55:07 --> Router Class Initialized
DEBUG - 2021-04-13 19:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:55:07 --> Input Class Initialized
INFO - 2021-04-13 19:55:07 --> Config Class Initialized
INFO - 2021-04-13 19:55:07 --> Hooks Class Initialized
INFO - 2021-04-13 19:55:07 --> Output Class Initialized
INFO - 2021-04-13 19:55:07 --> Language Class Initialized
DEBUG - 2021-04-13 19:55:07 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:55:07 --> Security Class Initialized
INFO - 2021-04-13 19:55:07 --> Utf8 Class Initialized
ERROR - 2021-04-13 19:55:07 --> 404 Page Not Found: user/Assets/img
INFO - 2021-04-13 19:55:07 --> URI Class Initialized
DEBUG - 2021-04-13 19:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:55:07 --> Input Class Initialized
INFO - 2021-04-13 19:55:07 --> Language Class Initialized
INFO - 2021-04-13 19:55:07 --> Router Class Initialized
ERROR - 2021-04-13 19:55:07 --> 404 Page Not Found: user/Assets/img
INFO - 2021-04-13 19:55:07 --> Output Class Initialized
INFO - 2021-04-13 19:55:07 --> Security Class Initialized
DEBUG - 2021-04-13 19:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:55:07 --> Input Class Initialized
INFO - 2021-04-13 19:55:07 --> Language Class Initialized
ERROR - 2021-04-13 19:55:07 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:55:07 --> Config Class Initialized
INFO - 2021-04-13 19:55:07 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:55:07 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:55:07 --> Utf8 Class Initialized
INFO - 2021-04-13 19:55:07 --> URI Class Initialized
INFO - 2021-04-13 19:55:07 --> Router Class Initialized
INFO - 2021-04-13 19:55:07 --> Output Class Initialized
INFO - 2021-04-13 19:55:07 --> Security Class Initialized
DEBUG - 2021-04-13 19:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:55:07 --> Input Class Initialized
INFO - 2021-04-13 19:55:07 --> Language Class Initialized
ERROR - 2021-04-13 19:55:07 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:55:07 --> Config Class Initialized
INFO - 2021-04-13 19:55:07 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:55:07 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:55:07 --> Utf8 Class Initialized
INFO - 2021-04-13 19:55:07 --> URI Class Initialized
INFO - 2021-04-13 19:55:07 --> Router Class Initialized
INFO - 2021-04-13 19:55:07 --> Output Class Initialized
INFO - 2021-04-13 19:55:07 --> Security Class Initialized
DEBUG - 2021-04-13 19:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:55:07 --> Input Class Initialized
INFO - 2021-04-13 19:55:07 --> Language Class Initialized
ERROR - 2021-04-13 19:55:07 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:55:07 --> Config Class Initialized
INFO - 2021-04-13 19:55:07 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:55:07 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:55:07 --> Utf8 Class Initialized
INFO - 2021-04-13 19:55:07 --> URI Class Initialized
INFO - 2021-04-13 19:55:07 --> Router Class Initialized
INFO - 2021-04-13 19:55:07 --> Output Class Initialized
INFO - 2021-04-13 19:55:07 --> Security Class Initialized
DEBUG - 2021-04-13 19:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:55:07 --> Input Class Initialized
INFO - 2021-04-13 19:55:07 --> Language Class Initialized
ERROR - 2021-04-13 19:55:07 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:55:07 --> Config Class Initialized
INFO - 2021-04-13 19:55:07 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:55:07 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:55:07 --> Utf8 Class Initialized
INFO - 2021-04-13 19:55:07 --> URI Class Initialized
INFO - 2021-04-13 19:55:07 --> Router Class Initialized
INFO - 2021-04-13 19:55:07 --> Output Class Initialized
INFO - 2021-04-13 19:55:07 --> Security Class Initialized
DEBUG - 2021-04-13 19:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:55:07 --> Input Class Initialized
INFO - 2021-04-13 19:55:07 --> Language Class Initialized
ERROR - 2021-04-13 19:55:07 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 19:55:07 --> Config Class Initialized
INFO - 2021-04-13 19:55:07 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:55:07 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:55:07 --> Utf8 Class Initialized
INFO - 2021-04-13 19:55:07 --> URI Class Initialized
INFO - 2021-04-13 19:55:07 --> Router Class Initialized
INFO - 2021-04-13 19:55:07 --> Output Class Initialized
INFO - 2021-04-13 19:55:07 --> Security Class Initialized
DEBUG - 2021-04-13 19:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:55:07 --> Input Class Initialized
INFO - 2021-04-13 19:55:07 --> Language Class Initialized
ERROR - 2021-04-13 19:55:07 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 19:55:07 --> Config Class Initialized
INFO - 2021-04-13 19:55:07 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:55:07 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:55:07 --> Utf8 Class Initialized
INFO - 2021-04-13 19:55:07 --> URI Class Initialized
INFO - 2021-04-13 19:55:07 --> Router Class Initialized
INFO - 2021-04-13 19:55:07 --> Output Class Initialized
INFO - 2021-04-13 19:55:07 --> Security Class Initialized
DEBUG - 2021-04-13 19:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:55:07 --> Input Class Initialized
INFO - 2021-04-13 19:55:07 --> Language Class Initialized
ERROR - 2021-04-13 19:55:07 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 19:55:07 --> Config Class Initialized
INFO - 2021-04-13 19:55:07 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:55:07 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:55:07 --> Utf8 Class Initialized
INFO - 2021-04-13 19:55:07 --> URI Class Initialized
INFO - 2021-04-13 19:55:07 --> Router Class Initialized
INFO - 2021-04-13 19:55:07 --> Output Class Initialized
INFO - 2021-04-13 19:55:07 --> Security Class Initialized
DEBUG - 2021-04-13 19:55:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:55:07 --> Input Class Initialized
INFO - 2021-04-13 19:55:07 --> Language Class Initialized
ERROR - 2021-04-13 19:55:07 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 19:55:16 --> Config Class Initialized
INFO - 2021-04-13 19:55:16 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:55:16 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:55:16 --> Utf8 Class Initialized
INFO - 2021-04-13 19:55:16 --> URI Class Initialized
INFO - 2021-04-13 19:55:16 --> Router Class Initialized
INFO - 2021-04-13 19:55:16 --> Output Class Initialized
INFO - 2021-04-13 19:55:16 --> Security Class Initialized
DEBUG - 2021-04-13 19:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:55:16 --> Input Class Initialized
INFO - 2021-04-13 19:55:16 --> Language Class Initialized
INFO - 2021-04-13 19:55:16 --> Loader Class Initialized
INFO - 2021-04-13 19:55:16 --> Helper loaded: url_helper
INFO - 2021-04-13 19:55:16 --> Helper loaded: form_helper
INFO - 2021-04-13 19:55:16 --> Helper loaded: common_helper
INFO - 2021-04-13 19:55:16 --> Helper loaded: util_helper
INFO - 2021-04-13 19:55:16 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:55:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:55:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:55:16 --> Form Validation Class Initialized
INFO - 2021-04-13 19:55:16 --> Controller Class Initialized
INFO - 2021-04-13 19:55:16 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-13 19:55:16 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 19:55:16 --> Final output sent to browser
DEBUG - 2021-04-13 19:55:16 --> Total execution time: 0.0347
INFO - 2021-04-13 19:55:16 --> Config Class Initialized
INFO - 2021-04-13 19:55:16 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:55:16 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:55:16 --> Utf8 Class Initialized
INFO - 2021-04-13 19:55:16 --> URI Class Initialized
INFO - 2021-04-13 19:55:16 --> Config Class Initialized
INFO - 2021-04-13 19:55:16 --> Hooks Class Initialized
INFO - 2021-04-13 19:55:16 --> Router Class Initialized
INFO - 2021-04-13 19:55:16 --> Output Class Initialized
DEBUG - 2021-04-13 19:55:16 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:55:16 --> Utf8 Class Initialized
INFO - 2021-04-13 19:55:16 --> Security Class Initialized
INFO - 2021-04-13 19:55:16 --> URI Class Initialized
DEBUG - 2021-04-13 19:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:55:16 --> Input Class Initialized
INFO - 2021-04-13 19:55:16 --> Router Class Initialized
INFO - 2021-04-13 19:55:16 --> Language Class Initialized
INFO - 2021-04-13 19:55:16 --> Output Class Initialized
ERROR - 2021-04-13 19:55:16 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:55:16 --> Security Class Initialized
DEBUG - 2021-04-13 19:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:55:16 --> Input Class Initialized
INFO - 2021-04-13 19:55:16 --> Language Class Initialized
ERROR - 2021-04-13 19:55:16 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:55:16 --> Config Class Initialized
INFO - 2021-04-13 19:55:16 --> Hooks Class Initialized
INFO - 2021-04-13 19:55:16 --> Config Class Initialized
INFO - 2021-04-13 19:55:16 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:55:16 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:55:16 --> Utf8 Class Initialized
DEBUG - 2021-04-13 19:55:16 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:55:16 --> Utf8 Class Initialized
INFO - 2021-04-13 19:55:16 --> URI Class Initialized
INFO - 2021-04-13 19:55:16 --> URI Class Initialized
INFO - 2021-04-13 19:55:16 --> Router Class Initialized
INFO - 2021-04-13 19:55:16 --> Router Class Initialized
INFO - 2021-04-13 19:55:16 --> Config Class Initialized
INFO - 2021-04-13 19:55:16 --> Output Class Initialized
INFO - 2021-04-13 19:55:16 --> Output Class Initialized
INFO - 2021-04-13 19:55:16 --> Config Class Initialized
INFO - 2021-04-13 19:55:16 --> Hooks Class Initialized
INFO - 2021-04-13 19:55:16 --> Security Class Initialized
INFO - 2021-04-13 19:55:16 --> Security Class Initialized
INFO - 2021-04-13 19:55:16 --> Config Class Initialized
INFO - 2021-04-13 19:55:16 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:55:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 19:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:55:16 --> Input Class Initialized
INFO - 2021-04-13 19:55:16 --> Input Class Initialized
DEBUG - 2021-04-13 19:55:16 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:55:16 --> Utf8 Class Initialized
INFO - 2021-04-13 19:55:16 --> Hooks Class Initialized
INFO - 2021-04-13 19:55:16 --> Language Class Initialized
INFO - 2021-04-13 19:55:16 --> Language Class Initialized
INFO - 2021-04-13 19:55:16 --> URI Class Initialized
DEBUG - 2021-04-13 19:55:16 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:55:16 --> Utf8 Class Initialized
ERROR - 2021-04-13 19:55:16 --> 404 Page Not Found: user/Assets/js
ERROR - 2021-04-13 19:55:16 --> 404 Page Not Found: user/Assets/js
DEBUG - 2021-04-13 19:55:16 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:55:16 --> Router Class Initialized
INFO - 2021-04-13 19:55:16 --> URI Class Initialized
INFO - 2021-04-13 19:55:16 --> Utf8 Class Initialized
INFO - 2021-04-13 19:55:16 --> URI Class Initialized
INFO - 2021-04-13 19:55:16 --> Router Class Initialized
INFO - 2021-04-13 19:55:16 --> Output Class Initialized
INFO - 2021-04-13 19:55:16 --> Router Class Initialized
INFO - 2021-04-13 19:55:16 --> Security Class Initialized
INFO - 2021-04-13 19:55:16 --> Output Class Initialized
DEBUG - 2021-04-13 19:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:55:16 --> Input Class Initialized
INFO - 2021-04-13 19:55:16 --> Security Class Initialized
INFO - 2021-04-13 19:55:16 --> Config Class Initialized
INFO - 2021-04-13 19:55:16 --> Output Class Initialized
INFO - 2021-04-13 19:55:16 --> Language Class Initialized
INFO - 2021-04-13 19:55:16 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:55:16 --> Input Class Initialized
INFO - 2021-04-13 19:55:16 --> Security Class Initialized
INFO - 2021-04-13 19:55:16 --> Language Class Initialized
ERROR - 2021-04-13 19:55:16 --> 404 Page Not Found: user/Assets/css
DEBUG - 2021-04-13 19:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:55:16 --> Input Class Initialized
DEBUG - 2021-04-13 19:55:16 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:55:16 --> Utf8 Class Initialized
INFO - 2021-04-13 19:55:16 --> Language Class Initialized
ERROR - 2021-04-13 19:55:16 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 19:55:16 --> URI Class Initialized
ERROR - 2021-04-13 19:55:16 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:55:16 --> Router Class Initialized
INFO - 2021-04-13 19:55:16 --> Output Class Initialized
INFO - 2021-04-13 19:55:16 --> Security Class Initialized
DEBUG - 2021-04-13 19:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:55:16 --> Input Class Initialized
INFO - 2021-04-13 19:55:16 --> Language Class Initialized
INFO - 2021-04-13 19:55:16 --> Config Class Initialized
INFO - 2021-04-13 19:55:16 --> Config Class Initialized
INFO - 2021-04-13 19:55:16 --> Hooks Class Initialized
INFO - 2021-04-13 19:55:16 --> Hooks Class Initialized
ERROR - 2021-04-13 19:55:16 --> 404 Page Not Found: user/Assets/css
DEBUG - 2021-04-13 19:55:16 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 19:55:16 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:55:16 --> Config Class Initialized
INFO - 2021-04-13 19:55:16 --> Utf8 Class Initialized
INFO - 2021-04-13 19:55:16 --> Utf8 Class Initialized
INFO - 2021-04-13 19:55:16 --> Hooks Class Initialized
INFO - 2021-04-13 19:55:16 --> URI Class Initialized
INFO - 2021-04-13 19:55:16 --> URI Class Initialized
DEBUG - 2021-04-13 19:55:16 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:55:16 --> Router Class Initialized
INFO - 2021-04-13 19:55:16 --> Utf8 Class Initialized
INFO - 2021-04-13 19:55:16 --> Router Class Initialized
INFO - 2021-04-13 19:55:16 --> URI Class Initialized
INFO - 2021-04-13 19:55:16 --> Output Class Initialized
INFO - 2021-04-13 19:55:16 --> Output Class Initialized
INFO - 2021-04-13 19:55:16 --> Router Class Initialized
INFO - 2021-04-13 19:55:16 --> Security Class Initialized
INFO - 2021-04-13 19:55:16 --> Security Class Initialized
DEBUG - 2021-04-13 19:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:55:16 --> Output Class Initialized
INFO - 2021-04-13 19:55:16 --> Input Class Initialized
DEBUG - 2021-04-13 19:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:55:16 --> Input Class Initialized
INFO - 2021-04-13 19:55:16 --> Language Class Initialized
INFO - 2021-04-13 19:55:16 --> Language Class Initialized
INFO - 2021-04-13 19:55:16 --> Security Class Initialized
ERROR - 2021-04-13 19:55:16 --> 404 Page Not Found: user/Assets/img
ERROR - 2021-04-13 19:55:16 --> 404 Page Not Found: user/Assets/js
DEBUG - 2021-04-13 19:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:55:16 --> Input Class Initialized
INFO - 2021-04-13 19:55:16 --> Language Class Initialized
ERROR - 2021-04-13 19:55:16 --> 404 Page Not Found: user/Assets/img
INFO - 2021-04-13 19:55:16 --> Config Class Initialized
INFO - 2021-04-13 19:55:16 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:55:16 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:55:16 --> Utf8 Class Initialized
INFO - 2021-04-13 19:55:16 --> URI Class Initialized
INFO - 2021-04-13 19:55:16 --> Router Class Initialized
INFO - 2021-04-13 19:55:16 --> Output Class Initialized
INFO - 2021-04-13 19:55:16 --> Security Class Initialized
DEBUG - 2021-04-13 19:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:55:16 --> Input Class Initialized
INFO - 2021-04-13 19:55:16 --> Language Class Initialized
ERROR - 2021-04-13 19:55:16 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:55:16 --> Config Class Initialized
INFO - 2021-04-13 19:55:16 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:55:16 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:55:16 --> Utf8 Class Initialized
INFO - 2021-04-13 19:55:16 --> URI Class Initialized
INFO - 2021-04-13 19:55:16 --> Router Class Initialized
INFO - 2021-04-13 19:55:16 --> Output Class Initialized
INFO - 2021-04-13 19:55:16 --> Security Class Initialized
DEBUG - 2021-04-13 19:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:55:16 --> Input Class Initialized
INFO - 2021-04-13 19:55:16 --> Language Class Initialized
ERROR - 2021-04-13 19:55:16 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 19:55:16 --> Config Class Initialized
INFO - 2021-04-13 19:55:16 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:55:16 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:55:16 --> Utf8 Class Initialized
INFO - 2021-04-13 19:55:16 --> URI Class Initialized
INFO - 2021-04-13 19:55:16 --> Router Class Initialized
INFO - 2021-04-13 19:55:16 --> Output Class Initialized
INFO - 2021-04-13 19:55:16 --> Security Class Initialized
DEBUG - 2021-04-13 19:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:55:16 --> Input Class Initialized
INFO - 2021-04-13 19:55:16 --> Language Class Initialized
ERROR - 2021-04-13 19:55:16 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 19:55:16 --> Config Class Initialized
INFO - 2021-04-13 19:55:16 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:55:16 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:55:16 --> Utf8 Class Initialized
INFO - 2021-04-13 19:55:16 --> URI Class Initialized
INFO - 2021-04-13 19:55:16 --> Router Class Initialized
INFO - 2021-04-13 19:55:16 --> Output Class Initialized
INFO - 2021-04-13 19:55:16 --> Security Class Initialized
DEBUG - 2021-04-13 19:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:55:16 --> Input Class Initialized
INFO - 2021-04-13 19:55:16 --> Language Class Initialized
ERROR - 2021-04-13 19:55:16 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 19:55:16 --> Config Class Initialized
INFO - 2021-04-13 19:55:16 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:55:16 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:55:16 --> Utf8 Class Initialized
INFO - 2021-04-13 19:55:16 --> URI Class Initialized
INFO - 2021-04-13 19:55:16 --> Router Class Initialized
INFO - 2021-04-13 19:55:16 --> Output Class Initialized
INFO - 2021-04-13 19:55:16 --> Security Class Initialized
DEBUG - 2021-04-13 19:55:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:55:16 --> Input Class Initialized
INFO - 2021-04-13 19:55:16 --> Language Class Initialized
ERROR - 2021-04-13 19:55:16 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 19:55:17 --> Config Class Initialized
INFO - 2021-04-13 19:55:17 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:55:17 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:55:17 --> Utf8 Class Initialized
INFO - 2021-04-13 19:55:17 --> URI Class Initialized
INFO - 2021-04-13 19:55:17 --> Router Class Initialized
INFO - 2021-04-13 19:55:17 --> Output Class Initialized
INFO - 2021-04-13 19:55:17 --> Security Class Initialized
DEBUG - 2021-04-13 19:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:55:17 --> Input Class Initialized
INFO - 2021-04-13 19:55:17 --> Language Class Initialized
INFO - 2021-04-13 19:55:17 --> Loader Class Initialized
INFO - 2021-04-13 19:55:17 --> Helper loaded: url_helper
INFO - 2021-04-13 19:55:17 --> Helper loaded: form_helper
INFO - 2021-04-13 19:55:17 --> Helper loaded: common_helper
INFO - 2021-04-13 19:55:17 --> Helper loaded: util_helper
INFO - 2021-04-13 19:55:17 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:55:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:55:17 --> Form Validation Class Initialized
INFO - 2021-04-13 19:55:17 --> Controller Class Initialized
INFO - 2021-04-13 19:55:17 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-13 19:55:17 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 19:55:17 --> Final output sent to browser
DEBUG - 2021-04-13 19:55:17 --> Total execution time: 0.0273
INFO - 2021-04-13 19:55:17 --> Config Class Initialized
INFO - 2021-04-13 19:55:17 --> Hooks Class Initialized
INFO - 2021-04-13 19:55:17 --> Config Class Initialized
INFO - 2021-04-13 19:55:17 --> Hooks Class Initialized
INFO - 2021-04-13 19:55:17 --> Config Class Initialized
DEBUG - 2021-04-13 19:55:17 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:55:17 --> Hooks Class Initialized
INFO - 2021-04-13 19:55:17 --> Utf8 Class Initialized
INFO - 2021-04-13 19:55:17 --> Config Class Initialized
DEBUG - 2021-04-13 19:55:17 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:55:17 --> URI Class Initialized
INFO - 2021-04-13 19:55:17 --> Hooks Class Initialized
INFO - 2021-04-13 19:55:17 --> Utf8 Class Initialized
DEBUG - 2021-04-13 19:55:17 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:55:17 --> Utf8 Class Initialized
INFO - 2021-04-13 19:55:17 --> URI Class Initialized
INFO - 2021-04-13 19:55:17 --> Router Class Initialized
INFO - 2021-04-13 19:55:17 --> URI Class Initialized
DEBUG - 2021-04-13 19:55:17 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:55:17 --> Utf8 Class Initialized
INFO - 2021-04-13 19:55:17 --> Router Class Initialized
INFO - 2021-04-13 19:55:17 --> Output Class Initialized
INFO - 2021-04-13 19:55:17 --> Router Class Initialized
INFO - 2021-04-13 19:55:17 --> URI Class Initialized
INFO - 2021-04-13 19:55:17 --> Output Class Initialized
INFO - 2021-04-13 19:55:17 --> Security Class Initialized
INFO - 2021-04-13 19:55:17 --> Router Class Initialized
INFO - 2021-04-13 19:55:17 --> Output Class Initialized
INFO - 2021-04-13 19:55:17 --> Security Class Initialized
DEBUG - 2021-04-13 19:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:55:17 --> Input Class Initialized
INFO - 2021-04-13 19:55:17 --> Output Class Initialized
INFO - 2021-04-13 19:55:17 --> Security Class Initialized
INFO - 2021-04-13 19:55:17 --> Language Class Initialized
DEBUG - 2021-04-13 19:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:55:17 --> Security Class Initialized
DEBUG - 2021-04-13 19:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:55:17 --> Input Class Initialized
INFO - 2021-04-13 19:55:17 --> Input Class Initialized
ERROR - 2021-04-13 19:55:17 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:55:17 --> Language Class Initialized
DEBUG - 2021-04-13 19:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:55:17 --> Language Class Initialized
INFO - 2021-04-13 19:55:17 --> Input Class Initialized
INFO - 2021-04-13 19:55:17 --> Language Class Initialized
ERROR - 2021-04-13 19:55:17 --> 404 Page Not Found: user/Assets/css
ERROR - 2021-04-13 19:55:17 --> 404 Page Not Found: user/Assets/css
ERROR - 2021-04-13 19:55:17 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:55:17 --> Config Class Initialized
INFO - 2021-04-13 19:55:17 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:55:17 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:55:17 --> Utf8 Class Initialized
INFO - 2021-04-13 19:55:17 --> URI Class Initialized
INFO - 2021-04-13 19:55:17 --> Router Class Initialized
INFO - 2021-04-13 19:55:17 --> Output Class Initialized
INFO - 2021-04-13 19:55:17 --> Security Class Initialized
DEBUG - 2021-04-13 19:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:55:17 --> Input Class Initialized
INFO - 2021-04-13 19:55:17 --> Language Class Initialized
INFO - 2021-04-13 19:55:17 --> Loader Class Initialized
INFO - 2021-04-13 19:55:17 --> Helper loaded: url_helper
INFO - 2021-04-13 19:55:17 --> Helper loaded: form_helper
INFO - 2021-04-13 19:55:17 --> Helper loaded: common_helper
INFO - 2021-04-13 19:55:17 --> Helper loaded: util_helper
INFO - 2021-04-13 19:55:17 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:55:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:55:17 --> Form Validation Class Initialized
INFO - 2021-04-13 19:55:17 --> Controller Class Initialized
INFO - 2021-04-13 19:55:17 --> Model Class Initialized
INFO - 2021-04-13 19:55:17 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 19:55:17 --> Final output sent to browser
DEBUG - 2021-04-13 19:55:17 --> Total execution time: 0.0257
INFO - 2021-04-13 19:55:19 --> Config Class Initialized
INFO - 2021-04-13 19:55:19 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:55:19 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:55:19 --> Utf8 Class Initialized
INFO - 2021-04-13 19:55:19 --> URI Class Initialized
DEBUG - 2021-04-13 19:55:19 --> No URI present. Default controller set.
INFO - 2021-04-13 19:55:19 --> Router Class Initialized
INFO - 2021-04-13 19:55:19 --> Output Class Initialized
INFO - 2021-04-13 19:55:19 --> Security Class Initialized
DEBUG - 2021-04-13 19:55:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:55:19 --> Input Class Initialized
INFO - 2021-04-13 19:55:19 --> Language Class Initialized
INFO - 2021-04-13 19:55:19 --> Loader Class Initialized
INFO - 2021-04-13 19:55:19 --> Helper loaded: url_helper
INFO - 2021-04-13 19:55:19 --> Helper loaded: form_helper
INFO - 2021-04-13 19:55:19 --> Helper loaded: common_helper
INFO - 2021-04-13 19:55:19 --> Helper loaded: util_helper
INFO - 2021-04-13 19:55:19 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:55:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:55:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:55:19 --> Form Validation Class Initialized
INFO - 2021-04-13 19:55:19 --> Controller Class Initialized
INFO - 2021-04-13 19:55:19 --> Model Class Initialized
INFO - 2021-04-13 19:55:19 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-13 19:55:19 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 19:55:19 --> Final output sent to browser
DEBUG - 2021-04-13 19:55:19 --> Total execution time: 0.0358
INFO - 2021-04-13 19:55:20 --> Config Class Initialized
INFO - 2021-04-13 19:55:20 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:55:20 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:55:20 --> Utf8 Class Initialized
INFO - 2021-04-13 19:55:20 --> URI Class Initialized
DEBUG - 2021-04-13 19:55:20 --> No URI present. Default controller set.
INFO - 2021-04-13 19:55:20 --> Router Class Initialized
INFO - 2021-04-13 19:55:20 --> Output Class Initialized
INFO - 2021-04-13 19:55:20 --> Security Class Initialized
DEBUG - 2021-04-13 19:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:55:20 --> Input Class Initialized
INFO - 2021-04-13 19:55:20 --> Language Class Initialized
INFO - 2021-04-13 19:55:20 --> Loader Class Initialized
INFO - 2021-04-13 19:55:20 --> Helper loaded: url_helper
INFO - 2021-04-13 19:55:20 --> Helper loaded: form_helper
INFO - 2021-04-13 19:55:20 --> Helper loaded: common_helper
INFO - 2021-04-13 19:55:20 --> Helper loaded: util_helper
INFO - 2021-04-13 19:55:20 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:55:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:55:20 --> Form Validation Class Initialized
INFO - 2021-04-13 19:55:20 --> Controller Class Initialized
INFO - 2021-04-13 19:55:20 --> Model Class Initialized
INFO - 2021-04-13 19:55:20 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-13 19:55:20 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 19:55:20 --> Final output sent to browser
DEBUG - 2021-04-13 19:55:20 --> Total execution time: 0.0283
INFO - 2021-04-13 19:55:21 --> Config Class Initialized
INFO - 2021-04-13 19:55:21 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:55:21 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:55:21 --> Utf8 Class Initialized
INFO - 2021-04-13 19:55:21 --> URI Class Initialized
DEBUG - 2021-04-13 19:55:21 --> No URI present. Default controller set.
INFO - 2021-04-13 19:55:21 --> Router Class Initialized
INFO - 2021-04-13 19:55:21 --> Output Class Initialized
INFO - 2021-04-13 19:55:21 --> Security Class Initialized
DEBUG - 2021-04-13 19:55:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:55:21 --> Input Class Initialized
INFO - 2021-04-13 19:55:21 --> Language Class Initialized
INFO - 2021-04-13 19:55:21 --> Loader Class Initialized
INFO - 2021-04-13 19:55:21 --> Helper loaded: url_helper
INFO - 2021-04-13 19:55:21 --> Helper loaded: form_helper
INFO - 2021-04-13 19:55:21 --> Helper loaded: common_helper
INFO - 2021-04-13 19:55:21 --> Helper loaded: util_helper
INFO - 2021-04-13 19:55:21 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:55:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:55:21 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:55:21 --> Form Validation Class Initialized
INFO - 2021-04-13 19:55:21 --> Controller Class Initialized
INFO - 2021-04-13 19:55:21 --> Model Class Initialized
INFO - 2021-04-13 19:55:21 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-13 19:55:21 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 19:55:21 --> Final output sent to browser
DEBUG - 2021-04-13 19:55:21 --> Total execution time: 0.0264
INFO - 2021-04-13 19:55:22 --> Config Class Initialized
INFO - 2021-04-13 19:55:22 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:55:22 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:55:22 --> Utf8 Class Initialized
INFO - 2021-04-13 19:55:22 --> URI Class Initialized
INFO - 2021-04-13 19:55:22 --> Router Class Initialized
INFO - 2021-04-13 19:55:22 --> Output Class Initialized
INFO - 2021-04-13 19:55:22 --> Security Class Initialized
DEBUG - 2021-04-13 19:55:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:55:22 --> Input Class Initialized
INFO - 2021-04-13 19:55:22 --> Language Class Initialized
INFO - 2021-04-13 19:55:22 --> Loader Class Initialized
INFO - 2021-04-13 19:55:22 --> Helper loaded: url_helper
INFO - 2021-04-13 19:55:22 --> Helper loaded: form_helper
INFO - 2021-04-13 19:55:22 --> Helper loaded: common_helper
INFO - 2021-04-13 19:55:22 --> Helper loaded: util_helper
INFO - 2021-04-13 19:55:22 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:55:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:55:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:55:22 --> Form Validation Class Initialized
INFO - 2021-04-13 19:55:22 --> Controller Class Initialized
INFO - 2021-04-13 19:55:22 --> Model Class Initialized
INFO - 2021-04-13 19:55:22 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 19:55:22 --> Final output sent to browser
DEBUG - 2021-04-13 19:55:22 --> Total execution time: 0.0267
INFO - 2021-04-13 19:55:23 --> Config Class Initialized
INFO - 2021-04-13 19:55:23 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:55:23 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:55:23 --> Utf8 Class Initialized
INFO - 2021-04-13 19:55:23 --> URI Class Initialized
INFO - 2021-04-13 19:55:23 --> Router Class Initialized
INFO - 2021-04-13 19:55:23 --> Output Class Initialized
INFO - 2021-04-13 19:55:23 --> Security Class Initialized
DEBUG - 2021-04-13 19:55:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:55:23 --> Input Class Initialized
INFO - 2021-04-13 19:55:23 --> Language Class Initialized
INFO - 2021-04-13 19:55:23 --> Loader Class Initialized
INFO - 2021-04-13 19:55:23 --> Helper loaded: url_helper
INFO - 2021-04-13 19:55:23 --> Helper loaded: form_helper
INFO - 2021-04-13 19:55:23 --> Helper loaded: common_helper
INFO - 2021-04-13 19:55:23 --> Helper loaded: util_helper
INFO - 2021-04-13 19:55:23 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:55:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:55:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:55:23 --> Form Validation Class Initialized
INFO - 2021-04-13 19:55:23 --> Controller Class Initialized
INFO - 2021-04-13 19:55:23 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-13 19:55:23 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 19:55:23 --> Final output sent to browser
DEBUG - 2021-04-13 19:55:23 --> Total execution time: 0.0242
INFO - 2021-04-13 19:55:24 --> Config Class Initialized
INFO - 2021-04-13 19:55:24 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:55:24 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:55:24 --> Utf8 Class Initialized
INFO - 2021-04-13 19:55:24 --> URI Class Initialized
INFO - 2021-04-13 19:55:24 --> Router Class Initialized
INFO - 2021-04-13 19:55:24 --> Output Class Initialized
INFO - 2021-04-13 19:55:24 --> Security Class Initialized
DEBUG - 2021-04-13 19:55:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:55:24 --> Input Class Initialized
INFO - 2021-04-13 19:55:24 --> Language Class Initialized
INFO - 2021-04-13 19:55:24 --> Loader Class Initialized
INFO - 2021-04-13 19:55:24 --> Helper loaded: url_helper
INFO - 2021-04-13 19:55:24 --> Helper loaded: form_helper
INFO - 2021-04-13 19:55:24 --> Helper loaded: common_helper
INFO - 2021-04-13 19:55:24 --> Helper loaded: util_helper
INFO - 2021-04-13 19:55:24 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:55:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:55:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:55:24 --> Form Validation Class Initialized
INFO - 2021-04-13 19:55:24 --> Controller Class Initialized
INFO - 2021-04-13 19:55:24 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-13 19:55:24 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 19:55:24 --> Final output sent to browser
DEBUG - 2021-04-13 19:55:24 --> Total execution time: 0.0246
INFO - 2021-04-13 19:56:16 --> Config Class Initialized
INFO - 2021-04-13 19:56:16 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:56:16 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:56:16 --> Utf8 Class Initialized
INFO - 2021-04-13 19:56:16 --> URI Class Initialized
INFO - 2021-04-13 19:56:16 --> Router Class Initialized
INFO - 2021-04-13 19:56:16 --> Output Class Initialized
INFO - 2021-04-13 19:56:16 --> Security Class Initialized
DEBUG - 2021-04-13 19:56:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:56:16 --> Input Class Initialized
INFO - 2021-04-13 19:56:16 --> Language Class Initialized
INFO - 2021-04-13 19:56:16 --> Loader Class Initialized
INFO - 2021-04-13 19:56:16 --> Helper loaded: url_helper
INFO - 2021-04-13 19:56:16 --> Helper loaded: form_helper
INFO - 2021-04-13 19:56:16 --> Helper loaded: common_helper
INFO - 2021-04-13 19:56:16 --> Helper loaded: util_helper
INFO - 2021-04-13 19:56:16 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:56:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:56:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:56:16 --> Form Validation Class Initialized
INFO - 2021-04-13 19:56:16 --> Controller Class Initialized
INFO - 2021-04-13 19:56:16 --> Final output sent to browser
DEBUG - 2021-04-13 19:56:16 --> Total execution time: 0.0344
INFO - 2021-04-13 19:56:24 --> Config Class Initialized
INFO - 2021-04-13 19:56:24 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:56:24 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:56:24 --> Utf8 Class Initialized
INFO - 2021-04-13 19:56:24 --> URI Class Initialized
INFO - 2021-04-13 19:56:24 --> Router Class Initialized
INFO - 2021-04-13 19:56:24 --> Output Class Initialized
INFO - 2021-04-13 19:56:24 --> Security Class Initialized
DEBUG - 2021-04-13 19:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:56:24 --> Input Class Initialized
INFO - 2021-04-13 19:56:24 --> Language Class Initialized
INFO - 2021-04-13 19:56:24 --> Loader Class Initialized
INFO - 2021-04-13 19:56:24 --> Helper loaded: url_helper
INFO - 2021-04-13 19:56:24 --> Helper loaded: form_helper
INFO - 2021-04-13 19:56:24 --> Helper loaded: common_helper
INFO - 2021-04-13 19:56:24 --> Helper loaded: util_helper
INFO - 2021-04-13 19:56:24 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:56:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:56:24 --> Form Validation Class Initialized
INFO - 2021-04-13 19:56:24 --> Controller Class Initialized
INFO - 2021-04-13 19:56:24 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-13 19:56:24 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 19:56:24 --> Final output sent to browser
DEBUG - 2021-04-13 19:56:24 --> Total execution time: 0.0354
INFO - 2021-04-13 19:56:24 --> Config Class Initialized
INFO - 2021-04-13 19:56:24 --> Hooks Class Initialized
INFO - 2021-04-13 19:56:24 --> Config Class Initialized
INFO - 2021-04-13 19:56:24 --> Hooks Class Initialized
INFO - 2021-04-13 19:56:24 --> Config Class Initialized
INFO - 2021-04-13 19:56:24 --> Hooks Class Initialized
INFO - 2021-04-13 19:56:24 --> Config Class Initialized
INFO - 2021-04-13 19:56:24 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:56:24 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:56:24 --> Utf8 Class Initialized
DEBUG - 2021-04-13 19:56:24 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:56:24 --> Utf8 Class Initialized
DEBUG - 2021-04-13 19:56:24 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:56:24 --> Utf8 Class Initialized
INFO - 2021-04-13 19:56:24 --> URI Class Initialized
DEBUG - 2021-04-13 19:56:24 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:56:24 --> URI Class Initialized
INFO - 2021-04-13 19:56:24 --> Utf8 Class Initialized
INFO - 2021-04-13 19:56:24 --> URI Class Initialized
INFO - 2021-04-13 19:56:24 --> Router Class Initialized
INFO - 2021-04-13 19:56:24 --> URI Class Initialized
INFO - 2021-04-13 19:56:24 --> Router Class Initialized
INFO - 2021-04-13 19:56:24 --> Router Class Initialized
INFO - 2021-04-13 19:56:24 --> Router Class Initialized
INFO - 2021-04-13 19:56:24 --> Output Class Initialized
INFO - 2021-04-13 19:56:24 --> Output Class Initialized
INFO - 2021-04-13 19:56:24 --> Output Class Initialized
INFO - 2021-04-13 19:56:24 --> Output Class Initialized
INFO - 2021-04-13 19:56:24 --> Security Class Initialized
INFO - 2021-04-13 19:56:24 --> Security Class Initialized
INFO - 2021-04-13 19:56:24 --> Security Class Initialized
INFO - 2021-04-13 19:56:24 --> Security Class Initialized
DEBUG - 2021-04-13 19:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:56:24 --> Input Class Initialized
DEBUG - 2021-04-13 19:56:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 19:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:56:24 --> Language Class Initialized
INFO - 2021-04-13 19:56:24 --> Input Class Initialized
DEBUG - 2021-04-13 19:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:56:24 --> Input Class Initialized
INFO - 2021-04-13 19:56:24 --> Input Class Initialized
INFO - 2021-04-13 19:56:24 --> Language Class Initialized
INFO - 2021-04-13 19:56:24 --> Language Class Initialized
ERROR - 2021-04-13 19:56:24 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:56:24 --> Language Class Initialized
ERROR - 2021-04-13 19:56:24 --> 404 Page Not Found: user/Assets/css
ERROR - 2021-04-13 19:56:24 --> 404 Page Not Found: user/Assets/css
ERROR - 2021-04-13 19:56:24 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:56:24 --> Config Class Initialized
INFO - 2021-04-13 19:56:24 --> Config Class Initialized
INFO - 2021-04-13 19:56:24 --> Hooks Class Initialized
INFO - 2021-04-13 19:56:24 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:56:24 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 19:56:24 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:56:24 --> Utf8 Class Initialized
INFO - 2021-04-13 19:56:24 --> Utf8 Class Initialized
INFO - 2021-04-13 19:56:24 --> URI Class Initialized
INFO - 2021-04-13 19:56:24 --> URI Class Initialized
INFO - 2021-04-13 19:56:24 --> Config Class Initialized
INFO - 2021-04-13 19:56:24 --> Hooks Class Initialized
INFO - 2021-04-13 19:56:24 --> Router Class Initialized
INFO - 2021-04-13 19:56:24 --> Router Class Initialized
INFO - 2021-04-13 19:56:24 --> Output Class Initialized
INFO - 2021-04-13 19:56:24 --> Output Class Initialized
DEBUG - 2021-04-13 19:56:24 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:56:24 --> Utf8 Class Initialized
INFO - 2021-04-13 19:56:24 --> Security Class Initialized
INFO - 2021-04-13 19:56:24 --> Security Class Initialized
INFO - 2021-04-13 19:56:24 --> URI Class Initialized
DEBUG - 2021-04-13 19:56:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 19:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:56:24 --> Router Class Initialized
INFO - 2021-04-13 19:56:24 --> Input Class Initialized
INFO - 2021-04-13 19:56:24 --> Input Class Initialized
INFO - 2021-04-13 19:56:24 --> Language Class Initialized
INFO - 2021-04-13 19:56:24 --> Language Class Initialized
INFO - 2021-04-13 19:56:24 --> Output Class Initialized
INFO - 2021-04-13 19:56:24 --> Config Class Initialized
ERROR - 2021-04-13 19:56:24 --> 404 Page Not Found: user/Assets/js
ERROR - 2021-04-13 19:56:24 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 19:56:24 --> Security Class Initialized
INFO - 2021-04-13 19:56:24 --> Hooks Class Initialized
INFO - 2021-04-13 19:56:24 --> Config Class Initialized
DEBUG - 2021-04-13 19:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:56:24 --> Input Class Initialized
INFO - 2021-04-13 19:56:24 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:56:24 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:56:24 --> Utf8 Class Initialized
INFO - 2021-04-13 19:56:24 --> Language Class Initialized
INFO - 2021-04-13 19:56:24 --> URI Class Initialized
ERROR - 2021-04-13 19:56:24 --> 404 Page Not Found: user/Assets/js
DEBUG - 2021-04-13 19:56:24 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:56:24 --> Utf8 Class Initialized
INFO - 2021-04-13 19:56:24 --> Router Class Initialized
INFO - 2021-04-13 19:56:24 --> URI Class Initialized
INFO - 2021-04-13 19:56:24 --> Output Class Initialized
INFO - 2021-04-13 19:56:24 --> Router Class Initialized
INFO - 2021-04-13 19:56:24 --> Security Class Initialized
INFO - 2021-04-13 19:56:24 --> Output Class Initialized
DEBUG - 2021-04-13 19:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:56:24 --> Input Class Initialized
INFO - 2021-04-13 19:56:24 --> Security Class Initialized
INFO - 2021-04-13 19:56:24 --> Config Class Initialized
INFO - 2021-04-13 19:56:24 --> Hooks Class Initialized
INFO - 2021-04-13 19:56:24 --> Language Class Initialized
DEBUG - 2021-04-13 19:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:56:24 --> Input Class Initialized
INFO - 2021-04-13 19:56:24 --> Language Class Initialized
DEBUG - 2021-04-13 19:56:24 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:56:24 --> Utf8 Class Initialized
ERROR - 2021-04-13 19:56:24 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:56:24 --> URI Class Initialized
INFO - 2021-04-13 19:56:24 --> Config Class Initialized
INFO - 2021-04-13 19:56:24 --> Hooks Class Initialized
ERROR - 2021-04-13 19:56:24 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 19:56:24 --> Router Class Initialized
DEBUG - 2021-04-13 19:56:24 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:56:24 --> Utf8 Class Initialized
INFO - 2021-04-13 19:56:24 --> Output Class Initialized
INFO - 2021-04-13 19:56:24 --> URI Class Initialized
INFO - 2021-04-13 19:56:24 --> Security Class Initialized
DEBUG - 2021-04-13 19:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:56:24 --> Router Class Initialized
INFO - 2021-04-13 19:56:24 --> Input Class Initialized
INFO - 2021-04-13 19:56:24 --> Language Class Initialized
INFO - 2021-04-13 19:56:24 --> Output Class Initialized
ERROR - 2021-04-13 19:56:24 --> 404 Page Not Found: user/Assets/img
INFO - 2021-04-13 19:56:24 --> Security Class Initialized
DEBUG - 2021-04-13 19:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:56:24 --> Input Class Initialized
INFO - 2021-04-13 19:56:24 --> Language Class Initialized
ERROR - 2021-04-13 19:56:24 --> 404 Page Not Found: user/Assets/img
INFO - 2021-04-13 19:56:24 --> Config Class Initialized
INFO - 2021-04-13 19:56:24 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:56:24 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:56:24 --> Utf8 Class Initialized
INFO - 2021-04-13 19:56:24 --> URI Class Initialized
INFO - 2021-04-13 19:56:24 --> Router Class Initialized
INFO - 2021-04-13 19:56:24 --> Output Class Initialized
INFO - 2021-04-13 19:56:24 --> Security Class Initialized
DEBUG - 2021-04-13 19:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:56:24 --> Input Class Initialized
INFO - 2021-04-13 19:56:24 --> Language Class Initialized
ERROR - 2021-04-13 19:56:24 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:56:24 --> Config Class Initialized
INFO - 2021-04-13 19:56:24 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:56:24 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:56:24 --> Utf8 Class Initialized
INFO - 2021-04-13 19:56:24 --> URI Class Initialized
INFO - 2021-04-13 19:56:24 --> Router Class Initialized
INFO - 2021-04-13 19:56:24 --> Output Class Initialized
INFO - 2021-04-13 19:56:24 --> Security Class Initialized
DEBUG - 2021-04-13 19:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:56:24 --> Input Class Initialized
INFO - 2021-04-13 19:56:24 --> Language Class Initialized
ERROR - 2021-04-13 19:56:24 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:56:24 --> Config Class Initialized
INFO - 2021-04-13 19:56:24 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:56:24 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:56:24 --> Utf8 Class Initialized
INFO - 2021-04-13 19:56:24 --> URI Class Initialized
INFO - 2021-04-13 19:56:24 --> Router Class Initialized
INFO - 2021-04-13 19:56:24 --> Output Class Initialized
INFO - 2021-04-13 19:56:24 --> Security Class Initialized
DEBUG - 2021-04-13 19:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:56:24 --> Input Class Initialized
INFO - 2021-04-13 19:56:24 --> Language Class Initialized
ERROR - 2021-04-13 19:56:24 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:56:24 --> Config Class Initialized
INFO - 2021-04-13 19:56:24 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:56:24 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:56:24 --> Utf8 Class Initialized
INFO - 2021-04-13 19:56:24 --> URI Class Initialized
INFO - 2021-04-13 19:56:24 --> Router Class Initialized
INFO - 2021-04-13 19:56:24 --> Output Class Initialized
INFO - 2021-04-13 19:56:24 --> Security Class Initialized
DEBUG - 2021-04-13 19:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:56:24 --> Input Class Initialized
INFO - 2021-04-13 19:56:24 --> Language Class Initialized
ERROR - 2021-04-13 19:56:24 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:56:24 --> Config Class Initialized
INFO - 2021-04-13 19:56:24 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:56:24 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:56:24 --> Utf8 Class Initialized
INFO - 2021-04-13 19:56:24 --> URI Class Initialized
INFO - 2021-04-13 19:56:24 --> Router Class Initialized
INFO - 2021-04-13 19:56:24 --> Output Class Initialized
INFO - 2021-04-13 19:56:24 --> Security Class Initialized
DEBUG - 2021-04-13 19:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:56:24 --> Input Class Initialized
INFO - 2021-04-13 19:56:24 --> Language Class Initialized
ERROR - 2021-04-13 19:56:24 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 19:56:24 --> Config Class Initialized
INFO - 2021-04-13 19:56:24 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:56:24 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:56:24 --> Utf8 Class Initialized
INFO - 2021-04-13 19:56:24 --> URI Class Initialized
INFO - 2021-04-13 19:56:24 --> Router Class Initialized
INFO - 2021-04-13 19:56:24 --> Output Class Initialized
INFO - 2021-04-13 19:56:24 --> Security Class Initialized
DEBUG - 2021-04-13 19:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:56:24 --> Input Class Initialized
INFO - 2021-04-13 19:56:24 --> Language Class Initialized
ERROR - 2021-04-13 19:56:24 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 19:56:24 --> Config Class Initialized
INFO - 2021-04-13 19:56:24 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:56:24 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:56:24 --> Utf8 Class Initialized
INFO - 2021-04-13 19:56:24 --> URI Class Initialized
INFO - 2021-04-13 19:56:24 --> Router Class Initialized
INFO - 2021-04-13 19:56:24 --> Output Class Initialized
INFO - 2021-04-13 19:56:24 --> Security Class Initialized
DEBUG - 2021-04-13 19:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:56:24 --> Input Class Initialized
INFO - 2021-04-13 19:56:24 --> Language Class Initialized
ERROR - 2021-04-13 19:56:24 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 19:56:24 --> Config Class Initialized
INFO - 2021-04-13 19:56:24 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:56:24 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:56:24 --> Utf8 Class Initialized
INFO - 2021-04-13 19:56:24 --> URI Class Initialized
INFO - 2021-04-13 19:56:24 --> Router Class Initialized
INFO - 2021-04-13 19:56:24 --> Output Class Initialized
INFO - 2021-04-13 19:56:24 --> Security Class Initialized
DEBUG - 2021-04-13 19:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:56:24 --> Input Class Initialized
INFO - 2021-04-13 19:56:24 --> Language Class Initialized
ERROR - 2021-04-13 19:56:24 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 19:56:29 --> Config Class Initialized
INFO - 2021-04-13 19:56:29 --> Config Class Initialized
INFO - 2021-04-13 19:56:29 --> Hooks Class Initialized
INFO - 2021-04-13 19:56:29 --> Config Class Initialized
INFO - 2021-04-13 19:56:29 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:56:29 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:56:29 --> Utf8 Class Initialized
INFO - 2021-04-13 19:56:29 --> URI Class Initialized
DEBUG - 2021-04-13 19:56:29 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:56:29 --> Router Class Initialized
INFO - 2021-04-13 19:56:29 --> Utf8 Class Initialized
INFO - 2021-04-13 19:56:29 --> URI Class Initialized
INFO - 2021-04-13 19:56:29 --> Output Class Initialized
INFO - 2021-04-13 19:56:29 --> Router Class Initialized
INFO - 2021-04-13 19:56:29 --> Security Class Initialized
INFO - 2021-04-13 19:56:29 --> Output Class Initialized
INFO - 2021-04-13 19:56:29 --> Config Class Initialized
INFO - 2021-04-13 19:56:29 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:56:29 --> Security Class Initialized
INFO - 2021-04-13 19:56:29 --> Input Class Initialized
INFO - 2021-04-13 19:56:29 --> Language Class Initialized
DEBUG - 2021-04-13 19:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:56:29 --> Input Class Initialized
DEBUG - 2021-04-13 19:56:29 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:56:29 --> Utf8 Class Initialized
INFO - 2021-04-13 19:56:29 --> Language Class Initialized
INFO - 2021-04-13 19:56:29 --> URI Class Initialized
ERROR - 2021-04-13 19:56:29 --> 404 Page Not Found: user/Assets/css
ERROR - 2021-04-13 19:56:29 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:56:29 --> Config Class Initialized
INFO - 2021-04-13 19:56:29 --> Hooks Class Initialized
INFO - 2021-04-13 19:56:29 --> Router Class Initialized
INFO - 2021-04-13 19:56:29 --> Output Class Initialized
DEBUG - 2021-04-13 19:56:29 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:56:29 --> Utf8 Class Initialized
INFO - 2021-04-13 19:56:29 --> Security Class Initialized
INFO - 2021-04-13 19:56:29 --> URI Class Initialized
DEBUG - 2021-04-13 19:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:56:29 --> Input Class Initialized
INFO - 2021-04-13 19:56:29 --> Hooks Class Initialized
INFO - 2021-04-13 19:56:29 --> Router Class Initialized
INFO - 2021-04-13 19:56:29 --> Language Class Initialized
INFO - 2021-04-13 19:56:29 --> Output Class Initialized
ERROR - 2021-04-13 19:56:29 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:56:29 --> Security Class Initialized
DEBUG - 2021-04-13 19:56:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 19:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:56:29 --> Utf8 Class Initialized
INFO - 2021-04-13 19:56:29 --> Input Class Initialized
INFO - 2021-04-13 19:56:29 --> Language Class Initialized
INFO - 2021-04-13 19:56:29 --> URI Class Initialized
ERROR - 2021-04-13 19:56:29 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:56:29 --> Router Class Initialized
INFO - 2021-04-13 19:56:29 --> Output Class Initialized
INFO - 2021-04-13 19:56:29 --> Security Class Initialized
DEBUG - 2021-04-13 19:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:56:29 --> Input Class Initialized
INFO - 2021-04-13 19:56:29 --> Language Class Initialized
ERROR - 2021-04-13 19:56:29 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:56:29 --> Config Class Initialized
INFO - 2021-04-13 19:56:29 --> Hooks Class Initialized
INFO - 2021-04-13 19:56:29 --> Config Class Initialized
INFO - 2021-04-13 19:56:29 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:56:29 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:56:29 --> Utf8 Class Initialized
DEBUG - 2021-04-13 19:56:29 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:56:29 --> URI Class Initialized
INFO - 2021-04-13 19:56:29 --> Utf8 Class Initialized
INFO - 2021-04-13 19:56:29 --> URI Class Initialized
INFO - 2021-04-13 19:56:29 --> Router Class Initialized
INFO - 2021-04-13 19:56:29 --> Router Class Initialized
INFO - 2021-04-13 19:56:29 --> Output Class Initialized
INFO - 2021-04-13 19:56:29 --> Output Class Initialized
INFO - 2021-04-13 19:56:29 --> Security Class Initialized
INFO - 2021-04-13 19:56:29 --> Security Class Initialized
DEBUG - 2021-04-13 19:56:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 19:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:56:29 --> Input Class Initialized
INFO - 2021-04-13 19:56:29 --> Input Class Initialized
INFO - 2021-04-13 19:56:29 --> Language Class Initialized
INFO - 2021-04-13 19:56:29 --> Language Class Initialized
ERROR - 2021-04-13 19:56:29 --> 404 Page Not Found: Fassets/js
ERROR - 2021-04-13 19:56:29 --> 404 Page Not Found: Fassets/js
INFO - 2021-04-13 19:56:29 --> Config Class Initialized
INFO - 2021-04-13 19:56:29 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:56:29 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:56:29 --> Utf8 Class Initialized
INFO - 2021-04-13 19:56:29 --> URI Class Initialized
INFO - 2021-04-13 19:56:29 --> Router Class Initialized
INFO - 2021-04-13 19:56:29 --> Output Class Initialized
INFO - 2021-04-13 19:56:29 --> Security Class Initialized
DEBUG - 2021-04-13 19:56:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:56:29 --> Input Class Initialized
INFO - 2021-04-13 19:56:29 --> Language Class Initialized
ERROR - 2021-04-13 19:56:29 --> 404 Page Not Found: Fassets/css
INFO - 2021-04-13 19:57:59 --> Config Class Initialized
INFO - 2021-04-13 19:57:59 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:57:59 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:57:59 --> Utf8 Class Initialized
INFO - 2021-04-13 19:57:59 --> URI Class Initialized
INFO - 2021-04-13 19:57:59 --> Router Class Initialized
INFO - 2021-04-13 19:57:59 --> Output Class Initialized
INFO - 2021-04-13 19:57:59 --> Security Class Initialized
DEBUG - 2021-04-13 19:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:57:59 --> Input Class Initialized
INFO - 2021-04-13 19:57:59 --> Language Class Initialized
INFO - 2021-04-13 19:57:59 --> Loader Class Initialized
INFO - 2021-04-13 19:57:59 --> Helper loaded: url_helper
INFO - 2021-04-13 19:57:59 --> Helper loaded: form_helper
INFO - 2021-04-13 19:57:59 --> Helper loaded: common_helper
INFO - 2021-04-13 19:57:59 --> Helper loaded: util_helper
INFO - 2021-04-13 19:57:59 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:57:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:57:59 --> Form Validation Class Initialized
INFO - 2021-04-13 19:57:59 --> Controller Class Initialized
INFO - 2021-04-13 19:57:59 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-13 19:57:59 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 19:57:59 --> Final output sent to browser
DEBUG - 2021-04-13 19:57:59 --> Total execution time: 0.0354
INFO - 2021-04-13 19:57:59 --> Config Class Initialized
INFO - 2021-04-13 19:57:59 --> Config Class Initialized
INFO - 2021-04-13 19:57:59 --> Hooks Class Initialized
INFO - 2021-04-13 19:57:59 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:57:59 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:57:59 --> Utf8 Class Initialized
DEBUG - 2021-04-13 19:57:59 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:57:59 --> Utf8 Class Initialized
INFO - 2021-04-13 19:57:59 --> URI Class Initialized
INFO - 2021-04-13 19:57:59 --> URI Class Initialized
INFO - 2021-04-13 19:57:59 --> Router Class Initialized
INFO - 2021-04-13 19:57:59 --> Router Class Initialized
INFO - 2021-04-13 19:57:59 --> Output Class Initialized
INFO - 2021-04-13 19:57:59 --> Output Class Initialized
INFO - 2021-04-13 19:57:59 --> Security Class Initialized
INFO - 2021-04-13 19:57:59 --> Security Class Initialized
DEBUG - 2021-04-13 19:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:57:59 --> Input Class Initialized
INFO - 2021-04-13 19:57:59 --> Language Class Initialized
DEBUG - 2021-04-13 19:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:57:59 --> Input Class Initialized
INFO - 2021-04-13 19:57:59 --> Language Class Initialized
ERROR - 2021-04-13 19:57:59 --> 404 Page Not Found: user/Assets/css
ERROR - 2021-04-13 19:57:59 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:57:59 --> Config Class Initialized
INFO - 2021-04-13 19:57:59 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:57:59 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:57:59 --> Utf8 Class Initialized
INFO - 2021-04-13 19:57:59 --> URI Class Initialized
INFO - 2021-04-13 19:57:59 --> Router Class Initialized
INFO - 2021-04-13 19:57:59 --> Output Class Initialized
INFO - 2021-04-13 19:57:59 --> Security Class Initialized
DEBUG - 2021-04-13 19:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:57:59 --> Input Class Initialized
INFO - 2021-04-13 19:57:59 --> Language Class Initialized
INFO - 2021-04-13 19:57:59 --> Loader Class Initialized
INFO - 2021-04-13 19:57:59 --> Helper loaded: url_helper
INFO - 2021-04-13 19:57:59 --> Helper loaded: form_helper
INFO - 2021-04-13 19:57:59 --> Helper loaded: common_helper
INFO - 2021-04-13 19:57:59 --> Helper loaded: util_helper
INFO - 2021-04-13 19:57:59 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:57:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:57:59 --> Form Validation Class Initialized
INFO - 2021-04-13 19:57:59 --> Controller Class Initialized
INFO - 2021-04-13 19:57:59 --> Model Class Initialized
INFO - 2021-04-13 19:57:59 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 19:57:59 --> Final output sent to browser
DEBUG - 2021-04-13 19:57:59 --> Total execution time: 0.0264
INFO - 2021-04-13 19:58:00 --> Config Class Initialized
INFO - 2021-04-13 19:58:00 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:58:00 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:58:00 --> Utf8 Class Initialized
INFO - 2021-04-13 19:58:00 --> URI Class Initialized
DEBUG - 2021-04-13 19:58:00 --> No URI present. Default controller set.
INFO - 2021-04-13 19:58:00 --> Router Class Initialized
INFO - 2021-04-13 19:58:00 --> Output Class Initialized
INFO - 2021-04-13 19:58:00 --> Security Class Initialized
DEBUG - 2021-04-13 19:58:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:58:00 --> Input Class Initialized
INFO - 2021-04-13 19:58:00 --> Language Class Initialized
INFO - 2021-04-13 19:58:00 --> Loader Class Initialized
INFO - 2021-04-13 19:58:00 --> Helper loaded: url_helper
INFO - 2021-04-13 19:58:00 --> Helper loaded: form_helper
INFO - 2021-04-13 19:58:00 --> Helper loaded: common_helper
INFO - 2021-04-13 19:58:00 --> Helper loaded: util_helper
INFO - 2021-04-13 19:58:00 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:58:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:58:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:58:00 --> Form Validation Class Initialized
INFO - 2021-04-13 19:58:00 --> Controller Class Initialized
INFO - 2021-04-13 19:58:00 --> Model Class Initialized
INFO - 2021-04-13 19:58:02 --> Config Class Initialized
INFO - 2021-04-13 19:58:02 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:58:02 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:58:02 --> Utf8 Class Initialized
INFO - 2021-04-13 19:58:02 --> URI Class Initialized
DEBUG - 2021-04-13 19:58:02 --> No URI present. Default controller set.
INFO - 2021-04-13 19:58:02 --> Router Class Initialized
INFO - 2021-04-13 19:58:02 --> Output Class Initialized
INFO - 2021-04-13 19:58:02 --> Security Class Initialized
DEBUG - 2021-04-13 19:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:58:02 --> Input Class Initialized
INFO - 2021-04-13 19:58:02 --> Language Class Initialized
INFO - 2021-04-13 19:58:02 --> Loader Class Initialized
INFO - 2021-04-13 19:58:02 --> Helper loaded: url_helper
INFO - 2021-04-13 19:58:02 --> Helper loaded: form_helper
INFO - 2021-04-13 19:58:02 --> Helper loaded: common_helper
INFO - 2021-04-13 19:58:02 --> Helper loaded: util_helper
INFO - 2021-04-13 19:58:02 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:58:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:58:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:58:03 --> Form Validation Class Initialized
INFO - 2021-04-13 19:58:03 --> Controller Class Initialized
INFO - 2021-04-13 19:58:03 --> Model Class Initialized
INFO - 2021-04-13 19:58:03 --> Config Class Initialized
INFO - 2021-04-13 19:58:03 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:58:03 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:58:03 --> Utf8 Class Initialized
INFO - 2021-04-13 19:58:03 --> URI Class Initialized
DEBUG - 2021-04-13 19:58:03 --> No URI present. Default controller set.
INFO - 2021-04-13 19:58:03 --> Router Class Initialized
INFO - 2021-04-13 19:58:03 --> Output Class Initialized
INFO - 2021-04-13 19:58:03 --> Security Class Initialized
DEBUG - 2021-04-13 19:58:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:58:03 --> Input Class Initialized
INFO - 2021-04-13 19:58:03 --> Language Class Initialized
INFO - 2021-04-13 19:58:03 --> Loader Class Initialized
INFO - 2021-04-13 19:58:03 --> Helper loaded: url_helper
INFO - 2021-04-13 19:58:03 --> Helper loaded: form_helper
INFO - 2021-04-13 19:58:03 --> Helper loaded: common_helper
INFO - 2021-04-13 19:58:03 --> Helper loaded: util_helper
INFO - 2021-04-13 19:58:03 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:58:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:58:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:58:03 --> Form Validation Class Initialized
INFO - 2021-04-13 19:58:03 --> Controller Class Initialized
INFO - 2021-04-13 19:58:03 --> Model Class Initialized
INFO - 2021-04-13 19:58:11 --> Config Class Initialized
INFO - 2021-04-13 19:58:11 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:58:11 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:58:11 --> Utf8 Class Initialized
INFO - 2021-04-13 19:58:11 --> URI Class Initialized
DEBUG - 2021-04-13 19:58:11 --> No URI present. Default controller set.
INFO - 2021-04-13 19:58:11 --> Router Class Initialized
INFO - 2021-04-13 19:58:11 --> Output Class Initialized
INFO - 2021-04-13 19:58:11 --> Security Class Initialized
DEBUG - 2021-04-13 19:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:58:11 --> Input Class Initialized
INFO - 2021-04-13 19:58:11 --> Language Class Initialized
INFO - 2021-04-13 19:58:11 --> Loader Class Initialized
INFO - 2021-04-13 19:58:11 --> Helper loaded: url_helper
INFO - 2021-04-13 19:58:11 --> Helper loaded: form_helper
INFO - 2021-04-13 19:58:11 --> Helper loaded: common_helper
INFO - 2021-04-13 19:58:11 --> Helper loaded: util_helper
INFO - 2021-04-13 19:58:11 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:58:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:58:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:58:11 --> Form Validation Class Initialized
INFO - 2021-04-13 19:58:11 --> Controller Class Initialized
INFO - 2021-04-13 19:58:11 --> Model Class Initialized
INFO - 2021-04-13 19:58:11 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-13 19:58:11 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 19:58:11 --> Final output sent to browser
DEBUG - 2021-04-13 19:58:11 --> Total execution time: 0.0270
INFO - 2021-04-13 19:58:55 --> Config Class Initialized
INFO - 2021-04-13 19:58:55 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:58:55 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:58:55 --> Utf8 Class Initialized
INFO - 2021-04-13 19:58:55 --> URI Class Initialized
DEBUG - 2021-04-13 19:58:55 --> No URI present. Default controller set.
INFO - 2021-04-13 19:58:55 --> Router Class Initialized
INFO - 2021-04-13 19:58:55 --> Output Class Initialized
INFO - 2021-04-13 19:58:55 --> Security Class Initialized
DEBUG - 2021-04-13 19:58:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:58:55 --> Input Class Initialized
INFO - 2021-04-13 19:58:55 --> Language Class Initialized
INFO - 2021-04-13 19:58:55 --> Loader Class Initialized
INFO - 2021-04-13 19:58:55 --> Helper loaded: url_helper
INFO - 2021-04-13 19:58:55 --> Helper loaded: form_helper
INFO - 2021-04-13 19:58:55 --> Helper loaded: common_helper
INFO - 2021-04-13 19:58:55 --> Helper loaded: util_helper
INFO - 2021-04-13 19:58:55 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:58:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:58:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:58:55 --> Form Validation Class Initialized
INFO - 2021-04-13 19:58:55 --> Controller Class Initialized
INFO - 2021-04-13 19:58:55 --> Model Class Initialized
INFO - 2021-04-13 19:58:55 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-13 19:58:55 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 19:58:55 --> Final output sent to browser
DEBUG - 2021-04-13 19:58:55 --> Total execution time: 0.0262
INFO - 2021-04-13 19:58:56 --> Config Class Initialized
INFO - 2021-04-13 19:58:56 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:58:56 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:58:56 --> Utf8 Class Initialized
INFO - 2021-04-13 19:58:56 --> URI Class Initialized
DEBUG - 2021-04-13 19:58:56 --> No URI present. Default controller set.
INFO - 2021-04-13 19:58:56 --> Router Class Initialized
INFO - 2021-04-13 19:58:56 --> Output Class Initialized
INFO - 2021-04-13 19:58:56 --> Security Class Initialized
DEBUG - 2021-04-13 19:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:58:56 --> Input Class Initialized
INFO - 2021-04-13 19:58:56 --> Language Class Initialized
INFO - 2021-04-13 19:58:56 --> Loader Class Initialized
INFO - 2021-04-13 19:58:56 --> Helper loaded: url_helper
INFO - 2021-04-13 19:58:56 --> Helper loaded: form_helper
INFO - 2021-04-13 19:58:56 --> Helper loaded: common_helper
INFO - 2021-04-13 19:58:56 --> Helper loaded: util_helper
INFO - 2021-04-13 19:58:56 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:58:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:58:56 --> Form Validation Class Initialized
INFO - 2021-04-13 19:58:56 --> Controller Class Initialized
INFO - 2021-04-13 19:58:56 --> Model Class Initialized
INFO - 2021-04-13 19:58:56 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-13 19:58:56 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 19:58:56 --> Final output sent to browser
DEBUG - 2021-04-13 19:58:56 --> Total execution time: 0.0252
INFO - 2021-04-13 19:58:56 --> Config Class Initialized
INFO - 2021-04-13 19:58:56 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:58:56 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:58:56 --> Utf8 Class Initialized
INFO - 2021-04-13 19:58:56 --> URI Class Initialized
DEBUG - 2021-04-13 19:58:56 --> No URI present. Default controller set.
INFO - 2021-04-13 19:58:56 --> Router Class Initialized
INFO - 2021-04-13 19:58:56 --> Output Class Initialized
INFO - 2021-04-13 19:58:56 --> Security Class Initialized
DEBUG - 2021-04-13 19:58:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:58:56 --> Input Class Initialized
INFO - 2021-04-13 19:58:56 --> Language Class Initialized
INFO - 2021-04-13 19:58:56 --> Loader Class Initialized
INFO - 2021-04-13 19:58:56 --> Helper loaded: url_helper
INFO - 2021-04-13 19:58:56 --> Helper loaded: form_helper
INFO - 2021-04-13 19:58:56 --> Helper loaded: common_helper
INFO - 2021-04-13 19:58:56 --> Helper loaded: util_helper
INFO - 2021-04-13 19:58:56 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:58:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:58:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:58:56 --> Form Validation Class Initialized
INFO - 2021-04-13 19:58:56 --> Controller Class Initialized
INFO - 2021-04-13 19:58:56 --> Model Class Initialized
INFO - 2021-04-13 19:58:56 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-13 19:58:56 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 19:58:56 --> Final output sent to browser
DEBUG - 2021-04-13 19:58:56 --> Total execution time: 0.0258
INFO - 2021-04-13 19:59:05 --> Config Class Initialized
INFO - 2021-04-13 19:59:05 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:59:05 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:59:05 --> Utf8 Class Initialized
INFO - 2021-04-13 19:59:05 --> URI Class Initialized
DEBUG - 2021-04-13 19:59:05 --> No URI present. Default controller set.
INFO - 2021-04-13 19:59:05 --> Router Class Initialized
INFO - 2021-04-13 19:59:05 --> Output Class Initialized
INFO - 2021-04-13 19:59:05 --> Security Class Initialized
DEBUG - 2021-04-13 19:59:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:59:05 --> Input Class Initialized
INFO - 2021-04-13 19:59:05 --> Language Class Initialized
INFO - 2021-04-13 19:59:05 --> Loader Class Initialized
INFO - 2021-04-13 19:59:05 --> Helper loaded: url_helper
INFO - 2021-04-13 19:59:05 --> Helper loaded: form_helper
INFO - 2021-04-13 19:59:05 --> Helper loaded: common_helper
INFO - 2021-04-13 19:59:05 --> Helper loaded: util_helper
INFO - 2021-04-13 19:59:05 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:59:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:59:05 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:59:05 --> Form Validation Class Initialized
INFO - 2021-04-13 19:59:05 --> Controller Class Initialized
INFO - 2021-04-13 19:59:05 --> Model Class Initialized
INFO - 2021-04-13 19:59:05 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-13 19:59:05 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 19:59:05 --> Final output sent to browser
DEBUG - 2021-04-13 19:59:05 --> Total execution time: 0.0265
INFO - 2021-04-13 19:59:11 --> Config Class Initialized
INFO - 2021-04-13 19:59:11 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:59:11 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:59:11 --> Utf8 Class Initialized
INFO - 2021-04-13 19:59:11 --> URI Class Initialized
INFO - 2021-04-13 19:59:11 --> Router Class Initialized
INFO - 2021-04-13 19:59:11 --> Output Class Initialized
INFO - 2021-04-13 19:59:11 --> Security Class Initialized
DEBUG - 2021-04-13 19:59:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:59:11 --> Input Class Initialized
INFO - 2021-04-13 19:59:11 --> Language Class Initialized
INFO - 2021-04-13 19:59:11 --> Loader Class Initialized
INFO - 2021-04-13 19:59:11 --> Helper loaded: url_helper
INFO - 2021-04-13 19:59:11 --> Helper loaded: form_helper
INFO - 2021-04-13 19:59:11 --> Helper loaded: common_helper
INFO - 2021-04-13 19:59:11 --> Helper loaded: util_helper
INFO - 2021-04-13 19:59:11 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:59:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:59:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:59:11 --> Form Validation Class Initialized
INFO - 2021-04-13 19:59:11 --> Controller Class Initialized
INFO - 2021-04-13 19:59:11 --> Model Class Initialized
INFO - 2021-04-13 19:59:11 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 19:59:11 --> Final output sent to browser
DEBUG - 2021-04-13 19:59:11 --> Total execution time: 0.0352
INFO - 2021-04-13 19:59:12 --> Config Class Initialized
INFO - 2021-04-13 19:59:12 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:59:12 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:59:12 --> Utf8 Class Initialized
INFO - 2021-04-13 19:59:12 --> URI Class Initialized
INFO - 2021-04-13 19:59:12 --> Router Class Initialized
INFO - 2021-04-13 19:59:12 --> Output Class Initialized
INFO - 2021-04-13 19:59:12 --> Security Class Initialized
DEBUG - 2021-04-13 19:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:59:12 --> Input Class Initialized
INFO - 2021-04-13 19:59:12 --> Language Class Initialized
INFO - 2021-04-13 19:59:12 --> Loader Class Initialized
INFO - 2021-04-13 19:59:12 --> Helper loaded: url_helper
INFO - 2021-04-13 19:59:12 --> Helper loaded: form_helper
INFO - 2021-04-13 19:59:12 --> Helper loaded: common_helper
INFO - 2021-04-13 19:59:12 --> Helper loaded: util_helper
INFO - 2021-04-13 19:59:12 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:59:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:59:12 --> Form Validation Class Initialized
INFO - 2021-04-13 19:59:12 --> Controller Class Initialized
INFO - 2021-04-13 19:59:12 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-13 19:59:12 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 19:59:12 --> Final output sent to browser
DEBUG - 2021-04-13 19:59:12 --> Total execution time: 0.0346
INFO - 2021-04-13 19:59:12 --> Config Class Initialized
INFO - 2021-04-13 19:59:12 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:59:12 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:59:12 --> Utf8 Class Initialized
INFO - 2021-04-13 19:59:12 --> URI Class Initialized
INFO - 2021-04-13 19:59:12 --> Router Class Initialized
INFO - 2021-04-13 19:59:12 --> Output Class Initialized
INFO - 2021-04-13 19:59:12 --> Security Class Initialized
DEBUG - 2021-04-13 19:59:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:59:12 --> Input Class Initialized
INFO - 2021-04-13 19:59:12 --> Language Class Initialized
INFO - 2021-04-13 19:59:12 --> Loader Class Initialized
INFO - 2021-04-13 19:59:12 --> Helper loaded: url_helper
INFO - 2021-04-13 19:59:12 --> Helper loaded: form_helper
INFO - 2021-04-13 19:59:12 --> Helper loaded: common_helper
INFO - 2021-04-13 19:59:12 --> Helper loaded: util_helper
INFO - 2021-04-13 19:59:12 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:59:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:59:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:59:12 --> Form Validation Class Initialized
INFO - 2021-04-13 19:59:12 --> Controller Class Initialized
INFO - 2021-04-13 19:59:12 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-13 19:59:12 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 19:59:12 --> Final output sent to browser
DEBUG - 2021-04-13 19:59:12 --> Total execution time: 0.0257
INFO - 2021-04-13 19:59:22 --> Config Class Initialized
INFO - 2021-04-13 19:59:22 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:59:22 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:59:22 --> Utf8 Class Initialized
INFO - 2021-04-13 19:59:22 --> URI Class Initialized
INFO - 2021-04-13 19:59:22 --> Router Class Initialized
INFO - 2021-04-13 19:59:22 --> Output Class Initialized
INFO - 2021-04-13 19:59:22 --> Security Class Initialized
DEBUG - 2021-04-13 19:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:59:22 --> Input Class Initialized
INFO - 2021-04-13 19:59:22 --> Language Class Initialized
INFO - 2021-04-13 19:59:22 --> Loader Class Initialized
INFO - 2021-04-13 19:59:22 --> Helper loaded: url_helper
INFO - 2021-04-13 19:59:22 --> Helper loaded: form_helper
INFO - 2021-04-13 19:59:22 --> Helper loaded: common_helper
INFO - 2021-04-13 19:59:22 --> Helper loaded: util_helper
INFO - 2021-04-13 19:59:22 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:59:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:59:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:59:22 --> Form Validation Class Initialized
INFO - 2021-04-13 19:59:22 --> Controller Class Initialized
INFO - 2021-04-13 19:59:22 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-13 19:59:22 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 19:59:22 --> Final output sent to browser
DEBUG - 2021-04-13 19:59:22 --> Total execution time: 0.0353
INFO - 2021-04-13 19:59:22 --> Config Class Initialized
INFO - 2021-04-13 19:59:22 --> Config Class Initialized
INFO - 2021-04-13 19:59:22 --> Hooks Class Initialized
INFO - 2021-04-13 19:59:22 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:59:22 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 19:59:22 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:59:22 --> Utf8 Class Initialized
INFO - 2021-04-13 19:59:22 --> Utf8 Class Initialized
INFO - 2021-04-13 19:59:22 --> URI Class Initialized
INFO - 2021-04-13 19:59:22 --> URI Class Initialized
INFO - 2021-04-13 19:59:22 --> Router Class Initialized
INFO - 2021-04-13 19:59:22 --> Router Class Initialized
INFO - 2021-04-13 19:59:22 --> Output Class Initialized
INFO - 2021-04-13 19:59:22 --> Config Class Initialized
INFO - 2021-04-13 19:59:22 --> Hooks Class Initialized
INFO - 2021-04-13 19:59:22 --> Security Class Initialized
INFO - 2021-04-13 19:59:22 --> Output Class Initialized
DEBUG - 2021-04-13 19:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:59:22 --> Input Class Initialized
INFO - 2021-04-13 19:59:22 --> Language Class Initialized
DEBUG - 2021-04-13 19:59:22 --> UTF-8 Support Enabled
ERROR - 2021-04-13 19:59:22 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:59:22 --> Utf8 Class Initialized
INFO - 2021-04-13 19:59:22 --> Security Class Initialized
INFO - 2021-04-13 19:59:22 --> URI Class Initialized
DEBUG - 2021-04-13 19:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:59:22 --> Input Class Initialized
INFO - 2021-04-13 19:59:22 --> Language Class Initialized
INFO - 2021-04-13 19:59:22 --> Router Class Initialized
INFO - 2021-04-13 19:59:22 --> Config Class Initialized
INFO - 2021-04-13 19:59:22 --> Hooks Class Initialized
INFO - 2021-04-13 19:59:22 --> Output Class Initialized
INFO - 2021-04-13 19:59:22 --> Config Class Initialized
INFO - 2021-04-13 19:59:22 --> Security Class Initialized
ERROR - 2021-04-13 19:59:22 --> 404 Page Not Found: user/Assets/css
DEBUG - 2021-04-13 19:59:22 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:59:22 --> Utf8 Class Initialized
INFO - 2021-04-13 19:59:22 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:59:22 --> Input Class Initialized
INFO - 2021-04-13 19:59:22 --> URI Class Initialized
INFO - 2021-04-13 19:59:22 --> Language Class Initialized
INFO - 2021-04-13 19:59:22 --> Router Class Initialized
ERROR - 2021-04-13 19:59:22 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:59:22 --> Output Class Initialized
INFO - 2021-04-13 19:59:22 --> Config Class Initialized
INFO - 2021-04-13 19:59:22 --> Hooks Class Initialized
INFO - 2021-04-13 19:59:22 --> Security Class Initialized
DEBUG - 2021-04-13 19:59:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 19:59:22 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:59:22 --> Input Class Initialized
INFO - 2021-04-13 19:59:22 --> Utf8 Class Initialized
INFO - 2021-04-13 19:59:22 --> Language Class Initialized
INFO - 2021-04-13 19:59:22 --> URI Class Initialized
ERROR - 2021-04-13 19:59:22 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:59:22 --> Config Class Initialized
INFO - 2021-04-13 19:59:22 --> Router Class Initialized
INFO - 2021-04-13 19:59:22 --> Hooks Class Initialized
INFO - 2021-04-13 19:59:22 --> Output Class Initialized
DEBUG - 2021-04-13 19:59:22 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:59:22 --> Utf8 Class Initialized
DEBUG - 2021-04-13 19:59:22 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:59:22 --> URI Class Initialized
INFO - 2021-04-13 19:59:22 --> Utf8 Class Initialized
INFO - 2021-04-13 19:59:22 --> Security Class Initialized
INFO - 2021-04-13 19:59:22 --> Router Class Initialized
INFO - 2021-04-13 19:59:22 --> URI Class Initialized
DEBUG - 2021-04-13 19:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:59:22 --> Input Class Initialized
INFO - 2021-04-13 19:59:22 --> Output Class Initialized
INFO - 2021-04-13 19:59:22 --> Router Class Initialized
INFO - 2021-04-13 19:59:22 --> Security Class Initialized
INFO - 2021-04-13 19:59:22 --> Language Class Initialized
INFO - 2021-04-13 19:59:22 --> Output Class Initialized
DEBUG - 2021-04-13 19:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:59:22 --> Input Class Initialized
INFO - 2021-04-13 19:59:22 --> Language Class Initialized
ERROR - 2021-04-13 19:59:22 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 19:59:22 --> Security Class Initialized
ERROR - 2021-04-13 19:59:22 --> 404 Page Not Found: user/Assets/js
DEBUG - 2021-04-13 19:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:59:22 --> Input Class Initialized
INFO - 2021-04-13 19:59:22 --> Language Class Initialized
ERROR - 2021-04-13 19:59:22 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 19:59:22 --> Config Class Initialized
INFO - 2021-04-13 19:59:22 --> Hooks Class Initialized
INFO - 2021-04-13 19:59:22 --> Config Class Initialized
INFO - 2021-04-13 19:59:22 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:59:22 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:59:22 --> Utf8 Class Initialized
INFO - 2021-04-13 19:59:22 --> URI Class Initialized
INFO - 2021-04-13 19:59:22 --> Config Class Initialized
INFO - 2021-04-13 19:59:22 --> Hooks Class Initialized
INFO - 2021-04-13 19:59:22 --> Router Class Initialized
DEBUG - 2021-04-13 19:59:22 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:59:22 --> Utf8 Class Initialized
INFO - 2021-04-13 19:59:22 --> Output Class Initialized
INFO - 2021-04-13 19:59:22 --> URI Class Initialized
INFO - 2021-04-13 19:59:22 --> Config Class Initialized
INFO - 2021-04-13 19:59:22 --> Security Class Initialized
INFO - 2021-04-13 19:59:22 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:59:22 --> Router Class Initialized
INFO - 2021-04-13 19:59:22 --> Input Class Initialized
INFO - 2021-04-13 19:59:22 --> Language Class Initialized
INFO - 2021-04-13 19:59:22 --> Output Class Initialized
DEBUG - 2021-04-13 19:59:22 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:59:22 --> Utf8 Class Initialized
ERROR - 2021-04-13 19:59:22 --> 404 Page Not Found: user/Assets/img
DEBUG - 2021-04-13 19:59:22 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:59:22 --> Security Class Initialized
INFO - 2021-04-13 19:59:22 --> URI Class Initialized
INFO - 2021-04-13 19:59:22 --> Utf8 Class Initialized
DEBUG - 2021-04-13 19:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:59:22 --> Input Class Initialized
INFO - 2021-04-13 19:59:22 --> URI Class Initialized
INFO - 2021-04-13 19:59:22 --> Router Class Initialized
INFO - 2021-04-13 19:59:22 --> Language Class Initialized
INFO - 2021-04-13 19:59:22 --> Router Class Initialized
INFO - 2021-04-13 19:59:22 --> Output Class Initialized
ERROR - 2021-04-13 19:59:22 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 19:59:22 --> Output Class Initialized
INFO - 2021-04-13 19:59:22 --> Security Class Initialized
INFO - 2021-04-13 19:59:22 --> Security Class Initialized
DEBUG - 2021-04-13 19:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:59:22 --> Input Class Initialized
INFO - 2021-04-13 19:59:22 --> Language Class Initialized
DEBUG - 2021-04-13 19:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:59:22 --> Input Class Initialized
INFO - 2021-04-13 19:59:22 --> Language Class Initialized
ERROR - 2021-04-13 19:59:22 --> 404 Page Not Found: user/Assets/img
ERROR - 2021-04-13 19:59:22 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:59:22 --> Config Class Initialized
INFO - 2021-04-13 19:59:22 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:59:22 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:59:22 --> Utf8 Class Initialized
INFO - 2021-04-13 19:59:22 --> URI Class Initialized
INFO - 2021-04-13 19:59:22 --> Router Class Initialized
INFO - 2021-04-13 19:59:22 --> Output Class Initialized
INFO - 2021-04-13 19:59:22 --> Security Class Initialized
DEBUG - 2021-04-13 19:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:59:22 --> Input Class Initialized
INFO - 2021-04-13 19:59:22 --> Language Class Initialized
ERROR - 2021-04-13 19:59:22 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 19:59:22 --> Config Class Initialized
INFO - 2021-04-13 19:59:22 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:59:22 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:59:22 --> Utf8 Class Initialized
INFO - 2021-04-13 19:59:22 --> URI Class Initialized
INFO - 2021-04-13 19:59:22 --> Router Class Initialized
INFO - 2021-04-13 19:59:22 --> Output Class Initialized
INFO - 2021-04-13 19:59:22 --> Security Class Initialized
DEBUG - 2021-04-13 19:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:59:22 --> Input Class Initialized
INFO - 2021-04-13 19:59:22 --> Language Class Initialized
ERROR - 2021-04-13 19:59:22 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 19:59:22 --> Config Class Initialized
INFO - 2021-04-13 19:59:22 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:59:22 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:59:22 --> Utf8 Class Initialized
INFO - 2021-04-13 19:59:22 --> URI Class Initialized
INFO - 2021-04-13 19:59:22 --> Router Class Initialized
INFO - 2021-04-13 19:59:22 --> Output Class Initialized
INFO - 2021-04-13 19:59:22 --> Security Class Initialized
DEBUG - 2021-04-13 19:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:59:22 --> Input Class Initialized
INFO - 2021-04-13 19:59:22 --> Language Class Initialized
ERROR - 2021-04-13 19:59:22 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 19:59:22 --> Config Class Initialized
INFO - 2021-04-13 19:59:22 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:59:22 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:59:22 --> Utf8 Class Initialized
INFO - 2021-04-13 19:59:22 --> URI Class Initialized
INFO - 2021-04-13 19:59:22 --> Router Class Initialized
INFO - 2021-04-13 19:59:22 --> Output Class Initialized
INFO - 2021-04-13 19:59:22 --> Security Class Initialized
DEBUG - 2021-04-13 19:59:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:59:22 --> Input Class Initialized
INFO - 2021-04-13 19:59:22 --> Language Class Initialized
ERROR - 2021-04-13 19:59:22 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 19:59:23 --> Config Class Initialized
INFO - 2021-04-13 19:59:23 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:59:23 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:59:23 --> Utf8 Class Initialized
INFO - 2021-04-13 19:59:23 --> URI Class Initialized
INFO - 2021-04-13 19:59:23 --> Router Class Initialized
INFO - 2021-04-13 19:59:23 --> Output Class Initialized
INFO - 2021-04-13 19:59:23 --> Security Class Initialized
DEBUG - 2021-04-13 19:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:59:23 --> Input Class Initialized
INFO - 2021-04-13 19:59:23 --> Language Class Initialized
INFO - 2021-04-13 19:59:23 --> Loader Class Initialized
INFO - 2021-04-13 19:59:23 --> Helper loaded: url_helper
INFO - 2021-04-13 19:59:23 --> Helper loaded: form_helper
INFO - 2021-04-13 19:59:23 --> Helper loaded: common_helper
INFO - 2021-04-13 19:59:23 --> Helper loaded: util_helper
INFO - 2021-04-13 19:59:23 --> Database Driver Class Initialized
DEBUG - 2021-04-13 19:59:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 19:59:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 19:59:23 --> Form Validation Class Initialized
INFO - 2021-04-13 19:59:23 --> Controller Class Initialized
INFO - 2021-04-13 19:59:23 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-13 19:59:23 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 19:59:23 --> Final output sent to browser
DEBUG - 2021-04-13 19:59:23 --> Total execution time: 0.0258
INFO - 2021-04-13 19:59:23 --> Config Class Initialized
INFO - 2021-04-13 19:59:23 --> Hooks Class Initialized
INFO - 2021-04-13 19:59:23 --> Config Class Initialized
INFO - 2021-04-13 19:59:23 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:59:23 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:59:23 --> Utf8 Class Initialized
DEBUG - 2021-04-13 19:59:23 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:59:23 --> Utf8 Class Initialized
INFO - 2021-04-13 19:59:23 --> URI Class Initialized
INFO - 2021-04-13 19:59:23 --> URI Class Initialized
INFO - 2021-04-13 19:59:23 --> Router Class Initialized
INFO - 2021-04-13 19:59:23 --> Config Class Initialized
INFO - 2021-04-13 19:59:23 --> Router Class Initialized
INFO - 2021-04-13 19:59:23 --> Hooks Class Initialized
INFO - 2021-04-13 19:59:23 --> Config Class Initialized
INFO - 2021-04-13 19:59:23 --> Output Class Initialized
INFO - 2021-04-13 19:59:23 --> Hooks Class Initialized
INFO - 2021-04-13 19:59:23 --> Output Class Initialized
INFO - 2021-04-13 19:59:23 --> Security Class Initialized
DEBUG - 2021-04-13 19:59:23 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:59:23 --> Security Class Initialized
DEBUG - 2021-04-13 19:59:23 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:59:23 --> Utf8 Class Initialized
DEBUG - 2021-04-13 19:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:59:23 --> URI Class Initialized
DEBUG - 2021-04-13 19:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:59:23 --> Input Class Initialized
INFO - 2021-04-13 19:59:23 --> Input Class Initialized
INFO - 2021-04-13 19:59:23 --> Router Class Initialized
INFO - 2021-04-13 19:59:23 --> Language Class Initialized
INFO - 2021-04-13 19:59:23 --> Language Class Initialized
INFO - 2021-04-13 19:59:23 --> Output Class Initialized
ERROR - 2021-04-13 19:59:23 --> 404 Page Not Found: user/Assets/css
ERROR - 2021-04-13 19:59:23 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:59:23 --> Security Class Initialized
INFO - 2021-04-13 19:59:23 --> Utf8 Class Initialized
DEBUG - 2021-04-13 19:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:59:23 --> Input Class Initialized
INFO - 2021-04-13 19:59:23 --> Config Class Initialized
INFO - 2021-04-13 19:59:23 --> Language Class Initialized
ERROR - 2021-04-13 19:59:23 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:59:23 --> URI Class Initialized
INFO - 2021-04-13 19:59:23 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:59:23 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:59:23 --> Router Class Initialized
INFO - 2021-04-13 19:59:23 --> Utf8 Class Initialized
INFO - 2021-04-13 19:59:23 --> Config Class Initialized
INFO - 2021-04-13 19:59:23 --> Config Class Initialized
INFO - 2021-04-13 19:59:23 --> Hooks Class Initialized
INFO - 2021-04-13 19:59:23 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:59:23 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:59:23 --> Utf8 Class Initialized
INFO - 2021-04-13 19:59:23 --> URI Class Initialized
DEBUG - 2021-04-13 19:59:23 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:59:23 --> Config Class Initialized
INFO - 2021-04-13 19:59:23 --> Utf8 Class Initialized
INFO - 2021-04-13 19:59:23 --> Config Class Initialized
INFO - 2021-04-13 19:59:23 --> Hooks Class Initialized
INFO - 2021-04-13 19:59:23 --> Hooks Class Initialized
INFO - 2021-04-13 19:59:23 --> URI Class Initialized
INFO - 2021-04-13 19:59:23 --> Router Class Initialized
INFO - 2021-04-13 19:59:23 --> Router Class Initialized
DEBUG - 2021-04-13 19:59:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 19:59:23 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:59:23 --> Utf8 Class Initialized
INFO - 2021-04-13 19:59:23 --> Output Class Initialized
INFO - 2021-04-13 19:59:23 --> Utf8 Class Initialized
INFO - 2021-04-13 19:59:23 --> URI Class Initialized
INFO - 2021-04-13 19:59:23 --> Output Class Initialized
INFO - 2021-04-13 19:59:23 --> URI Class Initialized
INFO - 2021-04-13 19:59:23 --> Security Class Initialized
INFO - 2021-04-13 19:59:23 --> Security Class Initialized
INFO - 2021-04-13 19:59:23 --> Router Class Initialized
INFO - 2021-04-13 19:59:23 --> Router Class Initialized
DEBUG - 2021-04-13 19:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:59:23 --> Input Class Initialized
DEBUG - 2021-04-13 19:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:59:23 --> Language Class Initialized
INFO - 2021-04-13 19:59:23 --> Input Class Initialized
INFO - 2021-04-13 19:59:23 --> Output Class Initialized
INFO - 2021-04-13 19:59:23 --> Output Class Initialized
INFO - 2021-04-13 19:59:23 --> Language Class Initialized
INFO - 2021-04-13 19:59:23 --> Security Class Initialized
INFO - 2021-04-13 19:59:23 --> Security Class Initialized
ERROR - 2021-04-13 19:59:23 --> 404 Page Not Found: user/Assets/js
ERROR - 2021-04-13 19:59:23 --> 404 Page Not Found: user/Assets/js
DEBUG - 2021-04-13 19:59:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 19:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:59:23 --> Output Class Initialized
INFO - 2021-04-13 19:59:23 --> Input Class Initialized
INFO - 2021-04-13 19:59:23 --> Input Class Initialized
INFO - 2021-04-13 19:59:23 --> Language Class Initialized
INFO - 2021-04-13 19:59:23 --> Language Class Initialized
INFO - 2021-04-13 19:59:23 --> Security Class Initialized
ERROR - 2021-04-13 19:59:23 --> 404 Page Not Found: user/Assets/js
ERROR - 2021-04-13 19:59:23 --> 404 Page Not Found: user/Assets/js
DEBUG - 2021-04-13 19:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:59:23 --> Input Class Initialized
INFO - 2021-04-13 19:59:23 --> Language Class Initialized
ERROR - 2021-04-13 19:59:23 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:59:23 --> Config Class Initialized
INFO - 2021-04-13 19:59:23 --> Hooks Class Initialized
INFO - 2021-04-13 19:59:23 --> Config Class Initialized
INFO - 2021-04-13 19:59:23 --> URI Class Initialized
INFO - 2021-04-13 19:59:23 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:59:23 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:59:23 --> Utf8 Class Initialized
INFO - 2021-04-13 19:59:23 --> Router Class Initialized
DEBUG - 2021-04-13 19:59:23 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:59:23 --> Utf8 Class Initialized
INFO - 2021-04-13 19:59:23 --> URI Class Initialized
INFO - 2021-04-13 19:59:23 --> URI Class Initialized
INFO - 2021-04-13 19:59:23 --> Output Class Initialized
INFO - 2021-04-13 19:59:23 --> Router Class Initialized
INFO - 2021-04-13 19:59:23 --> Router Class Initialized
INFO - 2021-04-13 19:59:23 --> Security Class Initialized
INFO - 2021-04-13 19:59:23 --> Output Class Initialized
DEBUG - 2021-04-13 19:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:59:23 --> Output Class Initialized
INFO - 2021-04-13 19:59:23 --> Input Class Initialized
INFO - 2021-04-13 19:59:23 --> Security Class Initialized
INFO - 2021-04-13 19:59:23 --> Language Class Initialized
INFO - 2021-04-13 19:59:23 --> Security Class Initialized
DEBUG - 2021-04-13 19:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:59:23 --> Input Class Initialized
ERROR - 2021-04-13 19:59:23 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:59:23 --> Language Class Initialized
DEBUG - 2021-04-13 19:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:59:23 --> Input Class Initialized
INFO - 2021-04-13 19:59:23 --> Language Class Initialized
ERROR - 2021-04-13 19:59:23 --> 404 Page Not Found: user/Assets/img
ERROR - 2021-04-13 19:59:23 --> 404 Page Not Found: user/Assets/img
INFO - 2021-04-13 19:59:23 --> Config Class Initialized
INFO - 2021-04-13 19:59:23 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:59:23 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:59:23 --> Utf8 Class Initialized
INFO - 2021-04-13 19:59:23 --> URI Class Initialized
INFO - 2021-04-13 19:59:23 --> Router Class Initialized
INFO - 2021-04-13 19:59:23 --> Output Class Initialized
INFO - 2021-04-13 19:59:23 --> Security Class Initialized
DEBUG - 2021-04-13 19:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:59:23 --> Input Class Initialized
INFO - 2021-04-13 19:59:23 --> Language Class Initialized
ERROR - 2021-04-13 19:59:23 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:59:23 --> Config Class Initialized
INFO - 2021-04-13 19:59:23 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:59:23 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:59:23 --> Utf8 Class Initialized
INFO - 2021-04-13 19:59:23 --> URI Class Initialized
INFO - 2021-04-13 19:59:23 --> Router Class Initialized
INFO - 2021-04-13 19:59:23 --> Output Class Initialized
INFO - 2021-04-13 19:59:23 --> Security Class Initialized
DEBUG - 2021-04-13 19:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:59:23 --> Input Class Initialized
INFO - 2021-04-13 19:59:23 --> Language Class Initialized
ERROR - 2021-04-13 19:59:23 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:59:23 --> Config Class Initialized
INFO - 2021-04-13 19:59:23 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:59:23 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:59:23 --> Utf8 Class Initialized
INFO - 2021-04-13 19:59:23 --> URI Class Initialized
INFO - 2021-04-13 19:59:23 --> Router Class Initialized
INFO - 2021-04-13 19:59:23 --> Output Class Initialized
INFO - 2021-04-13 19:59:23 --> Security Class Initialized
DEBUG - 2021-04-13 19:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:59:23 --> Input Class Initialized
INFO - 2021-04-13 19:59:23 --> Language Class Initialized
ERROR - 2021-04-13 19:59:23 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:59:23 --> Config Class Initialized
INFO - 2021-04-13 19:59:23 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:59:23 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:59:23 --> Utf8 Class Initialized
INFO - 2021-04-13 19:59:23 --> URI Class Initialized
INFO - 2021-04-13 19:59:23 --> Router Class Initialized
INFO - 2021-04-13 19:59:23 --> Output Class Initialized
INFO - 2021-04-13 19:59:23 --> Security Class Initialized
DEBUG - 2021-04-13 19:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:59:23 --> Input Class Initialized
INFO - 2021-04-13 19:59:23 --> Language Class Initialized
ERROR - 2021-04-13 19:59:23 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 19:59:23 --> Config Class Initialized
INFO - 2021-04-13 19:59:23 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:59:23 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:59:23 --> Utf8 Class Initialized
INFO - 2021-04-13 19:59:23 --> URI Class Initialized
INFO - 2021-04-13 19:59:23 --> Router Class Initialized
INFO - 2021-04-13 19:59:23 --> Output Class Initialized
INFO - 2021-04-13 19:59:23 --> Security Class Initialized
DEBUG - 2021-04-13 19:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:59:23 --> Input Class Initialized
INFO - 2021-04-13 19:59:23 --> Language Class Initialized
ERROR - 2021-04-13 19:59:23 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 19:59:23 --> Config Class Initialized
INFO - 2021-04-13 19:59:23 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:59:23 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:59:23 --> Utf8 Class Initialized
INFO - 2021-04-13 19:59:23 --> URI Class Initialized
INFO - 2021-04-13 19:59:23 --> Router Class Initialized
INFO - 2021-04-13 19:59:23 --> Output Class Initialized
INFO - 2021-04-13 19:59:23 --> Security Class Initialized
DEBUG - 2021-04-13 19:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:59:23 --> Input Class Initialized
INFO - 2021-04-13 19:59:23 --> Language Class Initialized
ERROR - 2021-04-13 19:59:23 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 19:59:23 --> Config Class Initialized
INFO - 2021-04-13 19:59:23 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:59:23 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:59:23 --> Utf8 Class Initialized
INFO - 2021-04-13 19:59:23 --> URI Class Initialized
INFO - 2021-04-13 19:59:23 --> Router Class Initialized
INFO - 2021-04-13 19:59:23 --> Output Class Initialized
INFO - 2021-04-13 19:59:23 --> Security Class Initialized
DEBUG - 2021-04-13 19:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:59:23 --> Input Class Initialized
INFO - 2021-04-13 19:59:23 --> Language Class Initialized
ERROR - 2021-04-13 19:59:23 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 19:59:23 --> Config Class Initialized
INFO - 2021-04-13 19:59:23 --> Hooks Class Initialized
DEBUG - 2021-04-13 19:59:23 --> UTF-8 Support Enabled
INFO - 2021-04-13 19:59:23 --> Utf8 Class Initialized
INFO - 2021-04-13 19:59:23 --> URI Class Initialized
INFO - 2021-04-13 19:59:23 --> Router Class Initialized
INFO - 2021-04-13 19:59:23 --> Output Class Initialized
INFO - 2021-04-13 19:59:23 --> Security Class Initialized
DEBUG - 2021-04-13 19:59:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 19:59:23 --> Input Class Initialized
INFO - 2021-04-13 19:59:23 --> Language Class Initialized
ERROR - 2021-04-13 19:59:23 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:00:23 --> Config Class Initialized
INFO - 2021-04-13 20:00:23 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:00:23 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:00:23 --> Utf8 Class Initialized
INFO - 2021-04-13 20:00:23 --> URI Class Initialized
INFO - 2021-04-13 20:00:23 --> Router Class Initialized
INFO - 2021-04-13 20:00:23 --> Output Class Initialized
INFO - 2021-04-13 20:00:23 --> Security Class Initialized
DEBUG - 2021-04-13 20:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:00:23 --> Input Class Initialized
INFO - 2021-04-13 20:00:23 --> Language Class Initialized
INFO - 2021-04-13 20:00:23 --> Loader Class Initialized
INFO - 2021-04-13 20:00:23 --> Helper loaded: url_helper
INFO - 2021-04-13 20:00:23 --> Helper loaded: form_helper
INFO - 2021-04-13 20:00:23 --> Helper loaded: common_helper
INFO - 2021-04-13 20:00:23 --> Helper loaded: util_helper
INFO - 2021-04-13 20:00:23 --> Database Driver Class Initialized
DEBUG - 2021-04-13 20:00:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 20:00:23 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 20:00:23 --> Form Validation Class Initialized
INFO - 2021-04-13 20:00:23 --> Controller Class Initialized
INFO - 2021-04-13 20:00:23 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-13 20:00:23 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 20:00:23 --> Final output sent to browser
DEBUG - 2021-04-13 20:00:23 --> Total execution time: 0.0355
INFO - 2021-04-13 20:00:23 --> Config Class Initialized
INFO - 2021-04-13 20:00:23 --> Hooks Class Initialized
INFO - 2021-04-13 20:00:23 --> Config Class Initialized
INFO - 2021-04-13 20:00:23 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:00:23 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:00:23 --> Utf8 Class Initialized
DEBUG - 2021-04-13 20:00:23 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:00:23 --> Utf8 Class Initialized
INFO - 2021-04-13 20:00:23 --> URI Class Initialized
INFO - 2021-04-13 20:00:23 --> URI Class Initialized
INFO - 2021-04-13 20:00:23 --> Router Class Initialized
INFO - 2021-04-13 20:00:23 --> Router Class Initialized
INFO - 2021-04-13 20:00:23 --> Output Class Initialized
INFO - 2021-04-13 20:00:23 --> Output Class Initialized
INFO - 2021-04-13 20:00:23 --> Security Class Initialized
INFO - 2021-04-13 20:00:23 --> Security Class Initialized
DEBUG - 2021-04-13 20:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:00:23 --> Input Class Initialized
INFO - 2021-04-13 20:00:23 --> Language Class Initialized
DEBUG - 2021-04-13 20:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:00:23 --> Input Class Initialized
INFO - 2021-04-13 20:00:23 --> Language Class Initialized
ERROR - 2021-04-13 20:00:23 --> 404 Page Not Found: user/Assets/css
ERROR - 2021-04-13 20:00:23 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:00:23 --> Config Class Initialized
INFO - 2021-04-13 20:00:23 --> Hooks Class Initialized
INFO - 2021-04-13 20:00:23 --> Config Class Initialized
INFO - 2021-04-13 20:00:23 --> Hooks Class Initialized
INFO - 2021-04-13 20:00:23 --> Config Class Initialized
INFO - 2021-04-13 20:00:23 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:00:23 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:00:23 --> Utf8 Class Initialized
DEBUG - 2021-04-13 20:00:23 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:00:23 --> URI Class Initialized
INFO - 2021-04-13 20:00:23 --> Utf8 Class Initialized
DEBUG - 2021-04-13 20:00:23 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:00:23 --> Utf8 Class Initialized
INFO - 2021-04-13 20:00:23 --> Router Class Initialized
INFO - 2021-04-13 20:00:23 --> URI Class Initialized
INFO - 2021-04-13 20:00:23 --> URI Class Initialized
INFO - 2021-04-13 20:00:23 --> Output Class Initialized
INFO - 2021-04-13 20:00:23 --> Security Class Initialized
INFO - 2021-04-13 20:00:23 --> Router Class Initialized
INFO - 2021-04-13 20:00:23 --> Router Class Initialized
DEBUG - 2021-04-13 20:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:00:23 --> Input Class Initialized
INFO - 2021-04-13 20:00:23 --> Language Class Initialized
INFO - 2021-04-13 20:00:23 --> Output Class Initialized
INFO - 2021-04-13 20:00:23 --> Output Class Initialized
INFO - 2021-04-13 20:00:23 --> Config Class Initialized
INFO - 2021-04-13 20:00:23 --> Hooks Class Initialized
ERROR - 2021-04-13 20:00:23 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:00:23 --> Security Class Initialized
INFO - 2021-04-13 20:00:23 --> Security Class Initialized
DEBUG - 2021-04-13 20:00:23 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:00:23 --> Utf8 Class Initialized
DEBUG - 2021-04-13 20:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:00:23 --> Input Class Initialized
INFO - 2021-04-13 20:00:23 --> URI Class Initialized
DEBUG - 2021-04-13 20:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:00:23 --> Input Class Initialized
INFO - 2021-04-13 20:00:23 --> Language Class Initialized
INFO - 2021-04-13 20:00:23 --> Router Class Initialized
INFO - 2021-04-13 20:00:23 --> Language Class Initialized
ERROR - 2021-04-13 20:00:23 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:00:23 --> Output Class Initialized
ERROR - 2021-04-13 20:00:23 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:00:23 --> Security Class Initialized
DEBUG - 2021-04-13 20:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:00:23 --> Config Class Initialized
INFO - 2021-04-13 20:00:23 --> Input Class Initialized
INFO - 2021-04-13 20:00:23 --> Hooks Class Initialized
INFO - 2021-04-13 20:00:23 --> Language Class Initialized
INFO - 2021-04-13 20:00:23 --> Config Class Initialized
INFO - 2021-04-13 20:00:23 --> Hooks Class Initialized
ERROR - 2021-04-13 20:00:23 --> 404 Page Not Found: user/Assets/css
DEBUG - 2021-04-13 20:00:23 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:00:23 --> Utf8 Class Initialized
INFO - 2021-04-13 20:00:23 --> URI Class Initialized
DEBUG - 2021-04-13 20:00:23 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:00:23 --> Router Class Initialized
INFO - 2021-04-13 20:00:23 --> Utf8 Class Initialized
INFO - 2021-04-13 20:00:23 --> URI Class Initialized
INFO - 2021-04-13 20:00:23 --> Output Class Initialized
INFO - 2021-04-13 20:00:23 --> Security Class Initialized
INFO - 2021-04-13 20:00:23 --> Router Class Initialized
DEBUG - 2021-04-13 20:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:00:23 --> Input Class Initialized
INFO - 2021-04-13 20:00:23 --> Language Class Initialized
INFO - 2021-04-13 20:00:23 --> Output Class Initialized
INFO - 2021-04-13 20:00:23 --> Config Class Initialized
INFO - 2021-04-13 20:00:23 --> Hooks Class Initialized
ERROR - 2021-04-13 20:00:23 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:00:23 --> Config Class Initialized
INFO - 2021-04-13 20:00:23 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:00:23 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:00:23 --> Utf8 Class Initialized
INFO - 2021-04-13 20:00:23 --> Security Class Initialized
DEBUG - 2021-04-13 20:00:23 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:00:23 --> Utf8 Class Initialized
INFO - 2021-04-13 20:00:23 --> URI Class Initialized
INFO - 2021-04-13 20:00:23 --> Router Class Initialized
INFO - 2021-04-13 20:00:23 --> URI Class Initialized
INFO - 2021-04-13 20:00:23 --> Output Class Initialized
INFO - 2021-04-13 20:00:23 --> Config Class Initialized
INFO - 2021-04-13 20:00:23 --> Hooks Class Initialized
INFO - 2021-04-13 20:00:23 --> Security Class Initialized
INFO - 2021-04-13 20:00:23 --> Router Class Initialized
DEBUG - 2021-04-13 20:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:00:23 --> Input Class Initialized
DEBUG - 2021-04-13 20:00:23 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:00:23 --> Language Class Initialized
INFO - 2021-04-13 20:00:23 --> Utf8 Class Initialized
INFO - 2021-04-13 20:00:23 --> Config Class Initialized
INFO - 2021-04-13 20:00:23 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:00:23 --> Output Class Initialized
ERROR - 2021-04-13 20:00:23 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:00:23 --> Input Class Initialized
INFO - 2021-04-13 20:00:23 --> URI Class Initialized
INFO - 2021-04-13 20:00:23 --> Security Class Initialized
DEBUG - 2021-04-13 20:00:23 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:00:23 --> Utf8 Class Initialized
INFO - 2021-04-13 20:00:23 --> Language Class Initialized
INFO - 2021-04-13 20:00:23 --> URI Class Initialized
DEBUG - 2021-04-13 20:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:00:23 --> Input Class Initialized
INFO - 2021-04-13 20:00:23 --> Router Class Initialized
INFO - 2021-04-13 20:00:23 --> Router Class Initialized
ERROR - 2021-04-13 20:00:23 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:00:23 --> Language Class Initialized
INFO - 2021-04-13 20:00:23 --> Output Class Initialized
INFO - 2021-04-13 20:00:23 --> Output Class Initialized
INFO - 2021-04-13 20:00:23 --> Security Class Initialized
ERROR - 2021-04-13 20:00:23 --> 404 Page Not Found: user/Assets/img
INFO - 2021-04-13 20:00:23 --> Security Class Initialized
DEBUG - 2021-04-13 20:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:00:23 --> Input Class Initialized
DEBUG - 2021-04-13 20:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:00:23 --> Language Class Initialized
INFO - 2021-04-13 20:00:23 --> Input Class Initialized
INFO - 2021-04-13 20:00:23 --> Language Class Initialized
ERROR - 2021-04-13 20:00:23 --> 404 Page Not Found: user/Assets/img
ERROR - 2021-04-13 20:00:23 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:00:23 --> Config Class Initialized
INFO - 2021-04-13 20:00:23 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:00:23 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:00:23 --> Utf8 Class Initialized
INFO - 2021-04-13 20:00:23 --> URI Class Initialized
INFO - 2021-04-13 20:00:23 --> Router Class Initialized
INFO - 2021-04-13 20:00:23 --> Output Class Initialized
INFO - 2021-04-13 20:00:23 --> Security Class Initialized
DEBUG - 2021-04-13 20:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:00:23 --> Input Class Initialized
INFO - 2021-04-13 20:00:23 --> Language Class Initialized
ERROR - 2021-04-13 20:00:23 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:00:23 --> Config Class Initialized
INFO - 2021-04-13 20:00:23 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:00:23 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:00:23 --> Utf8 Class Initialized
INFO - 2021-04-13 20:00:23 --> URI Class Initialized
INFO - 2021-04-13 20:00:23 --> Router Class Initialized
INFO - 2021-04-13 20:00:23 --> Output Class Initialized
INFO - 2021-04-13 20:00:23 --> Security Class Initialized
DEBUG - 2021-04-13 20:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:00:23 --> Input Class Initialized
INFO - 2021-04-13 20:00:23 --> Language Class Initialized
ERROR - 2021-04-13 20:00:23 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:00:23 --> Config Class Initialized
INFO - 2021-04-13 20:00:23 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:00:23 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:00:23 --> Utf8 Class Initialized
INFO - 2021-04-13 20:00:23 --> URI Class Initialized
INFO - 2021-04-13 20:00:23 --> Router Class Initialized
INFO - 2021-04-13 20:00:23 --> Output Class Initialized
INFO - 2021-04-13 20:00:23 --> Security Class Initialized
DEBUG - 2021-04-13 20:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:00:23 --> Input Class Initialized
INFO - 2021-04-13 20:00:23 --> Language Class Initialized
ERROR - 2021-04-13 20:00:23 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:00:23 --> Config Class Initialized
INFO - 2021-04-13 20:00:23 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:00:23 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:00:23 --> Utf8 Class Initialized
INFO - 2021-04-13 20:00:23 --> URI Class Initialized
INFO - 2021-04-13 20:00:23 --> Router Class Initialized
INFO - 2021-04-13 20:00:23 --> Output Class Initialized
INFO - 2021-04-13 20:00:23 --> Security Class Initialized
DEBUG - 2021-04-13 20:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:00:23 --> Input Class Initialized
INFO - 2021-04-13 20:00:23 --> Language Class Initialized
ERROR - 2021-04-13 20:00:23 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:00:23 --> Config Class Initialized
INFO - 2021-04-13 20:00:23 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:00:23 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:00:23 --> Utf8 Class Initialized
INFO - 2021-04-13 20:00:23 --> URI Class Initialized
INFO - 2021-04-13 20:00:23 --> Router Class Initialized
INFO - 2021-04-13 20:00:23 --> Output Class Initialized
INFO - 2021-04-13 20:00:23 --> Security Class Initialized
DEBUG - 2021-04-13 20:00:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:00:23 --> Input Class Initialized
INFO - 2021-04-13 20:00:23 --> Language Class Initialized
ERROR - 2021-04-13 20:00:23 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:00:43 --> Config Class Initialized
INFO - 2021-04-13 20:00:43 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:00:43 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:00:43 --> Utf8 Class Initialized
INFO - 2021-04-13 20:00:43 --> URI Class Initialized
INFO - 2021-04-13 20:00:43 --> Router Class Initialized
INFO - 2021-04-13 20:00:43 --> Output Class Initialized
INFO - 2021-04-13 20:00:43 --> Security Class Initialized
DEBUG - 2021-04-13 20:00:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:00:43 --> Input Class Initialized
INFO - 2021-04-13 20:00:43 --> Language Class Initialized
INFO - 2021-04-13 20:00:43 --> Loader Class Initialized
INFO - 2021-04-13 20:00:43 --> Helper loaded: url_helper
INFO - 2021-04-13 20:00:43 --> Helper loaded: form_helper
INFO - 2021-04-13 20:00:43 --> Helper loaded: common_helper
INFO - 2021-04-13 20:00:43 --> Helper loaded: util_helper
INFO - 2021-04-13 20:00:43 --> Database Driver Class Initialized
DEBUG - 2021-04-13 20:00:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 20:00:43 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 20:00:43 --> Form Validation Class Initialized
INFO - 2021-04-13 20:00:43 --> Controller Class Initialized
INFO - 2021-04-13 20:00:43 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-13 20:00:43 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 20:00:43 --> Final output sent to browser
DEBUG - 2021-04-13 20:00:43 --> Total execution time: 0.0247
INFO - 2021-04-13 20:00:56 --> Config Class Initialized
INFO - 2021-04-13 20:00:56 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:00:56 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:00:56 --> Utf8 Class Initialized
INFO - 2021-04-13 20:00:56 --> URI Class Initialized
INFO - 2021-04-13 20:00:56 --> Router Class Initialized
INFO - 2021-04-13 20:00:56 --> Output Class Initialized
INFO - 2021-04-13 20:00:56 --> Security Class Initialized
DEBUG - 2021-04-13 20:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:00:56 --> Input Class Initialized
INFO - 2021-04-13 20:00:56 --> Language Class Initialized
INFO - 2021-04-13 20:00:56 --> Loader Class Initialized
INFO - 2021-04-13 20:00:56 --> Helper loaded: url_helper
INFO - 2021-04-13 20:00:56 --> Helper loaded: form_helper
INFO - 2021-04-13 20:00:56 --> Helper loaded: common_helper
INFO - 2021-04-13 20:00:56 --> Helper loaded: util_helper
INFO - 2021-04-13 20:00:56 --> Database Driver Class Initialized
DEBUG - 2021-04-13 20:00:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 20:00:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 20:00:56 --> Form Validation Class Initialized
INFO - 2021-04-13 20:00:56 --> Controller Class Initialized
INFO - 2021-04-13 20:00:56 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-13 20:00:56 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 20:00:56 --> Final output sent to browser
DEBUG - 2021-04-13 20:00:56 --> Total execution time: 0.0347
INFO - 2021-04-13 20:00:56 --> Config Class Initialized
INFO - 2021-04-13 20:00:56 --> Hooks Class Initialized
INFO - 2021-04-13 20:00:56 --> Config Class Initialized
INFO - 2021-04-13 20:00:56 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:00:56 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:00:56 --> Utf8 Class Initialized
INFO - 2021-04-13 20:00:56 --> URI Class Initialized
INFO - 2021-04-13 20:00:56 --> Router Class Initialized
INFO - 2021-04-13 20:00:56 --> Output Class Initialized
DEBUG - 2021-04-13 20:00:56 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:00:56 --> Utf8 Class Initialized
INFO - 2021-04-13 20:00:56 --> Security Class Initialized
INFO - 2021-04-13 20:00:56 --> URI Class Initialized
DEBUG - 2021-04-13 20:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:00:56 --> Input Class Initialized
INFO - 2021-04-13 20:00:56 --> Router Class Initialized
INFO - 2021-04-13 20:00:56 --> Language Class Initialized
INFO - 2021-04-13 20:00:56 --> Config Class Initialized
ERROR - 2021-04-13 20:00:56 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:00:56 --> Output Class Initialized
INFO - 2021-04-13 20:00:56 --> Config Class Initialized
INFO - 2021-04-13 20:00:56 --> Hooks Class Initialized
INFO - 2021-04-13 20:00:56 --> Security Class Initialized
DEBUG - 2021-04-13 20:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:00:56 --> Input Class Initialized
DEBUG - 2021-04-13 20:00:56 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:00:56 --> Utf8 Class Initialized
INFO - 2021-04-13 20:00:56 --> Language Class Initialized
INFO - 2021-04-13 20:00:56 --> URI Class Initialized
ERROR - 2021-04-13 20:00:56 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:00:56 --> Router Class Initialized
INFO - 2021-04-13 20:00:56 --> Output Class Initialized
INFO - 2021-04-13 20:00:56 --> Security Class Initialized
DEBUG - 2021-04-13 20:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:00:56 --> Input Class Initialized
INFO - 2021-04-13 20:00:56 --> Language Class Initialized
INFO - 2021-04-13 20:00:56 --> Hooks Class Initialized
ERROR - 2021-04-13 20:00:56 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:00:56 --> Config Class Initialized
INFO - 2021-04-13 20:00:56 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:00:56 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:00:56 --> Utf8 Class Initialized
INFO - 2021-04-13 20:00:56 --> URI Class Initialized
DEBUG - 2021-04-13 20:00:56 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:00:56 --> Router Class Initialized
INFO - 2021-04-13 20:00:56 --> Output Class Initialized
INFO - 2021-04-13 20:00:56 --> Config Class Initialized
INFO - 2021-04-13 20:00:56 --> Hooks Class Initialized
INFO - 2021-04-13 20:00:56 --> Config Class Initialized
INFO - 2021-04-13 20:00:56 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:00:56 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:00:56 --> Utf8 Class Initialized
INFO - 2021-04-13 20:00:56 --> URI Class Initialized
INFO - 2021-04-13 20:00:56 --> Security Class Initialized
DEBUG - 2021-04-13 20:00:56 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:00:56 --> Utf8 Class Initialized
INFO - 2021-04-13 20:00:56 --> Router Class Initialized
INFO - 2021-04-13 20:00:56 --> Config Class Initialized
INFO - 2021-04-13 20:00:56 --> Hooks Class Initialized
INFO - 2021-04-13 20:00:56 --> URI Class Initialized
INFO - 2021-04-13 20:00:56 --> Output Class Initialized
INFO - 2021-04-13 20:00:56 --> Router Class Initialized
DEBUG - 2021-04-13 20:00:56 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:00:56 --> Utf8 Class Initialized
INFO - 2021-04-13 20:00:56 --> Security Class Initialized
INFO - 2021-04-13 20:00:56 --> Utf8 Class Initialized
INFO - 2021-04-13 20:00:56 --> Output Class Initialized
INFO - 2021-04-13 20:00:56 --> URI Class Initialized
DEBUG - 2021-04-13 20:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:00:56 --> Security Class Initialized
INFO - 2021-04-13 20:00:56 --> Router Class Initialized
INFO - 2021-04-13 20:00:56 --> Input Class Initialized
DEBUG - 2021-04-13 20:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:00:56 --> URI Class Initialized
DEBUG - 2021-04-13 20:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:00:56 --> Input Class Initialized
INFO - 2021-04-13 20:00:56 --> Language Class Initialized
INFO - 2021-04-13 20:00:56 --> Input Class Initialized
INFO - 2021-04-13 20:00:56 --> Output Class Initialized
INFO - 2021-04-13 20:00:56 --> Language Class Initialized
INFO - 2021-04-13 20:00:56 --> Security Class Initialized
ERROR - 2021-04-13 20:00:56 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:00:56 --> Router Class Initialized
INFO - 2021-04-13 20:00:56 --> Language Class Initialized
DEBUG - 2021-04-13 20:00:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 20:00:56 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:00:56 --> Input Class Initialized
INFO - 2021-04-13 20:00:56 --> Language Class Initialized
INFO - 2021-04-13 20:00:56 --> Output Class Initialized
ERROR - 2021-04-13 20:00:56 --> 404 Page Not Found: user/Assets/js
ERROR - 2021-04-13 20:00:56 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:00:56 --> Security Class Initialized
DEBUG - 2021-04-13 20:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:00:56 --> Input Class Initialized
INFO - 2021-04-13 20:00:56 --> Language Class Initialized
INFO - 2021-04-13 20:00:56 --> Config Class Initialized
INFO - 2021-04-13 20:00:56 --> Hooks Class Initialized
ERROR - 2021-04-13 20:00:56 --> 404 Page Not Found: user/Assets/js
DEBUG - 2021-04-13 20:00:56 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:00:56 --> Utf8 Class Initialized
INFO - 2021-04-13 20:00:56 --> URI Class Initialized
INFO - 2021-04-13 20:00:56 --> Router Class Initialized
INFO - 2021-04-13 20:00:56 --> Output Class Initialized
INFO - 2021-04-13 20:00:56 --> Security Class Initialized
INFO - 2021-04-13 20:00:56 --> Config Class Initialized
INFO - 2021-04-13 20:00:56 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:00:56 --> Input Class Initialized
INFO - 2021-04-13 20:00:56 --> Config Class Initialized
INFO - 2021-04-13 20:00:56 --> Config Class Initialized
INFO - 2021-04-13 20:00:56 --> Hooks Class Initialized
INFO - 2021-04-13 20:00:56 --> Language Class Initialized
INFO - 2021-04-13 20:00:56 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:00:56 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:00:56 --> Utf8 Class Initialized
INFO - 2021-04-13 20:00:56 --> URI Class Initialized
ERROR - 2021-04-13 20:00:56 --> 404 Page Not Found: user/Assets/css
DEBUG - 2021-04-13 20:00:56 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:00:56 --> Utf8 Class Initialized
DEBUG - 2021-04-13 20:00:56 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:00:56 --> Utf8 Class Initialized
INFO - 2021-04-13 20:00:56 --> URI Class Initialized
INFO - 2021-04-13 20:00:56 --> URI Class Initialized
INFO - 2021-04-13 20:00:56 --> Router Class Initialized
INFO - 2021-04-13 20:00:56 --> Router Class Initialized
INFO - 2021-04-13 20:00:56 --> Router Class Initialized
INFO - 2021-04-13 20:00:56 --> Output Class Initialized
INFO - 2021-04-13 20:00:56 --> Output Class Initialized
INFO - 2021-04-13 20:00:56 --> Output Class Initialized
INFO - 2021-04-13 20:00:56 --> Security Class Initialized
INFO - 2021-04-13 20:00:56 --> Security Class Initialized
INFO - 2021-04-13 20:00:56 --> Security Class Initialized
DEBUG - 2021-04-13 20:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 20:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 20:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:00:56 --> Input Class Initialized
INFO - 2021-04-13 20:00:56 --> Input Class Initialized
INFO - 2021-04-13 20:00:56 --> Input Class Initialized
INFO - 2021-04-13 20:00:56 --> Language Class Initialized
INFO - 2021-04-13 20:00:56 --> Language Class Initialized
INFO - 2021-04-13 20:00:56 --> Language Class Initialized
ERROR - 2021-04-13 20:00:56 --> 404 Page Not Found: user/Assets/css
ERROR - 2021-04-13 20:00:56 --> 404 Page Not Found: user/Assets/img
ERROR - 2021-04-13 20:00:56 --> 404 Page Not Found: user/Assets/img
INFO - 2021-04-13 20:00:56 --> Config Class Initialized
INFO - 2021-04-13 20:00:56 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:00:56 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:00:56 --> Utf8 Class Initialized
INFO - 2021-04-13 20:00:56 --> URI Class Initialized
INFO - 2021-04-13 20:00:56 --> Router Class Initialized
INFO - 2021-04-13 20:00:56 --> Output Class Initialized
INFO - 2021-04-13 20:00:56 --> Security Class Initialized
DEBUG - 2021-04-13 20:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:00:56 --> Input Class Initialized
INFO - 2021-04-13 20:00:56 --> Language Class Initialized
ERROR - 2021-04-13 20:00:56 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:00:56 --> Config Class Initialized
INFO - 2021-04-13 20:00:56 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:00:56 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:00:56 --> Utf8 Class Initialized
INFO - 2021-04-13 20:00:56 --> URI Class Initialized
INFO - 2021-04-13 20:00:56 --> Router Class Initialized
INFO - 2021-04-13 20:00:56 --> Output Class Initialized
INFO - 2021-04-13 20:00:56 --> Security Class Initialized
DEBUG - 2021-04-13 20:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:00:56 --> Input Class Initialized
INFO - 2021-04-13 20:00:56 --> Language Class Initialized
ERROR - 2021-04-13 20:00:56 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:00:56 --> Config Class Initialized
INFO - 2021-04-13 20:00:56 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:00:56 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:00:56 --> Utf8 Class Initialized
INFO - 2021-04-13 20:00:56 --> URI Class Initialized
INFO - 2021-04-13 20:00:56 --> Router Class Initialized
INFO - 2021-04-13 20:00:56 --> Output Class Initialized
INFO - 2021-04-13 20:00:56 --> Security Class Initialized
DEBUG - 2021-04-13 20:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:00:56 --> Input Class Initialized
INFO - 2021-04-13 20:00:56 --> Language Class Initialized
ERROR - 2021-04-13 20:00:56 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:00:56 --> Config Class Initialized
INFO - 2021-04-13 20:00:56 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:00:56 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:00:56 --> Utf8 Class Initialized
INFO - 2021-04-13 20:00:56 --> URI Class Initialized
INFO - 2021-04-13 20:00:56 --> Router Class Initialized
INFO - 2021-04-13 20:00:56 --> Output Class Initialized
INFO - 2021-04-13 20:00:56 --> Security Class Initialized
DEBUG - 2021-04-13 20:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:00:56 --> Input Class Initialized
INFO - 2021-04-13 20:00:56 --> Language Class Initialized
ERROR - 2021-04-13 20:00:56 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:00:56 --> Config Class Initialized
INFO - 2021-04-13 20:00:56 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:00:56 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:00:56 --> Utf8 Class Initialized
INFO - 2021-04-13 20:00:56 --> URI Class Initialized
INFO - 2021-04-13 20:00:56 --> Router Class Initialized
INFO - 2021-04-13 20:00:56 --> Output Class Initialized
INFO - 2021-04-13 20:00:56 --> Security Class Initialized
DEBUG - 2021-04-13 20:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:00:56 --> Input Class Initialized
INFO - 2021-04-13 20:00:56 --> Language Class Initialized
ERROR - 2021-04-13 20:00:56 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:00:56 --> Config Class Initialized
INFO - 2021-04-13 20:00:56 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:00:56 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:00:56 --> Utf8 Class Initialized
INFO - 2021-04-13 20:00:56 --> URI Class Initialized
INFO - 2021-04-13 20:00:56 --> Router Class Initialized
INFO - 2021-04-13 20:00:56 --> Output Class Initialized
INFO - 2021-04-13 20:00:56 --> Security Class Initialized
DEBUG - 2021-04-13 20:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:00:56 --> Input Class Initialized
INFO - 2021-04-13 20:00:56 --> Language Class Initialized
ERROR - 2021-04-13 20:00:56 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:00:56 --> Config Class Initialized
INFO - 2021-04-13 20:00:56 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:00:56 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:00:56 --> Utf8 Class Initialized
INFO - 2021-04-13 20:00:56 --> URI Class Initialized
INFO - 2021-04-13 20:00:56 --> Router Class Initialized
INFO - 2021-04-13 20:00:56 --> Output Class Initialized
INFO - 2021-04-13 20:00:56 --> Security Class Initialized
DEBUG - 2021-04-13 20:00:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:00:56 --> Input Class Initialized
INFO - 2021-04-13 20:00:56 --> Language Class Initialized
ERROR - 2021-04-13 20:00:56 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:02:04 --> Config Class Initialized
INFO - 2021-04-13 20:02:04 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:02:04 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:02:04 --> Utf8 Class Initialized
INFO - 2021-04-13 20:02:04 --> URI Class Initialized
INFO - 2021-04-13 20:02:04 --> Router Class Initialized
INFO - 2021-04-13 20:02:04 --> Output Class Initialized
INFO - 2021-04-13 20:02:04 --> Security Class Initialized
DEBUG - 2021-04-13 20:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:02:04 --> Input Class Initialized
INFO - 2021-04-13 20:02:04 --> Language Class Initialized
INFO - 2021-04-13 20:02:04 --> Loader Class Initialized
INFO - 2021-04-13 20:02:04 --> Helper loaded: url_helper
INFO - 2021-04-13 20:02:04 --> Helper loaded: form_helper
INFO - 2021-04-13 20:02:04 --> Helper loaded: common_helper
INFO - 2021-04-13 20:02:04 --> Helper loaded: util_helper
INFO - 2021-04-13 20:02:04 --> Database Driver Class Initialized
DEBUG - 2021-04-13 20:02:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 20:02:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 20:02:04 --> Form Validation Class Initialized
INFO - 2021-04-13 20:02:04 --> Controller Class Initialized
INFO - 2021-04-13 20:02:04 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-13 20:02:04 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 20:02:04 --> Final output sent to browser
DEBUG - 2021-04-13 20:02:04 --> Total execution time: 0.0257
INFO - 2021-04-13 20:02:04 --> Config Class Initialized
INFO - 2021-04-13 20:02:04 --> Hooks Class Initialized
INFO - 2021-04-13 20:02:04 --> Config Class Initialized
INFO - 2021-04-13 20:02:04 --> Hooks Class Initialized
INFO - 2021-04-13 20:02:04 --> Config Class Initialized
INFO - 2021-04-13 20:02:04 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:02:04 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:02:04 --> Utf8 Class Initialized
DEBUG - 2021-04-13 20:02:04 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:02:04 --> URI Class Initialized
DEBUG - 2021-04-13 20:02:04 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:02:04 --> Utf8 Class Initialized
INFO - 2021-04-13 20:02:04 --> Utf8 Class Initialized
INFO - 2021-04-13 20:02:04 --> URI Class Initialized
INFO - 2021-04-13 20:02:04 --> Router Class Initialized
INFO - 2021-04-13 20:02:04 --> URI Class Initialized
INFO - 2021-04-13 20:02:04 --> Router Class Initialized
INFO - 2021-04-13 20:02:04 --> Output Class Initialized
INFO - 2021-04-13 20:02:04 --> Router Class Initialized
INFO - 2021-04-13 20:02:04 --> Output Class Initialized
INFO - 2021-04-13 20:02:04 --> Security Class Initialized
INFO - 2021-04-13 20:02:04 --> Security Class Initialized
DEBUG - 2021-04-13 20:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:02:04 --> Input Class Initialized
INFO - 2021-04-13 20:02:04 --> Language Class Initialized
DEBUG - 2021-04-13 20:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:02:04 --> Input Class Initialized
INFO - 2021-04-13 20:02:04 --> Language Class Initialized
ERROR - 2021-04-13 20:02:04 --> 404 Page Not Found: user/Assets/css
ERROR - 2021-04-13 20:02:04 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:02:04 --> Output Class Initialized
INFO - 2021-04-13 20:02:04 --> Security Class Initialized
DEBUG - 2021-04-13 20:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:02:04 --> Input Class Initialized
INFO - 2021-04-13 20:02:04 --> Language Class Initialized
ERROR - 2021-04-13 20:02:04 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:02:04 --> Config Class Initialized
INFO - 2021-04-13 20:02:04 --> Hooks Class Initialized
INFO - 2021-04-13 20:02:04 --> Config Class Initialized
INFO - 2021-04-13 20:02:04 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:02:04 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 20:02:04 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:02:04 --> Utf8 Class Initialized
INFO - 2021-04-13 20:02:04 --> Utf8 Class Initialized
INFO - 2021-04-13 20:02:04 --> URI Class Initialized
INFO - 2021-04-13 20:02:04 --> URI Class Initialized
INFO - 2021-04-13 20:02:04 --> Config Class Initialized
INFO - 2021-04-13 20:02:04 --> Hooks Class Initialized
INFO - 2021-04-13 20:02:04 --> Router Class Initialized
INFO - 2021-04-13 20:02:04 --> Router Class Initialized
DEBUG - 2021-04-13 20:02:04 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:02:04 --> Utf8 Class Initialized
INFO - 2021-04-13 20:02:04 --> Output Class Initialized
INFO - 2021-04-13 20:02:04 --> Output Class Initialized
INFO - 2021-04-13 20:02:04 --> Config Class Initialized
INFO - 2021-04-13 20:02:04 --> Hooks Class Initialized
INFO - 2021-04-13 20:02:04 --> URI Class Initialized
INFO - 2021-04-13 20:02:04 --> Security Class Initialized
INFO - 2021-04-13 20:02:04 --> Security Class Initialized
DEBUG - 2021-04-13 20:02:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 20:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:02:04 --> Input Class Initialized
INFO - 2021-04-13 20:02:04 --> Input Class Initialized
DEBUG - 2021-04-13 20:02:04 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:02:04 --> Language Class Initialized
INFO - 2021-04-13 20:02:04 --> Language Class Initialized
INFO - 2021-04-13 20:02:04 --> Router Class Initialized
ERROR - 2021-04-13 20:02:04 --> 404 Page Not Found: user/Assets/js
ERROR - 2021-04-13 20:02:04 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:02:04 --> Config Class Initialized
INFO - 2021-04-13 20:02:04 --> Hooks Class Initialized
INFO - 2021-04-13 20:02:04 --> Output Class Initialized
INFO - 2021-04-13 20:02:04 --> Security Class Initialized
DEBUG - 2021-04-13 20:02:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 20:02:04 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:02:04 --> Utf8 Class Initialized
INFO - 2021-04-13 20:02:04 --> Input Class Initialized
INFO - 2021-04-13 20:02:04 --> Utf8 Class Initialized
INFO - 2021-04-13 20:02:04 --> Config Class Initialized
INFO - 2021-04-13 20:02:04 --> Hooks Class Initialized
INFO - 2021-04-13 20:02:04 --> Language Class Initialized
INFO - 2021-04-13 20:02:04 --> URI Class Initialized
ERROR - 2021-04-13 20:02:04 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:02:04 --> Router Class Initialized
DEBUG - 2021-04-13 20:02:04 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:02:04 --> Utf8 Class Initialized
INFO - 2021-04-13 20:02:04 --> URI Class Initialized
INFO - 2021-04-13 20:02:04 --> Output Class Initialized
INFO - 2021-04-13 20:02:04 --> Router Class Initialized
INFO - 2021-04-13 20:02:04 --> Security Class Initialized
DEBUG - 2021-04-13 20:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:02:04 --> Input Class Initialized
INFO - 2021-04-13 20:02:04 --> Output Class Initialized
INFO - 2021-04-13 20:02:04 --> Language Class Initialized
INFO - 2021-04-13 20:02:04 --> Security Class Initialized
INFO - 2021-04-13 20:02:04 --> Config Class Initialized
INFO - 2021-04-13 20:02:04 --> Hooks Class Initialized
ERROR - 2021-04-13 20:02:04 --> 404 Page Not Found: user/Assets/css
DEBUG - 2021-04-13 20:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:02:04 --> Input Class Initialized
INFO - 2021-04-13 20:02:04 --> Config Class Initialized
DEBUG - 2021-04-13 20:02:04 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:02:04 --> Hooks Class Initialized
INFO - 2021-04-13 20:02:04 --> Utf8 Class Initialized
INFO - 2021-04-13 20:02:04 --> URI Class Initialized
INFO - 2021-04-13 20:02:04 --> Language Class Initialized
INFO - 2021-04-13 20:02:04 --> Router Class Initialized
DEBUG - 2021-04-13 20:02:04 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:02:04 --> Utf8 Class Initialized
INFO - 2021-04-13 20:02:04 --> URI Class Initialized
INFO - 2021-04-13 20:02:04 --> Output Class Initialized
INFO - 2021-04-13 20:02:04 --> Security Class Initialized
INFO - 2021-04-13 20:02:04 --> Router Class Initialized
ERROR - 2021-04-13 20:02:04 --> 404 Page Not Found: user/Assets/js
DEBUG - 2021-04-13 20:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:02:04 --> Input Class Initialized
INFO - 2021-04-13 20:02:04 --> Output Class Initialized
INFO - 2021-04-13 20:02:04 --> Language Class Initialized
INFO - 2021-04-13 20:02:04 --> Security Class Initialized
ERROR - 2021-04-13 20:02:04 --> 404 Page Not Found: user/Assets/js
DEBUG - 2021-04-13 20:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:02:04 --> Input Class Initialized
INFO - 2021-04-13 20:02:04 --> Language Class Initialized
ERROR - 2021-04-13 20:02:04 --> 404 Page Not Found: user/Assets/img
INFO - 2021-04-13 20:02:04 --> Config Class Initialized
INFO - 2021-04-13 20:02:04 --> Hooks Class Initialized
INFO - 2021-04-13 20:02:04 --> Config Class Initialized
INFO - 2021-04-13 20:02:04 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:02:04 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:02:04 --> Utf8 Class Initialized
INFO - 2021-04-13 20:02:04 --> URI Class Initialized
INFO - 2021-04-13 20:02:04 --> URI Class Initialized
DEBUG - 2021-04-13 20:02:04 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:02:04 --> Utf8 Class Initialized
INFO - 2021-04-13 20:02:04 --> Router Class Initialized
INFO - 2021-04-13 20:02:04 --> URI Class Initialized
INFO - 2021-04-13 20:02:04 --> Router Class Initialized
INFO - 2021-04-13 20:02:04 --> Output Class Initialized
INFO - 2021-04-13 20:02:04 --> Router Class Initialized
INFO - 2021-04-13 20:02:04 --> Output Class Initialized
INFO - 2021-04-13 20:02:04 --> Security Class Initialized
INFO - 2021-04-13 20:02:04 --> Output Class Initialized
INFO - 2021-04-13 20:02:04 --> Security Class Initialized
DEBUG - 2021-04-13 20:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:02:04 --> Input Class Initialized
DEBUG - 2021-04-13 20:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:02:04 --> Security Class Initialized
INFO - 2021-04-13 20:02:04 --> Input Class Initialized
INFO - 2021-04-13 20:02:04 --> Language Class Initialized
INFO - 2021-04-13 20:02:04 --> Language Class Initialized
DEBUG - 2021-04-13 20:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:02:04 --> Input Class Initialized
ERROR - 2021-04-13 20:02:04 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:02:04 --> Language Class Initialized
ERROR - 2021-04-13 20:02:04 --> 404 Page Not Found: user/Assets/img
ERROR - 2021-04-13 20:02:04 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:02:04 --> Config Class Initialized
INFO - 2021-04-13 20:02:04 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:02:04 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:02:04 --> Utf8 Class Initialized
INFO - 2021-04-13 20:02:04 --> URI Class Initialized
INFO - 2021-04-13 20:02:04 --> Router Class Initialized
INFO - 2021-04-13 20:02:04 --> Output Class Initialized
INFO - 2021-04-13 20:02:04 --> Security Class Initialized
DEBUG - 2021-04-13 20:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:02:04 --> Input Class Initialized
INFO - 2021-04-13 20:02:04 --> Language Class Initialized
ERROR - 2021-04-13 20:02:04 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:02:04 --> Config Class Initialized
INFO - 2021-04-13 20:02:04 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:02:04 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:02:04 --> Utf8 Class Initialized
INFO - 2021-04-13 20:02:04 --> URI Class Initialized
INFO - 2021-04-13 20:02:04 --> Router Class Initialized
INFO - 2021-04-13 20:02:04 --> Output Class Initialized
INFO - 2021-04-13 20:02:04 --> Security Class Initialized
DEBUG - 2021-04-13 20:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:02:04 --> Input Class Initialized
INFO - 2021-04-13 20:02:04 --> Language Class Initialized
ERROR - 2021-04-13 20:02:04 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:02:04 --> Config Class Initialized
INFO - 2021-04-13 20:02:04 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:02:04 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:02:04 --> Utf8 Class Initialized
INFO - 2021-04-13 20:02:04 --> URI Class Initialized
INFO - 2021-04-13 20:02:04 --> Router Class Initialized
INFO - 2021-04-13 20:02:04 --> Output Class Initialized
INFO - 2021-04-13 20:02:04 --> Security Class Initialized
DEBUG - 2021-04-13 20:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:02:04 --> Input Class Initialized
INFO - 2021-04-13 20:02:04 --> Language Class Initialized
ERROR - 2021-04-13 20:02:04 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:02:04 --> Config Class Initialized
INFO - 2021-04-13 20:02:04 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:02:04 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:02:04 --> Utf8 Class Initialized
INFO - 2021-04-13 20:02:04 --> URI Class Initialized
INFO - 2021-04-13 20:02:04 --> Router Class Initialized
INFO - 2021-04-13 20:02:04 --> Output Class Initialized
INFO - 2021-04-13 20:02:04 --> Security Class Initialized
DEBUG - 2021-04-13 20:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:02:04 --> Input Class Initialized
INFO - 2021-04-13 20:02:04 --> Language Class Initialized
ERROR - 2021-04-13 20:02:04 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:02:04 --> Config Class Initialized
INFO - 2021-04-13 20:02:04 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:02:04 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:02:04 --> Utf8 Class Initialized
INFO - 2021-04-13 20:02:04 --> URI Class Initialized
INFO - 2021-04-13 20:02:04 --> Router Class Initialized
INFO - 2021-04-13 20:02:04 --> Output Class Initialized
INFO - 2021-04-13 20:02:04 --> Security Class Initialized
DEBUG - 2021-04-13 20:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:02:04 --> Input Class Initialized
INFO - 2021-04-13 20:02:04 --> Language Class Initialized
ERROR - 2021-04-13 20:02:04 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:02:04 --> Config Class Initialized
INFO - 2021-04-13 20:02:04 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:02:04 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:02:04 --> Utf8 Class Initialized
INFO - 2021-04-13 20:02:04 --> URI Class Initialized
INFO - 2021-04-13 20:02:04 --> Router Class Initialized
INFO - 2021-04-13 20:02:04 --> Output Class Initialized
INFO - 2021-04-13 20:02:04 --> Security Class Initialized
DEBUG - 2021-04-13 20:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:02:04 --> Input Class Initialized
INFO - 2021-04-13 20:02:04 --> Language Class Initialized
ERROR - 2021-04-13 20:02:04 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:02:04 --> Config Class Initialized
INFO - 2021-04-13 20:02:04 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:02:04 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:02:04 --> Utf8 Class Initialized
INFO - 2021-04-13 20:02:04 --> URI Class Initialized
INFO - 2021-04-13 20:02:04 --> Router Class Initialized
INFO - 2021-04-13 20:02:04 --> Output Class Initialized
INFO - 2021-04-13 20:02:04 --> Security Class Initialized
DEBUG - 2021-04-13 20:02:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:02:04 --> Input Class Initialized
INFO - 2021-04-13 20:02:04 --> Language Class Initialized
ERROR - 2021-04-13 20:02:04 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:22:14 --> Config Class Initialized
INFO - 2021-04-13 20:22:14 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:22:14 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:22:14 --> Utf8 Class Initialized
INFO - 2021-04-13 20:22:14 --> URI Class Initialized
INFO - 2021-04-13 20:22:14 --> Router Class Initialized
INFO - 2021-04-13 20:22:14 --> Output Class Initialized
INFO - 2021-04-13 20:22:14 --> Security Class Initialized
DEBUG - 2021-04-13 20:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:22:14 --> Input Class Initialized
INFO - 2021-04-13 20:22:14 --> Language Class Initialized
INFO - 2021-04-13 20:22:14 --> Loader Class Initialized
INFO - 2021-04-13 20:22:14 --> Helper loaded: url_helper
INFO - 2021-04-13 20:22:14 --> Helper loaded: form_helper
INFO - 2021-04-13 20:22:14 --> Helper loaded: common_helper
INFO - 2021-04-13 20:22:14 --> Helper loaded: util_helper
INFO - 2021-04-13 20:22:14 --> Database Driver Class Initialized
DEBUG - 2021-04-13 20:22:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 20:22:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 20:22:14 --> Form Validation Class Initialized
INFO - 2021-04-13 20:22:14 --> Controller Class Initialized
INFO - 2021-04-13 20:22:14 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-13 20:22:14 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 20:22:14 --> Final output sent to browser
DEBUG - 2021-04-13 20:22:14 --> Total execution time: 0.0279
INFO - 2021-04-13 20:22:14 --> Config Class Initialized
INFO - 2021-04-13 20:22:14 --> Hooks Class Initialized
INFO - 2021-04-13 20:22:14 --> Config Class Initialized
INFO - 2021-04-13 20:22:14 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:22:14 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:22:14 --> Utf8 Class Initialized
DEBUG - 2021-04-13 20:22:14 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:22:14 --> URI Class Initialized
INFO - 2021-04-13 20:22:14 --> Utf8 Class Initialized
INFO - 2021-04-13 20:22:14 --> URI Class Initialized
INFO - 2021-04-13 20:22:14 --> Router Class Initialized
INFO - 2021-04-13 20:22:14 --> Router Class Initialized
INFO - 2021-04-13 20:22:14 --> Output Class Initialized
INFO - 2021-04-13 20:22:14 --> Output Class Initialized
INFO - 2021-04-13 20:22:14 --> Security Class Initialized
INFO - 2021-04-13 20:22:14 --> Security Class Initialized
DEBUG - 2021-04-13 20:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:22:14 --> Input Class Initialized
DEBUG - 2021-04-13 20:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:22:14 --> Language Class Initialized
INFO - 2021-04-13 20:22:14 --> Input Class Initialized
INFO - 2021-04-13 20:22:14 --> Language Class Initialized
ERROR - 2021-04-13 20:22:14 --> 404 Page Not Found: user/Assets/css
ERROR - 2021-04-13 20:22:14 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:22:14 --> Config Class Initialized
INFO - 2021-04-13 20:22:14 --> Hooks Class Initialized
INFO - 2021-04-13 20:22:14 --> Config Class Initialized
INFO - 2021-04-13 20:22:14 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:22:14 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:22:14 --> Utf8 Class Initialized
INFO - 2021-04-13 20:22:14 --> URI Class Initialized
DEBUG - 2021-04-13 20:22:14 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:22:14 --> Utf8 Class Initialized
INFO - 2021-04-13 20:22:14 --> Router Class Initialized
INFO - 2021-04-13 20:22:14 --> URI Class Initialized
INFO - 2021-04-13 20:22:14 --> Router Class Initialized
INFO - 2021-04-13 20:22:14 --> Output Class Initialized
INFO - 2021-04-13 20:22:14 --> Security Class Initialized
INFO - 2021-04-13 20:22:14 --> Config Class Initialized
INFO - 2021-04-13 20:22:14 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:22:14 --> Output Class Initialized
INFO - 2021-04-13 20:22:14 --> Input Class Initialized
DEBUG - 2021-04-13 20:22:14 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:22:14 --> Utf8 Class Initialized
INFO - 2021-04-13 20:22:14 --> Language Class Initialized
INFO - 2021-04-13 20:22:14 --> Security Class Initialized
INFO - 2021-04-13 20:22:14 --> URI Class Initialized
DEBUG - 2021-04-13 20:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:22:14 --> Router Class Initialized
INFO - 2021-04-13 20:22:14 --> Input Class Initialized
ERROR - 2021-04-13 20:22:14 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:22:14 --> Language Class Initialized
INFO - 2021-04-13 20:22:14 --> Output Class Initialized
ERROR - 2021-04-13 20:22:14 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:22:14 --> Security Class Initialized
DEBUG - 2021-04-13 20:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:22:14 --> Input Class Initialized
INFO - 2021-04-13 20:22:14 --> Language Class Initialized
ERROR - 2021-04-13 20:22:14 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:22:14 --> Config Class Initialized
INFO - 2021-04-13 20:22:14 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:22:14 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:22:14 --> Config Class Initialized
INFO - 2021-04-13 20:22:14 --> Utf8 Class Initialized
INFO - 2021-04-13 20:22:14 --> Hooks Class Initialized
INFO - 2021-04-13 20:22:14 --> URI Class Initialized
INFO - 2021-04-13 20:22:14 --> Config Class Initialized
INFO - 2021-04-13 20:22:14 --> Router Class Initialized
DEBUG - 2021-04-13 20:22:14 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:22:14 --> Hooks Class Initialized
INFO - 2021-04-13 20:22:14 --> Utf8 Class Initialized
INFO - 2021-04-13 20:22:14 --> URI Class Initialized
INFO - 2021-04-13 20:22:14 --> Output Class Initialized
INFO - 2021-04-13 20:22:14 --> Router Class Initialized
DEBUG - 2021-04-13 20:22:14 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:22:14 --> Security Class Initialized
INFO - 2021-04-13 20:22:14 --> Utf8 Class Initialized
INFO - 2021-04-13 20:22:14 --> URI Class Initialized
INFO - 2021-04-13 20:22:14 --> Output Class Initialized
DEBUG - 2021-04-13 20:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:22:14 --> Input Class Initialized
INFO - 2021-04-13 20:22:14 --> Config Class Initialized
INFO - 2021-04-13 20:22:14 --> Hooks Class Initialized
INFO - 2021-04-13 20:22:14 --> Language Class Initialized
INFO - 2021-04-13 20:22:14 --> Security Class Initialized
INFO - 2021-04-13 20:22:14 --> Router Class Initialized
ERROR - 2021-04-13 20:22:14 --> 404 Page Not Found: user/Assets/js
DEBUG - 2021-04-13 20:22:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 20:22:14 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:22:14 --> Input Class Initialized
INFO - 2021-04-13 20:22:14 --> Utf8 Class Initialized
INFO - 2021-04-13 20:22:14 --> Output Class Initialized
INFO - 2021-04-13 20:22:14 --> Language Class Initialized
INFO - 2021-04-13 20:22:14 --> URI Class Initialized
INFO - 2021-04-13 20:22:14 --> Security Class Initialized
ERROR - 2021-04-13 20:22:14 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:22:14 --> Router Class Initialized
DEBUG - 2021-04-13 20:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:22:14 --> Input Class Initialized
INFO - 2021-04-13 20:22:14 --> Language Class Initialized
INFO - 2021-04-13 20:22:14 --> Output Class Initialized
ERROR - 2021-04-13 20:22:14 --> 404 Page Not Found: user/Assets/img
INFO - 2021-04-13 20:22:14 --> Security Class Initialized
DEBUG - 2021-04-13 20:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:22:14 --> Input Class Initialized
INFO - 2021-04-13 20:22:14 --> Language Class Initialized
ERROR - 2021-04-13 20:22:14 --> 404 Page Not Found: user/Assets/img
INFO - 2021-04-13 20:22:14 --> Config Class Initialized
INFO - 2021-04-13 20:22:14 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:22:14 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:22:14 --> Utf8 Class Initialized
INFO - 2021-04-13 20:22:14 --> URI Class Initialized
INFO - 2021-04-13 20:22:14 --> Router Class Initialized
INFO - 2021-04-13 20:22:14 --> Config Class Initialized
INFO - 2021-04-13 20:22:14 --> Hooks Class Initialized
INFO - 2021-04-13 20:22:14 --> Output Class Initialized
INFO - 2021-04-13 20:22:14 --> Security Class Initialized
DEBUG - 2021-04-13 20:22:14 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:22:14 --> Utf8 Class Initialized
DEBUG - 2021-04-13 20:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:22:14 --> Input Class Initialized
INFO - 2021-04-13 20:22:14 --> URI Class Initialized
INFO - 2021-04-13 20:22:14 --> Language Class Initialized
INFO - 2021-04-13 20:22:14 --> Router Class Initialized
ERROR - 2021-04-13 20:22:14 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:22:14 --> Output Class Initialized
INFO - 2021-04-13 20:22:14 --> Security Class Initialized
DEBUG - 2021-04-13 20:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:22:14 --> Input Class Initialized
INFO - 2021-04-13 20:22:14 --> Language Class Initialized
ERROR - 2021-04-13 20:22:14 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:22:14 --> Config Class Initialized
INFO - 2021-04-13 20:22:14 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:22:14 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:22:14 --> Utf8 Class Initialized
INFO - 2021-04-13 20:22:14 --> URI Class Initialized
INFO - 2021-04-13 20:22:14 --> Router Class Initialized
INFO - 2021-04-13 20:22:14 --> Output Class Initialized
INFO - 2021-04-13 20:22:14 --> Security Class Initialized
DEBUG - 2021-04-13 20:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:22:14 --> Input Class Initialized
INFO - 2021-04-13 20:22:14 --> Language Class Initialized
ERROR - 2021-04-13 20:22:14 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:22:14 --> Config Class Initialized
INFO - 2021-04-13 20:22:14 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:22:14 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:22:14 --> Utf8 Class Initialized
INFO - 2021-04-13 20:22:14 --> URI Class Initialized
INFO - 2021-04-13 20:22:14 --> Router Class Initialized
INFO - 2021-04-13 20:22:14 --> Output Class Initialized
INFO - 2021-04-13 20:22:14 --> Security Class Initialized
DEBUG - 2021-04-13 20:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:22:14 --> Input Class Initialized
INFO - 2021-04-13 20:22:14 --> Language Class Initialized
ERROR - 2021-04-13 20:22:14 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:22:14 --> Config Class Initialized
INFO - 2021-04-13 20:22:14 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:22:14 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:22:14 --> Utf8 Class Initialized
INFO - 2021-04-13 20:22:14 --> URI Class Initialized
INFO - 2021-04-13 20:22:14 --> Router Class Initialized
INFO - 2021-04-13 20:22:14 --> Output Class Initialized
INFO - 2021-04-13 20:22:14 --> Security Class Initialized
DEBUG - 2021-04-13 20:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:22:14 --> Input Class Initialized
INFO - 2021-04-13 20:22:14 --> Language Class Initialized
ERROR - 2021-04-13 20:22:14 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:22:14 --> Config Class Initialized
INFO - 2021-04-13 20:22:14 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:22:14 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:22:14 --> Utf8 Class Initialized
INFO - 2021-04-13 20:22:14 --> URI Class Initialized
INFO - 2021-04-13 20:22:14 --> Router Class Initialized
INFO - 2021-04-13 20:22:14 --> Output Class Initialized
INFO - 2021-04-13 20:22:14 --> Security Class Initialized
DEBUG - 2021-04-13 20:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:22:14 --> Input Class Initialized
INFO - 2021-04-13 20:22:14 --> Language Class Initialized
ERROR - 2021-04-13 20:22:14 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:22:14 --> Config Class Initialized
INFO - 2021-04-13 20:22:14 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:22:14 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:22:14 --> Utf8 Class Initialized
INFO - 2021-04-13 20:22:14 --> URI Class Initialized
INFO - 2021-04-13 20:22:14 --> Router Class Initialized
INFO - 2021-04-13 20:22:14 --> Output Class Initialized
INFO - 2021-04-13 20:22:14 --> Security Class Initialized
DEBUG - 2021-04-13 20:22:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:22:14 --> Input Class Initialized
INFO - 2021-04-13 20:22:14 --> Language Class Initialized
ERROR - 2021-04-13 20:22:14 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:28:48 --> Config Class Initialized
INFO - 2021-04-13 20:28:48 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:28:48 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:28:48 --> Utf8 Class Initialized
INFO - 2021-04-13 20:28:48 --> URI Class Initialized
INFO - 2021-04-13 20:28:48 --> Router Class Initialized
INFO - 2021-04-13 20:28:48 --> Output Class Initialized
INFO - 2021-04-13 20:28:48 --> Security Class Initialized
DEBUG - 2021-04-13 20:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:28:48 --> Input Class Initialized
INFO - 2021-04-13 20:28:48 --> Language Class Initialized
INFO - 2021-04-13 20:28:48 --> Loader Class Initialized
INFO - 2021-04-13 20:28:48 --> Helper loaded: url_helper
INFO - 2021-04-13 20:28:48 --> Helper loaded: form_helper
INFO - 2021-04-13 20:28:48 --> Helper loaded: common_helper
INFO - 2021-04-13 20:28:48 --> Helper loaded: util_helper
INFO - 2021-04-13 20:28:48 --> Database Driver Class Initialized
DEBUG - 2021-04-13 20:28:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 20:28:48 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 20:28:48 --> Form Validation Class Initialized
INFO - 2021-04-13 20:28:48 --> Controller Class Initialized
INFO - 2021-04-13 20:28:48 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-13 20:28:48 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 20:28:48 --> Final output sent to browser
DEBUG - 2021-04-13 20:28:48 --> Total execution time: 0.0362
INFO - 2021-04-13 20:28:48 --> Config Class Initialized
INFO - 2021-04-13 20:28:48 --> Hooks Class Initialized
INFO - 2021-04-13 20:28:48 --> Config Class Initialized
DEBUG - 2021-04-13 20:28:48 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:28:48 --> Config Class Initialized
INFO - 2021-04-13 20:28:48 --> Utf8 Class Initialized
INFO - 2021-04-13 20:28:48 --> Hooks Class Initialized
INFO - 2021-04-13 20:28:48 --> Hooks Class Initialized
INFO - 2021-04-13 20:28:48 --> URI Class Initialized
INFO - 2021-04-13 20:28:48 --> Router Class Initialized
INFO - 2021-04-13 20:28:48 --> Output Class Initialized
DEBUG - 2021-04-13 20:28:48 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:28:48 --> Security Class Initialized
DEBUG - 2021-04-13 20:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:28:48 --> Input Class Initialized
INFO - 2021-04-13 20:28:48 --> Utf8 Class Initialized
INFO - 2021-04-13 20:28:48 --> Language Class Initialized
ERROR - 2021-04-13 20:28:48 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:28:48 --> URI Class Initialized
INFO - 2021-04-13 20:28:48 --> Config Class Initialized
INFO - 2021-04-13 20:28:48 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:28:48 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:28:48 --> Utf8 Class Initialized
INFO - 2021-04-13 20:28:48 --> Router Class Initialized
INFO - 2021-04-13 20:28:48 --> URI Class Initialized
DEBUG - 2021-04-13 20:28:48 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:28:48 --> Utf8 Class Initialized
INFO - 2021-04-13 20:28:48 --> Output Class Initialized
INFO - 2021-04-13 20:28:48 --> URI Class Initialized
INFO - 2021-04-13 20:28:48 --> Router Class Initialized
INFO - 2021-04-13 20:28:48 --> Security Class Initialized
INFO - 2021-04-13 20:28:48 --> Router Class Initialized
INFO - 2021-04-13 20:28:48 --> Output Class Initialized
INFO - 2021-04-13 20:28:48 --> Output Class Initialized
DEBUG - 2021-04-13 20:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:28:48 --> Security Class Initialized
INFO - 2021-04-13 20:28:48 --> Input Class Initialized
INFO - 2021-04-13 20:28:48 --> Security Class Initialized
DEBUG - 2021-04-13 20:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 20:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:28:48 --> Input Class Initialized
INFO - 2021-04-13 20:28:48 --> Language Class Initialized
INFO - 2021-04-13 20:28:48 --> Input Class Initialized
INFO - 2021-04-13 20:28:48 --> Language Class Initialized
INFO - 2021-04-13 20:28:48 --> Language Class Initialized
ERROR - 2021-04-13 20:28:48 --> 404 Page Not Found: user/Assets/css
ERROR - 2021-04-13 20:28:48 --> 404 Page Not Found: user/Assets/css
ERROR - 2021-04-13 20:28:48 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:28:48 --> Config Class Initialized
INFO - 2021-04-13 20:28:48 --> Hooks Class Initialized
INFO - 2021-04-13 20:28:48 --> Config Class Initialized
DEBUG - 2021-04-13 20:28:48 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:28:48 --> Hooks Class Initialized
INFO - 2021-04-13 20:28:48 --> Utf8 Class Initialized
INFO - 2021-04-13 20:28:48 --> Config Class Initialized
INFO - 2021-04-13 20:28:48 --> Hooks Class Initialized
INFO - 2021-04-13 20:28:48 --> URI Class Initialized
DEBUG - 2021-04-13 20:28:48 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:28:48 --> Utf8 Class Initialized
INFO - 2021-04-13 20:28:48 --> Router Class Initialized
DEBUG - 2021-04-13 20:28:48 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:28:48 --> Utf8 Class Initialized
INFO - 2021-04-13 20:28:48 --> URI Class Initialized
INFO - 2021-04-13 20:28:48 --> Output Class Initialized
INFO - 2021-04-13 20:28:48 --> URI Class Initialized
INFO - 2021-04-13 20:28:48 --> Router Class Initialized
INFO - 2021-04-13 20:28:48 --> Security Class Initialized
INFO - 2021-04-13 20:28:48 --> Router Class Initialized
INFO - 2021-04-13 20:28:48 --> Output Class Initialized
DEBUG - 2021-04-13 20:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:28:48 --> Input Class Initialized
INFO - 2021-04-13 20:28:48 --> Output Class Initialized
INFO - 2021-04-13 20:28:48 --> Language Class Initialized
INFO - 2021-04-13 20:28:48 --> Security Class Initialized
INFO - 2021-04-13 20:28:48 --> Security Class Initialized
DEBUG - 2021-04-13 20:28:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 20:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:28:48 --> Input Class Initialized
INFO - 2021-04-13 20:28:48 --> Input Class Initialized
INFO - 2021-04-13 20:28:48 --> Language Class Initialized
INFO - 2021-04-13 20:28:48 --> Language Class Initialized
ERROR - 2021-04-13 20:28:48 --> 404 Page Not Found: user/Assets/js
ERROR - 2021-04-13 20:28:48 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:28:48 --> Config Class Initialized
INFO - 2021-04-13 20:28:48 --> Hooks Class Initialized
ERROR - 2021-04-13 20:28:48 --> 404 Page Not Found: user/Assets/js
DEBUG - 2021-04-13 20:28:48 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:28:48 --> Utf8 Class Initialized
INFO - 2021-04-13 20:28:48 --> URI Class Initialized
INFO - 2021-04-13 20:28:48 --> Router Class Initialized
INFO - 2021-04-13 20:28:48 --> Config Class Initialized
INFO - 2021-04-13 20:28:48 --> Hooks Class Initialized
INFO - 2021-04-13 20:28:48 --> Output Class Initialized
DEBUG - 2021-04-13 20:28:48 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:28:48 --> Security Class Initialized
INFO - 2021-04-13 20:28:48 --> Utf8 Class Initialized
INFO - 2021-04-13 20:28:48 --> Config Class Initialized
INFO - 2021-04-13 20:28:48 --> Hooks Class Initialized
INFO - 2021-04-13 20:28:48 --> URI Class Initialized
DEBUG - 2021-04-13 20:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:28:48 --> Input Class Initialized
INFO - 2021-04-13 20:28:48 --> Language Class Initialized
INFO - 2021-04-13 20:28:48 --> Router Class Initialized
DEBUG - 2021-04-13 20:28:48 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:28:48 --> Utf8 Class Initialized
ERROR - 2021-04-13 20:28:48 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:28:48 --> Config Class Initialized
INFO - 2021-04-13 20:28:48 --> URI Class Initialized
INFO - 2021-04-13 20:28:48 --> Hooks Class Initialized
INFO - 2021-04-13 20:28:48 --> Config Class Initialized
INFO - 2021-04-13 20:28:48 --> Router Class Initialized
INFO - 2021-04-13 20:28:48 --> Output Class Initialized
INFO - 2021-04-13 20:28:48 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:28:48 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:28:48 --> Utf8 Class Initialized
INFO - 2021-04-13 20:28:48 --> Security Class Initialized
INFO - 2021-04-13 20:28:48 --> Output Class Initialized
INFO - 2021-04-13 20:28:48 --> URI Class Initialized
DEBUG - 2021-04-13 20:28:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 20:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:28:48 --> Input Class Initialized
INFO - 2021-04-13 20:28:48 --> Security Class Initialized
INFO - 2021-04-13 20:28:48 --> Utf8 Class Initialized
INFO - 2021-04-13 20:28:48 --> Language Class Initialized
INFO - 2021-04-13 20:28:48 --> Router Class Initialized
DEBUG - 2021-04-13 20:28:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:28:48 --> URI Class Initialized
INFO - 2021-04-13 20:28:48 --> Input Class Initialized
ERROR - 2021-04-13 20:28:49 --> 404 Page Not Found: user/Assets/img
INFO - 2021-04-13 20:28:49 --> Output Class Initialized
INFO - 2021-04-13 20:28:49 --> Language Class Initialized
INFO - 2021-04-13 20:28:49 --> Router Class Initialized
INFO - 2021-04-13 20:28:49 --> Security Class Initialized
INFO - 2021-04-13 20:28:49 --> Output Class Initialized
ERROR - 2021-04-13 20:28:49 --> 404 Page Not Found: user/Assets/img
DEBUG - 2021-04-13 20:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:28:49 --> Input Class Initialized
INFO - 2021-04-13 20:28:49 --> Security Class Initialized
INFO - 2021-04-13 20:28:49 --> Language Class Initialized
DEBUG - 2021-04-13 20:28:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 20:28:49 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:28:49 --> Input Class Initialized
INFO - 2021-04-13 20:28:49 --> Language Class Initialized
ERROR - 2021-04-13 20:28:49 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:28:49 --> Config Class Initialized
INFO - 2021-04-13 20:28:49 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:28:49 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:28:49 --> Utf8 Class Initialized
INFO - 2021-04-13 20:28:49 --> URI Class Initialized
INFO - 2021-04-13 20:28:49 --> Router Class Initialized
INFO - 2021-04-13 20:28:49 --> Output Class Initialized
INFO - 2021-04-13 20:28:49 --> Security Class Initialized
DEBUG - 2021-04-13 20:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:28:49 --> Input Class Initialized
INFO - 2021-04-13 20:28:49 --> Language Class Initialized
ERROR - 2021-04-13 20:28:49 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:28:49 --> Config Class Initialized
INFO - 2021-04-13 20:28:49 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:28:49 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:28:49 --> Utf8 Class Initialized
INFO - 2021-04-13 20:28:49 --> URI Class Initialized
INFO - 2021-04-13 20:28:49 --> Router Class Initialized
INFO - 2021-04-13 20:28:49 --> Output Class Initialized
INFO - 2021-04-13 20:28:49 --> Security Class Initialized
DEBUG - 2021-04-13 20:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:28:49 --> Input Class Initialized
INFO - 2021-04-13 20:28:49 --> Language Class Initialized
ERROR - 2021-04-13 20:28:49 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:28:49 --> Config Class Initialized
INFO - 2021-04-13 20:28:49 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:28:49 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:28:49 --> Utf8 Class Initialized
INFO - 2021-04-13 20:28:49 --> URI Class Initialized
INFO - 2021-04-13 20:28:49 --> Router Class Initialized
INFO - 2021-04-13 20:28:49 --> Output Class Initialized
INFO - 2021-04-13 20:28:49 --> Security Class Initialized
DEBUG - 2021-04-13 20:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:28:49 --> Input Class Initialized
INFO - 2021-04-13 20:28:49 --> Language Class Initialized
ERROR - 2021-04-13 20:28:49 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:28:49 --> Config Class Initialized
INFO - 2021-04-13 20:28:49 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:28:49 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:28:49 --> Utf8 Class Initialized
INFO - 2021-04-13 20:28:49 --> URI Class Initialized
INFO - 2021-04-13 20:28:49 --> Router Class Initialized
INFO - 2021-04-13 20:28:49 --> Output Class Initialized
INFO - 2021-04-13 20:28:49 --> Security Class Initialized
DEBUG - 2021-04-13 20:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:28:49 --> Input Class Initialized
INFO - 2021-04-13 20:28:49 --> Language Class Initialized
ERROR - 2021-04-13 20:28:49 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:28:49 --> Config Class Initialized
INFO - 2021-04-13 20:28:49 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:28:49 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:28:49 --> Utf8 Class Initialized
INFO - 2021-04-13 20:28:49 --> URI Class Initialized
INFO - 2021-04-13 20:28:49 --> Router Class Initialized
INFO - 2021-04-13 20:28:49 --> Output Class Initialized
INFO - 2021-04-13 20:28:49 --> Security Class Initialized
DEBUG - 2021-04-13 20:28:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:28:49 --> Input Class Initialized
INFO - 2021-04-13 20:28:49 --> Language Class Initialized
ERROR - 2021-04-13 20:28:49 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:33:03 --> Config Class Initialized
INFO - 2021-04-13 20:33:03 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:33:03 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:33:03 --> Utf8 Class Initialized
INFO - 2021-04-13 20:33:03 --> URI Class Initialized
INFO - 2021-04-13 20:33:03 --> Router Class Initialized
INFO - 2021-04-13 20:33:03 --> Output Class Initialized
INFO - 2021-04-13 20:33:03 --> Security Class Initialized
DEBUG - 2021-04-13 20:33:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:33:03 --> Input Class Initialized
INFO - 2021-04-13 20:33:03 --> Language Class Initialized
INFO - 2021-04-13 20:33:03 --> Loader Class Initialized
INFO - 2021-04-13 20:33:03 --> Helper loaded: url_helper
INFO - 2021-04-13 20:33:03 --> Helper loaded: form_helper
INFO - 2021-04-13 20:33:03 --> Helper loaded: common_helper
INFO - 2021-04-13 20:33:03 --> Helper loaded: util_helper
INFO - 2021-04-13 20:33:03 --> Database Driver Class Initialized
ERROR - 2021-04-13 20:33:03 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 20:33:03 --> Unable to connect to the database
DEBUG - 2021-04-13 20:33:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 20:33:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 20:33:03 --> Form Validation Class Initialized
INFO - 2021-04-13 20:33:03 --> Controller Class Initialized
INFO - 2021-04-13 20:33:03 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-13 20:33:03 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 20:33:03 --> Final output sent to browser
DEBUG - 2021-04-13 20:33:03 --> Total execution time: 0.0361
INFO - 2021-04-13 20:33:04 --> Config Class Initialized
INFO - 2021-04-13 20:33:04 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:33:04 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:33:04 --> Utf8 Class Initialized
INFO - 2021-04-13 20:33:04 --> URI Class Initialized
INFO - 2021-04-13 20:33:04 --> Config Class Initialized
INFO - 2021-04-13 20:33:04 --> Hooks Class Initialized
INFO - 2021-04-13 20:33:04 --> Router Class Initialized
INFO - 2021-04-13 20:33:04 --> Output Class Initialized
INFO - 2021-04-13 20:33:04 --> Config Class Initialized
DEBUG - 2021-04-13 20:33:04 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:33:04 --> Hooks Class Initialized
INFO - 2021-04-13 20:33:04 --> Utf8 Class Initialized
INFO - 2021-04-13 20:33:04 --> Security Class Initialized
INFO - 2021-04-13 20:33:04 --> Config Class Initialized
INFO - 2021-04-13 20:33:04 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:33:04 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 20:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:33:04 --> Input Class Initialized
INFO - 2021-04-13 20:33:04 --> URI Class Initialized
INFO - 2021-04-13 20:33:04 --> Language Class Initialized
INFO - 2021-04-13 20:33:04 --> Utf8 Class Initialized
ERROR - 2021-04-13 20:33:04 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:33:04 --> Router Class Initialized
DEBUG - 2021-04-13 20:33:04 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:33:04 --> Utf8 Class Initialized
INFO - 2021-04-13 20:33:04 --> URI Class Initialized
INFO - 2021-04-13 20:33:04 --> URI Class Initialized
INFO - 2021-04-13 20:33:04 --> Output Class Initialized
INFO - 2021-04-13 20:33:04 --> Router Class Initialized
INFO - 2021-04-13 20:33:04 --> Router Class Initialized
INFO - 2021-04-13 20:33:04 --> Security Class Initialized
INFO - 2021-04-13 20:33:04 --> Output Class Initialized
DEBUG - 2021-04-13 20:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:33:04 --> Output Class Initialized
INFO - 2021-04-13 20:33:04 --> Input Class Initialized
INFO - 2021-04-13 20:33:04 --> Security Class Initialized
INFO - 2021-04-13 20:33:04 --> Language Class Initialized
INFO - 2021-04-13 20:33:04 --> Security Class Initialized
DEBUG - 2021-04-13 20:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:33:04 --> Input Class Initialized
ERROR - 2021-04-13 20:33:04 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:33:04 --> Language Class Initialized
INFO - 2021-04-13 20:33:04 --> Config Class Initialized
DEBUG - 2021-04-13 20:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:33:04 --> Hooks Class Initialized
INFO - 2021-04-13 20:33:04 --> Input Class Initialized
ERROR - 2021-04-13 20:33:04 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:33:04 --> Language Class Initialized
DEBUG - 2021-04-13 20:33:04 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:33:04 --> Utf8 Class Initialized
ERROR - 2021-04-13 20:33:04 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:33:04 --> URI Class Initialized
INFO - 2021-04-13 20:33:04 --> Router Class Initialized
INFO - 2021-04-13 20:33:04 --> Output Class Initialized
INFO - 2021-04-13 20:33:04 --> Security Class Initialized
DEBUG - 2021-04-13 20:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:33:04 --> Input Class Initialized
INFO - 2021-04-13 20:33:04 --> Language Class Initialized
ERROR - 2021-04-13 20:33:04 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:33:04 --> Config Class Initialized
INFO - 2021-04-13 20:33:04 --> Config Class Initialized
INFO - 2021-04-13 20:33:04 --> Hooks Class Initialized
INFO - 2021-04-13 20:33:04 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:33:04 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 20:33:04 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:33:04 --> Utf8 Class Initialized
INFO - 2021-04-13 20:33:04 --> Utf8 Class Initialized
INFO - 2021-04-13 20:33:04 --> URI Class Initialized
INFO - 2021-04-13 20:33:04 --> URI Class Initialized
INFO - 2021-04-13 20:33:04 --> Config Class Initialized
INFO - 2021-04-13 20:33:04 --> Hooks Class Initialized
INFO - 2021-04-13 20:33:04 --> Router Class Initialized
INFO - 2021-04-13 20:33:04 --> Router Class Initialized
DEBUG - 2021-04-13 20:33:04 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:33:04 --> Output Class Initialized
INFO - 2021-04-13 20:33:04 --> Output Class Initialized
INFO - 2021-04-13 20:33:04 --> Utf8 Class Initialized
INFO - 2021-04-13 20:33:04 --> URI Class Initialized
INFO - 2021-04-13 20:33:04 --> Config Class Initialized
INFO - 2021-04-13 20:33:04 --> Security Class Initialized
INFO - 2021-04-13 20:33:04 --> Hooks Class Initialized
INFO - 2021-04-13 20:33:04 --> Security Class Initialized
INFO - 2021-04-13 20:33:04 --> Router Class Initialized
DEBUG - 2021-04-13 20:33:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 20:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:33:04 --> Input Class Initialized
INFO - 2021-04-13 20:33:04 --> Input Class Initialized
DEBUG - 2021-04-13 20:33:04 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:33:04 --> Language Class Initialized
INFO - 2021-04-13 20:33:04 --> Language Class Initialized
INFO - 2021-04-13 20:33:04 --> Utf8 Class Initialized
INFO - 2021-04-13 20:33:04 --> URI Class Initialized
ERROR - 2021-04-13 20:33:04 --> 404 Page Not Found: user/Assets/js
ERROR - 2021-04-13 20:33:04 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:33:04 --> Router Class Initialized
INFO - 2021-04-13 20:33:04 --> Output Class Initialized
INFO - 2021-04-13 20:33:04 --> Output Class Initialized
INFO - 2021-04-13 20:33:04 --> Security Class Initialized
DEBUG - 2021-04-13 20:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:33:04 --> Input Class Initialized
INFO - 2021-04-13 20:33:04 --> Language Class Initialized
ERROR - 2021-04-13 20:33:04 --> 404 Page Not Found: user/Assets/img
INFO - 2021-04-13 20:33:04 --> Security Class Initialized
INFO - 2021-04-13 20:33:04 --> Config Class Initialized
INFO - 2021-04-13 20:33:04 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:33:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 20:33:04 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:33:04 --> Utf8 Class Initialized
INFO - 2021-04-13 20:33:04 --> Input Class Initialized
INFO - 2021-04-13 20:33:04 --> URI Class Initialized
INFO - 2021-04-13 20:33:04 --> Router Class Initialized
INFO - 2021-04-13 20:33:04 --> Config Class Initialized
INFO - 2021-04-13 20:33:04 --> Hooks Class Initialized
INFO - 2021-04-13 20:33:04 --> Output Class Initialized
INFO - 2021-04-13 20:33:04 --> Language Class Initialized
INFO - 2021-04-13 20:33:04 --> Security Class Initialized
DEBUG - 2021-04-13 20:33:04 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:33:04 --> Utf8 Class Initialized
INFO - 2021-04-13 20:33:04 --> Config Class Initialized
DEBUG - 2021-04-13 20:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:33:04 --> Hooks Class Initialized
INFO - 2021-04-13 20:33:04 --> Input Class Initialized
INFO - 2021-04-13 20:33:04 --> URI Class Initialized
INFO - 2021-04-13 20:33:04 --> Language Class Initialized
ERROR - 2021-04-13 20:33:04 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:33:04 --> Router Class Initialized
ERROR - 2021-04-13 20:33:04 --> 404 Page Not Found: user/Assets/img
DEBUG - 2021-04-13 20:33:04 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:33:04 --> Utf8 Class Initialized
INFO - 2021-04-13 20:33:04 --> Output Class Initialized
INFO - 2021-04-13 20:33:04 --> URI Class Initialized
INFO - 2021-04-13 20:33:04 --> Security Class Initialized
DEBUG - 2021-04-13 20:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:33:04 --> Input Class Initialized
INFO - 2021-04-13 20:33:04 --> Router Class Initialized
INFO - 2021-04-13 20:33:04 --> Language Class Initialized
INFO - 2021-04-13 20:33:04 --> Output Class Initialized
ERROR - 2021-04-13 20:33:04 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:33:04 --> Security Class Initialized
DEBUG - 2021-04-13 20:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:33:04 --> Input Class Initialized
INFO - 2021-04-13 20:33:04 --> Language Class Initialized
ERROR - 2021-04-13 20:33:04 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:33:04 --> Config Class Initialized
INFO - 2021-04-13 20:33:04 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:33:04 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:33:04 --> Utf8 Class Initialized
INFO - 2021-04-13 20:33:04 --> URI Class Initialized
INFO - 2021-04-13 20:33:04 --> Router Class Initialized
INFO - 2021-04-13 20:33:04 --> Output Class Initialized
INFO - 2021-04-13 20:33:04 --> Security Class Initialized
DEBUG - 2021-04-13 20:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:33:04 --> Input Class Initialized
INFO - 2021-04-13 20:33:04 --> Language Class Initialized
ERROR - 2021-04-13 20:33:04 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:33:04 --> Config Class Initialized
INFO - 2021-04-13 20:33:04 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:33:04 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:33:04 --> Utf8 Class Initialized
INFO - 2021-04-13 20:33:04 --> URI Class Initialized
INFO - 2021-04-13 20:33:04 --> Router Class Initialized
INFO - 2021-04-13 20:33:04 --> Output Class Initialized
INFO - 2021-04-13 20:33:04 --> Security Class Initialized
DEBUG - 2021-04-13 20:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:33:04 --> Input Class Initialized
INFO - 2021-04-13 20:33:04 --> Language Class Initialized
ERROR - 2021-04-13 20:33:04 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:33:04 --> Config Class Initialized
INFO - 2021-04-13 20:33:04 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:33:04 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:33:04 --> Utf8 Class Initialized
INFO - 2021-04-13 20:33:04 --> URI Class Initialized
INFO - 2021-04-13 20:33:04 --> Router Class Initialized
INFO - 2021-04-13 20:33:04 --> Output Class Initialized
INFO - 2021-04-13 20:33:04 --> Security Class Initialized
DEBUG - 2021-04-13 20:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:33:04 --> Input Class Initialized
INFO - 2021-04-13 20:33:04 --> Language Class Initialized
ERROR - 2021-04-13 20:33:04 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:33:04 --> Config Class Initialized
INFO - 2021-04-13 20:33:04 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:33:04 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:33:04 --> Utf8 Class Initialized
INFO - 2021-04-13 20:33:04 --> URI Class Initialized
INFO - 2021-04-13 20:33:04 --> Router Class Initialized
INFO - 2021-04-13 20:33:04 --> Output Class Initialized
INFO - 2021-04-13 20:33:04 --> Security Class Initialized
DEBUG - 2021-04-13 20:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:33:04 --> Input Class Initialized
INFO - 2021-04-13 20:33:04 --> Language Class Initialized
ERROR - 2021-04-13 20:33:04 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:33:04 --> Config Class Initialized
INFO - 2021-04-13 20:33:04 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:33:04 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:33:04 --> Utf8 Class Initialized
INFO - 2021-04-13 20:33:04 --> URI Class Initialized
INFO - 2021-04-13 20:33:04 --> Router Class Initialized
INFO - 2021-04-13 20:33:04 --> Output Class Initialized
INFO - 2021-04-13 20:33:04 --> Security Class Initialized
DEBUG - 2021-04-13 20:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:33:04 --> Input Class Initialized
INFO - 2021-04-13 20:33:04 --> Language Class Initialized
ERROR - 2021-04-13 20:33:04 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:33:04 --> Config Class Initialized
INFO - 2021-04-13 20:33:04 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:33:04 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:33:04 --> Utf8 Class Initialized
INFO - 2021-04-13 20:33:04 --> URI Class Initialized
INFO - 2021-04-13 20:33:04 --> Router Class Initialized
INFO - 2021-04-13 20:33:04 --> Output Class Initialized
INFO - 2021-04-13 20:33:04 --> Security Class Initialized
DEBUG - 2021-04-13 20:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:33:04 --> Input Class Initialized
INFO - 2021-04-13 20:33:04 --> Language Class Initialized
ERROR - 2021-04-13 20:33:04 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:33:04 --> Config Class Initialized
INFO - 2021-04-13 20:33:04 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:33:04 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:33:04 --> Utf8 Class Initialized
INFO - 2021-04-13 20:33:04 --> URI Class Initialized
INFO - 2021-04-13 20:33:04 --> Router Class Initialized
INFO - 2021-04-13 20:33:04 --> Output Class Initialized
INFO - 2021-04-13 20:33:04 --> Security Class Initialized
DEBUG - 2021-04-13 20:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:33:04 --> Input Class Initialized
INFO - 2021-04-13 20:33:04 --> Language Class Initialized
ERROR - 2021-04-13 20:33:04 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:33:04 --> Config Class Initialized
INFO - 2021-04-13 20:33:04 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:33:04 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:33:04 --> Utf8 Class Initialized
INFO - 2021-04-13 20:33:04 --> URI Class Initialized
INFO - 2021-04-13 20:33:04 --> Router Class Initialized
INFO - 2021-04-13 20:33:04 --> Output Class Initialized
INFO - 2021-04-13 20:33:04 --> Security Class Initialized
DEBUG - 2021-04-13 20:33:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:33:04 --> Input Class Initialized
INFO - 2021-04-13 20:33:04 --> Language Class Initialized
ERROR - 2021-04-13 20:33:04 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:33:08 --> Config Class Initialized
INFO - 2021-04-13 20:33:08 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:33:08 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:33:08 --> Utf8 Class Initialized
INFO - 2021-04-13 20:33:08 --> URI Class Initialized
INFO - 2021-04-13 20:33:08 --> Router Class Initialized
INFO - 2021-04-13 20:33:08 --> Output Class Initialized
INFO - 2021-04-13 20:33:08 --> Security Class Initialized
DEBUG - 2021-04-13 20:33:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:33:08 --> Input Class Initialized
INFO - 2021-04-13 20:33:08 --> Language Class Initialized
INFO - 2021-04-13 20:33:08 --> Loader Class Initialized
INFO - 2021-04-13 20:33:08 --> Helper loaded: url_helper
INFO - 2021-04-13 20:33:08 --> Helper loaded: form_helper
INFO - 2021-04-13 20:33:08 --> Helper loaded: common_helper
INFO - 2021-04-13 20:33:08 --> Helper loaded: util_helper
INFO - 2021-04-13 20:33:08 --> Database Driver Class Initialized
ERROR - 2021-04-13 20:33:08 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 20:33:08 --> Unable to connect to the database
DEBUG - 2021-04-13 20:33:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 20:33:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 20:33:08 --> Form Validation Class Initialized
INFO - 2021-04-13 20:33:08 --> Controller Class Initialized
INFO - 2021-04-13 20:33:08 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-13 20:33:08 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 20:33:08 --> Final output sent to browser
DEBUG - 2021-04-13 20:33:08 --> Total execution time: 0.0366
INFO - 2021-04-13 20:33:09 --> Config Class Initialized
INFO - 2021-04-13 20:33:09 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:33:09 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:33:09 --> Utf8 Class Initialized
INFO - 2021-04-13 20:33:09 --> URI Class Initialized
INFO - 2021-04-13 20:33:09 --> Router Class Initialized
INFO - 2021-04-13 20:33:09 --> Output Class Initialized
INFO - 2021-04-13 20:33:09 --> Security Class Initialized
DEBUG - 2021-04-13 20:33:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:33:09 --> Input Class Initialized
INFO - 2021-04-13 20:33:09 --> Language Class Initialized
INFO - 2021-04-13 20:33:09 --> Loader Class Initialized
INFO - 2021-04-13 20:33:09 --> Helper loaded: url_helper
INFO - 2021-04-13 20:33:09 --> Helper loaded: form_helper
INFO - 2021-04-13 20:33:09 --> Helper loaded: common_helper
INFO - 2021-04-13 20:33:09 --> Helper loaded: util_helper
INFO - 2021-04-13 20:33:09 --> Database Driver Class Initialized
ERROR - 2021-04-13 20:33:09 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 20:33:09 --> Unable to connect to the database
DEBUG - 2021-04-13 20:33:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 20:33:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 20:33:09 --> Form Validation Class Initialized
INFO - 2021-04-13 20:33:09 --> Controller Class Initialized
INFO - 2021-04-13 20:33:09 --> Model Class Initialized
INFO - 2021-04-13 20:33:09 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 20:33:09 --> Final output sent to browser
DEBUG - 2021-04-13 20:33:09 --> Total execution time: 0.0273
INFO - 2021-04-13 20:33:10 --> Config Class Initialized
INFO - 2021-04-13 20:33:10 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:33:10 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:33:10 --> Utf8 Class Initialized
INFO - 2021-04-13 20:33:10 --> URI Class Initialized
DEBUG - 2021-04-13 20:33:10 --> No URI present. Default controller set.
INFO - 2021-04-13 20:33:10 --> Router Class Initialized
INFO - 2021-04-13 20:33:10 --> Output Class Initialized
INFO - 2021-04-13 20:33:10 --> Security Class Initialized
DEBUG - 2021-04-13 20:33:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:33:10 --> Input Class Initialized
INFO - 2021-04-13 20:33:10 --> Language Class Initialized
INFO - 2021-04-13 20:33:10 --> Loader Class Initialized
INFO - 2021-04-13 20:33:10 --> Helper loaded: url_helper
INFO - 2021-04-13 20:33:10 --> Helper loaded: form_helper
INFO - 2021-04-13 20:33:10 --> Helper loaded: common_helper
INFO - 2021-04-13 20:33:10 --> Helper loaded: util_helper
INFO - 2021-04-13 20:33:10 --> Database Driver Class Initialized
ERROR - 2021-04-13 20:33:10 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 20:33:10 --> Unable to connect to the database
DEBUG - 2021-04-13 20:33:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 20:33:10 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 20:33:10 --> Form Validation Class Initialized
INFO - 2021-04-13 20:33:10 --> Controller Class Initialized
INFO - 2021-04-13 20:33:10 --> Model Class Initialized
INFO - 2021-04-13 20:33:10 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-13 20:33:10 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 20:33:10 --> Final output sent to browser
DEBUG - 2021-04-13 20:33:10 --> Total execution time: 0.0354
INFO - 2021-04-13 20:33:12 --> Config Class Initialized
INFO - 2021-04-13 20:33:12 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:33:12 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:33:12 --> Utf8 Class Initialized
INFO - 2021-04-13 20:33:12 --> URI Class Initialized
DEBUG - 2021-04-13 20:33:12 --> No URI present. Default controller set.
INFO - 2021-04-13 20:33:12 --> Router Class Initialized
INFO - 2021-04-13 20:33:12 --> Output Class Initialized
INFO - 2021-04-13 20:33:12 --> Security Class Initialized
DEBUG - 2021-04-13 20:33:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:33:12 --> Input Class Initialized
INFO - 2021-04-13 20:33:12 --> Language Class Initialized
INFO - 2021-04-13 20:33:12 --> Loader Class Initialized
INFO - 2021-04-13 20:33:12 --> Helper loaded: url_helper
INFO - 2021-04-13 20:33:12 --> Helper loaded: form_helper
INFO - 2021-04-13 20:33:12 --> Helper loaded: common_helper
INFO - 2021-04-13 20:33:12 --> Helper loaded: util_helper
INFO - 2021-04-13 20:33:12 --> Database Driver Class Initialized
ERROR - 2021-04-13 20:33:12 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 20:33:12 --> Unable to connect to the database
DEBUG - 2021-04-13 20:33:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 20:33:12 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 20:33:12 --> Form Validation Class Initialized
INFO - 2021-04-13 20:33:12 --> Controller Class Initialized
INFO - 2021-04-13 20:33:12 --> Model Class Initialized
INFO - 2021-04-13 20:33:12 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-13 20:33:12 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 20:33:12 --> Final output sent to browser
DEBUG - 2021-04-13 20:33:12 --> Total execution time: 0.0311
INFO - 2021-04-13 20:33:17 --> Config Class Initialized
INFO - 2021-04-13 20:33:17 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:33:17 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:33:17 --> Utf8 Class Initialized
INFO - 2021-04-13 20:33:17 --> URI Class Initialized
INFO - 2021-04-13 20:33:17 --> Router Class Initialized
INFO - 2021-04-13 20:33:17 --> Output Class Initialized
INFO - 2021-04-13 20:33:17 --> Security Class Initialized
DEBUG - 2021-04-13 20:33:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:33:17 --> Input Class Initialized
INFO - 2021-04-13 20:33:17 --> Language Class Initialized
ERROR - 2021-04-13 20:33:17 --> 404 Page Not Found: Logout/index
INFO - 2021-04-13 20:33:19 --> Config Class Initialized
INFO - 2021-04-13 20:33:19 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:33:19 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:33:19 --> Utf8 Class Initialized
INFO - 2021-04-13 20:33:19 --> URI Class Initialized
DEBUG - 2021-04-13 20:33:19 --> No URI present. Default controller set.
INFO - 2021-04-13 20:33:19 --> Router Class Initialized
INFO - 2021-04-13 20:33:19 --> Output Class Initialized
INFO - 2021-04-13 20:33:19 --> Security Class Initialized
DEBUG - 2021-04-13 20:33:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:33:19 --> Input Class Initialized
INFO - 2021-04-13 20:33:19 --> Language Class Initialized
INFO - 2021-04-13 20:33:19 --> Loader Class Initialized
INFO - 2021-04-13 20:33:19 --> Helper loaded: url_helper
INFO - 2021-04-13 20:33:19 --> Helper loaded: form_helper
INFO - 2021-04-13 20:33:19 --> Helper loaded: common_helper
INFO - 2021-04-13 20:33:19 --> Helper loaded: util_helper
INFO - 2021-04-13 20:33:19 --> Database Driver Class Initialized
ERROR - 2021-04-13 20:33:19 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 20:33:19 --> Unable to connect to the database
DEBUG - 2021-04-13 20:33:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 20:33:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 20:33:19 --> Form Validation Class Initialized
INFO - 2021-04-13 20:33:19 --> Controller Class Initialized
INFO - 2021-04-13 20:33:19 --> Model Class Initialized
INFO - 2021-04-13 20:33:19 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-13 20:33:19 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 20:33:19 --> Final output sent to browser
DEBUG - 2021-04-13 20:33:19 --> Total execution time: 0.0269
INFO - 2021-04-13 20:33:22 --> Config Class Initialized
INFO - 2021-04-13 20:33:22 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:33:22 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:33:22 --> Utf8 Class Initialized
INFO - 2021-04-13 20:33:22 --> URI Class Initialized
DEBUG - 2021-04-13 20:33:22 --> No URI present. Default controller set.
INFO - 2021-04-13 20:33:22 --> Router Class Initialized
INFO - 2021-04-13 20:33:22 --> Output Class Initialized
INFO - 2021-04-13 20:33:22 --> Security Class Initialized
DEBUG - 2021-04-13 20:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:33:22 --> Input Class Initialized
INFO - 2021-04-13 20:33:22 --> Language Class Initialized
INFO - 2021-04-13 20:33:22 --> Loader Class Initialized
INFO - 2021-04-13 20:33:22 --> Helper loaded: url_helper
INFO - 2021-04-13 20:33:22 --> Helper loaded: form_helper
INFO - 2021-04-13 20:33:22 --> Helper loaded: common_helper
INFO - 2021-04-13 20:33:22 --> Helper loaded: util_helper
INFO - 2021-04-13 20:33:22 --> Database Driver Class Initialized
ERROR - 2021-04-13 20:33:22 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 20:33:22 --> Unable to connect to the database
DEBUG - 2021-04-13 20:33:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 20:33:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 20:33:22 --> Form Validation Class Initialized
INFO - 2021-04-13 20:33:22 --> Controller Class Initialized
INFO - 2021-04-13 20:33:22 --> Model Class Initialized
INFO - 2021-04-13 20:33:22 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-13 20:33:22 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 20:33:22 --> Final output sent to browser
DEBUG - 2021-04-13 20:33:22 --> Total execution time: 0.0304
INFO - 2021-04-13 20:33:25 --> Config Class Initialized
INFO - 2021-04-13 20:33:25 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:33:25 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:33:25 --> Utf8 Class Initialized
INFO - 2021-04-13 20:33:25 --> URI Class Initialized
INFO - 2021-04-13 20:33:25 --> Router Class Initialized
INFO - 2021-04-13 20:33:25 --> Output Class Initialized
INFO - 2021-04-13 20:33:25 --> Security Class Initialized
DEBUG - 2021-04-13 20:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:33:25 --> Input Class Initialized
INFO - 2021-04-13 20:33:25 --> Language Class Initialized
INFO - 2021-04-13 20:33:25 --> Loader Class Initialized
INFO - 2021-04-13 20:33:25 --> Helper loaded: url_helper
INFO - 2021-04-13 20:33:25 --> Helper loaded: form_helper
INFO - 2021-04-13 20:33:25 --> Helper loaded: common_helper
INFO - 2021-04-13 20:33:25 --> Helper loaded: util_helper
INFO - 2021-04-13 20:33:25 --> Database Driver Class Initialized
ERROR - 2021-04-13 20:33:25 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 20:33:25 --> Unable to connect to the database
DEBUG - 2021-04-13 20:33:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 20:33:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 20:33:25 --> Form Validation Class Initialized
INFO - 2021-04-13 20:33:25 --> Controller Class Initialized
INFO - 2021-04-13 20:33:25 --> Model Class Initialized
INFO - 2021-04-13 20:33:25 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\register.php
INFO - 2021-04-13 20:33:25 --> Final output sent to browser
DEBUG - 2021-04-13 20:33:25 --> Total execution time: 0.0250
INFO - 2021-04-13 20:33:25 --> Config Class Initialized
INFO - 2021-04-13 20:33:25 --> Config Class Initialized
INFO - 2021-04-13 20:33:25 --> Hooks Class Initialized
INFO - 2021-04-13 20:33:25 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:33:25 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:33:25 --> Utf8 Class Initialized
DEBUG - 2021-04-13 20:33:25 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:33:25 --> Utf8 Class Initialized
INFO - 2021-04-13 20:33:25 --> URI Class Initialized
INFO - 2021-04-13 20:33:25 --> URI Class Initialized
INFO - 2021-04-13 20:33:25 --> Router Class Initialized
INFO - 2021-04-13 20:33:25 --> Router Class Initialized
INFO - 2021-04-13 20:33:25 --> Output Class Initialized
INFO - 2021-04-13 20:33:25 --> Output Class Initialized
INFO - 2021-04-13 20:33:25 --> Security Class Initialized
INFO - 2021-04-13 20:33:25 --> Security Class Initialized
DEBUG - 2021-04-13 20:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:33:25 --> Input Class Initialized
INFO - 2021-04-13 20:33:25 --> Language Class Initialized
DEBUG - 2021-04-13 20:33:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:33:25 --> Input Class Initialized
ERROR - 2021-04-13 20:33:25 --> 404 Page Not Found: Fasset/img
INFO - 2021-04-13 20:33:25 --> Language Class Initialized
ERROR - 2021-04-13 20:33:25 --> 404 Page Not Found: Fasset/img
INFO - 2021-04-13 20:33:26 --> Config Class Initialized
INFO - 2021-04-13 20:33:26 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:33:26 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:33:26 --> Utf8 Class Initialized
INFO - 2021-04-13 20:33:26 --> URI Class Initialized
DEBUG - 2021-04-13 20:33:26 --> No URI present. Default controller set.
INFO - 2021-04-13 20:33:26 --> Router Class Initialized
INFO - 2021-04-13 20:33:26 --> Output Class Initialized
INFO - 2021-04-13 20:33:26 --> Security Class Initialized
DEBUG - 2021-04-13 20:33:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:33:26 --> Input Class Initialized
INFO - 2021-04-13 20:33:26 --> Language Class Initialized
INFO - 2021-04-13 20:33:26 --> Loader Class Initialized
INFO - 2021-04-13 20:33:26 --> Helper loaded: url_helper
INFO - 2021-04-13 20:33:26 --> Helper loaded: form_helper
INFO - 2021-04-13 20:33:26 --> Helper loaded: common_helper
INFO - 2021-04-13 20:33:26 --> Helper loaded: util_helper
INFO - 2021-04-13 20:33:26 --> Database Driver Class Initialized
ERROR - 2021-04-13 20:33:26 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 20:33:26 --> Unable to connect to the database
DEBUG - 2021-04-13 20:33:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 20:33:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 20:33:26 --> Form Validation Class Initialized
INFO - 2021-04-13 20:33:26 --> Controller Class Initialized
INFO - 2021-04-13 20:33:26 --> Model Class Initialized
INFO - 2021-04-13 20:33:26 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-13 20:33:26 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 20:33:26 --> Final output sent to browser
DEBUG - 2021-04-13 20:33:26 --> Total execution time: 0.0276
INFO - 2021-04-13 20:33:29 --> Config Class Initialized
INFO - 2021-04-13 20:33:29 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:33:29 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:33:29 --> Utf8 Class Initialized
INFO - 2021-04-13 20:33:29 --> URI Class Initialized
INFO - 2021-04-13 20:33:29 --> Router Class Initialized
INFO - 2021-04-13 20:33:29 --> Output Class Initialized
INFO - 2021-04-13 20:33:29 --> Security Class Initialized
DEBUG - 2021-04-13 20:33:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:33:29 --> Input Class Initialized
INFO - 2021-04-13 20:33:29 --> Language Class Initialized
ERROR - 2021-04-13 20:33:29 --> 404 Page Not Found: Logout/index
INFO - 2021-04-13 20:33:34 --> Config Class Initialized
INFO - 2021-04-13 20:33:34 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:33:34 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:33:34 --> Utf8 Class Initialized
INFO - 2021-04-13 20:33:34 --> URI Class Initialized
DEBUG - 2021-04-13 20:33:34 --> No URI present. Default controller set.
INFO - 2021-04-13 20:33:34 --> Router Class Initialized
INFO - 2021-04-13 20:33:34 --> Output Class Initialized
INFO - 2021-04-13 20:33:34 --> Security Class Initialized
DEBUG - 2021-04-13 20:33:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:33:34 --> Input Class Initialized
INFO - 2021-04-13 20:33:34 --> Language Class Initialized
INFO - 2021-04-13 20:33:34 --> Loader Class Initialized
INFO - 2021-04-13 20:33:34 --> Helper loaded: url_helper
INFO - 2021-04-13 20:33:34 --> Helper loaded: form_helper
INFO - 2021-04-13 20:33:34 --> Helper loaded: common_helper
INFO - 2021-04-13 20:33:34 --> Helper loaded: util_helper
INFO - 2021-04-13 20:33:34 --> Database Driver Class Initialized
ERROR - 2021-04-13 20:33:34 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 20:33:34 --> Unable to connect to the database
DEBUG - 2021-04-13 20:33:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 20:33:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 20:33:34 --> Form Validation Class Initialized
INFO - 2021-04-13 20:33:34 --> Controller Class Initialized
INFO - 2021-04-13 20:33:34 --> Model Class Initialized
INFO - 2021-04-13 20:33:34 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-13 20:33:34 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 20:33:34 --> Final output sent to browser
DEBUG - 2021-04-13 20:33:34 --> Total execution time: 0.0268
INFO - 2021-04-13 20:34:47 --> Config Class Initialized
INFO - 2021-04-13 20:34:47 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:34:47 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:34:47 --> Utf8 Class Initialized
INFO - 2021-04-13 20:34:47 --> URI Class Initialized
DEBUG - 2021-04-13 20:34:47 --> No URI present. Default controller set.
INFO - 2021-04-13 20:34:47 --> Router Class Initialized
INFO - 2021-04-13 20:34:47 --> Output Class Initialized
INFO - 2021-04-13 20:34:47 --> Security Class Initialized
DEBUG - 2021-04-13 20:34:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:34:47 --> Input Class Initialized
INFO - 2021-04-13 20:34:47 --> Language Class Initialized
INFO - 2021-04-13 20:34:47 --> Loader Class Initialized
INFO - 2021-04-13 20:34:47 --> Helper loaded: url_helper
INFO - 2021-04-13 20:34:47 --> Helper loaded: form_helper
INFO - 2021-04-13 20:34:47 --> Helper loaded: common_helper
INFO - 2021-04-13 20:34:47 --> Helper loaded: util_helper
INFO - 2021-04-13 20:34:47 --> Database Driver Class Initialized
DEBUG - 2021-04-13 20:34:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 20:34:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 20:34:47 --> Form Validation Class Initialized
INFO - 2021-04-13 20:34:47 --> Controller Class Initialized
INFO - 2021-04-13 20:34:47 --> Model Class Initialized
INFO - 2021-04-13 20:34:47 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-13 20:34:47 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 20:34:47 --> Final output sent to browser
DEBUG - 2021-04-13 20:34:47 --> Total execution time: 0.0264
INFO - 2021-04-13 20:34:49 --> Config Class Initialized
INFO - 2021-04-13 20:34:49 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:34:49 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:34:49 --> Utf8 Class Initialized
INFO - 2021-04-13 20:34:49 --> URI Class Initialized
DEBUG - 2021-04-13 20:34:49 --> No URI present. Default controller set.
INFO - 2021-04-13 20:34:49 --> Router Class Initialized
INFO - 2021-04-13 20:34:49 --> Output Class Initialized
INFO - 2021-04-13 20:34:49 --> Security Class Initialized
DEBUG - 2021-04-13 20:34:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:34:49 --> Input Class Initialized
INFO - 2021-04-13 20:34:49 --> Language Class Initialized
INFO - 2021-04-13 20:34:49 --> Loader Class Initialized
INFO - 2021-04-13 20:34:49 --> Helper loaded: url_helper
INFO - 2021-04-13 20:34:49 --> Helper loaded: form_helper
INFO - 2021-04-13 20:34:49 --> Helper loaded: common_helper
INFO - 2021-04-13 20:34:49 --> Helper loaded: util_helper
INFO - 2021-04-13 20:34:49 --> Database Driver Class Initialized
DEBUG - 2021-04-13 20:34:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 20:34:49 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 20:34:49 --> Form Validation Class Initialized
INFO - 2021-04-13 20:34:49 --> Controller Class Initialized
INFO - 2021-04-13 20:34:49 --> Model Class Initialized
INFO - 2021-04-13 20:34:49 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-13 20:34:49 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 20:34:49 --> Final output sent to browser
DEBUG - 2021-04-13 20:34:49 --> Total execution time: 0.0246
INFO - 2021-04-13 20:34:51 --> Config Class Initialized
INFO - 2021-04-13 20:34:51 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:34:51 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:34:51 --> Utf8 Class Initialized
INFO - 2021-04-13 20:34:51 --> URI Class Initialized
INFO - 2021-04-13 20:34:51 --> Router Class Initialized
INFO - 2021-04-13 20:34:51 --> Output Class Initialized
INFO - 2021-04-13 20:34:51 --> Security Class Initialized
DEBUG - 2021-04-13 20:34:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:34:51 --> Input Class Initialized
INFO - 2021-04-13 20:34:51 --> Language Class Initialized
ERROR - 2021-04-13 20:34:51 --> 404 Page Not Found: Logout/index
INFO - 2021-04-13 20:34:53 --> Config Class Initialized
INFO - 2021-04-13 20:34:53 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:34:53 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:34:53 --> Utf8 Class Initialized
INFO - 2021-04-13 20:34:53 --> URI Class Initialized
DEBUG - 2021-04-13 20:34:53 --> No URI present. Default controller set.
INFO - 2021-04-13 20:34:53 --> Router Class Initialized
INFO - 2021-04-13 20:34:53 --> Output Class Initialized
INFO - 2021-04-13 20:34:53 --> Security Class Initialized
DEBUG - 2021-04-13 20:34:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:34:53 --> Input Class Initialized
INFO - 2021-04-13 20:34:53 --> Language Class Initialized
INFO - 2021-04-13 20:34:53 --> Loader Class Initialized
INFO - 2021-04-13 20:34:53 --> Helper loaded: url_helper
INFO - 2021-04-13 20:34:53 --> Helper loaded: form_helper
INFO - 2021-04-13 20:34:53 --> Helper loaded: common_helper
INFO - 2021-04-13 20:34:53 --> Helper loaded: util_helper
INFO - 2021-04-13 20:34:53 --> Database Driver Class Initialized
DEBUG - 2021-04-13 20:34:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 20:34:53 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 20:34:53 --> Form Validation Class Initialized
INFO - 2021-04-13 20:34:53 --> Controller Class Initialized
INFO - 2021-04-13 20:34:53 --> Model Class Initialized
INFO - 2021-04-13 20:34:53 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-13 20:34:53 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 20:34:53 --> Final output sent to browser
DEBUG - 2021-04-13 20:34:53 --> Total execution time: 0.0356
INFO - 2021-04-13 20:35:00 --> Config Class Initialized
INFO - 2021-04-13 20:35:00 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:35:00 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:35:00 --> Utf8 Class Initialized
INFO - 2021-04-13 20:35:00 --> URI Class Initialized
INFO - 2021-04-13 20:35:00 --> Router Class Initialized
INFO - 2021-04-13 20:35:00 --> Output Class Initialized
INFO - 2021-04-13 20:35:00 --> Security Class Initialized
DEBUG - 2021-04-13 20:35:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:35:00 --> Input Class Initialized
INFO - 2021-04-13 20:35:00 --> Language Class Initialized
ERROR - 2021-04-13 20:35:00 --> 404 Page Not Found: Logout/index
INFO - 2021-04-13 20:35:04 --> Config Class Initialized
INFO - 2021-04-13 20:35:04 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:35:04 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:35:04 --> Utf8 Class Initialized
INFO - 2021-04-13 20:35:04 --> URI Class Initialized
DEBUG - 2021-04-13 20:35:04 --> No URI present. Default controller set.
INFO - 2021-04-13 20:35:04 --> Router Class Initialized
INFO - 2021-04-13 20:35:04 --> Output Class Initialized
INFO - 2021-04-13 20:35:04 --> Security Class Initialized
DEBUG - 2021-04-13 20:35:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:35:04 --> Input Class Initialized
INFO - 2021-04-13 20:35:04 --> Language Class Initialized
INFO - 2021-04-13 20:35:04 --> Loader Class Initialized
INFO - 2021-04-13 20:35:04 --> Helper loaded: url_helper
INFO - 2021-04-13 20:35:04 --> Helper loaded: form_helper
INFO - 2021-04-13 20:35:04 --> Helper loaded: common_helper
INFO - 2021-04-13 20:35:04 --> Helper loaded: util_helper
INFO - 2021-04-13 20:35:04 --> Database Driver Class Initialized
DEBUG - 2021-04-13 20:35:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 20:35:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 20:35:04 --> Form Validation Class Initialized
INFO - 2021-04-13 20:35:04 --> Controller Class Initialized
INFO - 2021-04-13 20:35:04 --> Model Class Initialized
INFO - 2021-04-13 20:35:04 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-13 20:35:04 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 20:35:04 --> Final output sent to browser
DEBUG - 2021-04-13 20:35:04 --> Total execution time: 0.0254
INFO - 2021-04-13 20:35:22 --> Config Class Initialized
INFO - 2021-04-13 20:35:22 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:35:22 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:35:22 --> Utf8 Class Initialized
INFO - 2021-04-13 20:35:22 --> URI Class Initialized
DEBUG - 2021-04-13 20:35:22 --> No URI present. Default controller set.
INFO - 2021-04-13 20:35:22 --> Router Class Initialized
INFO - 2021-04-13 20:35:22 --> Output Class Initialized
INFO - 2021-04-13 20:35:22 --> Security Class Initialized
DEBUG - 2021-04-13 20:35:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:35:22 --> Input Class Initialized
INFO - 2021-04-13 20:35:22 --> Language Class Initialized
INFO - 2021-04-13 20:35:22 --> Loader Class Initialized
INFO - 2021-04-13 20:35:22 --> Helper loaded: url_helper
INFO - 2021-04-13 20:35:22 --> Helper loaded: form_helper
INFO - 2021-04-13 20:35:22 --> Helper loaded: common_helper
INFO - 2021-04-13 20:35:22 --> Helper loaded: util_helper
INFO - 2021-04-13 20:35:22 --> Database Driver Class Initialized
DEBUG - 2021-04-13 20:35:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 20:35:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 20:35:22 --> Form Validation Class Initialized
INFO - 2021-04-13 20:35:22 --> Controller Class Initialized
INFO - 2021-04-13 20:35:22 --> Model Class Initialized
INFO - 2021-04-13 20:35:22 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-13 20:35:22 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 20:35:22 --> Final output sent to browser
DEBUG - 2021-04-13 20:35:22 --> Total execution time: 0.0632
INFO - 2021-04-13 20:35:25 --> Config Class Initialized
INFO - 2021-04-13 20:35:25 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:35:25 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:35:25 --> Utf8 Class Initialized
INFO - 2021-04-13 20:35:25 --> URI Class Initialized
INFO - 2021-04-13 20:35:25 --> Router Class Initialized
INFO - 2021-04-13 20:35:25 --> Output Class Initialized
INFO - 2021-04-13 20:35:25 --> Security Class Initialized
DEBUG - 2021-04-13 20:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:35:25 --> Input Class Initialized
INFO - 2021-04-13 20:35:25 --> Language Class Initialized
INFO - 2021-04-13 20:35:25 --> Loader Class Initialized
INFO - 2021-04-13 20:35:25 --> Helper loaded: url_helper
INFO - 2021-04-13 20:35:25 --> Helper loaded: form_helper
INFO - 2021-04-13 20:35:25 --> Helper loaded: common_helper
INFO - 2021-04-13 20:35:25 --> Helper loaded: util_helper
INFO - 2021-04-13 20:35:25 --> Database Driver Class Initialized
DEBUG - 2021-04-13 20:35:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 20:35:25 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 20:35:25 --> Form Validation Class Initialized
INFO - 2021-04-13 20:35:25 --> Controller Class Initialized
INFO - 2021-04-13 20:35:25 --> Model Class Initialized
INFO - 2021-04-13 20:35:25 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 20:35:25 --> Final output sent to browser
DEBUG - 2021-04-13 20:35:25 --> Total execution time: 0.0244
INFO - 2021-04-13 20:35:25 --> Config Class Initialized
INFO - 2021-04-13 20:35:25 --> Hooks Class Initialized
INFO - 2021-04-13 20:35:25 --> Config Class Initialized
INFO - 2021-04-13 20:35:25 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:35:25 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:35:25 --> Utf8 Class Initialized
DEBUG - 2021-04-13 20:35:25 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:35:25 --> Utf8 Class Initialized
INFO - 2021-04-13 20:35:25 --> URI Class Initialized
INFO - 2021-04-13 20:35:25 --> URI Class Initialized
INFO - 2021-04-13 20:35:25 --> Router Class Initialized
INFO - 2021-04-13 20:35:25 --> Router Class Initialized
INFO - 2021-04-13 20:35:25 --> Output Class Initialized
INFO - 2021-04-13 20:35:25 --> Output Class Initialized
INFO - 2021-04-13 20:35:25 --> Security Class Initialized
INFO - 2021-04-13 20:35:25 --> Security Class Initialized
DEBUG - 2021-04-13 20:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:35:25 --> Input Class Initialized
DEBUG - 2021-04-13 20:35:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:35:25 --> Language Class Initialized
INFO - 2021-04-13 20:35:25 --> Input Class Initialized
INFO - 2021-04-13 20:35:25 --> Language Class Initialized
ERROR - 2021-04-13 20:35:25 --> 404 Page Not Found: Fasset/img
ERROR - 2021-04-13 20:35:25 --> 404 Page Not Found: Fasset/img
INFO - 2021-04-13 20:35:47 --> Config Class Initialized
INFO - 2021-04-13 20:35:47 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:35:47 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:35:47 --> Utf8 Class Initialized
INFO - 2021-04-13 20:35:47 --> URI Class Initialized
INFO - 2021-04-13 20:35:47 --> Router Class Initialized
INFO - 2021-04-13 20:35:47 --> Output Class Initialized
INFO - 2021-04-13 20:35:47 --> Security Class Initialized
DEBUG - 2021-04-13 20:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:35:47 --> Input Class Initialized
INFO - 2021-04-13 20:35:47 --> Language Class Initialized
INFO - 2021-04-13 20:35:47 --> Loader Class Initialized
INFO - 2021-04-13 20:35:47 --> Helper loaded: url_helper
INFO - 2021-04-13 20:35:47 --> Helper loaded: form_helper
INFO - 2021-04-13 20:35:47 --> Helper loaded: common_helper
INFO - 2021-04-13 20:35:47 --> Helper loaded: util_helper
INFO - 2021-04-13 20:35:47 --> Database Driver Class Initialized
DEBUG - 2021-04-13 20:35:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 20:35:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 20:35:47 --> Form Validation Class Initialized
INFO - 2021-04-13 20:35:47 --> Controller Class Initialized
INFO - 2021-04-13 20:35:47 --> Model Class Initialized
INFO - 2021-04-13 20:35:47 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-04-13 20:35:47 --> Config Class Initialized
INFO - 2021-04-13 20:35:47 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:35:47 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:35:47 --> Utf8 Class Initialized
INFO - 2021-04-13 20:35:47 --> URI Class Initialized
INFO - 2021-04-13 20:35:47 --> Router Class Initialized
INFO - 2021-04-13 20:35:47 --> Output Class Initialized
INFO - 2021-04-13 20:35:47 --> Security Class Initialized
DEBUG - 2021-04-13 20:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:35:47 --> Input Class Initialized
INFO - 2021-04-13 20:35:47 --> Language Class Initialized
INFO - 2021-04-13 20:35:47 --> Loader Class Initialized
INFO - 2021-04-13 20:35:47 --> Helper loaded: url_helper
INFO - 2021-04-13 20:35:47 --> Helper loaded: form_helper
INFO - 2021-04-13 20:35:47 --> Helper loaded: common_helper
INFO - 2021-04-13 20:35:47 --> Helper loaded: util_helper
INFO - 2021-04-13 20:35:47 --> Database Driver Class Initialized
DEBUG - 2021-04-13 20:35:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 20:35:47 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 20:35:47 --> Form Validation Class Initialized
INFO - 2021-04-13 20:35:47 --> Controller Class Initialized
INFO - 2021-04-13 20:35:47 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-13 20:35:47 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 20:35:47 --> Final output sent to browser
DEBUG - 2021-04-13 20:35:47 --> Total execution time: 0.0345
INFO - 2021-04-13 20:35:47 --> Config Class Initialized
INFO - 2021-04-13 20:35:47 --> Hooks Class Initialized
INFO - 2021-04-13 20:35:47 --> Config Class Initialized
INFO - 2021-04-13 20:35:47 --> Hooks Class Initialized
INFO - 2021-04-13 20:35:47 --> Config Class Initialized
INFO - 2021-04-13 20:35:47 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:35:47 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:35:47 --> Utf8 Class Initialized
INFO - 2021-04-13 20:35:47 --> URI Class Initialized
DEBUG - 2021-04-13 20:35:47 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:35:47 --> Utf8 Class Initialized
INFO - 2021-04-13 20:35:47 --> Router Class Initialized
INFO - 2021-04-13 20:35:47 --> URI Class Initialized
INFO - 2021-04-13 20:35:47 --> Router Class Initialized
INFO - 2021-04-13 20:35:47 --> Output Class Initialized
INFO - 2021-04-13 20:35:47 --> Security Class Initialized
INFO - 2021-04-13 20:35:47 --> Output Class Initialized
DEBUG - 2021-04-13 20:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:35:47 --> Security Class Initialized
INFO - 2021-04-13 20:35:47 --> Input Class Initialized
INFO - 2021-04-13 20:35:47 --> Language Class Initialized
DEBUG - 2021-04-13 20:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:35:47 --> Input Class Initialized
INFO - 2021-04-13 20:35:47 --> Language Class Initialized
ERROR - 2021-04-13 20:35:47 --> 404 Page Not Found: user/Assets/css
ERROR - 2021-04-13 20:35:47 --> 404 Page Not Found: user/Assets/css
DEBUG - 2021-04-13 20:35:47 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:35:47 --> Utf8 Class Initialized
INFO - 2021-04-13 20:35:47 --> Config Class Initialized
INFO - 2021-04-13 20:35:47 --> Hooks Class Initialized
INFO - 2021-04-13 20:35:47 --> URI Class Initialized
INFO - 2021-04-13 20:35:47 --> Router Class Initialized
DEBUG - 2021-04-13 20:35:47 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:35:47 --> Utf8 Class Initialized
INFO - 2021-04-13 20:35:47 --> Config Class Initialized
INFO - 2021-04-13 20:35:47 --> Hooks Class Initialized
INFO - 2021-04-13 20:35:47 --> Output Class Initialized
INFO - 2021-04-13 20:35:47 --> URI Class Initialized
INFO - 2021-04-13 20:35:47 --> Config Class Initialized
INFO - 2021-04-13 20:35:47 --> Hooks Class Initialized
INFO - 2021-04-13 20:35:47 --> Security Class Initialized
INFO - 2021-04-13 20:35:47 --> Router Class Initialized
DEBUG - 2021-04-13 20:35:47 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:35:47 --> Utf8 Class Initialized
DEBUG - 2021-04-13 20:35:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 20:35:47 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:35:47 --> Utf8 Class Initialized
INFO - 2021-04-13 20:35:47 --> Input Class Initialized
INFO - 2021-04-13 20:35:47 --> URI Class Initialized
INFO - 2021-04-13 20:35:47 --> Output Class Initialized
INFO - 2021-04-13 20:35:47 --> Language Class Initialized
INFO - 2021-04-13 20:35:47 --> URI Class Initialized
INFO - 2021-04-13 20:35:47 --> Router Class Initialized
INFO - 2021-04-13 20:35:47 --> Security Class Initialized
ERROR - 2021-04-13 20:35:47 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:35:47 --> Router Class Initialized
INFO - 2021-04-13 20:35:47 --> Output Class Initialized
DEBUG - 2021-04-13 20:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:35:47 --> Input Class Initialized
INFO - 2021-04-13 20:35:47 --> Security Class Initialized
INFO - 2021-04-13 20:35:47 --> Output Class Initialized
INFO - 2021-04-13 20:35:47 --> Language Class Initialized
DEBUG - 2021-04-13 20:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:35:47 --> Input Class Initialized
INFO - 2021-04-13 20:35:47 --> Security Class Initialized
ERROR - 2021-04-13 20:35:47 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:35:47 --> Language Class Initialized
DEBUG - 2021-04-13 20:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:35:47 --> Input Class Initialized
ERROR - 2021-04-13 20:35:47 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:35:47 --> Language Class Initialized
ERROR - 2021-04-13 20:35:47 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:35:47 --> Config Class Initialized
INFO - 2021-04-13 20:35:47 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:35:47 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:35:47 --> Config Class Initialized
INFO - 2021-04-13 20:35:47 --> Hooks Class Initialized
INFO - 2021-04-13 20:35:47 --> Config Class Initialized
INFO - 2021-04-13 20:35:47 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:35:47 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:35:47 --> Utf8 Class Initialized
INFO - 2021-04-13 20:35:47 --> URI Class Initialized
DEBUG - 2021-04-13 20:35:47 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:35:47 --> Utf8 Class Initialized
INFO - 2021-04-13 20:35:47 --> URI Class Initialized
INFO - 2021-04-13 20:35:47 --> Config Class Initialized
INFO - 2021-04-13 20:35:47 --> Hooks Class Initialized
INFO - 2021-04-13 20:35:47 --> Router Class Initialized
INFO - 2021-04-13 20:35:47 --> Router Class Initialized
INFO - 2021-04-13 20:35:47 --> Output Class Initialized
INFO - 2021-04-13 20:35:47 --> Security Class Initialized
INFO - 2021-04-13 20:35:47 --> Output Class Initialized
DEBUG - 2021-04-13 20:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:35:47 --> Input Class Initialized
INFO - 2021-04-13 20:35:47 --> Language Class Initialized
INFO - 2021-04-13 20:35:47 --> Security Class Initialized
DEBUG - 2021-04-13 20:35:47 --> UTF-8 Support Enabled
ERROR - 2021-04-13 20:35:47 --> 404 Page Not Found: user/Assets/img
INFO - 2021-04-13 20:35:47 --> Utf8 Class Initialized
DEBUG - 2021-04-13 20:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:35:47 --> Input Class Initialized
INFO - 2021-04-13 20:35:47 --> URI Class Initialized
INFO - 2021-04-13 20:35:47 --> Utf8 Class Initialized
INFO - 2021-04-13 20:35:47 --> Language Class Initialized
INFO - 2021-04-13 20:35:47 --> Config Class Initialized
INFO - 2021-04-13 20:35:47 --> Hooks Class Initialized
INFO - 2021-04-13 20:35:47 --> URI Class Initialized
INFO - 2021-04-13 20:35:47 --> Router Class Initialized
ERROR - 2021-04-13 20:35:47 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:35:47 --> Router Class Initialized
INFO - 2021-04-13 20:35:47 --> Output Class Initialized
DEBUG - 2021-04-13 20:35:47 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:35:47 --> Utf8 Class Initialized
INFO - 2021-04-13 20:35:47 --> Output Class Initialized
INFO - 2021-04-13 20:35:47 --> URI Class Initialized
INFO - 2021-04-13 20:35:47 --> Security Class Initialized
INFO - 2021-04-13 20:35:47 --> Security Class Initialized
DEBUG - 2021-04-13 20:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:35:47 --> Input Class Initialized
INFO - 2021-04-13 20:35:47 --> Router Class Initialized
INFO - 2021-04-13 20:35:47 --> Language Class Initialized
DEBUG - 2021-04-13 20:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:35:47 --> Input Class Initialized
INFO - 2021-04-13 20:35:47 --> Language Class Initialized
INFO - 2021-04-13 20:35:47 --> Output Class Initialized
ERROR - 2021-04-13 20:35:47 --> 404 Page Not Found: user/Assets/js
ERROR - 2021-04-13 20:35:47 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:35:47 --> Security Class Initialized
DEBUG - 2021-04-13 20:35:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:35:47 --> Input Class Initialized
INFO - 2021-04-13 20:35:47 --> Language Class Initialized
ERROR - 2021-04-13 20:35:47 --> 404 Page Not Found: user/Assets/img
INFO - 2021-04-13 20:35:48 --> Config Class Initialized
INFO - 2021-04-13 20:35:48 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:35:48 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:35:48 --> Utf8 Class Initialized
INFO - 2021-04-13 20:35:48 --> URI Class Initialized
INFO - 2021-04-13 20:35:48 --> Router Class Initialized
INFO - 2021-04-13 20:35:48 --> Output Class Initialized
INFO - 2021-04-13 20:35:48 --> Security Class Initialized
DEBUG - 2021-04-13 20:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:35:48 --> Input Class Initialized
INFO - 2021-04-13 20:35:48 --> Language Class Initialized
ERROR - 2021-04-13 20:35:48 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:35:48 --> Config Class Initialized
INFO - 2021-04-13 20:35:48 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:35:48 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:35:48 --> Utf8 Class Initialized
INFO - 2021-04-13 20:35:48 --> URI Class Initialized
INFO - 2021-04-13 20:35:48 --> Router Class Initialized
INFO - 2021-04-13 20:35:48 --> Output Class Initialized
INFO - 2021-04-13 20:35:48 --> Security Class Initialized
DEBUG - 2021-04-13 20:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:35:48 --> Input Class Initialized
INFO - 2021-04-13 20:35:48 --> Language Class Initialized
ERROR - 2021-04-13 20:35:48 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:35:48 --> Config Class Initialized
INFO - 2021-04-13 20:35:48 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:35:48 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:35:48 --> Utf8 Class Initialized
INFO - 2021-04-13 20:35:48 --> URI Class Initialized
INFO - 2021-04-13 20:35:48 --> Router Class Initialized
INFO - 2021-04-13 20:35:48 --> Output Class Initialized
INFO - 2021-04-13 20:35:48 --> Security Class Initialized
DEBUG - 2021-04-13 20:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:35:48 --> Input Class Initialized
INFO - 2021-04-13 20:35:48 --> Language Class Initialized
ERROR - 2021-04-13 20:35:48 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:35:48 --> Config Class Initialized
INFO - 2021-04-13 20:35:48 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:35:48 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:35:48 --> Utf8 Class Initialized
INFO - 2021-04-13 20:35:48 --> URI Class Initialized
INFO - 2021-04-13 20:35:48 --> Router Class Initialized
INFO - 2021-04-13 20:35:48 --> Output Class Initialized
INFO - 2021-04-13 20:35:48 --> Security Class Initialized
DEBUG - 2021-04-13 20:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:35:48 --> Input Class Initialized
INFO - 2021-04-13 20:35:48 --> Language Class Initialized
ERROR - 2021-04-13 20:35:48 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:35:48 --> Config Class Initialized
INFO - 2021-04-13 20:35:48 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:35:48 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:35:48 --> Utf8 Class Initialized
INFO - 2021-04-13 20:35:48 --> URI Class Initialized
INFO - 2021-04-13 20:35:48 --> Router Class Initialized
INFO - 2021-04-13 20:35:48 --> Output Class Initialized
INFO - 2021-04-13 20:35:48 --> Security Class Initialized
DEBUG - 2021-04-13 20:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:35:48 --> Input Class Initialized
INFO - 2021-04-13 20:35:48 --> Language Class Initialized
ERROR - 2021-04-13 20:35:48 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:35:48 --> Config Class Initialized
INFO - 2021-04-13 20:35:48 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:35:48 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:35:48 --> Utf8 Class Initialized
INFO - 2021-04-13 20:35:48 --> URI Class Initialized
INFO - 2021-04-13 20:35:48 --> Router Class Initialized
INFO - 2021-04-13 20:35:48 --> Output Class Initialized
INFO - 2021-04-13 20:35:48 --> Security Class Initialized
DEBUG - 2021-04-13 20:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:35:48 --> Input Class Initialized
INFO - 2021-04-13 20:35:48 --> Language Class Initialized
ERROR - 2021-04-13 20:35:48 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:35:48 --> Config Class Initialized
INFO - 2021-04-13 20:35:48 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:35:48 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:35:48 --> Utf8 Class Initialized
INFO - 2021-04-13 20:35:48 --> URI Class Initialized
INFO - 2021-04-13 20:35:48 --> Router Class Initialized
INFO - 2021-04-13 20:35:48 --> Output Class Initialized
INFO - 2021-04-13 20:35:48 --> Security Class Initialized
DEBUG - 2021-04-13 20:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:35:48 --> Input Class Initialized
INFO - 2021-04-13 20:35:48 --> Language Class Initialized
ERROR - 2021-04-13 20:35:48 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:35:48 --> Config Class Initialized
INFO - 2021-04-13 20:35:48 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:35:48 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:35:48 --> Utf8 Class Initialized
INFO - 2021-04-13 20:35:48 --> URI Class Initialized
INFO - 2021-04-13 20:35:48 --> Router Class Initialized
INFO - 2021-04-13 20:35:48 --> Output Class Initialized
INFO - 2021-04-13 20:35:48 --> Security Class Initialized
DEBUG - 2021-04-13 20:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:35:48 --> Input Class Initialized
INFO - 2021-04-13 20:35:48 --> Language Class Initialized
ERROR - 2021-04-13 20:35:48 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:35:48 --> Config Class Initialized
INFO - 2021-04-13 20:35:48 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:35:48 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:35:48 --> Utf8 Class Initialized
INFO - 2021-04-13 20:35:48 --> URI Class Initialized
INFO - 2021-04-13 20:35:48 --> Router Class Initialized
INFO - 2021-04-13 20:35:48 --> Output Class Initialized
INFO - 2021-04-13 20:35:48 --> Security Class Initialized
DEBUG - 2021-04-13 20:35:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:35:48 --> Input Class Initialized
INFO - 2021-04-13 20:35:48 --> Language Class Initialized
ERROR - 2021-04-13 20:35:48 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:35:50 --> Config Class Initialized
INFO - 2021-04-13 20:35:50 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:35:50 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:35:50 --> Utf8 Class Initialized
INFO - 2021-04-13 20:35:50 --> URI Class Initialized
INFO - 2021-04-13 20:35:50 --> Router Class Initialized
INFO - 2021-04-13 20:35:50 --> Output Class Initialized
INFO - 2021-04-13 20:35:50 --> Security Class Initialized
DEBUG - 2021-04-13 20:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:35:50 --> Input Class Initialized
INFO - 2021-04-13 20:35:50 --> Language Class Initialized
ERROR - 2021-04-13 20:35:50 --> 404 Page Not Found: Logout/index
INFO - 2021-04-13 20:35:52 --> Config Class Initialized
INFO - 2021-04-13 20:35:52 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:35:52 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:35:52 --> Utf8 Class Initialized
INFO - 2021-04-13 20:35:52 --> URI Class Initialized
INFO - 2021-04-13 20:35:52 --> Router Class Initialized
INFO - 2021-04-13 20:35:52 --> Output Class Initialized
INFO - 2021-04-13 20:35:52 --> Security Class Initialized
DEBUG - 2021-04-13 20:35:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:35:52 --> Input Class Initialized
INFO - 2021-04-13 20:35:52 --> Language Class Initialized
INFO - 2021-04-13 20:35:52 --> Loader Class Initialized
INFO - 2021-04-13 20:35:52 --> Helper loaded: url_helper
INFO - 2021-04-13 20:35:52 --> Helper loaded: form_helper
INFO - 2021-04-13 20:35:52 --> Helper loaded: common_helper
INFO - 2021-04-13 20:35:52 --> Helper loaded: util_helper
INFO - 2021-04-13 20:35:52 --> Database Driver Class Initialized
DEBUG - 2021-04-13 20:35:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 20:35:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 20:35:52 --> Form Validation Class Initialized
INFO - 2021-04-13 20:35:52 --> Controller Class Initialized
INFO - 2021-04-13 20:35:52 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-13 20:35:52 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 20:35:52 --> Final output sent to browser
DEBUG - 2021-04-13 20:35:52 --> Total execution time: 0.0251
INFO - 2021-04-13 20:35:54 --> Config Class Initialized
INFO - 2021-04-13 20:35:54 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:35:54 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:35:54 --> Utf8 Class Initialized
INFO - 2021-04-13 20:35:54 --> URI Class Initialized
INFO - 2021-04-13 20:35:54 --> Router Class Initialized
INFO - 2021-04-13 20:35:54 --> Output Class Initialized
INFO - 2021-04-13 20:35:54 --> Security Class Initialized
DEBUG - 2021-04-13 20:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:35:54 --> Input Class Initialized
INFO - 2021-04-13 20:35:54 --> Language Class Initialized
INFO - 2021-04-13 20:35:54 --> Loader Class Initialized
INFO - 2021-04-13 20:35:54 --> Helper loaded: url_helper
INFO - 2021-04-13 20:35:54 --> Helper loaded: form_helper
INFO - 2021-04-13 20:35:54 --> Helper loaded: common_helper
INFO - 2021-04-13 20:35:54 --> Helper loaded: util_helper
INFO - 2021-04-13 20:35:54 --> Database Driver Class Initialized
DEBUG - 2021-04-13 20:35:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 20:35:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 20:35:54 --> Form Validation Class Initialized
INFO - 2021-04-13 20:35:54 --> Controller Class Initialized
INFO - 2021-04-13 20:35:54 --> Model Class Initialized
INFO - 2021-04-13 20:35:54 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 20:35:54 --> Final output sent to browser
DEBUG - 2021-04-13 20:35:54 --> Total execution time: 0.0255
INFO - 2021-04-13 20:35:54 --> Config Class Initialized
INFO - 2021-04-13 20:35:54 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:35:54 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:35:54 --> Utf8 Class Initialized
INFO - 2021-04-13 20:35:54 --> URI Class Initialized
DEBUG - 2021-04-13 20:35:54 --> No URI present. Default controller set.
INFO - 2021-04-13 20:35:54 --> Router Class Initialized
INFO - 2021-04-13 20:35:54 --> Output Class Initialized
INFO - 2021-04-13 20:35:54 --> Security Class Initialized
DEBUG - 2021-04-13 20:35:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:35:54 --> Input Class Initialized
INFO - 2021-04-13 20:35:54 --> Language Class Initialized
INFO - 2021-04-13 20:35:54 --> Loader Class Initialized
INFO - 2021-04-13 20:35:54 --> Helper loaded: url_helper
INFO - 2021-04-13 20:35:54 --> Helper loaded: form_helper
INFO - 2021-04-13 20:35:54 --> Helper loaded: common_helper
INFO - 2021-04-13 20:35:54 --> Helper loaded: util_helper
INFO - 2021-04-13 20:35:54 --> Database Driver Class Initialized
DEBUG - 2021-04-13 20:35:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 20:35:54 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 20:35:54 --> Form Validation Class Initialized
INFO - 2021-04-13 20:35:54 --> Controller Class Initialized
INFO - 2021-04-13 20:35:54 --> Model Class Initialized
INFO - 2021-04-13 20:35:54 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-13 20:35:54 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 20:35:54 --> Final output sent to browser
DEBUG - 2021-04-13 20:35:54 --> Total execution time: 0.0266
INFO - 2021-04-13 20:35:57 --> Config Class Initialized
INFO - 2021-04-13 20:35:57 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:35:57 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:35:57 --> Utf8 Class Initialized
INFO - 2021-04-13 20:35:57 --> URI Class Initialized
DEBUG - 2021-04-13 20:35:57 --> No URI present. Default controller set.
INFO - 2021-04-13 20:35:57 --> Router Class Initialized
INFO - 2021-04-13 20:35:57 --> Output Class Initialized
INFO - 2021-04-13 20:35:57 --> Security Class Initialized
DEBUG - 2021-04-13 20:35:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:35:57 --> Input Class Initialized
INFO - 2021-04-13 20:35:57 --> Language Class Initialized
INFO - 2021-04-13 20:35:57 --> Loader Class Initialized
INFO - 2021-04-13 20:35:57 --> Helper loaded: url_helper
INFO - 2021-04-13 20:35:57 --> Helper loaded: form_helper
INFO - 2021-04-13 20:35:57 --> Helper loaded: common_helper
INFO - 2021-04-13 20:35:57 --> Helper loaded: util_helper
INFO - 2021-04-13 20:35:57 --> Database Driver Class Initialized
DEBUG - 2021-04-13 20:35:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 20:35:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 20:35:57 --> Form Validation Class Initialized
INFO - 2021-04-13 20:35:57 --> Controller Class Initialized
INFO - 2021-04-13 20:35:57 --> Model Class Initialized
INFO - 2021-04-13 20:35:57 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-13 20:35:57 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 20:35:57 --> Final output sent to browser
DEBUG - 2021-04-13 20:35:57 --> Total execution time: 0.0298
INFO - 2021-04-13 20:36:08 --> Config Class Initialized
INFO - 2021-04-13 20:36:08 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:36:08 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:36:08 --> Utf8 Class Initialized
INFO - 2021-04-13 20:36:08 --> URI Class Initialized
DEBUG - 2021-04-13 20:36:08 --> No URI present. Default controller set.
INFO - 2021-04-13 20:36:08 --> Router Class Initialized
INFO - 2021-04-13 20:36:08 --> Output Class Initialized
INFO - 2021-04-13 20:36:08 --> Security Class Initialized
DEBUG - 2021-04-13 20:36:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:36:08 --> Input Class Initialized
INFO - 2021-04-13 20:36:08 --> Language Class Initialized
INFO - 2021-04-13 20:36:08 --> Loader Class Initialized
INFO - 2021-04-13 20:36:08 --> Helper loaded: url_helper
INFO - 2021-04-13 20:36:08 --> Helper loaded: form_helper
INFO - 2021-04-13 20:36:08 --> Helper loaded: common_helper
INFO - 2021-04-13 20:36:08 --> Helper loaded: util_helper
INFO - 2021-04-13 20:36:08 --> Database Driver Class Initialized
DEBUG - 2021-04-13 20:36:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 20:36:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 20:36:08 --> Form Validation Class Initialized
INFO - 2021-04-13 20:36:08 --> Controller Class Initialized
INFO - 2021-04-13 20:36:08 --> Model Class Initialized
INFO - 2021-04-13 20:36:08 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-13 20:36:08 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 20:36:08 --> Final output sent to browser
DEBUG - 2021-04-13 20:36:08 --> Total execution time: 0.0708
INFO - 2021-04-13 20:39:57 --> Config Class Initialized
INFO - 2021-04-13 20:39:57 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:39:57 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:39:57 --> Utf8 Class Initialized
INFO - 2021-04-13 20:39:57 --> URI Class Initialized
INFO - 2021-04-13 20:39:57 --> Router Class Initialized
INFO - 2021-04-13 20:39:57 --> Output Class Initialized
INFO - 2021-04-13 20:39:57 --> Security Class Initialized
DEBUG - 2021-04-13 20:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:39:57 --> Input Class Initialized
INFO - 2021-04-13 20:39:57 --> Language Class Initialized
INFO - 2021-04-13 20:39:57 --> Loader Class Initialized
INFO - 2021-04-13 20:39:57 --> Helper loaded: url_helper
INFO - 2021-04-13 20:39:57 --> Helper loaded: form_helper
INFO - 2021-04-13 20:39:57 --> Helper loaded: common_helper
INFO - 2021-04-13 20:39:57 --> Helper loaded: util_helper
INFO - 2021-04-13 20:39:57 --> Database Driver Class Initialized
DEBUG - 2021-04-13 20:39:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 20:39:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 20:39:57 --> Form Validation Class Initialized
INFO - 2021-04-13 20:39:57 --> Controller Class Initialized
INFO - 2021-04-13 20:39:57 --> Model Class Initialized
INFO - 2021-04-13 20:39:57 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 20:39:57 --> Final output sent to browser
DEBUG - 2021-04-13 20:39:57 --> Total execution time: 0.0350
INFO - 2021-04-13 20:39:57 --> Config Class Initialized
INFO - 2021-04-13 20:39:57 --> Hooks Class Initialized
INFO - 2021-04-13 20:39:57 --> Config Class Initialized
DEBUG - 2021-04-13 20:39:57 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:39:57 --> Utf8 Class Initialized
INFO - 2021-04-13 20:39:57 --> Hooks Class Initialized
INFO - 2021-04-13 20:39:57 --> URI Class Initialized
INFO - 2021-04-13 20:39:57 --> Router Class Initialized
DEBUG - 2021-04-13 20:39:57 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:39:57 --> Utf8 Class Initialized
INFO - 2021-04-13 20:39:57 --> Output Class Initialized
INFO - 2021-04-13 20:39:57 --> URI Class Initialized
INFO - 2021-04-13 20:39:57 --> Security Class Initialized
INFO - 2021-04-13 20:39:57 --> Router Class Initialized
DEBUG - 2021-04-13 20:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:39:57 --> Input Class Initialized
INFO - 2021-04-13 20:39:57 --> Language Class Initialized
INFO - 2021-04-13 20:39:57 --> Output Class Initialized
ERROR - 2021-04-13 20:39:57 --> 404 Page Not Found: Fasset/img
INFO - 2021-04-13 20:39:57 --> Security Class Initialized
DEBUG - 2021-04-13 20:39:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:39:57 --> Input Class Initialized
INFO - 2021-04-13 20:39:57 --> Language Class Initialized
ERROR - 2021-04-13 20:39:57 --> 404 Page Not Found: Fasset/img
INFO - 2021-04-13 20:46:40 --> Config Class Initialized
INFO - 2021-04-13 20:46:40 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:46:40 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:46:40 --> Utf8 Class Initialized
INFO - 2021-04-13 20:46:40 --> URI Class Initialized
INFO - 2021-04-13 20:46:40 --> Router Class Initialized
INFO - 2021-04-13 20:46:40 --> Output Class Initialized
INFO - 2021-04-13 20:46:40 --> Security Class Initialized
DEBUG - 2021-04-13 20:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:46:40 --> Input Class Initialized
INFO - 2021-04-13 20:46:40 --> Language Class Initialized
INFO - 2021-04-13 20:46:40 --> Loader Class Initialized
INFO - 2021-04-13 20:46:40 --> Helper loaded: url_helper
INFO - 2021-04-13 20:46:40 --> Helper loaded: form_helper
INFO - 2021-04-13 20:46:40 --> Helper loaded: common_helper
INFO - 2021-04-13 20:46:40 --> Helper loaded: util_helper
INFO - 2021-04-13 20:46:40 --> Database Driver Class Initialized
DEBUG - 2021-04-13 20:46:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 20:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 20:46:40 --> Form Validation Class Initialized
INFO - 2021-04-13 20:46:40 --> Controller Class Initialized
INFO - 2021-04-13 20:46:40 --> Model Class Initialized
INFO - 2021-04-13 20:46:40 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-04-13 20:46:40 --> Config Class Initialized
INFO - 2021-04-13 20:46:40 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:46:40 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:46:40 --> Utf8 Class Initialized
INFO - 2021-04-13 20:46:40 --> URI Class Initialized
INFO - 2021-04-13 20:46:40 --> Router Class Initialized
INFO - 2021-04-13 20:46:40 --> Output Class Initialized
INFO - 2021-04-13 20:46:40 --> Security Class Initialized
DEBUG - 2021-04-13 20:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:46:40 --> Input Class Initialized
INFO - 2021-04-13 20:46:40 --> Language Class Initialized
INFO - 2021-04-13 20:46:40 --> Loader Class Initialized
INFO - 2021-04-13 20:46:40 --> Helper loaded: url_helper
INFO - 2021-04-13 20:46:40 --> Helper loaded: form_helper
INFO - 2021-04-13 20:46:40 --> Helper loaded: common_helper
INFO - 2021-04-13 20:46:40 --> Helper loaded: util_helper
INFO - 2021-04-13 20:46:40 --> Database Driver Class Initialized
DEBUG - 2021-04-13 20:46:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 20:46:40 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 20:46:40 --> Form Validation Class Initialized
INFO - 2021-04-13 20:46:40 --> Controller Class Initialized
INFO - 2021-04-13 20:46:40 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-13 20:46:40 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 20:46:40 --> Final output sent to browser
DEBUG - 2021-04-13 20:46:40 --> Total execution time: 0.0361
INFO - 2021-04-13 20:46:40 --> Config Class Initialized
INFO - 2021-04-13 20:46:40 --> Hooks Class Initialized
INFO - 2021-04-13 20:46:40 --> Config Class Initialized
INFO - 2021-04-13 20:46:40 --> Hooks Class Initialized
INFO - 2021-04-13 20:46:40 --> Config Class Initialized
INFO - 2021-04-13 20:46:40 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:46:40 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:46:40 --> Config Class Initialized
INFO - 2021-04-13 20:46:40 --> Config Class Initialized
DEBUG - 2021-04-13 20:46:40 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:46:40 --> Hooks Class Initialized
INFO - 2021-04-13 20:46:40 --> Hooks Class Initialized
INFO - 2021-04-13 20:46:40 --> Utf8 Class Initialized
DEBUG - 2021-04-13 20:46:40 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:46:40 --> Utf8 Class Initialized
INFO - 2021-04-13 20:46:40 --> URI Class Initialized
INFO - 2021-04-13 20:46:40 --> URI Class Initialized
DEBUG - 2021-04-13 20:46:40 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 20:46:40 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:46:40 --> Router Class Initialized
INFO - 2021-04-13 20:46:40 --> Utf8 Class Initialized
INFO - 2021-04-13 20:46:40 --> Utf8 Class Initialized
INFO - 2021-04-13 20:46:40 --> URI Class Initialized
INFO - 2021-04-13 20:46:40 --> Router Class Initialized
INFO - 2021-04-13 20:46:40 --> URI Class Initialized
INFO - 2021-04-13 20:46:40 --> Output Class Initialized
INFO - 2021-04-13 20:46:40 --> Router Class Initialized
INFO - 2021-04-13 20:46:40 --> Output Class Initialized
INFO - 2021-04-13 20:46:40 --> Router Class Initialized
INFO - 2021-04-13 20:46:40 --> Security Class Initialized
INFO - 2021-04-13 20:46:40 --> Security Class Initialized
DEBUG - 2021-04-13 20:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:46:40 --> Input Class Initialized
INFO - 2021-04-13 20:46:40 --> Output Class Initialized
INFO - 2021-04-13 20:46:40 --> Language Class Initialized
DEBUG - 2021-04-13 20:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:46:40 --> Input Class Initialized
INFO - 2021-04-13 20:46:40 --> Security Class Initialized
INFO - 2021-04-13 20:46:40 --> Language Class Initialized
ERROR - 2021-04-13 20:46:40 --> 404 Page Not Found: user/Assets/css
DEBUG - 2021-04-13 20:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:46:40 --> Input Class Initialized
ERROR - 2021-04-13 20:46:40 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:46:40 --> Language Class Initialized
ERROR - 2021-04-13 20:46:40 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:46:40 --> Config Class Initialized
INFO - 2021-04-13 20:46:40 --> Config Class Initialized
INFO - 2021-04-13 20:46:40 --> Output Class Initialized
INFO - 2021-04-13 20:46:40 --> Hooks Class Initialized
INFO - 2021-04-13 20:46:40 --> Hooks Class Initialized
INFO - 2021-04-13 20:46:40 --> Config Class Initialized
INFO - 2021-04-13 20:46:40 --> Hooks Class Initialized
INFO - 2021-04-13 20:46:40 --> Security Class Initialized
DEBUG - 2021-04-13 20:46:40 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:46:40 --> Utf8 Class Initialized
DEBUG - 2021-04-13 20:46:40 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:46:40 --> Utf8 Class Initialized
INFO - 2021-04-13 20:46:40 --> URI Class Initialized
DEBUG - 2021-04-13 20:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 20:46:40 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:46:40 --> Utf8 Class Initialized
INFO - 2021-04-13 20:46:40 --> Input Class Initialized
INFO - 2021-04-13 20:46:40 --> URI Class Initialized
INFO - 2021-04-13 20:46:40 --> Router Class Initialized
INFO - 2021-04-13 20:46:40 --> URI Class Initialized
INFO - 2021-04-13 20:46:40 --> Language Class Initialized
INFO - 2021-04-13 20:46:40 --> Router Class Initialized
INFO - 2021-04-13 20:46:40 --> Router Class Initialized
INFO - 2021-04-13 20:46:40 --> Output Class Initialized
ERROR - 2021-04-13 20:46:40 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:46:40 --> Security Class Initialized
INFO - 2021-04-13 20:46:40 --> Output Class Initialized
INFO - 2021-04-13 20:46:40 --> Output Class Initialized
DEBUG - 2021-04-13 20:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:46:40 --> Input Class Initialized
INFO - 2021-04-13 20:46:40 --> Security Class Initialized
INFO - 2021-04-13 20:46:40 --> Language Class Initialized
DEBUG - 2021-04-13 20:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:46:40 --> Input Class Initialized
INFO - 2021-04-13 20:46:40 --> Language Class Initialized
ERROR - 2021-04-13 20:46:40 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:46:40 --> Security Class Initialized
ERROR - 2021-04-13 20:46:40 --> 404 Page Not Found: user/Assets/js
DEBUG - 2021-04-13 20:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:46:40 --> Input Class Initialized
INFO - 2021-04-13 20:46:40 --> Language Class Initialized
INFO - 2021-04-13 20:46:40 --> Config Class Initialized
INFO - 2021-04-13 20:46:40 --> Hooks Class Initialized
ERROR - 2021-04-13 20:46:40 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:46:40 --> Config Class Initialized
DEBUG - 2021-04-13 20:46:40 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:46:40 --> Utf8 Class Initialized
INFO - 2021-04-13 20:46:40 --> URI Class Initialized
INFO - 2021-04-13 20:46:40 --> Config Class Initialized
INFO - 2021-04-13 20:46:40 --> Hooks Class Initialized
INFO - 2021-04-13 20:46:40 --> Utf8 Class Initialized
INFO - 2021-04-13 20:46:40 --> Router Class Initialized
INFO - 2021-04-13 20:46:40 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:46:40 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:46:40 --> Output Class Initialized
INFO - 2021-04-13 20:46:40 --> Utf8 Class Initialized
INFO - 2021-04-13 20:46:40 --> URI Class Initialized
INFO - 2021-04-13 20:46:40 --> URI Class Initialized
INFO - 2021-04-13 20:46:40 --> Security Class Initialized
DEBUG - 2021-04-13 20:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 20:46:40 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:46:40 --> Router Class Initialized
INFO - 2021-04-13 20:46:40 --> Input Class Initialized
INFO - 2021-04-13 20:46:40 --> Utf8 Class Initialized
INFO - 2021-04-13 20:46:40 --> Language Class Initialized
INFO - 2021-04-13 20:46:40 --> Output Class Initialized
INFO - 2021-04-13 20:46:40 --> URI Class Initialized
ERROR - 2021-04-13 20:46:40 --> 404 Page Not Found: user/Assets/img
INFO - 2021-04-13 20:46:40 --> Security Class Initialized
INFO - 2021-04-13 20:46:40 --> Router Class Initialized
INFO - 2021-04-13 20:46:40 --> Router Class Initialized
DEBUG - 2021-04-13 20:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:46:40 --> Input Class Initialized
INFO - 2021-04-13 20:46:40 --> Language Class Initialized
INFO - 2021-04-13 20:46:40 --> Output Class Initialized
INFO - 2021-04-13 20:46:40 --> Output Class Initialized
INFO - 2021-04-13 20:46:40 --> Security Class Initialized
ERROR - 2021-04-13 20:46:40 --> 404 Page Not Found: user/Assets/img
DEBUG - 2021-04-13 20:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:46:40 --> Security Class Initialized
INFO - 2021-04-13 20:46:40 --> Input Class Initialized
INFO - 2021-04-13 20:46:40 --> Language Class Initialized
DEBUG - 2021-04-13 20:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:46:40 --> Input Class Initialized
INFO - 2021-04-13 20:46:40 --> Language Class Initialized
ERROR - 2021-04-13 20:46:40 --> 404 Page Not Found: user/Assets/js
ERROR - 2021-04-13 20:46:40 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:46:40 --> Config Class Initialized
INFO - 2021-04-13 20:46:40 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:46:40 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:46:40 --> Utf8 Class Initialized
INFO - 2021-04-13 20:46:40 --> URI Class Initialized
INFO - 2021-04-13 20:46:40 --> Router Class Initialized
INFO - 2021-04-13 20:46:40 --> Output Class Initialized
INFO - 2021-04-13 20:46:40 --> Security Class Initialized
DEBUG - 2021-04-13 20:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:46:40 --> Input Class Initialized
INFO - 2021-04-13 20:46:40 --> Language Class Initialized
ERROR - 2021-04-13 20:46:40 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:46:40 --> Config Class Initialized
INFO - 2021-04-13 20:46:40 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:46:40 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:46:40 --> Utf8 Class Initialized
INFO - 2021-04-13 20:46:40 --> URI Class Initialized
INFO - 2021-04-13 20:46:40 --> Router Class Initialized
INFO - 2021-04-13 20:46:40 --> Output Class Initialized
INFO - 2021-04-13 20:46:40 --> Security Class Initialized
DEBUG - 2021-04-13 20:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:46:40 --> Input Class Initialized
INFO - 2021-04-13 20:46:40 --> Language Class Initialized
ERROR - 2021-04-13 20:46:40 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:46:40 --> Config Class Initialized
INFO - 2021-04-13 20:46:40 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:46:40 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:46:40 --> Utf8 Class Initialized
INFO - 2021-04-13 20:46:40 --> URI Class Initialized
INFO - 2021-04-13 20:46:40 --> Router Class Initialized
INFO - 2021-04-13 20:46:40 --> Output Class Initialized
INFO - 2021-04-13 20:46:40 --> Security Class Initialized
DEBUG - 2021-04-13 20:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:46:40 --> Input Class Initialized
INFO - 2021-04-13 20:46:40 --> Language Class Initialized
ERROR - 2021-04-13 20:46:40 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:46:40 --> Config Class Initialized
INFO - 2021-04-13 20:46:40 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:46:40 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:46:40 --> Utf8 Class Initialized
INFO - 2021-04-13 20:46:40 --> URI Class Initialized
INFO - 2021-04-13 20:46:40 --> Router Class Initialized
INFO - 2021-04-13 20:46:40 --> Output Class Initialized
INFO - 2021-04-13 20:46:40 --> Security Class Initialized
DEBUG - 2021-04-13 20:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:46:40 --> Input Class Initialized
INFO - 2021-04-13 20:46:40 --> Language Class Initialized
ERROR - 2021-04-13 20:46:40 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:46:40 --> Config Class Initialized
INFO - 2021-04-13 20:46:40 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:46:40 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:46:40 --> Utf8 Class Initialized
INFO - 2021-04-13 20:46:40 --> URI Class Initialized
INFO - 2021-04-13 20:46:40 --> Router Class Initialized
INFO - 2021-04-13 20:46:40 --> Output Class Initialized
INFO - 2021-04-13 20:46:40 --> Security Class Initialized
DEBUG - 2021-04-13 20:46:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:46:40 --> Input Class Initialized
INFO - 2021-04-13 20:46:40 --> Language Class Initialized
ERROR - 2021-04-13 20:46:40 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:46:41 --> Config Class Initialized
INFO - 2021-04-13 20:46:41 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:46:41 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:46:41 --> Utf8 Class Initialized
INFO - 2021-04-13 20:46:41 --> URI Class Initialized
INFO - 2021-04-13 20:46:41 --> Router Class Initialized
INFO - 2021-04-13 20:46:41 --> Output Class Initialized
INFO - 2021-04-13 20:46:41 --> Security Class Initialized
DEBUG - 2021-04-13 20:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:46:41 --> Input Class Initialized
INFO - 2021-04-13 20:46:41 --> Language Class Initialized
ERROR - 2021-04-13 20:46:41 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:46:41 --> Config Class Initialized
INFO - 2021-04-13 20:46:41 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:46:41 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:46:41 --> Utf8 Class Initialized
INFO - 2021-04-13 20:46:41 --> URI Class Initialized
INFO - 2021-04-13 20:46:41 --> Router Class Initialized
INFO - 2021-04-13 20:46:41 --> Output Class Initialized
INFO - 2021-04-13 20:46:41 --> Security Class Initialized
DEBUG - 2021-04-13 20:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:46:41 --> Input Class Initialized
INFO - 2021-04-13 20:46:41 --> Language Class Initialized
ERROR - 2021-04-13 20:46:41 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:46:41 --> Config Class Initialized
INFO - 2021-04-13 20:46:41 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:46:41 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:46:41 --> Utf8 Class Initialized
INFO - 2021-04-13 20:46:41 --> URI Class Initialized
INFO - 2021-04-13 20:46:41 --> Router Class Initialized
INFO - 2021-04-13 20:46:41 --> Output Class Initialized
INFO - 2021-04-13 20:46:41 --> Security Class Initialized
DEBUG - 2021-04-13 20:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:46:41 --> Input Class Initialized
INFO - 2021-04-13 20:46:41 --> Language Class Initialized
ERROR - 2021-04-13 20:46:41 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:46:41 --> Config Class Initialized
INFO - 2021-04-13 20:46:41 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:46:41 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:46:41 --> Utf8 Class Initialized
INFO - 2021-04-13 20:46:41 --> URI Class Initialized
INFO - 2021-04-13 20:46:41 --> Router Class Initialized
INFO - 2021-04-13 20:46:41 --> Output Class Initialized
INFO - 2021-04-13 20:46:41 --> Security Class Initialized
DEBUG - 2021-04-13 20:46:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:46:41 --> Input Class Initialized
INFO - 2021-04-13 20:46:41 --> Language Class Initialized
ERROR - 2021-04-13 20:46:41 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:47:11 --> Config Class Initialized
INFO - 2021-04-13 20:47:11 --> Hooks Class Initialized
INFO - 2021-04-13 20:47:11 --> Config Class Initialized
INFO - 2021-04-13 20:47:11 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:47:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 20:47:11 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:47:11 --> Utf8 Class Initialized
INFO - 2021-04-13 20:47:11 --> Utf8 Class Initialized
INFO - 2021-04-13 20:47:11 --> URI Class Initialized
INFO - 2021-04-13 20:47:11 --> URI Class Initialized
INFO - 2021-04-13 20:47:11 --> Router Class Initialized
INFO - 2021-04-13 20:47:11 --> Router Class Initialized
INFO - 2021-04-13 20:47:11 --> Output Class Initialized
INFO - 2021-04-13 20:47:11 --> Output Class Initialized
INFO - 2021-04-13 20:47:11 --> Security Class Initialized
INFO - 2021-04-13 20:47:11 --> Security Class Initialized
DEBUG - 2021-04-13 20:47:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 20:47:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:47:11 --> Input Class Initialized
INFO - 2021-04-13 20:47:11 --> Input Class Initialized
INFO - 2021-04-13 20:47:11 --> Language Class Initialized
INFO - 2021-04-13 20:47:11 --> Language Class Initialized
ERROR - 2021-04-13 20:47:11 --> 404 Page Not Found: Fasset/img
ERROR - 2021-04-13 20:47:11 --> 404 Page Not Found: Fasset/img
INFO - 2021-04-13 20:47:22 --> Config Class Initialized
INFO - 2021-04-13 20:47:22 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:47:22 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:47:22 --> Utf8 Class Initialized
INFO - 2021-04-13 20:47:22 --> URI Class Initialized
INFO - 2021-04-13 20:47:22 --> Router Class Initialized
INFO - 2021-04-13 20:47:22 --> Output Class Initialized
INFO - 2021-04-13 20:47:22 --> Security Class Initialized
DEBUG - 2021-04-13 20:47:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:47:22 --> Input Class Initialized
INFO - 2021-04-13 20:47:22 --> Language Class Initialized
INFO - 2021-04-13 20:47:22 --> Loader Class Initialized
INFO - 2021-04-13 20:47:22 --> Helper loaded: url_helper
INFO - 2021-04-13 20:47:22 --> Helper loaded: form_helper
INFO - 2021-04-13 20:47:22 --> Helper loaded: common_helper
INFO - 2021-04-13 20:47:22 --> Helper loaded: util_helper
INFO - 2021-04-13 20:47:22 --> Database Driver Class Initialized
DEBUG - 2021-04-13 20:47:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 20:47:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 20:47:22 --> Form Validation Class Initialized
INFO - 2021-04-13 20:47:22 --> Controller Class Initialized
INFO - 2021-04-13 20:47:22 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-13 20:47:22 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 20:47:22 --> Final output sent to browser
DEBUG - 2021-04-13 20:47:22 --> Total execution time: 0.0432
INFO - 2021-04-13 20:47:22 --> Config Class Initialized
INFO - 2021-04-13 20:47:22 --> Hooks Class Initialized
INFO - 2021-04-13 20:47:22 --> Config Class Initialized
INFO - 2021-04-13 20:47:22 --> Hooks Class Initialized
INFO - 2021-04-13 20:47:22 --> Config Class Initialized
INFO - 2021-04-13 20:47:22 --> Hooks Class Initialized
INFO - 2021-04-13 20:47:22 --> Config Class Initialized
INFO - 2021-04-13 20:47:22 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:47:22 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 20:47:22 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:47:22 --> Utf8 Class Initialized
INFO - 2021-04-13 20:47:22 --> Utf8 Class Initialized
INFO - 2021-04-13 20:47:22 --> URI Class Initialized
INFO - 2021-04-13 20:47:22 --> URI Class Initialized
DEBUG - 2021-04-13 20:47:22 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:47:22 --> Utf8 Class Initialized
DEBUG - 2021-04-13 20:47:22 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:47:22 --> Utf8 Class Initialized
INFO - 2021-04-13 20:47:22 --> URI Class Initialized
INFO - 2021-04-13 20:47:22 --> Router Class Initialized
INFO - 2021-04-13 20:47:22 --> Router Class Initialized
INFO - 2021-04-13 20:47:23 --> URI Class Initialized
INFO - 2021-04-13 20:47:23 --> Router Class Initialized
INFO - 2021-04-13 20:47:23 --> Output Class Initialized
INFO - 2021-04-13 20:47:23 --> Output Class Initialized
INFO - 2021-04-13 20:47:23 --> Router Class Initialized
INFO - 2021-04-13 20:47:23 --> Output Class Initialized
INFO - 2021-04-13 20:47:23 --> Security Class Initialized
INFO - 2021-04-13 20:47:23 --> Security Class Initialized
INFO - 2021-04-13 20:47:23 --> Output Class Initialized
DEBUG - 2021-04-13 20:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:47:23 --> Security Class Initialized
DEBUG - 2021-04-13 20:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:47:23 --> Input Class Initialized
INFO - 2021-04-13 20:47:23 --> Input Class Initialized
INFO - 2021-04-13 20:47:23 --> Security Class Initialized
INFO - 2021-04-13 20:47:23 --> Language Class Initialized
INFO - 2021-04-13 20:47:23 --> Language Class Initialized
DEBUG - 2021-04-13 20:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:47:23 --> Input Class Initialized
DEBUG - 2021-04-13 20:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:47:23 --> Input Class Initialized
INFO - 2021-04-13 20:47:23 --> Language Class Initialized
ERROR - 2021-04-13 20:47:23 --> 404 Page Not Found: user/Assets/css
ERROR - 2021-04-13 20:47:23 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:47:23 --> Language Class Initialized
ERROR - 2021-04-13 20:47:23 --> 404 Page Not Found: user/Assets/css
ERROR - 2021-04-13 20:47:23 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:47:23 --> Config Class Initialized
INFO - 2021-04-13 20:47:23 --> Hooks Class Initialized
INFO - 2021-04-13 20:47:23 --> Config Class Initialized
INFO - 2021-04-13 20:47:23 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:47:23 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:47:23 --> Utf8 Class Initialized
INFO - 2021-04-13 20:47:23 --> URI Class Initialized
INFO - 2021-04-13 20:47:23 --> Router Class Initialized
INFO - 2021-04-13 20:47:23 --> Config Class Initialized
INFO - 2021-04-13 20:47:23 --> Hooks Class Initialized
INFO - 2021-04-13 20:47:23 --> Output Class Initialized
INFO - 2021-04-13 20:47:23 --> Security Class Initialized
DEBUG - 2021-04-13 20:47:23 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:47:23 --> Config Class Initialized
INFO - 2021-04-13 20:47:23 --> Utf8 Class Initialized
INFO - 2021-04-13 20:47:23 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:47:23 --> Input Class Initialized
INFO - 2021-04-13 20:47:23 --> URI Class Initialized
INFO - 2021-04-13 20:47:23 --> Language Class Initialized
DEBUG - 2021-04-13 20:47:23 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:47:23 --> Router Class Initialized
INFO - 2021-04-13 20:47:23 --> Utf8 Class Initialized
ERROR - 2021-04-13 20:47:23 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:47:23 --> URI Class Initialized
INFO - 2021-04-13 20:47:23 --> Config Class Initialized
INFO - 2021-04-13 20:47:23 --> Output Class Initialized
INFO - 2021-04-13 20:47:23 --> Hooks Class Initialized
INFO - 2021-04-13 20:47:23 --> Config Class Initialized
INFO - 2021-04-13 20:47:23 --> Hooks Class Initialized
INFO - 2021-04-13 20:47:23 --> Router Class Initialized
INFO - 2021-04-13 20:47:23 --> Security Class Initialized
DEBUG - 2021-04-13 20:47:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 20:47:23 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:47:23 --> Output Class Initialized
INFO - 2021-04-13 20:47:23 --> Input Class Initialized
INFO - 2021-04-13 20:47:23 --> Utf8 Class Initialized
INFO - 2021-04-13 20:47:23 --> Language Class Initialized
DEBUG - 2021-04-13 20:47:23 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:47:23 --> URI Class Initialized
INFO - 2021-04-13 20:47:23 --> Security Class Initialized
INFO - 2021-04-13 20:47:23 --> Utf8 Class Initialized
INFO - 2021-04-13 20:47:23 --> URI Class Initialized
INFO - 2021-04-13 20:47:23 --> Router Class Initialized
ERROR - 2021-04-13 20:47:23 --> 404 Page Not Found: user/Assets/js
DEBUG - 2021-04-13 20:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:47:23 --> Input Class Initialized
INFO - 2021-04-13 20:47:23 --> Output Class Initialized
INFO - 2021-04-13 20:47:23 --> Language Class Initialized
INFO - 2021-04-13 20:47:23 --> Security Class Initialized
INFO - 2021-04-13 20:47:23 --> Router Class Initialized
ERROR - 2021-04-13 20:47:23 --> 404 Page Not Found: user/Assets/js
DEBUG - 2021-04-13 20:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:47:23 --> Input Class Initialized
INFO - 2021-04-13 20:47:23 --> Language Class Initialized
INFO - 2021-04-13 20:47:23 --> Output Class Initialized
DEBUG - 2021-04-13 20:47:23 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:47:23 --> Utf8 Class Initialized
ERROR - 2021-04-13 20:47:23 --> 404 Page Not Found: user/Assets/img
INFO - 2021-04-13 20:47:23 --> Security Class Initialized
INFO - 2021-04-13 20:47:23 --> URI Class Initialized
DEBUG - 2021-04-13 20:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:47:23 --> Input Class Initialized
INFO - 2021-04-13 20:47:23 --> Router Class Initialized
INFO - 2021-04-13 20:47:23 --> Language Class Initialized
INFO - 2021-04-13 20:47:23 --> Output Class Initialized
ERROR - 2021-04-13 20:47:23 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:47:23 --> Security Class Initialized
DEBUG - 2021-04-13 20:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:47:23 --> Input Class Initialized
INFO - 2021-04-13 20:47:23 --> Language Class Initialized
ERROR - 2021-04-13 20:47:23 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:47:23 --> Config Class Initialized
INFO - 2021-04-13 20:47:23 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:47:23 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:47:23 --> Utf8 Class Initialized
INFO - 2021-04-13 20:47:23 --> URI Class Initialized
INFO - 2021-04-13 20:47:23 --> Router Class Initialized
INFO - 2021-04-13 20:47:23 --> Output Class Initialized
INFO - 2021-04-13 20:47:23 --> Security Class Initialized
DEBUG - 2021-04-13 20:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:47:23 --> Input Class Initialized
INFO - 2021-04-13 20:47:23 --> Language Class Initialized
ERROR - 2021-04-13 20:47:23 --> 404 Page Not Found: user/Assets/img
INFO - 2021-04-13 20:47:23 --> Config Class Initialized
INFO - 2021-04-13 20:47:23 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:47:23 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:47:23 --> Utf8 Class Initialized
INFO - 2021-04-13 20:47:23 --> URI Class Initialized
INFO - 2021-04-13 20:47:23 --> Router Class Initialized
INFO - 2021-04-13 20:47:23 --> Output Class Initialized
INFO - 2021-04-13 20:47:23 --> Security Class Initialized
DEBUG - 2021-04-13 20:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:47:23 --> Input Class Initialized
INFO - 2021-04-13 20:47:23 --> Language Class Initialized
ERROR - 2021-04-13 20:47:23 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:47:23 --> Config Class Initialized
INFO - 2021-04-13 20:47:23 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:47:23 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:47:23 --> Utf8 Class Initialized
INFO - 2021-04-13 20:47:23 --> URI Class Initialized
INFO - 2021-04-13 20:47:23 --> Router Class Initialized
INFO - 2021-04-13 20:47:23 --> Output Class Initialized
INFO - 2021-04-13 20:47:23 --> Security Class Initialized
DEBUG - 2021-04-13 20:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:47:23 --> Input Class Initialized
INFO - 2021-04-13 20:47:23 --> Language Class Initialized
ERROR - 2021-04-13 20:47:23 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:47:23 --> Config Class Initialized
INFO - 2021-04-13 20:47:23 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:47:23 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:47:23 --> Utf8 Class Initialized
INFO - 2021-04-13 20:47:23 --> URI Class Initialized
INFO - 2021-04-13 20:47:23 --> Router Class Initialized
INFO - 2021-04-13 20:47:23 --> Output Class Initialized
INFO - 2021-04-13 20:47:23 --> Security Class Initialized
DEBUG - 2021-04-13 20:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:47:23 --> Input Class Initialized
INFO - 2021-04-13 20:47:23 --> Language Class Initialized
ERROR - 2021-04-13 20:47:23 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:47:23 --> Config Class Initialized
INFO - 2021-04-13 20:47:23 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:47:23 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:47:23 --> Utf8 Class Initialized
INFO - 2021-04-13 20:47:23 --> URI Class Initialized
INFO - 2021-04-13 20:47:23 --> Router Class Initialized
INFO - 2021-04-13 20:47:23 --> Output Class Initialized
INFO - 2021-04-13 20:47:23 --> Security Class Initialized
DEBUG - 2021-04-13 20:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:47:23 --> Input Class Initialized
INFO - 2021-04-13 20:47:23 --> Language Class Initialized
ERROR - 2021-04-13 20:47:23 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:47:23 --> Config Class Initialized
INFO - 2021-04-13 20:47:23 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:47:23 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:47:23 --> Utf8 Class Initialized
INFO - 2021-04-13 20:47:23 --> URI Class Initialized
INFO - 2021-04-13 20:47:23 --> Router Class Initialized
INFO - 2021-04-13 20:47:23 --> Output Class Initialized
INFO - 2021-04-13 20:47:23 --> Security Class Initialized
DEBUG - 2021-04-13 20:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:47:23 --> Input Class Initialized
INFO - 2021-04-13 20:47:23 --> Language Class Initialized
ERROR - 2021-04-13 20:47:23 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:47:23 --> Config Class Initialized
INFO - 2021-04-13 20:47:23 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:47:23 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:47:23 --> Utf8 Class Initialized
INFO - 2021-04-13 20:47:23 --> URI Class Initialized
INFO - 2021-04-13 20:47:23 --> Router Class Initialized
INFO - 2021-04-13 20:47:23 --> Output Class Initialized
INFO - 2021-04-13 20:47:23 --> Security Class Initialized
DEBUG - 2021-04-13 20:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:47:23 --> Input Class Initialized
INFO - 2021-04-13 20:47:23 --> Language Class Initialized
ERROR - 2021-04-13 20:47:23 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:47:23 --> Config Class Initialized
INFO - 2021-04-13 20:47:23 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:47:23 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:47:23 --> Utf8 Class Initialized
INFO - 2021-04-13 20:47:23 --> URI Class Initialized
INFO - 2021-04-13 20:47:23 --> Router Class Initialized
INFO - 2021-04-13 20:47:23 --> Output Class Initialized
INFO - 2021-04-13 20:47:23 --> Security Class Initialized
DEBUG - 2021-04-13 20:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:47:23 --> Input Class Initialized
INFO - 2021-04-13 20:47:23 --> Language Class Initialized
ERROR - 2021-04-13 20:47:23 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:47:23 --> Config Class Initialized
INFO - 2021-04-13 20:47:23 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:47:23 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:47:23 --> Utf8 Class Initialized
INFO - 2021-04-13 20:47:23 --> URI Class Initialized
INFO - 2021-04-13 20:47:23 --> Router Class Initialized
INFO - 2021-04-13 20:47:23 --> Output Class Initialized
INFO - 2021-04-13 20:47:23 --> Security Class Initialized
DEBUG - 2021-04-13 20:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:47:23 --> Input Class Initialized
INFO - 2021-04-13 20:47:23 --> Language Class Initialized
ERROR - 2021-04-13 20:47:23 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:47:23 --> Config Class Initialized
INFO - 2021-04-13 20:47:23 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:47:23 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:47:23 --> Utf8 Class Initialized
INFO - 2021-04-13 20:47:23 --> URI Class Initialized
INFO - 2021-04-13 20:47:23 --> Router Class Initialized
INFO - 2021-04-13 20:47:23 --> Output Class Initialized
INFO - 2021-04-13 20:47:23 --> Security Class Initialized
DEBUG - 2021-04-13 20:47:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:47:23 --> Input Class Initialized
INFO - 2021-04-13 20:47:23 --> Language Class Initialized
ERROR - 2021-04-13 20:47:23 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:47:28 --> Config Class Initialized
INFO - 2021-04-13 20:47:28 --> Config Class Initialized
INFO - 2021-04-13 20:47:28 --> Hooks Class Initialized
INFO - 2021-04-13 20:47:28 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:47:28 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:47:28 --> Utf8 Class Initialized
DEBUG - 2021-04-13 20:47:28 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:47:28 --> Utf8 Class Initialized
INFO - 2021-04-13 20:47:28 --> URI Class Initialized
INFO - 2021-04-13 20:47:28 --> URI Class Initialized
INFO - 2021-04-13 20:47:28 --> Router Class Initialized
INFO - 2021-04-13 20:47:28 --> Router Class Initialized
INFO - 2021-04-13 20:47:28 --> Output Class Initialized
INFO - 2021-04-13 20:47:28 --> Output Class Initialized
INFO - 2021-04-13 20:47:28 --> Security Class Initialized
INFO - 2021-04-13 20:47:28 --> Security Class Initialized
DEBUG - 2021-04-13 20:47:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 20:47:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:47:28 --> Input Class Initialized
INFO - 2021-04-13 20:47:28 --> Input Class Initialized
INFO - 2021-04-13 20:47:28 --> Language Class Initialized
INFO - 2021-04-13 20:47:28 --> Language Class Initialized
ERROR - 2021-04-13 20:47:28 --> 404 Page Not Found: Fasset/img
ERROR - 2021-04-13 20:47:28 --> 404 Page Not Found: Fasset/img
INFO - 2021-04-13 20:47:31 --> Config Class Initialized
INFO - 2021-04-13 20:47:31 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:47:31 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:47:31 --> Utf8 Class Initialized
INFO - 2021-04-13 20:47:31 --> URI Class Initialized
INFO - 2021-04-13 20:47:31 --> Router Class Initialized
INFO - 2021-04-13 20:47:31 --> Output Class Initialized
INFO - 2021-04-13 20:47:31 --> Security Class Initialized
DEBUG - 2021-04-13 20:47:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:47:31 --> Input Class Initialized
INFO - 2021-04-13 20:47:31 --> Language Class Initialized
INFO - 2021-04-13 20:47:31 --> Loader Class Initialized
INFO - 2021-04-13 20:47:31 --> Helper loaded: url_helper
INFO - 2021-04-13 20:47:31 --> Helper loaded: form_helper
INFO - 2021-04-13 20:47:31 --> Helper loaded: common_helper
INFO - 2021-04-13 20:47:31 --> Helper loaded: util_helper
INFO - 2021-04-13 20:47:31 --> Database Driver Class Initialized
DEBUG - 2021-04-13 20:47:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 20:47:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 20:47:31 --> Form Validation Class Initialized
INFO - 2021-04-13 20:47:31 --> Controller Class Initialized
INFO - 2021-04-13 20:47:31 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-13 20:47:31 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 20:47:31 --> Final output sent to browser
DEBUG - 2021-04-13 20:47:31 --> Total execution time: 0.0282
INFO - 2021-04-13 20:47:33 --> Config Class Initialized
INFO - 2021-04-13 20:47:33 --> Hooks Class Initialized
INFO - 2021-04-13 20:47:33 --> Config Class Initialized
INFO - 2021-04-13 20:47:33 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:47:33 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:47:33 --> Utf8 Class Initialized
DEBUG - 2021-04-13 20:47:33 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:47:33 --> Utf8 Class Initialized
INFO - 2021-04-13 20:47:33 --> URI Class Initialized
INFO - 2021-04-13 20:47:33 --> URI Class Initialized
INFO - 2021-04-13 20:47:33 --> Router Class Initialized
INFO - 2021-04-13 20:47:33 --> Router Class Initialized
INFO - 2021-04-13 20:47:33 --> Output Class Initialized
INFO - 2021-04-13 20:47:33 --> Output Class Initialized
INFO - 2021-04-13 20:47:33 --> Security Class Initialized
INFO - 2021-04-13 20:47:33 --> Security Class Initialized
DEBUG - 2021-04-13 20:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:47:33 --> Input Class Initialized
INFO - 2021-04-13 20:47:33 --> Language Class Initialized
DEBUG - 2021-04-13 20:47:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:47:33 --> Input Class Initialized
INFO - 2021-04-13 20:47:33 --> Language Class Initialized
ERROR - 2021-04-13 20:47:33 --> 404 Page Not Found: Fasset/img
ERROR - 2021-04-13 20:47:33 --> 404 Page Not Found: Fasset/img
INFO - 2021-04-13 20:47:37 --> Config Class Initialized
INFO - 2021-04-13 20:47:37 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:47:37 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:47:37 --> Utf8 Class Initialized
INFO - 2021-04-13 20:47:37 --> URI Class Initialized
INFO - 2021-04-13 20:47:37 --> Router Class Initialized
INFO - 2021-04-13 20:47:37 --> Output Class Initialized
INFO - 2021-04-13 20:47:37 --> Security Class Initialized
DEBUG - 2021-04-13 20:47:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:47:37 --> Input Class Initialized
INFO - 2021-04-13 20:47:37 --> Language Class Initialized
INFO - 2021-04-13 20:47:37 --> Loader Class Initialized
INFO - 2021-04-13 20:47:37 --> Helper loaded: url_helper
INFO - 2021-04-13 20:47:37 --> Helper loaded: form_helper
INFO - 2021-04-13 20:47:37 --> Helper loaded: common_helper
INFO - 2021-04-13 20:47:37 --> Helper loaded: util_helper
INFO - 2021-04-13 20:47:37 --> Database Driver Class Initialized
DEBUG - 2021-04-13 20:47:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 20:47:37 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 20:47:37 --> Form Validation Class Initialized
INFO - 2021-04-13 20:47:37 --> Controller Class Initialized
INFO - 2021-04-13 20:47:37 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-13 20:47:37 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 20:47:37 --> Final output sent to browser
DEBUG - 2021-04-13 20:47:37 --> Total execution time: 0.0302
INFO - 2021-04-13 20:47:40 --> Config Class Initialized
INFO - 2021-04-13 20:47:40 --> Hooks Class Initialized
INFO - 2021-04-13 20:47:40 --> Config Class Initialized
INFO - 2021-04-13 20:47:40 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:47:40 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 20:47:40 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:47:40 --> Utf8 Class Initialized
INFO - 2021-04-13 20:47:40 --> Utf8 Class Initialized
INFO - 2021-04-13 20:47:40 --> URI Class Initialized
INFO - 2021-04-13 20:47:40 --> URI Class Initialized
INFO - 2021-04-13 20:47:40 --> Router Class Initialized
INFO - 2021-04-13 20:47:40 --> Router Class Initialized
INFO - 2021-04-13 20:47:40 --> Output Class Initialized
INFO - 2021-04-13 20:47:40 --> Output Class Initialized
INFO - 2021-04-13 20:47:40 --> Security Class Initialized
INFO - 2021-04-13 20:47:40 --> Security Class Initialized
DEBUG - 2021-04-13 20:47:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 20:47:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:47:40 --> Input Class Initialized
INFO - 2021-04-13 20:47:40 --> Input Class Initialized
INFO - 2021-04-13 20:47:40 --> Language Class Initialized
INFO - 2021-04-13 20:47:40 --> Language Class Initialized
ERROR - 2021-04-13 20:47:40 --> 404 Page Not Found: Fasset/img
ERROR - 2021-04-13 20:47:40 --> 404 Page Not Found: Fasset/img
INFO - 2021-04-13 20:52:11 --> Config Class Initialized
INFO - 2021-04-13 20:52:11 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:52:11 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:52:11 --> Utf8 Class Initialized
INFO - 2021-04-13 20:52:11 --> URI Class Initialized
DEBUG - 2021-04-13 20:52:11 --> No URI present. Default controller set.
INFO - 2021-04-13 20:52:11 --> Router Class Initialized
INFO - 2021-04-13 20:52:11 --> Output Class Initialized
INFO - 2021-04-13 20:52:11 --> Security Class Initialized
DEBUG - 2021-04-13 20:52:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:52:11 --> Input Class Initialized
INFO - 2021-04-13 20:52:11 --> Language Class Initialized
INFO - 2021-04-13 20:52:11 --> Loader Class Initialized
INFO - 2021-04-13 20:52:11 --> Helper loaded: url_helper
INFO - 2021-04-13 20:52:11 --> Helper loaded: form_helper
INFO - 2021-04-13 20:52:11 --> Helper loaded: common_helper
INFO - 2021-04-13 20:52:11 --> Helper loaded: util_helper
INFO - 2021-04-13 20:52:11 --> Database Driver Class Initialized
ERROR - 2021-04-13 20:52:11 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 20:52:11 --> Unable to connect to the database
DEBUG - 2021-04-13 20:52:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 20:52:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 20:52:11 --> Form Validation Class Initialized
INFO - 2021-04-13 20:52:11 --> Controller Class Initialized
INFO - 2021-04-13 20:52:11 --> Model Class Initialized
INFO - 2021-04-13 20:52:11 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-13 20:52:11 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 20:52:11 --> Final output sent to browser
DEBUG - 2021-04-13 20:52:11 --> Total execution time: 0.0381
INFO - 2021-04-13 20:52:16 --> Config Class Initialized
INFO - 2021-04-13 20:52:16 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:52:16 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:52:16 --> Utf8 Class Initialized
INFO - 2021-04-13 20:52:16 --> URI Class Initialized
INFO - 2021-04-13 20:52:16 --> Router Class Initialized
INFO - 2021-04-13 20:52:16 --> Output Class Initialized
INFO - 2021-04-13 20:52:16 --> Security Class Initialized
DEBUG - 2021-04-13 20:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:52:16 --> Input Class Initialized
INFO - 2021-04-13 20:52:16 --> Language Class Initialized
INFO - 2021-04-13 20:52:16 --> Loader Class Initialized
INFO - 2021-04-13 20:52:16 --> Helper loaded: url_helper
INFO - 2021-04-13 20:52:16 --> Helper loaded: form_helper
INFO - 2021-04-13 20:52:16 --> Helper loaded: common_helper
INFO - 2021-04-13 20:52:16 --> Helper loaded: util_helper
INFO - 2021-04-13 20:52:16 --> Database Driver Class Initialized
ERROR - 2021-04-13 20:52:16 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 20:52:16 --> Unable to connect to the database
DEBUG - 2021-04-13 20:52:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 20:52:16 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 20:52:16 --> Form Validation Class Initialized
INFO - 2021-04-13 20:52:16 --> Controller Class Initialized
INFO - 2021-04-13 20:52:16 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-13 20:52:16 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 20:52:16 --> Final output sent to browser
DEBUG - 2021-04-13 20:52:16 --> Total execution time: 0.0350
INFO - 2021-04-13 20:52:16 --> Config Class Initialized
INFO - 2021-04-13 20:52:16 --> Hooks Class Initialized
INFO - 2021-04-13 20:52:16 --> Config Class Initialized
INFO - 2021-04-13 20:52:16 --> Hooks Class Initialized
INFO - 2021-04-13 20:52:16 --> Config Class Initialized
INFO - 2021-04-13 20:52:16 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:52:16 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 20:52:16 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:52:16 --> Utf8 Class Initialized
INFO - 2021-04-13 20:52:16 --> Utf8 Class Initialized
INFO - 2021-04-13 20:52:16 --> URI Class Initialized
INFO - 2021-04-13 20:52:16 --> URI Class Initialized
DEBUG - 2021-04-13 20:52:16 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:52:16 --> Utf8 Class Initialized
INFO - 2021-04-13 20:52:16 --> Router Class Initialized
INFO - 2021-04-13 20:52:16 --> Router Class Initialized
INFO - 2021-04-13 20:52:16 --> URI Class Initialized
INFO - 2021-04-13 20:52:16 --> Output Class Initialized
INFO - 2021-04-13 20:52:16 --> Output Class Initialized
INFO - 2021-04-13 20:52:16 --> Router Class Initialized
INFO - 2021-04-13 20:52:16 --> Security Class Initialized
INFO - 2021-04-13 20:52:16 --> Security Class Initialized
INFO - 2021-04-13 20:52:16 --> Output Class Initialized
DEBUG - 2021-04-13 20:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:52:16 --> Input Class Initialized
DEBUG - 2021-04-13 20:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:52:16 --> Input Class Initialized
INFO - 2021-04-13 20:52:16 --> Security Class Initialized
INFO - 2021-04-13 20:52:16 --> Language Class Initialized
INFO - 2021-04-13 20:52:16 --> Language Class Initialized
DEBUG - 2021-04-13 20:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:52:16 --> Input Class Initialized
ERROR - 2021-04-13 20:52:16 --> 404 Page Not Found: user/Assets/css
ERROR - 2021-04-13 20:52:16 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:52:16 --> Language Class Initialized
ERROR - 2021-04-13 20:52:16 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:52:16 --> Config Class Initialized
INFO - 2021-04-13 20:52:16 --> Hooks Class Initialized
INFO - 2021-04-13 20:52:16 --> Config Class Initialized
INFO - 2021-04-13 20:52:16 --> Config Class Initialized
INFO - 2021-04-13 20:52:16 --> Hooks Class Initialized
INFO - 2021-04-13 20:52:16 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:52:16 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:52:16 --> Utf8 Class Initialized
DEBUG - 2021-04-13 20:52:16 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:52:16 --> Utf8 Class Initialized
DEBUG - 2021-04-13 20:52:16 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:52:16 --> URI Class Initialized
INFO - 2021-04-13 20:52:16 --> Utf8 Class Initialized
INFO - 2021-04-13 20:52:16 --> URI Class Initialized
INFO - 2021-04-13 20:52:16 --> URI Class Initialized
INFO - 2021-04-13 20:52:16 --> Router Class Initialized
INFO - 2021-04-13 20:52:16 --> Router Class Initialized
INFO - 2021-04-13 20:52:16 --> Router Class Initialized
INFO - 2021-04-13 20:52:16 --> Output Class Initialized
INFO - 2021-04-13 20:52:16 --> Output Class Initialized
INFO - 2021-04-13 20:52:16 --> Output Class Initialized
INFO - 2021-04-13 20:52:16 --> Security Class Initialized
INFO - 2021-04-13 20:52:16 --> Security Class Initialized
INFO - 2021-04-13 20:52:16 --> Security Class Initialized
DEBUG - 2021-04-13 20:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:52:16 --> Input Class Initialized
DEBUG - 2021-04-13 20:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:52:16 --> Language Class Initialized
DEBUG - 2021-04-13 20:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:52:16 --> Input Class Initialized
INFO - 2021-04-13 20:52:16 --> Input Class Initialized
INFO - 2021-04-13 20:52:16 --> Language Class Initialized
INFO - 2021-04-13 20:52:16 --> Language Class Initialized
ERROR - 2021-04-13 20:52:16 --> 404 Page Not Found: user/Assets/js
ERROR - 2021-04-13 20:52:16 --> 404 Page Not Found: user/Assets/js
ERROR - 2021-04-13 20:52:16 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:52:16 --> Config Class Initialized
INFO - 2021-04-13 20:52:16 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:52:16 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:52:16 --> Utf8 Class Initialized
INFO - 2021-04-13 20:52:16 --> URI Class Initialized
INFO - 2021-04-13 20:52:16 --> Config Class Initialized
INFO - 2021-04-13 20:52:16 --> Hooks Class Initialized
INFO - 2021-04-13 20:52:16 --> Router Class Initialized
INFO - 2021-04-13 20:52:16 --> Config Class Initialized
INFO - 2021-04-13 20:52:16 --> Hooks Class Initialized
INFO - 2021-04-13 20:52:16 --> Config Class Initialized
INFO - 2021-04-13 20:52:16 --> Output Class Initialized
INFO - 2021-04-13 20:52:16 --> Hooks Class Initialized
INFO - 2021-04-13 20:52:16 --> Config Class Initialized
DEBUG - 2021-04-13 20:52:16 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:52:16 --> Utf8 Class Initialized
INFO - 2021-04-13 20:52:16 --> Hooks Class Initialized
INFO - 2021-04-13 20:52:16 --> Security Class Initialized
INFO - 2021-04-13 20:52:16 --> URI Class Initialized
DEBUG - 2021-04-13 20:52:16 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 20:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:52:16 --> Router Class Initialized
INFO - 2021-04-13 20:52:16 --> Input Class Initialized
DEBUG - 2021-04-13 20:52:16 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:52:16 --> Utf8 Class Initialized
INFO - 2021-04-13 20:52:16 --> Utf8 Class Initialized
INFO - 2021-04-13 20:52:16 --> Language Class Initialized
INFO - 2021-04-13 20:52:16 --> Output Class Initialized
INFO - 2021-04-13 20:52:16 --> URI Class Initialized
INFO - 2021-04-13 20:52:16 --> URI Class Initialized
ERROR - 2021-04-13 20:52:16 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:52:16 --> Security Class Initialized
INFO - 2021-04-13 20:52:16 --> Router Class Initialized
DEBUG - 2021-04-13 20:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:52:16 --> Input Class Initialized
INFO - 2021-04-13 20:52:16 --> Router Class Initialized
INFO - 2021-04-13 20:52:16 --> Language Class Initialized
INFO - 2021-04-13 20:52:16 --> Output Class Initialized
INFO - 2021-04-13 20:52:16 --> Output Class Initialized
ERROR - 2021-04-13 20:52:16 --> 404 Page Not Found: user/Assets/img
DEBUG - 2021-04-13 20:52:16 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:52:16 --> Security Class Initialized
INFO - 2021-04-13 20:52:16 --> Utf8 Class Initialized
INFO - 2021-04-13 20:52:16 --> Security Class Initialized
DEBUG - 2021-04-13 20:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:52:16 --> URI Class Initialized
INFO - 2021-04-13 20:52:16 --> Input Class Initialized
DEBUG - 2021-04-13 20:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:52:16 --> Input Class Initialized
INFO - 2021-04-13 20:52:16 --> Language Class Initialized
INFO - 2021-04-13 20:52:16 --> Language Class Initialized
INFO - 2021-04-13 20:52:16 --> Router Class Initialized
ERROR - 2021-04-13 20:52:16 --> 404 Page Not Found: user/Assets/img
ERROR - 2021-04-13 20:52:16 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:52:16 --> Output Class Initialized
INFO - 2021-04-13 20:52:16 --> Security Class Initialized
DEBUG - 2021-04-13 20:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:52:16 --> Input Class Initialized
INFO - 2021-04-13 20:52:16 --> Language Class Initialized
ERROR - 2021-04-13 20:52:16 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:52:16 --> Config Class Initialized
INFO - 2021-04-13 20:52:16 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:52:16 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:52:16 --> Utf8 Class Initialized
INFO - 2021-04-13 20:52:16 --> URI Class Initialized
INFO - 2021-04-13 20:52:16 --> Router Class Initialized
INFO - 2021-04-13 20:52:16 --> Output Class Initialized
INFO - 2021-04-13 20:52:16 --> Security Class Initialized
DEBUG - 2021-04-13 20:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:52:16 --> Input Class Initialized
INFO - 2021-04-13 20:52:16 --> Language Class Initialized
ERROR - 2021-04-13 20:52:16 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:52:16 --> Config Class Initialized
INFO - 2021-04-13 20:52:16 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:52:16 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:52:16 --> Utf8 Class Initialized
INFO - 2021-04-13 20:52:16 --> URI Class Initialized
INFO - 2021-04-13 20:52:16 --> Router Class Initialized
INFO - 2021-04-13 20:52:16 --> Output Class Initialized
INFO - 2021-04-13 20:52:16 --> Security Class Initialized
DEBUG - 2021-04-13 20:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:52:16 --> Input Class Initialized
INFO - 2021-04-13 20:52:16 --> Language Class Initialized
ERROR - 2021-04-13 20:52:16 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:52:16 --> Config Class Initialized
INFO - 2021-04-13 20:52:16 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:52:16 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:52:16 --> Utf8 Class Initialized
INFO - 2021-04-13 20:52:16 --> URI Class Initialized
INFO - 2021-04-13 20:52:16 --> Router Class Initialized
INFO - 2021-04-13 20:52:16 --> Output Class Initialized
INFO - 2021-04-13 20:52:16 --> Security Class Initialized
DEBUG - 2021-04-13 20:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:52:16 --> Input Class Initialized
INFO - 2021-04-13 20:52:16 --> Language Class Initialized
ERROR - 2021-04-13 20:52:16 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:52:16 --> Config Class Initialized
INFO - 2021-04-13 20:52:16 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:52:16 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:52:16 --> Utf8 Class Initialized
INFO - 2021-04-13 20:52:16 --> URI Class Initialized
INFO - 2021-04-13 20:52:16 --> Router Class Initialized
INFO - 2021-04-13 20:52:16 --> Output Class Initialized
INFO - 2021-04-13 20:52:16 --> Security Class Initialized
DEBUG - 2021-04-13 20:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:52:16 --> Input Class Initialized
INFO - 2021-04-13 20:52:16 --> Language Class Initialized
ERROR - 2021-04-13 20:52:16 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:52:16 --> Config Class Initialized
INFO - 2021-04-13 20:52:16 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:52:16 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:52:16 --> Utf8 Class Initialized
INFO - 2021-04-13 20:52:16 --> URI Class Initialized
INFO - 2021-04-13 20:52:16 --> Router Class Initialized
INFO - 2021-04-13 20:52:16 --> Output Class Initialized
INFO - 2021-04-13 20:52:16 --> Security Class Initialized
DEBUG - 2021-04-13 20:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:52:16 --> Input Class Initialized
INFO - 2021-04-13 20:52:16 --> Language Class Initialized
ERROR - 2021-04-13 20:52:16 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:52:16 --> Config Class Initialized
INFO - 2021-04-13 20:52:16 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:52:16 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:52:16 --> Utf8 Class Initialized
INFO - 2021-04-13 20:52:16 --> URI Class Initialized
INFO - 2021-04-13 20:52:16 --> Router Class Initialized
INFO - 2021-04-13 20:52:16 --> Output Class Initialized
INFO - 2021-04-13 20:52:16 --> Security Class Initialized
DEBUG - 2021-04-13 20:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:52:16 --> Input Class Initialized
INFO - 2021-04-13 20:52:16 --> Language Class Initialized
ERROR - 2021-04-13 20:52:16 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:52:16 --> Config Class Initialized
INFO - 2021-04-13 20:52:16 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:52:16 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:52:16 --> Utf8 Class Initialized
INFO - 2021-04-13 20:52:16 --> URI Class Initialized
INFO - 2021-04-13 20:52:16 --> Router Class Initialized
INFO - 2021-04-13 20:52:16 --> Output Class Initialized
INFO - 2021-04-13 20:52:16 --> Security Class Initialized
DEBUG - 2021-04-13 20:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:52:16 --> Input Class Initialized
INFO - 2021-04-13 20:52:16 --> Language Class Initialized
ERROR - 2021-04-13 20:52:16 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:52:16 --> Config Class Initialized
INFO - 2021-04-13 20:52:16 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:52:16 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:52:16 --> Utf8 Class Initialized
INFO - 2021-04-13 20:52:16 --> URI Class Initialized
INFO - 2021-04-13 20:52:16 --> Router Class Initialized
INFO - 2021-04-13 20:52:16 --> Output Class Initialized
INFO - 2021-04-13 20:52:16 --> Security Class Initialized
DEBUG - 2021-04-13 20:52:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:52:16 --> Input Class Initialized
INFO - 2021-04-13 20:52:16 --> Language Class Initialized
ERROR - 2021-04-13 20:52:16 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:52:17 --> Config Class Initialized
INFO - 2021-04-13 20:52:17 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:52:17 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:52:17 --> Utf8 Class Initialized
INFO - 2021-04-13 20:52:17 --> URI Class Initialized
INFO - 2021-04-13 20:52:17 --> Router Class Initialized
INFO - 2021-04-13 20:52:17 --> Output Class Initialized
INFO - 2021-04-13 20:52:17 --> Security Class Initialized
DEBUG - 2021-04-13 20:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:52:17 --> Input Class Initialized
INFO - 2021-04-13 20:52:17 --> Language Class Initialized
INFO - 2021-04-13 20:52:17 --> Loader Class Initialized
INFO - 2021-04-13 20:52:17 --> Helper loaded: url_helper
INFO - 2021-04-13 20:52:17 --> Helper loaded: form_helper
INFO - 2021-04-13 20:52:17 --> Helper loaded: common_helper
INFO - 2021-04-13 20:52:17 --> Helper loaded: util_helper
INFO - 2021-04-13 20:52:17 --> Database Driver Class Initialized
ERROR - 2021-04-13 20:52:17 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 20:52:17 --> Unable to connect to the database
DEBUG - 2021-04-13 20:52:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 20:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 20:52:17 --> Form Validation Class Initialized
INFO - 2021-04-13 20:52:17 --> Controller Class Initialized
INFO - 2021-04-13 20:52:17 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-13 20:52:17 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 20:52:17 --> Final output sent to browser
DEBUG - 2021-04-13 20:52:17 --> Total execution time: 0.0253
INFO - 2021-04-13 20:52:17 --> Config Class Initialized
INFO - 2021-04-13 20:52:17 --> Hooks Class Initialized
INFO - 2021-04-13 20:52:17 --> Config Class Initialized
INFO - 2021-04-13 20:52:17 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:52:17 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:52:17 --> Utf8 Class Initialized
INFO - 2021-04-13 20:52:17 --> Config Class Initialized
INFO - 2021-04-13 20:52:17 --> Hooks Class Initialized
INFO - 2021-04-13 20:52:17 --> URI Class Initialized
DEBUG - 2021-04-13 20:52:17 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:52:17 --> Utf8 Class Initialized
INFO - 2021-04-13 20:52:17 --> Router Class Initialized
INFO - 2021-04-13 20:52:17 --> Config Class Initialized
DEBUG - 2021-04-13 20:52:17 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:52:17 --> Hooks Class Initialized
INFO - 2021-04-13 20:52:17 --> Utf8 Class Initialized
INFO - 2021-04-13 20:52:17 --> URI Class Initialized
INFO - 2021-04-13 20:52:17 --> Output Class Initialized
INFO - 2021-04-13 20:52:17 --> URI Class Initialized
INFO - 2021-04-13 20:52:17 --> Router Class Initialized
DEBUG - 2021-04-13 20:52:17 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:52:17 --> Security Class Initialized
INFO - 2021-04-13 20:52:17 --> Router Class Initialized
INFO - 2021-04-13 20:52:17 --> Utf8 Class Initialized
INFO - 2021-04-13 20:52:17 --> URI Class Initialized
DEBUG - 2021-04-13 20:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:52:17 --> Output Class Initialized
INFO - 2021-04-13 20:52:17 --> Output Class Initialized
INFO - 2021-04-13 20:52:17 --> Input Class Initialized
INFO - 2021-04-13 20:52:17 --> Language Class Initialized
INFO - 2021-04-13 20:52:17 --> Router Class Initialized
INFO - 2021-04-13 20:52:17 --> Security Class Initialized
INFO - 2021-04-13 20:52:17 --> Security Class Initialized
ERROR - 2021-04-13 20:52:17 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:52:17 --> Output Class Initialized
DEBUG - 2021-04-13 20:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 20:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:52:17 --> Input Class Initialized
INFO - 2021-04-13 20:52:17 --> Input Class Initialized
INFO - 2021-04-13 20:52:17 --> Language Class Initialized
INFO - 2021-04-13 20:52:17 --> Language Class Initialized
INFO - 2021-04-13 20:52:17 --> Security Class Initialized
DEBUG - 2021-04-13 20:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:52:17 --> Input Class Initialized
ERROR - 2021-04-13 20:52:17 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:52:17 --> Language Class Initialized
ERROR - 2021-04-13 20:52:17 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:52:17 --> Config Class Initialized
INFO - 2021-04-13 20:52:17 --> Hooks Class Initialized
INFO - 2021-04-13 20:52:17 --> Config Class Initialized
INFO - 2021-04-13 20:52:17 --> Hooks Class Initialized
INFO - 2021-04-13 20:52:17 --> Config Class Initialized
INFO - 2021-04-13 20:52:17 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:52:17 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 20:52:17 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:52:17 --> Utf8 Class Initialized
INFO - 2021-04-13 20:52:17 --> Utf8 Class Initialized
DEBUG - 2021-04-13 20:52:17 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:52:17 --> Utf8 Class Initialized
INFO - 2021-04-13 20:52:17 --> URI Class Initialized
INFO - 2021-04-13 20:52:17 --> URI Class Initialized
INFO - 2021-04-13 20:52:17 --> URI Class Initialized
INFO - 2021-04-13 20:52:17 --> Router Class Initialized
INFO - 2021-04-13 20:52:17 --> Router Class Initialized
INFO - 2021-04-13 20:52:17 --> Router Class Initialized
INFO - 2021-04-13 20:52:17 --> Output Class Initialized
INFO - 2021-04-13 20:52:17 --> Output Class Initialized
INFO - 2021-04-13 20:52:17 --> Output Class Initialized
INFO - 2021-04-13 20:52:17 --> Security Class Initialized
INFO - 2021-04-13 20:52:17 --> Security Class Initialized
INFO - 2021-04-13 20:52:17 --> Security Class Initialized
DEBUG - 2021-04-13 20:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:52:17 --> Input Class Initialized
DEBUG - 2021-04-13 20:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:52:17 --> Input Class Initialized
DEBUG - 2021-04-13 20:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:52:17 --> Input Class Initialized
INFO - 2021-04-13 20:52:17 --> Language Class Initialized
INFO - 2021-04-13 20:52:17 --> Language Class Initialized
INFO - 2021-04-13 20:52:17 --> Config Class Initialized
INFO - 2021-04-13 20:52:17 --> Hooks Class Initialized
ERROR - 2021-04-13 20:52:17 --> 404 Page Not Found: user/Assets/js
ERROR - 2021-04-13 20:52:17 --> 404 Page Not Found: user/Assets/js
ERROR - 2021-04-13 20:52:17 --> 404 Page Not Found: user/Assets/css
DEBUG - 2021-04-13 20:52:17 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:52:17 --> Utf8 Class Initialized
INFO - 2021-04-13 20:52:17 --> URI Class Initialized
INFO - 2021-04-13 20:52:17 --> Language Class Initialized
INFO - 2021-04-13 20:52:17 --> Config Class Initialized
ERROR - 2021-04-13 20:52:17 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:52:17 --> Router Class Initialized
INFO - 2021-04-13 20:52:17 --> Hooks Class Initialized
INFO - 2021-04-13 20:52:17 --> Output Class Initialized
INFO - 2021-04-13 20:52:17 --> Config Class Initialized
INFO - 2021-04-13 20:52:17 --> Hooks Class Initialized
INFO - 2021-04-13 20:52:17 --> Security Class Initialized
DEBUG - 2021-04-13 20:52:17 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 20:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:52:17 --> Utf8 Class Initialized
INFO - 2021-04-13 20:52:17 --> Input Class Initialized
DEBUG - 2021-04-13 20:52:17 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:52:17 --> Utf8 Class Initialized
INFO - 2021-04-13 20:52:17 --> URI Class Initialized
INFO - 2021-04-13 20:52:17 --> Language Class Initialized
INFO - 2021-04-13 20:52:17 --> URI Class Initialized
ERROR - 2021-04-13 20:52:17 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:52:17 --> Router Class Initialized
INFO - 2021-04-13 20:52:17 --> Router Class Initialized
INFO - 2021-04-13 20:52:17 --> Output Class Initialized
INFO - 2021-04-13 20:52:17 --> Output Class Initialized
INFO - 2021-04-13 20:52:17 --> Security Class Initialized
INFO - 2021-04-13 20:52:17 --> Security Class Initialized
DEBUG - 2021-04-13 20:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 20:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:52:17 --> Input Class Initialized
INFO - 2021-04-13 20:52:17 --> Input Class Initialized
INFO - 2021-04-13 20:52:17 --> Config Class Initialized
INFO - 2021-04-13 20:52:17 --> Hooks Class Initialized
INFO - 2021-04-13 20:52:17 --> Language Class Initialized
INFO - 2021-04-13 20:52:17 --> Language Class Initialized
ERROR - 2021-04-13 20:52:17 --> 404 Page Not Found: user/Assets/img
ERROR - 2021-04-13 20:52:17 --> 404 Page Not Found: user/Assets/css
DEBUG - 2021-04-13 20:52:17 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:52:17 --> Utf8 Class Initialized
INFO - 2021-04-13 20:52:17 --> URI Class Initialized
INFO - 2021-04-13 20:52:17 --> Router Class Initialized
INFO - 2021-04-13 20:52:17 --> Output Class Initialized
INFO - 2021-04-13 20:52:17 --> Security Class Initialized
DEBUG - 2021-04-13 20:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:52:17 --> Input Class Initialized
INFO - 2021-04-13 20:52:17 --> Language Class Initialized
INFO - 2021-04-13 20:52:17 --> Config Class Initialized
INFO - 2021-04-13 20:52:17 --> Hooks Class Initialized
ERROR - 2021-04-13 20:52:17 --> 404 Page Not Found: user/Assets/img
DEBUG - 2021-04-13 20:52:17 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:52:17 --> Utf8 Class Initialized
INFO - 2021-04-13 20:52:17 --> URI Class Initialized
INFO - 2021-04-13 20:52:17 --> Router Class Initialized
INFO - 2021-04-13 20:52:17 --> Output Class Initialized
INFO - 2021-04-13 20:52:17 --> Security Class Initialized
DEBUG - 2021-04-13 20:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:52:17 --> Input Class Initialized
INFO - 2021-04-13 20:52:17 --> Language Class Initialized
ERROR - 2021-04-13 20:52:17 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:52:17 --> Config Class Initialized
INFO - 2021-04-13 20:52:17 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:52:17 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:52:17 --> Utf8 Class Initialized
INFO - 2021-04-13 20:52:17 --> URI Class Initialized
INFO - 2021-04-13 20:52:17 --> Router Class Initialized
INFO - 2021-04-13 20:52:17 --> Output Class Initialized
INFO - 2021-04-13 20:52:17 --> Security Class Initialized
DEBUG - 2021-04-13 20:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:52:17 --> Input Class Initialized
INFO - 2021-04-13 20:52:17 --> Language Class Initialized
ERROR - 2021-04-13 20:52:17 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:52:17 --> Config Class Initialized
INFO - 2021-04-13 20:52:17 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:52:17 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:52:17 --> Utf8 Class Initialized
INFO - 2021-04-13 20:52:17 --> URI Class Initialized
INFO - 2021-04-13 20:52:17 --> Router Class Initialized
INFO - 2021-04-13 20:52:17 --> Output Class Initialized
INFO - 2021-04-13 20:52:17 --> Security Class Initialized
DEBUG - 2021-04-13 20:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:52:17 --> Input Class Initialized
INFO - 2021-04-13 20:52:17 --> Language Class Initialized
ERROR - 2021-04-13 20:52:17 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:52:17 --> Config Class Initialized
INFO - 2021-04-13 20:52:17 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:52:17 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:52:17 --> Utf8 Class Initialized
INFO - 2021-04-13 20:52:17 --> URI Class Initialized
INFO - 2021-04-13 20:52:17 --> Router Class Initialized
INFO - 2021-04-13 20:52:17 --> Output Class Initialized
INFO - 2021-04-13 20:52:17 --> Security Class Initialized
DEBUG - 2021-04-13 20:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:52:17 --> Input Class Initialized
INFO - 2021-04-13 20:52:17 --> Language Class Initialized
ERROR - 2021-04-13 20:52:17 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:52:17 --> Config Class Initialized
INFO - 2021-04-13 20:52:17 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:52:17 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:52:17 --> Utf8 Class Initialized
INFO - 2021-04-13 20:52:17 --> URI Class Initialized
INFO - 2021-04-13 20:52:17 --> Router Class Initialized
INFO - 2021-04-13 20:52:17 --> Output Class Initialized
INFO - 2021-04-13 20:52:17 --> Security Class Initialized
DEBUG - 2021-04-13 20:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:52:17 --> Input Class Initialized
INFO - 2021-04-13 20:52:17 --> Language Class Initialized
ERROR - 2021-04-13 20:52:17 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:52:17 --> Config Class Initialized
INFO - 2021-04-13 20:52:17 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:52:17 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:52:17 --> Utf8 Class Initialized
INFO - 2021-04-13 20:52:17 --> URI Class Initialized
INFO - 2021-04-13 20:52:17 --> Router Class Initialized
INFO - 2021-04-13 20:52:17 --> Output Class Initialized
INFO - 2021-04-13 20:52:17 --> Security Class Initialized
DEBUG - 2021-04-13 20:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:52:17 --> Input Class Initialized
INFO - 2021-04-13 20:52:17 --> Language Class Initialized
ERROR - 2021-04-13 20:52:17 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:52:17 --> Config Class Initialized
INFO - 2021-04-13 20:52:17 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:52:17 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:52:17 --> Utf8 Class Initialized
INFO - 2021-04-13 20:52:17 --> URI Class Initialized
INFO - 2021-04-13 20:52:17 --> Router Class Initialized
INFO - 2021-04-13 20:52:17 --> Output Class Initialized
INFO - 2021-04-13 20:52:17 --> Security Class Initialized
DEBUG - 2021-04-13 20:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:52:17 --> Input Class Initialized
INFO - 2021-04-13 20:52:17 --> Language Class Initialized
ERROR - 2021-04-13 20:52:17 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:52:17 --> Config Class Initialized
INFO - 2021-04-13 20:52:17 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:52:17 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:52:17 --> Utf8 Class Initialized
INFO - 2021-04-13 20:52:17 --> URI Class Initialized
INFO - 2021-04-13 20:52:17 --> Router Class Initialized
INFO - 2021-04-13 20:52:17 --> Output Class Initialized
INFO - 2021-04-13 20:52:17 --> Security Class Initialized
DEBUG - 2021-04-13 20:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:52:17 --> Input Class Initialized
INFO - 2021-04-13 20:52:17 --> Language Class Initialized
ERROR - 2021-04-13 20:52:17 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:52:17 --> Config Class Initialized
INFO - 2021-04-13 20:52:17 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:52:17 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:52:17 --> Utf8 Class Initialized
INFO - 2021-04-13 20:52:17 --> URI Class Initialized
INFO - 2021-04-13 20:52:17 --> Router Class Initialized
INFO - 2021-04-13 20:52:17 --> Output Class Initialized
INFO - 2021-04-13 20:52:17 --> Security Class Initialized
DEBUG - 2021-04-13 20:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:52:17 --> Input Class Initialized
INFO - 2021-04-13 20:52:17 --> Language Class Initialized
INFO - 2021-04-13 20:52:17 --> Loader Class Initialized
INFO - 2021-04-13 20:52:17 --> Helper loaded: url_helper
INFO - 2021-04-13 20:52:17 --> Helper loaded: form_helper
INFO - 2021-04-13 20:52:17 --> Helper loaded: common_helper
INFO - 2021-04-13 20:52:17 --> Helper loaded: util_helper
INFO - 2021-04-13 20:52:17 --> Database Driver Class Initialized
ERROR - 2021-04-13 20:52:17 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 20:52:17 --> Unable to connect to the database
DEBUG - 2021-04-13 20:52:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 20:52:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 20:52:17 --> Form Validation Class Initialized
INFO - 2021-04-13 20:52:17 --> Controller Class Initialized
INFO - 2021-04-13 20:52:17 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-13 20:52:17 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 20:52:17 --> Final output sent to browser
DEBUG - 2021-04-13 20:52:17 --> Total execution time: 0.0249
INFO - 2021-04-13 20:52:17 --> Config Class Initialized
INFO - 2021-04-13 20:52:17 --> Hooks Class Initialized
INFO - 2021-04-13 20:52:17 --> Config Class Initialized
DEBUG - 2021-04-13 20:52:17 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:52:17 --> Hooks Class Initialized
INFO - 2021-04-13 20:52:17 --> Config Class Initialized
INFO - 2021-04-13 20:52:17 --> Config Class Initialized
INFO - 2021-04-13 20:52:17 --> Hooks Class Initialized
INFO - 2021-04-13 20:52:17 --> Hooks Class Initialized
INFO - 2021-04-13 20:52:17 --> Utf8 Class Initialized
INFO - 2021-04-13 20:52:17 --> Config Class Initialized
DEBUG - 2021-04-13 20:52:17 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:52:17 --> Hooks Class Initialized
INFO - 2021-04-13 20:52:17 --> Utf8 Class Initialized
DEBUG - 2021-04-13 20:52:17 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 20:52:17 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:52:17 --> Utf8 Class Initialized
INFO - 2021-04-13 20:52:17 --> Utf8 Class Initialized
INFO - 2021-04-13 20:52:17 --> URI Class Initialized
INFO - 2021-04-13 20:52:17 --> URI Class Initialized
INFO - 2021-04-13 20:52:17 --> URI Class Initialized
INFO - 2021-04-13 20:52:17 --> Router Class Initialized
INFO - 2021-04-13 20:52:17 --> Router Class Initialized
INFO - 2021-04-13 20:52:17 --> Router Class Initialized
DEBUG - 2021-04-13 20:52:17 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:52:17 --> Output Class Initialized
INFO - 2021-04-13 20:52:17 --> Output Class Initialized
INFO - 2021-04-13 20:52:17 --> Output Class Initialized
INFO - 2021-04-13 20:52:17 --> URI Class Initialized
INFO - 2021-04-13 20:52:17 --> Utf8 Class Initialized
INFO - 2021-04-13 20:52:17 --> Security Class Initialized
INFO - 2021-04-13 20:52:17 --> Security Class Initialized
INFO - 2021-04-13 20:52:17 --> Security Class Initialized
DEBUG - 2021-04-13 20:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 20:52:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 20:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:52:17 --> Input Class Initialized
INFO - 2021-04-13 20:52:17 --> Input Class Initialized
INFO - 2021-04-13 20:52:17 --> Input Class Initialized
INFO - 2021-04-13 20:52:17 --> Language Class Initialized
INFO - 2021-04-13 20:52:17 --> Language Class Initialized
INFO - 2021-04-13 20:52:17 --> Language Class Initialized
INFO - 2021-04-13 20:52:17 --> URI Class Initialized
ERROR - 2021-04-13 20:52:17 --> 404 Page Not Found: user/Assets/css
ERROR - 2021-04-13 20:52:17 --> 404 Page Not Found: user/Assets/css
ERROR - 2021-04-13 20:52:17 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:52:17 --> Router Class Initialized
INFO - 2021-04-13 20:52:17 --> Router Class Initialized
INFO - 2021-04-13 20:52:17 --> Output Class Initialized
INFO - 2021-04-13 20:52:17 --> Output Class Initialized
INFO - 2021-04-13 20:52:17 --> Security Class Initialized
INFO - 2021-04-13 20:52:17 --> Security Class Initialized
DEBUG - 2021-04-13 20:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:52:17 --> Input Class Initialized
INFO - 2021-04-13 20:52:17 --> Language Class Initialized
DEBUG - 2021-04-13 20:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:52:17 --> Input Class Initialized
INFO - 2021-04-13 20:52:17 --> Language Class Initialized
ERROR - 2021-04-13 20:52:17 --> 404 Page Not Found: user/Assets/css
ERROR - 2021-04-13 20:52:17 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:52:17 --> Config Class Initialized
INFO - 2021-04-13 20:52:17 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:52:17 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:52:17 --> Utf8 Class Initialized
INFO - 2021-04-13 20:52:17 --> URI Class Initialized
INFO - 2021-04-13 20:52:17 --> Router Class Initialized
INFO - 2021-04-13 20:52:17 --> Config Class Initialized
INFO - 2021-04-13 20:52:17 --> Hooks Class Initialized
INFO - 2021-04-13 20:52:17 --> Output Class Initialized
INFO - 2021-04-13 20:52:17 --> Config Class Initialized
INFO - 2021-04-13 20:52:17 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:52:17 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:52:17 --> Config Class Initialized
INFO - 2021-04-13 20:52:17 --> Utf8 Class Initialized
INFO - 2021-04-13 20:52:17 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:52:17 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:52:17 --> Security Class Initialized
INFO - 2021-04-13 20:52:17 --> URI Class Initialized
INFO - 2021-04-13 20:52:17 --> Utf8 Class Initialized
INFO - 2021-04-13 20:52:17 --> URI Class Initialized
INFO - 2021-04-13 20:52:17 --> Router Class Initialized
DEBUG - 2021-04-13 20:52:17 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:52:17 --> Utf8 Class Initialized
INFO - 2021-04-13 20:52:17 --> Router Class Initialized
INFO - 2021-04-13 20:52:17 --> URI Class Initialized
INFO - 2021-04-13 20:52:17 --> Output Class Initialized
INFO - 2021-04-13 20:52:17 --> Output Class Initialized
INFO - 2021-04-13 20:52:17 --> Router Class Initialized
INFO - 2021-04-13 20:52:17 --> Security Class Initialized
DEBUG - 2021-04-13 20:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:52:17 --> Input Class Initialized
INFO - 2021-04-13 20:52:17 --> Security Class Initialized
DEBUG - 2021-04-13 20:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:52:17 --> Input Class Initialized
INFO - 2021-04-13 20:52:17 --> Output Class Initialized
INFO - 2021-04-13 20:52:17 --> Language Class Initialized
DEBUG - 2021-04-13 20:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:52:17 --> Input Class Initialized
INFO - 2021-04-13 20:52:17 --> Security Class Initialized
INFO - 2021-04-13 20:52:17 --> Language Class Initialized
ERROR - 2021-04-13 20:52:17 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:52:17 --> Language Class Initialized
DEBUG - 2021-04-13 20:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:52:17 --> Input Class Initialized
ERROR - 2021-04-13 20:52:17 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:52:17 --> Language Class Initialized
ERROR - 2021-04-13 20:52:17 --> 404 Page Not Found: user/Assets/js
ERROR - 2021-04-13 20:52:17 --> 404 Page Not Found: user/Assets/img
INFO - 2021-04-13 20:52:17 --> Config Class Initialized
INFO - 2021-04-13 20:52:17 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:52:17 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:52:17 --> Utf8 Class Initialized
INFO - 2021-04-13 20:52:17 --> URI Class Initialized
INFO - 2021-04-13 20:52:17 --> Config Class Initialized
INFO - 2021-04-13 20:52:17 --> Router Class Initialized
INFO - 2021-04-13 20:52:17 --> Hooks Class Initialized
INFO - 2021-04-13 20:52:17 --> Output Class Initialized
DEBUG - 2021-04-13 20:52:17 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:52:17 --> Security Class Initialized
INFO - 2021-04-13 20:52:17 --> Utf8 Class Initialized
DEBUG - 2021-04-13 20:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:52:17 --> Input Class Initialized
INFO - 2021-04-13 20:52:17 --> URI Class Initialized
INFO - 2021-04-13 20:52:17 --> Language Class Initialized
ERROR - 2021-04-13 20:52:17 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:52:17 --> Router Class Initialized
INFO - 2021-04-13 20:52:17 --> Output Class Initialized
INFO - 2021-04-13 20:52:17 --> Security Class Initialized
INFO - 2021-04-13 20:52:17 --> Config Class Initialized
INFO - 2021-04-13 20:52:17 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:52:17 --> Input Class Initialized
INFO - 2021-04-13 20:52:17 --> Language Class Initialized
ERROR - 2021-04-13 20:52:17 --> 404 Page Not Found: user/Assets/img
DEBUG - 2021-04-13 20:52:17 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:52:17 --> Utf8 Class Initialized
INFO - 2021-04-13 20:52:17 --> URI Class Initialized
INFO - 2021-04-13 20:52:17 --> Router Class Initialized
INFO - 2021-04-13 20:52:17 --> Output Class Initialized
INFO - 2021-04-13 20:52:17 --> Security Class Initialized
DEBUG - 2021-04-13 20:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:52:17 --> Input Class Initialized
INFO - 2021-04-13 20:52:17 --> Language Class Initialized
ERROR - 2021-04-13 20:52:17 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:52:17 --> Config Class Initialized
INFO - 2021-04-13 20:52:17 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:52:17 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:52:17 --> Utf8 Class Initialized
INFO - 2021-04-13 20:52:17 --> URI Class Initialized
INFO - 2021-04-13 20:52:17 --> Router Class Initialized
INFO - 2021-04-13 20:52:17 --> Output Class Initialized
INFO - 2021-04-13 20:52:17 --> Security Class Initialized
DEBUG - 2021-04-13 20:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:52:17 --> Input Class Initialized
INFO - 2021-04-13 20:52:17 --> Language Class Initialized
ERROR - 2021-04-13 20:52:17 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:52:17 --> Config Class Initialized
INFO - 2021-04-13 20:52:17 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:52:17 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:52:17 --> Utf8 Class Initialized
INFO - 2021-04-13 20:52:17 --> URI Class Initialized
INFO - 2021-04-13 20:52:17 --> Router Class Initialized
INFO - 2021-04-13 20:52:17 --> Output Class Initialized
INFO - 2021-04-13 20:52:17 --> Security Class Initialized
DEBUG - 2021-04-13 20:52:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:52:17 --> Input Class Initialized
INFO - 2021-04-13 20:52:17 --> Language Class Initialized
ERROR - 2021-04-13 20:52:18 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:52:18 --> Config Class Initialized
INFO - 2021-04-13 20:52:18 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:52:18 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:52:18 --> Utf8 Class Initialized
INFO - 2021-04-13 20:52:18 --> URI Class Initialized
INFO - 2021-04-13 20:52:18 --> Router Class Initialized
INFO - 2021-04-13 20:52:18 --> Output Class Initialized
INFO - 2021-04-13 20:52:18 --> Security Class Initialized
DEBUG - 2021-04-13 20:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:52:18 --> Input Class Initialized
INFO - 2021-04-13 20:52:18 --> Language Class Initialized
ERROR - 2021-04-13 20:52:18 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:52:18 --> Config Class Initialized
INFO - 2021-04-13 20:52:18 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:52:18 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:52:18 --> Utf8 Class Initialized
INFO - 2021-04-13 20:52:18 --> URI Class Initialized
INFO - 2021-04-13 20:52:18 --> Router Class Initialized
INFO - 2021-04-13 20:52:18 --> Output Class Initialized
INFO - 2021-04-13 20:52:18 --> Security Class Initialized
DEBUG - 2021-04-13 20:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:52:18 --> Input Class Initialized
INFO - 2021-04-13 20:52:18 --> Language Class Initialized
ERROR - 2021-04-13 20:52:18 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:52:18 --> Config Class Initialized
INFO - 2021-04-13 20:52:18 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:52:18 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:52:18 --> Utf8 Class Initialized
INFO - 2021-04-13 20:52:18 --> URI Class Initialized
INFO - 2021-04-13 20:52:18 --> Router Class Initialized
INFO - 2021-04-13 20:52:18 --> Output Class Initialized
INFO - 2021-04-13 20:52:18 --> Security Class Initialized
DEBUG - 2021-04-13 20:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:52:18 --> Input Class Initialized
INFO - 2021-04-13 20:52:18 --> Language Class Initialized
ERROR - 2021-04-13 20:52:18 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:52:18 --> Config Class Initialized
INFO - 2021-04-13 20:52:18 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:52:18 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:52:18 --> Utf8 Class Initialized
INFO - 2021-04-13 20:52:18 --> URI Class Initialized
INFO - 2021-04-13 20:52:18 --> Router Class Initialized
INFO - 2021-04-13 20:52:18 --> Output Class Initialized
INFO - 2021-04-13 20:52:18 --> Security Class Initialized
DEBUG - 2021-04-13 20:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:52:18 --> Input Class Initialized
INFO - 2021-04-13 20:52:18 --> Language Class Initialized
ERROR - 2021-04-13 20:52:18 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:52:18 --> Config Class Initialized
INFO - 2021-04-13 20:52:18 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:52:18 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:52:18 --> Utf8 Class Initialized
INFO - 2021-04-13 20:52:18 --> URI Class Initialized
INFO - 2021-04-13 20:52:18 --> Router Class Initialized
INFO - 2021-04-13 20:52:18 --> Output Class Initialized
INFO - 2021-04-13 20:52:18 --> Security Class Initialized
DEBUG - 2021-04-13 20:52:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:52:18 --> Input Class Initialized
INFO - 2021-04-13 20:52:18 --> Language Class Initialized
ERROR - 2021-04-13 20:52:18 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:52:26 --> Config Class Initialized
INFO - 2021-04-13 20:52:26 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:52:26 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:52:26 --> Utf8 Class Initialized
INFO - 2021-04-13 20:52:26 --> URI Class Initialized
DEBUG - 2021-04-13 20:52:26 --> No URI present. Default controller set.
INFO - 2021-04-13 20:52:26 --> Router Class Initialized
INFO - 2021-04-13 20:52:26 --> Output Class Initialized
INFO - 2021-04-13 20:52:26 --> Security Class Initialized
DEBUG - 2021-04-13 20:52:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:52:26 --> Input Class Initialized
INFO - 2021-04-13 20:52:26 --> Language Class Initialized
INFO - 2021-04-13 20:52:26 --> Loader Class Initialized
INFO - 2021-04-13 20:52:26 --> Helper loaded: url_helper
INFO - 2021-04-13 20:52:26 --> Helper loaded: form_helper
INFO - 2021-04-13 20:52:26 --> Helper loaded: common_helper
INFO - 2021-04-13 20:52:26 --> Helper loaded: util_helper
INFO - 2021-04-13 20:52:26 --> Database Driver Class Initialized
ERROR - 2021-04-13 20:52:26 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 20:52:26 --> Unable to connect to the database
DEBUG - 2021-04-13 20:52:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 20:52:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 20:52:26 --> Form Validation Class Initialized
INFO - 2021-04-13 20:52:26 --> Controller Class Initialized
INFO - 2021-04-13 20:52:26 --> Model Class Initialized
INFO - 2021-04-13 20:52:26 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-13 20:52:26 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 20:52:26 --> Final output sent to browser
DEBUG - 2021-04-13 20:52:26 --> Total execution time: 0.0276
INFO - 2021-04-13 20:52:29 --> Config Class Initialized
INFO - 2021-04-13 20:52:29 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:52:29 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:52:29 --> Utf8 Class Initialized
INFO - 2021-04-13 20:52:29 --> URI Class Initialized
INFO - 2021-04-13 20:52:29 --> Router Class Initialized
INFO - 2021-04-13 20:52:29 --> Output Class Initialized
INFO - 2021-04-13 20:52:29 --> Security Class Initialized
DEBUG - 2021-04-13 20:52:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:52:29 --> Input Class Initialized
INFO - 2021-04-13 20:52:29 --> Language Class Initialized
ERROR - 2021-04-13 20:52:29 --> 404 Page Not Found: Logout/index
INFO - 2021-04-13 20:52:31 --> Config Class Initialized
INFO - 2021-04-13 20:52:31 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:52:31 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:52:31 --> Utf8 Class Initialized
INFO - 2021-04-13 20:52:31 --> URI Class Initialized
DEBUG - 2021-04-13 20:52:31 --> No URI present. Default controller set.
INFO - 2021-04-13 20:52:31 --> Router Class Initialized
INFO - 2021-04-13 20:52:31 --> Output Class Initialized
INFO - 2021-04-13 20:52:31 --> Security Class Initialized
DEBUG - 2021-04-13 20:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:52:31 --> Input Class Initialized
INFO - 2021-04-13 20:52:31 --> Language Class Initialized
INFO - 2021-04-13 20:52:31 --> Loader Class Initialized
INFO - 2021-04-13 20:52:31 --> Helper loaded: url_helper
INFO - 2021-04-13 20:52:31 --> Helper loaded: form_helper
INFO - 2021-04-13 20:52:31 --> Helper loaded: common_helper
INFO - 2021-04-13 20:52:31 --> Helper loaded: util_helper
INFO - 2021-04-13 20:52:31 --> Database Driver Class Initialized
ERROR - 2021-04-13 20:52:31 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'FoodTruck'@'localhost' (using password: YES) C:\xampp1\htdocs\FoodTruck\php\system\database\drivers\mysqli\mysqli_driver.php 201
ERROR - 2021-04-13 20:52:31 --> Unable to connect to the database
DEBUG - 2021-04-13 20:52:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 20:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 20:52:31 --> Form Validation Class Initialized
INFO - 2021-04-13 20:52:31 --> Controller Class Initialized
INFO - 2021-04-13 20:52:31 --> Model Class Initialized
INFO - 2021-04-13 20:52:31 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-13 20:52:31 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 20:52:31 --> Final output sent to browser
DEBUG - 2021-04-13 20:52:31 --> Total execution time: 0.0263
INFO - 2021-04-13 20:54:52 --> Config Class Initialized
INFO - 2021-04-13 20:54:52 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:54:52 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:54:52 --> Utf8 Class Initialized
INFO - 2021-04-13 20:54:52 --> URI Class Initialized
DEBUG - 2021-04-13 20:54:52 --> No URI present. Default controller set.
INFO - 2021-04-13 20:54:52 --> Router Class Initialized
INFO - 2021-04-13 20:54:52 --> Output Class Initialized
INFO - 2021-04-13 20:54:52 --> Security Class Initialized
DEBUG - 2021-04-13 20:54:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:54:52 --> Input Class Initialized
INFO - 2021-04-13 20:54:52 --> Language Class Initialized
INFO - 2021-04-13 20:54:52 --> Loader Class Initialized
INFO - 2021-04-13 20:54:52 --> Helper loaded: url_helper
INFO - 2021-04-13 20:54:52 --> Helper loaded: form_helper
INFO - 2021-04-13 20:54:52 --> Helper loaded: common_helper
INFO - 2021-04-13 20:54:52 --> Helper loaded: util_helper
INFO - 2021-04-13 20:54:52 --> Database Driver Class Initialized
DEBUG - 2021-04-13 20:54:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 20:54:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 20:54:52 --> Form Validation Class Initialized
INFO - 2021-04-13 20:54:52 --> Controller Class Initialized
INFO - 2021-04-13 20:54:52 --> Model Class Initialized
INFO - 2021-04-13 20:54:52 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-13 20:54:52 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 20:54:52 --> Final output sent to browser
DEBUG - 2021-04-13 20:54:52 --> Total execution time: 0.0446
INFO - 2021-04-13 20:54:55 --> Config Class Initialized
INFO - 2021-04-13 20:54:55 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:54:55 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:54:55 --> Utf8 Class Initialized
INFO - 2021-04-13 20:54:55 --> URI Class Initialized
INFO - 2021-04-13 20:54:55 --> Router Class Initialized
INFO - 2021-04-13 20:54:55 --> Output Class Initialized
INFO - 2021-04-13 20:54:55 --> Security Class Initialized
DEBUG - 2021-04-13 20:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:54:55 --> Input Class Initialized
INFO - 2021-04-13 20:54:55 --> Language Class Initialized
INFO - 2021-04-13 20:54:55 --> Loader Class Initialized
INFO - 2021-04-13 20:54:55 --> Helper loaded: url_helper
INFO - 2021-04-13 20:54:55 --> Helper loaded: form_helper
INFO - 2021-04-13 20:54:55 --> Helper loaded: common_helper
INFO - 2021-04-13 20:54:55 --> Helper loaded: util_helper
INFO - 2021-04-13 20:54:55 --> Database Driver Class Initialized
DEBUG - 2021-04-13 20:54:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 20:54:55 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 20:54:55 --> Form Validation Class Initialized
INFO - 2021-04-13 20:54:55 --> Controller Class Initialized
INFO - 2021-04-13 20:54:55 --> Model Class Initialized
INFO - 2021-04-13 20:54:55 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 20:54:55 --> Final output sent to browser
DEBUG - 2021-04-13 20:54:55 --> Total execution time: 0.0242
INFO - 2021-04-13 20:54:55 --> Config Class Initialized
INFO - 2021-04-13 20:54:55 --> Config Class Initialized
INFO - 2021-04-13 20:54:55 --> Hooks Class Initialized
INFO - 2021-04-13 20:54:55 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:54:55 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:54:55 --> Utf8 Class Initialized
DEBUG - 2021-04-13 20:54:55 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:54:55 --> URI Class Initialized
INFO - 2021-04-13 20:54:55 --> Utf8 Class Initialized
INFO - 2021-04-13 20:54:55 --> URI Class Initialized
INFO - 2021-04-13 20:54:55 --> Router Class Initialized
INFO - 2021-04-13 20:54:55 --> Router Class Initialized
INFO - 2021-04-13 20:54:55 --> Output Class Initialized
INFO - 2021-04-13 20:54:55 --> Output Class Initialized
INFO - 2021-04-13 20:54:55 --> Security Class Initialized
INFO - 2021-04-13 20:54:55 --> Security Class Initialized
DEBUG - 2021-04-13 20:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:54:55 --> Input Class Initialized
INFO - 2021-04-13 20:54:55 --> Language Class Initialized
DEBUG - 2021-04-13 20:54:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:54:55 --> Input Class Initialized
ERROR - 2021-04-13 20:54:55 --> 404 Page Not Found: Fasset/img
INFO - 2021-04-13 20:54:55 --> Language Class Initialized
ERROR - 2021-04-13 20:54:55 --> 404 Page Not Found: Fasset/img
INFO - 2021-04-13 20:55:08 --> Config Class Initialized
INFO - 2021-04-13 20:55:08 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:55:08 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:55:08 --> Utf8 Class Initialized
INFO - 2021-04-13 20:55:08 --> URI Class Initialized
INFO - 2021-04-13 20:55:08 --> Router Class Initialized
INFO - 2021-04-13 20:55:08 --> Output Class Initialized
INFO - 2021-04-13 20:55:08 --> Security Class Initialized
DEBUG - 2021-04-13 20:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:55:08 --> Input Class Initialized
INFO - 2021-04-13 20:55:08 --> Language Class Initialized
INFO - 2021-04-13 20:55:08 --> Loader Class Initialized
INFO - 2021-04-13 20:55:08 --> Helper loaded: url_helper
INFO - 2021-04-13 20:55:08 --> Helper loaded: form_helper
INFO - 2021-04-13 20:55:08 --> Helper loaded: common_helper
INFO - 2021-04-13 20:55:08 --> Helper loaded: util_helper
INFO - 2021-04-13 20:55:08 --> Database Driver Class Initialized
DEBUG - 2021-04-13 20:55:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 20:55:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 20:55:08 --> Form Validation Class Initialized
INFO - 2021-04-13 20:55:08 --> Controller Class Initialized
INFO - 2021-04-13 20:55:08 --> Model Class Initialized
INFO - 2021-04-13 20:55:08 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-04-13 20:55:08 --> Config Class Initialized
INFO - 2021-04-13 20:55:08 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:55:08 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:55:08 --> Utf8 Class Initialized
INFO - 2021-04-13 20:55:08 --> URI Class Initialized
INFO - 2021-04-13 20:55:08 --> Router Class Initialized
INFO - 2021-04-13 20:55:08 --> Output Class Initialized
INFO - 2021-04-13 20:55:08 --> Security Class Initialized
DEBUG - 2021-04-13 20:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:55:08 --> Input Class Initialized
INFO - 2021-04-13 20:55:08 --> Language Class Initialized
INFO - 2021-04-13 20:55:08 --> Loader Class Initialized
INFO - 2021-04-13 20:55:08 --> Helper loaded: url_helper
INFO - 2021-04-13 20:55:08 --> Helper loaded: form_helper
INFO - 2021-04-13 20:55:08 --> Helper loaded: common_helper
INFO - 2021-04-13 20:55:08 --> Helper loaded: util_helper
INFO - 2021-04-13 20:55:08 --> Database Driver Class Initialized
DEBUG - 2021-04-13 20:55:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 20:55:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 20:55:08 --> Form Validation Class Initialized
INFO - 2021-04-13 20:55:08 --> Controller Class Initialized
INFO - 2021-04-13 20:55:08 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-13 20:55:08 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 20:55:08 --> Final output sent to browser
DEBUG - 2021-04-13 20:55:08 --> Total execution time: 0.0254
INFO - 2021-04-13 20:55:08 --> Config Class Initialized
INFO - 2021-04-13 20:55:08 --> Hooks Class Initialized
INFO - 2021-04-13 20:55:08 --> Config Class Initialized
INFO - 2021-04-13 20:55:08 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:55:08 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:55:08 --> Utf8 Class Initialized
INFO - 2021-04-13 20:55:08 --> Config Class Initialized
INFO - 2021-04-13 20:55:08 --> URI Class Initialized
INFO - 2021-04-13 20:55:08 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:55:08 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:55:08 --> Config Class Initialized
INFO - 2021-04-13 20:55:08 --> Utf8 Class Initialized
INFO - 2021-04-13 20:55:08 --> Router Class Initialized
INFO - 2021-04-13 20:55:08 --> Hooks Class Initialized
INFO - 2021-04-13 20:55:08 --> URI Class Initialized
DEBUG - 2021-04-13 20:55:08 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:55:08 --> Config Class Initialized
INFO - 2021-04-13 20:55:08 --> Output Class Initialized
INFO - 2021-04-13 20:55:08 --> Utf8 Class Initialized
INFO - 2021-04-13 20:55:08 --> Hooks Class Initialized
INFO - 2021-04-13 20:55:08 --> Router Class Initialized
DEBUG - 2021-04-13 20:55:08 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:55:08 --> URI Class Initialized
INFO - 2021-04-13 20:55:08 --> Security Class Initialized
INFO - 2021-04-13 20:55:08 --> Utf8 Class Initialized
INFO - 2021-04-13 20:55:08 --> Output Class Initialized
DEBUG - 2021-04-13 20:55:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 20:55:08 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:55:08 --> URI Class Initialized
INFO - 2021-04-13 20:55:08 --> Router Class Initialized
INFO - 2021-04-13 20:55:08 --> Input Class Initialized
INFO - 2021-04-13 20:55:08 --> Utf8 Class Initialized
INFO - 2021-04-13 20:55:08 --> Security Class Initialized
INFO - 2021-04-13 20:55:08 --> Language Class Initialized
INFO - 2021-04-13 20:55:08 --> Router Class Initialized
INFO - 2021-04-13 20:55:08 --> Output Class Initialized
INFO - 2021-04-13 20:55:08 --> URI Class Initialized
DEBUG - 2021-04-13 20:55:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 20:55:08 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:55:08 --> Input Class Initialized
INFO - 2021-04-13 20:55:08 --> Output Class Initialized
INFO - 2021-04-13 20:55:08 --> Security Class Initialized
INFO - 2021-04-13 20:55:08 --> Router Class Initialized
INFO - 2021-04-13 20:55:08 --> Language Class Initialized
INFO - 2021-04-13 20:55:08 --> Security Class Initialized
DEBUG - 2021-04-13 20:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:55:08 --> Input Class Initialized
INFO - 2021-04-13 20:55:08 --> Language Class Initialized
DEBUG - 2021-04-13 20:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:55:08 --> Output Class Initialized
INFO - 2021-04-13 20:55:08 --> Input Class Initialized
ERROR - 2021-04-13 20:55:08 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:55:08 --> Language Class Initialized
ERROR - 2021-04-13 20:55:08 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:55:08 --> Security Class Initialized
ERROR - 2021-04-13 20:55:08 --> 404 Page Not Found: user/Assets/css
DEBUG - 2021-04-13 20:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:55:08 --> Input Class Initialized
INFO - 2021-04-13 20:55:08 --> Language Class Initialized
ERROR - 2021-04-13 20:55:08 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:55:08 --> Config Class Initialized
INFO - 2021-04-13 20:55:08 --> Hooks Class Initialized
INFO - 2021-04-13 20:55:08 --> Config Class Initialized
INFO - 2021-04-13 20:55:08 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:55:08 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:55:08 --> Utf8 Class Initialized
INFO - 2021-04-13 20:55:08 --> Config Class Initialized
DEBUG - 2021-04-13 20:55:08 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:55:08 --> Utf8 Class Initialized
INFO - 2021-04-13 20:55:08 --> URI Class Initialized
INFO - 2021-04-13 20:55:08 --> URI Class Initialized
INFO - 2021-04-13 20:55:08 --> Router Class Initialized
INFO - 2021-04-13 20:55:08 --> Router Class Initialized
INFO - 2021-04-13 20:55:08 --> Output Class Initialized
INFO - 2021-04-13 20:55:08 --> Security Class Initialized
INFO - 2021-04-13 20:55:08 --> Output Class Initialized
DEBUG - 2021-04-13 20:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:55:08 --> Input Class Initialized
INFO - 2021-04-13 20:55:08 --> Security Class Initialized
INFO - 2021-04-13 20:55:08 --> Language Class Initialized
DEBUG - 2021-04-13 20:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:55:08 --> Input Class Initialized
ERROR - 2021-04-13 20:55:08 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:55:08 --> Language Class Initialized
INFO - 2021-04-13 20:55:08 --> Hooks Class Initialized
ERROR - 2021-04-13 20:55:08 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:55:08 --> Config Class Initialized
INFO - 2021-04-13 20:55:08 --> Config Class Initialized
INFO - 2021-04-13 20:55:08 --> Hooks Class Initialized
INFO - 2021-04-13 20:55:08 --> Hooks Class Initialized
INFO - 2021-04-13 20:55:08 --> Config Class Initialized
INFO - 2021-04-13 20:55:08 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:55:08 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:55:08 --> Utf8 Class Initialized
DEBUG - 2021-04-13 20:55:08 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:55:08 --> Utf8 Class Initialized
DEBUG - 2021-04-13 20:55:08 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:55:08 --> Utf8 Class Initialized
INFO - 2021-04-13 20:55:08 --> URI Class Initialized
INFO - 2021-04-13 20:55:08 --> URI Class Initialized
DEBUG - 2021-04-13 20:55:08 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:55:08 --> URI Class Initialized
INFO - 2021-04-13 20:55:08 --> Utf8 Class Initialized
INFO - 2021-04-13 20:55:08 --> Router Class Initialized
INFO - 2021-04-13 20:55:08 --> Router Class Initialized
INFO - 2021-04-13 20:55:08 --> Router Class Initialized
INFO - 2021-04-13 20:55:08 --> URI Class Initialized
INFO - 2021-04-13 20:55:08 --> Output Class Initialized
INFO - 2021-04-13 20:55:08 --> Output Class Initialized
INFO - 2021-04-13 20:55:08 --> Router Class Initialized
INFO - 2021-04-13 20:55:08 --> Output Class Initialized
INFO - 2021-04-13 20:55:08 --> Security Class Initialized
INFO - 2021-04-13 20:55:08 --> Security Class Initialized
INFO - 2021-04-13 20:55:08 --> Output Class Initialized
INFO - 2021-04-13 20:55:08 --> Security Class Initialized
DEBUG - 2021-04-13 20:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:55:08 --> Input Class Initialized
DEBUG - 2021-04-13 20:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:55:08 --> Security Class Initialized
INFO - 2021-04-13 20:55:08 --> Input Class Initialized
INFO - 2021-04-13 20:55:08 --> Language Class Initialized
DEBUG - 2021-04-13 20:55:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:55:08 --> Input Class Initialized
INFO - 2021-04-13 20:55:08 --> Language Class Initialized
INFO - 2021-04-13 20:55:08 --> Language Class Initialized
DEBUG - 2021-04-13 20:55:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 20:55:08 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:55:08 --> Input Class Initialized
INFO - 2021-04-13 20:55:08 --> Language Class Initialized
ERROR - 2021-04-13 20:55:08 --> 404 Page Not Found: user/Assets/img
ERROR - 2021-04-13 20:55:08 --> 404 Page Not Found: user/Assets/js
ERROR - 2021-04-13 20:55:08 --> 404 Page Not Found: user/Assets/img
INFO - 2021-04-13 20:55:09 --> Config Class Initialized
INFO - 2021-04-13 20:55:09 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:55:09 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:55:09 --> Utf8 Class Initialized
INFO - 2021-04-13 20:55:09 --> URI Class Initialized
INFO - 2021-04-13 20:55:09 --> Router Class Initialized
INFO - 2021-04-13 20:55:09 --> Output Class Initialized
INFO - 2021-04-13 20:55:09 --> Security Class Initialized
DEBUG - 2021-04-13 20:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:55:09 --> Input Class Initialized
INFO - 2021-04-13 20:55:09 --> Language Class Initialized
ERROR - 2021-04-13 20:55:09 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:55:09 --> Config Class Initialized
INFO - 2021-04-13 20:55:09 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:55:09 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:55:09 --> Utf8 Class Initialized
INFO - 2021-04-13 20:55:09 --> URI Class Initialized
INFO - 2021-04-13 20:55:09 --> Router Class Initialized
INFO - 2021-04-13 20:55:09 --> Output Class Initialized
INFO - 2021-04-13 20:55:09 --> Security Class Initialized
DEBUG - 2021-04-13 20:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:55:09 --> Input Class Initialized
INFO - 2021-04-13 20:55:09 --> Language Class Initialized
ERROR - 2021-04-13 20:55:09 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:55:09 --> Config Class Initialized
INFO - 2021-04-13 20:55:09 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:55:09 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:55:09 --> Utf8 Class Initialized
INFO - 2021-04-13 20:55:09 --> URI Class Initialized
INFO - 2021-04-13 20:55:09 --> Router Class Initialized
INFO - 2021-04-13 20:55:09 --> Output Class Initialized
INFO - 2021-04-13 20:55:09 --> Security Class Initialized
DEBUG - 2021-04-13 20:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:55:09 --> Input Class Initialized
INFO - 2021-04-13 20:55:09 --> Language Class Initialized
ERROR - 2021-04-13 20:55:09 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:55:09 --> Config Class Initialized
INFO - 2021-04-13 20:55:09 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:55:09 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:55:09 --> Utf8 Class Initialized
INFO - 2021-04-13 20:55:09 --> URI Class Initialized
INFO - 2021-04-13 20:55:09 --> Router Class Initialized
INFO - 2021-04-13 20:55:09 --> Output Class Initialized
INFO - 2021-04-13 20:55:09 --> Security Class Initialized
DEBUG - 2021-04-13 20:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:55:09 --> Input Class Initialized
INFO - 2021-04-13 20:55:09 --> Language Class Initialized
ERROR - 2021-04-13 20:55:09 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:55:09 --> Config Class Initialized
INFO - 2021-04-13 20:55:09 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:55:09 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:55:09 --> Utf8 Class Initialized
INFO - 2021-04-13 20:55:09 --> URI Class Initialized
INFO - 2021-04-13 20:55:09 --> Router Class Initialized
INFO - 2021-04-13 20:55:09 --> Output Class Initialized
INFO - 2021-04-13 20:55:09 --> Security Class Initialized
DEBUG - 2021-04-13 20:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:55:09 --> Input Class Initialized
INFO - 2021-04-13 20:55:09 --> Language Class Initialized
ERROR - 2021-04-13 20:55:09 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 20:55:09 --> Config Class Initialized
INFO - 2021-04-13 20:55:09 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:55:09 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:55:09 --> Utf8 Class Initialized
INFO - 2021-04-13 20:55:09 --> URI Class Initialized
INFO - 2021-04-13 20:55:09 --> Router Class Initialized
INFO - 2021-04-13 20:55:09 --> Output Class Initialized
INFO - 2021-04-13 20:55:09 --> Security Class Initialized
DEBUG - 2021-04-13 20:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:55:09 --> Input Class Initialized
INFO - 2021-04-13 20:55:09 --> Language Class Initialized
ERROR - 2021-04-13 20:55:09 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:55:09 --> Config Class Initialized
INFO - 2021-04-13 20:55:09 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:55:09 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:55:09 --> Utf8 Class Initialized
INFO - 2021-04-13 20:55:09 --> URI Class Initialized
INFO - 2021-04-13 20:55:09 --> Router Class Initialized
INFO - 2021-04-13 20:55:09 --> Output Class Initialized
INFO - 2021-04-13 20:55:09 --> Security Class Initialized
DEBUG - 2021-04-13 20:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:55:09 --> Input Class Initialized
INFO - 2021-04-13 20:55:09 --> Language Class Initialized
ERROR - 2021-04-13 20:55:09 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:55:09 --> Config Class Initialized
INFO - 2021-04-13 20:55:09 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:55:09 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:55:09 --> Utf8 Class Initialized
INFO - 2021-04-13 20:55:09 --> URI Class Initialized
INFO - 2021-04-13 20:55:09 --> Router Class Initialized
INFO - 2021-04-13 20:55:09 --> Output Class Initialized
INFO - 2021-04-13 20:55:09 --> Security Class Initialized
DEBUG - 2021-04-13 20:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:55:09 --> Input Class Initialized
INFO - 2021-04-13 20:55:09 --> Language Class Initialized
ERROR - 2021-04-13 20:55:09 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 20:55:09 --> Config Class Initialized
INFO - 2021-04-13 20:55:09 --> Hooks Class Initialized
DEBUG - 2021-04-13 20:55:09 --> UTF-8 Support Enabled
INFO - 2021-04-13 20:55:09 --> Utf8 Class Initialized
INFO - 2021-04-13 20:55:09 --> URI Class Initialized
INFO - 2021-04-13 20:55:09 --> Router Class Initialized
INFO - 2021-04-13 20:55:09 --> Output Class Initialized
INFO - 2021-04-13 20:55:09 --> Security Class Initialized
DEBUG - 2021-04-13 20:55:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 20:55:09 --> Input Class Initialized
INFO - 2021-04-13 20:55:09 --> Language Class Initialized
ERROR - 2021-04-13 20:55:09 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 21:00:03 --> Config Class Initialized
INFO - 2021-04-13 21:00:03 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:00:03 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:00:03 --> Utf8 Class Initialized
INFO - 2021-04-13 21:00:03 --> URI Class Initialized
INFO - 2021-04-13 21:00:03 --> Router Class Initialized
INFO - 2021-04-13 21:00:03 --> Output Class Initialized
INFO - 2021-04-13 21:00:03 --> Security Class Initialized
DEBUG - 2021-04-13 21:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:00:03 --> Input Class Initialized
INFO - 2021-04-13 21:00:03 --> Language Class Initialized
INFO - 2021-04-13 21:00:03 --> Loader Class Initialized
INFO - 2021-04-13 21:00:03 --> Helper loaded: url_helper
INFO - 2021-04-13 21:00:03 --> Helper loaded: form_helper
INFO - 2021-04-13 21:00:03 --> Helper loaded: common_helper
INFO - 2021-04-13 21:00:03 --> Helper loaded: util_helper
INFO - 2021-04-13 21:00:03 --> Database Driver Class Initialized
DEBUG - 2021-04-13 21:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 21:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 21:00:03 --> Form Validation Class Initialized
INFO - 2021-04-13 21:00:03 --> Controller Class Initialized
INFO - 2021-04-13 21:00:03 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-13 21:00:03 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 21:00:03 --> Final output sent to browser
DEBUG - 2021-04-13 21:00:03 --> Total execution time: 0.0402
INFO - 2021-04-13 21:00:03 --> Config Class Initialized
INFO - 2021-04-13 21:00:03 --> Hooks Class Initialized
INFO - 2021-04-13 21:00:03 --> Config Class Initialized
INFO - 2021-04-13 21:00:03 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:00:03 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:00:03 --> Utf8 Class Initialized
INFO - 2021-04-13 21:00:03 --> URI Class Initialized
DEBUG - 2021-04-13 21:00:03 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:00:03 --> Utf8 Class Initialized
INFO - 2021-04-13 21:00:03 --> Router Class Initialized
INFO - 2021-04-13 21:00:03 --> URI Class Initialized
INFO - 2021-04-13 21:00:03 --> Output Class Initialized
INFO - 2021-04-13 21:00:03 --> Router Class Initialized
INFO - 2021-04-13 21:00:03 --> Security Class Initialized
INFO - 2021-04-13 21:00:03 --> Output Class Initialized
DEBUG - 2021-04-13 21:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:00:03 --> Config Class Initialized
INFO - 2021-04-13 21:00:03 --> Input Class Initialized
INFO - 2021-04-13 21:00:03 --> Hooks Class Initialized
INFO - 2021-04-13 21:00:03 --> Language Class Initialized
INFO - 2021-04-13 21:00:03 --> Security Class Initialized
DEBUG - 2021-04-13 21:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:00:03 --> Input Class Initialized
ERROR - 2021-04-13 21:00:03 --> 404 Page Not Found: user/Assets/css
DEBUG - 2021-04-13 21:00:03 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:00:03 --> Utf8 Class Initialized
INFO - 2021-04-13 21:00:03 --> Language Class Initialized
INFO - 2021-04-13 21:00:03 --> URI Class Initialized
ERROR - 2021-04-13 21:00:03 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 21:00:03 --> Router Class Initialized
INFO - 2021-04-13 21:00:03 --> Output Class Initialized
INFO - 2021-04-13 21:00:03 --> Security Class Initialized
DEBUG - 2021-04-13 21:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:00:03 --> Input Class Initialized
INFO - 2021-04-13 21:00:03 --> Language Class Initialized
ERROR - 2021-04-13 21:00:03 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 21:00:03 --> Config Class Initialized
INFO - 2021-04-13 21:00:03 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:00:03 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:00:03 --> Utf8 Class Initialized
INFO - 2021-04-13 21:00:03 --> URI Class Initialized
INFO - 2021-04-13 21:00:03 --> Config Class Initialized
INFO - 2021-04-13 21:00:03 --> Hooks Class Initialized
INFO - 2021-04-13 21:00:03 --> Router Class Initialized
INFO - 2021-04-13 21:00:03 --> Output Class Initialized
DEBUG - 2021-04-13 21:00:03 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:00:03 --> Config Class Initialized
INFO - 2021-04-13 21:00:03 --> Utf8 Class Initialized
INFO - 2021-04-13 21:00:03 --> Hooks Class Initialized
INFO - 2021-04-13 21:00:03 --> Security Class Initialized
INFO - 2021-04-13 21:00:03 --> URI Class Initialized
DEBUG - 2021-04-13 21:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 21:00:03 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:00:03 --> Input Class Initialized
INFO - 2021-04-13 21:00:03 --> Router Class Initialized
INFO - 2021-04-13 21:00:03 --> Utf8 Class Initialized
INFO - 2021-04-13 21:00:03 --> Language Class Initialized
INFO - 2021-04-13 21:00:03 --> URI Class Initialized
INFO - 2021-04-13 21:00:03 --> Output Class Initialized
ERROR - 2021-04-13 21:00:03 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 21:00:03 --> Router Class Initialized
INFO - 2021-04-13 21:00:03 --> Security Class Initialized
INFO - 2021-04-13 21:00:03 --> Output Class Initialized
DEBUG - 2021-04-13 21:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:00:03 --> Input Class Initialized
INFO - 2021-04-13 21:00:03 --> Language Class Initialized
INFO - 2021-04-13 21:00:03 --> Config Class Initialized
INFO - 2021-04-13 21:00:03 --> Security Class Initialized
INFO - 2021-04-13 21:00:03 --> Hooks Class Initialized
ERROR - 2021-04-13 21:00:03 --> 404 Page Not Found: user/Assets/css
DEBUG - 2021-04-13 21:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:00:03 --> Input Class Initialized
INFO - 2021-04-13 21:00:03 --> Language Class Initialized
DEBUG - 2021-04-13 21:00:03 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:00:03 --> Utf8 Class Initialized
INFO - 2021-04-13 21:00:03 --> URI Class Initialized
INFO - 2021-04-13 21:00:03 --> Router Class Initialized
ERROR - 2021-04-13 21:00:03 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 21:00:03 --> Output Class Initialized
INFO - 2021-04-13 21:00:03 --> Config Class Initialized
INFO - 2021-04-13 21:00:03 --> Hooks Class Initialized
INFO - 2021-04-13 21:00:03 --> Security Class Initialized
DEBUG - 2021-04-13 21:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:00:03 --> Input Class Initialized
DEBUG - 2021-04-13 21:00:03 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:00:03 --> Config Class Initialized
INFO - 2021-04-13 21:00:03 --> Hooks Class Initialized
INFO - 2021-04-13 21:00:03 --> Language Class Initialized
INFO - 2021-04-13 21:00:03 --> Utf8 Class Initialized
INFO - 2021-04-13 21:00:03 --> Config Class Initialized
INFO - 2021-04-13 21:00:03 --> Hooks Class Initialized
INFO - 2021-04-13 21:00:03 --> URI Class Initialized
ERROR - 2021-04-13 21:00:03 --> 404 Page Not Found: user/Assets/css
DEBUG - 2021-04-13 21:00:03 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:00:03 --> Utf8 Class Initialized
INFO - 2021-04-13 21:00:03 --> URI Class Initialized
DEBUG - 2021-04-13 21:00:03 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:00:03 --> Utf8 Class Initialized
INFO - 2021-04-13 21:00:03 --> Router Class Initialized
INFO - 2021-04-13 21:00:03 --> URI Class Initialized
INFO - 2021-04-13 21:00:03 --> Output Class Initialized
INFO - 2021-04-13 21:00:03 --> Router Class Initialized
INFO - 2021-04-13 21:00:03 --> Security Class Initialized
INFO - 2021-04-13 21:00:03 --> Output Class Initialized
DEBUG - 2021-04-13 21:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:00:03 --> Input Class Initialized
INFO - 2021-04-13 21:00:03 --> Config Class Initialized
INFO - 2021-04-13 21:00:03 --> Language Class Initialized
INFO - 2021-04-13 21:00:03 --> Hooks Class Initialized
ERROR - 2021-04-13 21:00:03 --> 404 Page Not Found: user/Assets/img
INFO - 2021-04-13 21:00:03 --> Security Class Initialized
INFO - 2021-04-13 21:00:03 --> Config Class Initialized
INFO - 2021-04-13 21:00:03 --> Hooks Class Initialized
INFO - 2021-04-13 21:00:03 --> Router Class Initialized
DEBUG - 2021-04-13 21:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:00:03 --> Input Class Initialized
DEBUG - 2021-04-13 21:00:03 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:00:03 --> Utf8 Class Initialized
DEBUG - 2021-04-13 21:00:03 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:00:03 --> Language Class Initialized
INFO - 2021-04-13 21:00:03 --> Utf8 Class Initialized
INFO - 2021-04-13 21:00:03 --> URI Class Initialized
INFO - 2021-04-13 21:00:03 --> URI Class Initialized
ERROR - 2021-04-13 21:00:03 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 21:00:03 --> Router Class Initialized
INFO - 2021-04-13 21:00:03 --> Router Class Initialized
INFO - 2021-04-13 21:00:03 --> Output Class Initialized
INFO - 2021-04-13 21:00:03 --> Output Class Initialized
INFO - 2021-04-13 21:00:03 --> Security Class Initialized
INFO - 2021-04-13 21:00:03 --> Output Class Initialized
DEBUG - 2021-04-13 21:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:00:03 --> Security Class Initialized
INFO - 2021-04-13 21:00:03 --> Input Class Initialized
INFO - 2021-04-13 21:00:03 --> Security Class Initialized
INFO - 2021-04-13 21:00:03 --> Language Class Initialized
DEBUG - 2021-04-13 21:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 21:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:00:03 --> Input Class Initialized
INFO - 2021-04-13 21:00:03 --> Input Class Initialized
ERROR - 2021-04-13 21:00:03 --> 404 Page Not Found: user/Assets/img
INFO - 2021-04-13 21:00:03 --> Language Class Initialized
INFO - 2021-04-13 21:00:03 --> Language Class Initialized
ERROR - 2021-04-13 21:00:03 --> 404 Page Not Found: user/Assets/js
ERROR - 2021-04-13 21:00:03 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 21:00:03 --> Config Class Initialized
INFO - 2021-04-13 21:00:03 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:00:03 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:00:03 --> Utf8 Class Initialized
INFO - 2021-04-13 21:00:03 --> URI Class Initialized
INFO - 2021-04-13 21:00:03 --> Router Class Initialized
INFO - 2021-04-13 21:00:03 --> Output Class Initialized
INFO - 2021-04-13 21:00:03 --> Security Class Initialized
DEBUG - 2021-04-13 21:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:00:03 --> Input Class Initialized
INFO - 2021-04-13 21:00:03 --> Language Class Initialized
ERROR - 2021-04-13 21:00:03 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 21:00:03 --> Config Class Initialized
INFO - 2021-04-13 21:00:03 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:00:03 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:00:03 --> Utf8 Class Initialized
INFO - 2021-04-13 21:00:03 --> URI Class Initialized
INFO - 2021-04-13 21:00:03 --> Router Class Initialized
INFO - 2021-04-13 21:00:03 --> Output Class Initialized
INFO - 2021-04-13 21:00:03 --> Security Class Initialized
DEBUG - 2021-04-13 21:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:00:03 --> Input Class Initialized
INFO - 2021-04-13 21:00:03 --> Language Class Initialized
ERROR - 2021-04-13 21:00:03 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 21:00:03 --> Config Class Initialized
INFO - 2021-04-13 21:00:03 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:00:03 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:00:03 --> Utf8 Class Initialized
INFO - 2021-04-13 21:00:03 --> URI Class Initialized
INFO - 2021-04-13 21:00:03 --> Router Class Initialized
INFO - 2021-04-13 21:00:03 --> Output Class Initialized
INFO - 2021-04-13 21:00:03 --> Security Class Initialized
DEBUG - 2021-04-13 21:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:00:03 --> Input Class Initialized
INFO - 2021-04-13 21:00:03 --> Language Class Initialized
ERROR - 2021-04-13 21:00:03 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 21:00:03 --> Config Class Initialized
INFO - 2021-04-13 21:00:03 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:00:03 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:00:03 --> Utf8 Class Initialized
INFO - 2021-04-13 21:00:03 --> URI Class Initialized
INFO - 2021-04-13 21:00:03 --> Router Class Initialized
INFO - 2021-04-13 21:00:03 --> Output Class Initialized
INFO - 2021-04-13 21:00:03 --> Security Class Initialized
DEBUG - 2021-04-13 21:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:00:03 --> Input Class Initialized
INFO - 2021-04-13 21:00:03 --> Language Class Initialized
ERROR - 2021-04-13 21:00:03 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 21:00:03 --> Config Class Initialized
INFO - 2021-04-13 21:00:03 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:00:03 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:00:03 --> Utf8 Class Initialized
INFO - 2021-04-13 21:00:03 --> URI Class Initialized
INFO - 2021-04-13 21:00:03 --> Router Class Initialized
INFO - 2021-04-13 21:00:03 --> Output Class Initialized
INFO - 2021-04-13 21:00:03 --> Security Class Initialized
DEBUG - 2021-04-13 21:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:00:03 --> Input Class Initialized
INFO - 2021-04-13 21:00:03 --> Language Class Initialized
ERROR - 2021-04-13 21:00:03 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 21:00:03 --> Config Class Initialized
INFO - 2021-04-13 21:00:03 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:00:03 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:00:03 --> Utf8 Class Initialized
INFO - 2021-04-13 21:00:03 --> URI Class Initialized
INFO - 2021-04-13 21:00:03 --> Router Class Initialized
INFO - 2021-04-13 21:00:03 --> Output Class Initialized
INFO - 2021-04-13 21:00:03 --> Security Class Initialized
DEBUG - 2021-04-13 21:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:00:03 --> Input Class Initialized
INFO - 2021-04-13 21:00:03 --> Language Class Initialized
ERROR - 2021-04-13 21:00:03 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 21:00:07 --> Config Class Initialized
INFO - 2021-04-13 21:00:07 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:00:07 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:00:07 --> Utf8 Class Initialized
INFO - 2021-04-13 21:00:07 --> URI Class Initialized
INFO - 2021-04-13 21:00:07 --> Router Class Initialized
INFO - 2021-04-13 21:00:07 --> Output Class Initialized
INFO - 2021-04-13 21:00:07 --> Security Class Initialized
DEBUG - 2021-04-13 21:00:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:00:07 --> Input Class Initialized
INFO - 2021-04-13 21:00:07 --> Language Class Initialized
ERROR - 2021-04-13 21:00:07 --> 404 Page Not Found: Logout/index
INFO - 2021-04-13 21:00:08 --> Config Class Initialized
INFO - 2021-04-13 21:00:08 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:00:08 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:00:08 --> Utf8 Class Initialized
INFO - 2021-04-13 21:00:08 --> URI Class Initialized
INFO - 2021-04-13 21:00:08 --> Router Class Initialized
INFO - 2021-04-13 21:00:08 --> Output Class Initialized
INFO - 2021-04-13 21:00:08 --> Security Class Initialized
DEBUG - 2021-04-13 21:00:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:00:08 --> Input Class Initialized
INFO - 2021-04-13 21:00:08 --> Language Class Initialized
INFO - 2021-04-13 21:00:08 --> Loader Class Initialized
INFO - 2021-04-13 21:00:08 --> Helper loaded: url_helper
INFO - 2021-04-13 21:00:08 --> Helper loaded: form_helper
INFO - 2021-04-13 21:00:08 --> Helper loaded: common_helper
INFO - 2021-04-13 21:00:08 --> Helper loaded: util_helper
INFO - 2021-04-13 21:00:08 --> Database Driver Class Initialized
DEBUG - 2021-04-13 21:00:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 21:00:08 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 21:00:08 --> Form Validation Class Initialized
INFO - 2021-04-13 21:00:08 --> Controller Class Initialized
INFO - 2021-04-13 21:00:08 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-13 21:00:08 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 21:00:08 --> Final output sent to browser
DEBUG - 2021-04-13 21:00:08 --> Total execution time: 0.0342
INFO - 2021-04-13 21:07:10 --> Config Class Initialized
INFO - 2021-04-13 21:07:10 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:07:10 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:07:10 --> Utf8 Class Initialized
INFO - 2021-04-13 21:07:10 --> URI Class Initialized
INFO - 2021-04-13 21:07:10 --> Router Class Initialized
INFO - 2021-04-13 21:07:10 --> Output Class Initialized
INFO - 2021-04-13 21:07:10 --> Security Class Initialized
DEBUG - 2021-04-13 21:07:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:07:10 --> Input Class Initialized
INFO - 2021-04-13 21:07:10 --> Language Class Initialized
ERROR - 2021-04-13 21:07:10 --> Severity: error --> Exception: syntax error, unexpected 'redirect' (T_STRING) C:\xampp1\htdocs\FoodTruck\php\application\controllers\user\Dashboard.php 40
INFO - 2021-04-13 21:07:13 --> Config Class Initialized
INFO - 2021-04-13 21:07:13 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:07:13 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:07:13 --> Utf8 Class Initialized
INFO - 2021-04-13 21:07:13 --> URI Class Initialized
INFO - 2021-04-13 21:07:13 --> Router Class Initialized
INFO - 2021-04-13 21:07:13 --> Output Class Initialized
INFO - 2021-04-13 21:07:13 --> Security Class Initialized
DEBUG - 2021-04-13 21:07:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:07:13 --> Input Class Initialized
INFO - 2021-04-13 21:07:13 --> Language Class Initialized
ERROR - 2021-04-13 21:07:13 --> Severity: error --> Exception: syntax error, unexpected 'redirect' (T_STRING) C:\xampp1\htdocs\FoodTruck\php\application\controllers\user\Dashboard.php 40
INFO - 2021-04-13 21:07:15 --> Config Class Initialized
INFO - 2021-04-13 21:07:15 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:07:15 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:07:15 --> Utf8 Class Initialized
INFO - 2021-04-13 21:07:15 --> URI Class Initialized
INFO - 2021-04-13 21:07:15 --> Router Class Initialized
INFO - 2021-04-13 21:07:15 --> Output Class Initialized
INFO - 2021-04-13 21:07:15 --> Security Class Initialized
DEBUG - 2021-04-13 21:07:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:07:15 --> Input Class Initialized
INFO - 2021-04-13 21:07:15 --> Language Class Initialized
INFO - 2021-04-13 21:07:15 --> Loader Class Initialized
INFO - 2021-04-13 21:07:15 --> Helper loaded: url_helper
INFO - 2021-04-13 21:07:15 --> Helper loaded: form_helper
INFO - 2021-04-13 21:07:15 --> Helper loaded: common_helper
INFO - 2021-04-13 21:07:15 --> Helper loaded: util_helper
INFO - 2021-04-13 21:07:15 --> Database Driver Class Initialized
DEBUG - 2021-04-13 21:07:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 21:07:15 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 21:07:15 --> Form Validation Class Initialized
INFO - 2021-04-13 21:07:15 --> Controller Class Initialized
INFO - 2021-04-13 21:07:15 --> Model Class Initialized
INFO - 2021-04-13 21:07:15 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 21:07:15 --> Final output sent to browser
DEBUG - 2021-04-13 21:07:15 --> Total execution time: 0.0394
INFO - 2021-04-13 21:07:19 --> Config Class Initialized
INFO - 2021-04-13 21:07:19 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:07:19 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:07:19 --> Utf8 Class Initialized
INFO - 2021-04-13 21:07:19 --> URI Class Initialized
INFO - 2021-04-13 21:07:19 --> Router Class Initialized
INFO - 2021-04-13 21:07:19 --> Output Class Initialized
INFO - 2021-04-13 21:07:19 --> Security Class Initialized
DEBUG - 2021-04-13 21:07:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:07:19 --> Input Class Initialized
INFO - 2021-04-13 21:07:19 --> Language Class Initialized
ERROR - 2021-04-13 21:07:19 --> Severity: error --> Exception: syntax error, unexpected 'redirect' (T_STRING) C:\xampp1\htdocs\FoodTruck\php\application\controllers\user\Dashboard.php 40
INFO - 2021-04-13 21:07:22 --> Config Class Initialized
INFO - 2021-04-13 21:07:22 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:07:22 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:07:22 --> Utf8 Class Initialized
INFO - 2021-04-13 21:07:22 --> URI Class Initialized
INFO - 2021-04-13 21:07:22 --> Router Class Initialized
INFO - 2021-04-13 21:07:22 --> Output Class Initialized
INFO - 2021-04-13 21:07:22 --> Security Class Initialized
DEBUG - 2021-04-13 21:07:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:07:22 --> Input Class Initialized
INFO - 2021-04-13 21:07:22 --> Language Class Initialized
INFO - 2021-04-13 21:07:22 --> Loader Class Initialized
INFO - 2021-04-13 21:07:22 --> Helper loaded: url_helper
INFO - 2021-04-13 21:07:22 --> Helper loaded: form_helper
INFO - 2021-04-13 21:07:22 --> Helper loaded: common_helper
INFO - 2021-04-13 21:07:22 --> Helper loaded: util_helper
INFO - 2021-04-13 21:07:22 --> Database Driver Class Initialized
DEBUG - 2021-04-13 21:07:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 21:07:22 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 21:07:22 --> Form Validation Class Initialized
INFO - 2021-04-13 21:07:22 --> Controller Class Initialized
INFO - 2021-04-13 21:07:22 --> Model Class Initialized
INFO - 2021-04-13 21:07:22 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 21:07:22 --> Final output sent to browser
DEBUG - 2021-04-13 21:07:22 --> Total execution time: 0.0302
INFO - 2021-04-13 21:07:34 --> Config Class Initialized
INFO - 2021-04-13 21:07:34 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:07:34 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:07:34 --> Utf8 Class Initialized
INFO - 2021-04-13 21:07:34 --> URI Class Initialized
INFO - 2021-04-13 21:07:34 --> Router Class Initialized
INFO - 2021-04-13 21:07:34 --> Output Class Initialized
INFO - 2021-04-13 21:07:34 --> Security Class Initialized
DEBUG - 2021-04-13 21:07:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:07:34 --> Input Class Initialized
INFO - 2021-04-13 21:07:34 --> Language Class Initialized
INFO - 2021-04-13 21:07:34 --> Loader Class Initialized
INFO - 2021-04-13 21:07:34 --> Helper loaded: url_helper
INFO - 2021-04-13 21:07:34 --> Helper loaded: form_helper
INFO - 2021-04-13 21:07:34 --> Helper loaded: common_helper
INFO - 2021-04-13 21:07:34 --> Helper loaded: util_helper
INFO - 2021-04-13 21:07:34 --> Database Driver Class Initialized
DEBUG - 2021-04-13 21:07:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 21:07:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 21:07:34 --> Form Validation Class Initialized
INFO - 2021-04-13 21:07:34 --> Controller Class Initialized
INFO - 2021-04-13 21:07:34 --> Model Class Initialized
INFO - 2021-04-13 21:07:34 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-04-13 21:07:35 --> Config Class Initialized
INFO - 2021-04-13 21:07:35 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:07:35 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:07:35 --> Utf8 Class Initialized
INFO - 2021-04-13 21:07:35 --> URI Class Initialized
INFO - 2021-04-13 21:07:35 --> Router Class Initialized
INFO - 2021-04-13 21:07:35 --> Output Class Initialized
INFO - 2021-04-13 21:07:35 --> Security Class Initialized
DEBUG - 2021-04-13 21:07:35 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:07:35 --> Input Class Initialized
INFO - 2021-04-13 21:07:35 --> Language Class Initialized
ERROR - 2021-04-13 21:07:35 --> Severity: error --> Exception: syntax error, unexpected 'redirect' (T_STRING) C:\xampp1\htdocs\FoodTruck\php\application\controllers\user\Dashboard.php 40
INFO - 2021-04-13 21:07:52 --> Config Class Initialized
INFO - 2021-04-13 21:07:52 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:07:52 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:07:52 --> Utf8 Class Initialized
INFO - 2021-04-13 21:07:52 --> URI Class Initialized
INFO - 2021-04-13 21:07:52 --> Router Class Initialized
INFO - 2021-04-13 21:07:52 --> Output Class Initialized
INFO - 2021-04-13 21:07:52 --> Security Class Initialized
DEBUG - 2021-04-13 21:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:07:52 --> Input Class Initialized
INFO - 2021-04-13 21:07:52 --> Language Class Initialized
INFO - 2021-04-13 21:07:52 --> Loader Class Initialized
INFO - 2021-04-13 21:07:52 --> Helper loaded: url_helper
INFO - 2021-04-13 21:07:52 --> Helper loaded: form_helper
INFO - 2021-04-13 21:07:52 --> Helper loaded: common_helper
INFO - 2021-04-13 21:07:52 --> Helper loaded: util_helper
INFO - 2021-04-13 21:07:52 --> Database Driver Class Initialized
DEBUG - 2021-04-13 21:07:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 21:07:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 21:07:52 --> Form Validation Class Initialized
INFO - 2021-04-13 21:07:52 --> Controller Class Initialized
INFO - 2021-04-13 21:07:52 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-13 21:07:52 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 21:07:52 --> Final output sent to browser
DEBUG - 2021-04-13 21:07:52 --> Total execution time: 0.0290
INFO - 2021-04-13 21:07:52 --> Config Class Initialized
INFO - 2021-04-13 21:07:52 --> Config Class Initialized
INFO - 2021-04-13 21:07:52 --> Hooks Class Initialized
INFO - 2021-04-13 21:07:52 --> Config Class Initialized
INFO - 2021-04-13 21:07:52 --> Hooks Class Initialized
INFO - 2021-04-13 21:07:52 --> Config Class Initialized
INFO - 2021-04-13 21:07:52 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:07:52 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:07:52 --> Utf8 Class Initialized
DEBUG - 2021-04-13 21:07:52 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:07:52 --> Utf8 Class Initialized
INFO - 2021-04-13 21:07:52 --> URI Class Initialized
DEBUG - 2021-04-13 21:07:52 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:07:52 --> Utf8 Class Initialized
INFO - 2021-04-13 21:07:52 --> URI Class Initialized
INFO - 2021-04-13 21:07:52 --> Router Class Initialized
INFO - 2021-04-13 21:07:52 --> URI Class Initialized
INFO - 2021-04-13 21:07:52 --> Hooks Class Initialized
INFO - 2021-04-13 21:07:52 --> Router Class Initialized
INFO - 2021-04-13 21:07:52 --> Router Class Initialized
INFO - 2021-04-13 21:07:52 --> Output Class Initialized
INFO - 2021-04-13 21:07:52 --> Security Class Initialized
INFO - 2021-04-13 21:07:52 --> Output Class Initialized
INFO - 2021-04-13 21:07:52 --> Output Class Initialized
INFO - 2021-04-13 21:07:52 --> Config Class Initialized
INFO - 2021-04-13 21:07:52 --> Security Class Initialized
INFO - 2021-04-13 21:07:52 --> Security Class Initialized
DEBUG - 2021-04-13 21:07:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 21:07:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 21:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:07:52 --> Input Class Initialized
INFO - 2021-04-13 21:07:52 --> Input Class Initialized
INFO - 2021-04-13 21:07:52 --> Utf8 Class Initialized
INFO - 2021-04-13 21:07:52 --> Hooks Class Initialized
INFO - 2021-04-13 21:07:52 --> Language Class Initialized
INFO - 2021-04-13 21:07:52 --> Language Class Initialized
INFO - 2021-04-13 21:07:52 --> URI Class Initialized
ERROR - 2021-04-13 21:07:52 --> 404 Page Not Found: user/Assets/css
ERROR - 2021-04-13 21:07:52 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 21:07:52 --> Router Class Initialized
DEBUG - 2021-04-13 21:07:52 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:07:52 --> Utf8 Class Initialized
DEBUG - 2021-04-13 21:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:07:52 --> URI Class Initialized
INFO - 2021-04-13 21:07:52 --> Output Class Initialized
INFO - 2021-04-13 21:07:52 --> Input Class Initialized
INFO - 2021-04-13 21:07:52 --> Config Class Initialized
INFO - 2021-04-13 21:07:52 --> Hooks Class Initialized
INFO - 2021-04-13 21:07:52 --> Language Class Initialized
INFO - 2021-04-13 21:07:52 --> Security Class Initialized
INFO - 2021-04-13 21:07:52 --> Router Class Initialized
DEBUG - 2021-04-13 21:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:07:52 --> Input Class Initialized
INFO - 2021-04-13 21:07:52 --> Output Class Initialized
INFO - 2021-04-13 21:07:52 --> Config Class Initialized
INFO - 2021-04-13 21:07:52 --> Config Class Initialized
INFO - 2021-04-13 21:07:52 --> Hooks Class Initialized
INFO - 2021-04-13 21:07:52 --> Hooks Class Initialized
INFO - 2021-04-13 21:07:52 --> Language Class Initialized
DEBUG - 2021-04-13 21:07:52 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:07:52 --> Utf8 Class Initialized
INFO - 2021-04-13 21:07:52 --> Security Class Initialized
DEBUG - 2021-04-13 21:07:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 21:07:52 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:07:52 --> Utf8 Class Initialized
INFO - 2021-04-13 21:07:52 --> Utf8 Class Initialized
INFO - 2021-04-13 21:07:52 --> URI Class Initialized
INFO - 2021-04-13 21:07:52 --> URI Class Initialized
DEBUG - 2021-04-13 21:07:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 21:07:52 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 21:07:52 --> Input Class Initialized
INFO - 2021-04-13 21:07:52 --> Router Class Initialized
INFO - 2021-04-13 21:07:52 --> Router Class Initialized
INFO - 2021-04-13 21:07:52 --> URI Class Initialized
INFO - 2021-04-13 21:07:52 --> Language Class Initialized
INFO - 2021-04-13 21:07:52 --> Output Class Initialized
INFO - 2021-04-13 21:07:52 --> Output Class Initialized
INFO - 2021-04-13 21:07:52 --> Security Class Initialized
INFO - 2021-04-13 21:07:52 --> Router Class Initialized
DEBUG - 2021-04-13 21:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:07:52 --> Input Class Initialized
INFO - 2021-04-13 21:07:52 --> Security Class Initialized
INFO - 2021-04-13 21:07:52 --> Language Class Initialized
DEBUG - 2021-04-13 21:07:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 21:07:52 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 21:07:52 --> Output Class Initialized
ERROR - 2021-04-13 21:07:52 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 21:07:52 --> Input Class Initialized
INFO - 2021-04-13 21:07:52 --> Config Class Initialized
INFO - 2021-04-13 21:07:52 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:07:52 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:07:52 --> Utf8 Class Initialized
INFO - 2021-04-13 21:07:52 --> URI Class Initialized
INFO - 2021-04-13 21:07:52 --> Security Class Initialized
INFO - 2021-04-13 21:07:52 --> Router Class Initialized
INFO - 2021-04-13 21:07:52 --> Language Class Initialized
INFO - 2021-04-13 21:07:52 --> Output Class Initialized
DEBUG - 2021-04-13 21:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:07:52 --> Input Class Initialized
INFO - 2021-04-13 21:07:52 --> Config Class Initialized
INFO - 2021-04-13 21:07:52 --> Hooks Class Initialized
INFO - 2021-04-13 21:07:52 --> Security Class Initialized
INFO - 2021-04-13 21:07:52 --> Language Class Initialized
ERROR - 2021-04-13 21:07:52 --> 404 Page Not Found: user/Assets/js
DEBUG - 2021-04-13 21:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:07:52 --> Input Class Initialized
DEBUG - 2021-04-13 21:07:52 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:07:52 --> Config Class Initialized
INFO - 2021-04-13 21:07:52 --> Language Class Initialized
INFO - 2021-04-13 21:07:52 --> Utf8 Class Initialized
INFO - 2021-04-13 21:07:52 --> Hooks Class Initialized
INFO - 2021-04-13 21:07:52 --> URI Class Initialized
ERROR - 2021-04-13 21:07:52 --> 404 Page Not Found: user/Assets/js
ERROR - 2021-04-13 21:07:52 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 21:07:52 --> Router Class Initialized
DEBUG - 2021-04-13 21:07:52 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:07:52 --> Utf8 Class Initialized
INFO - 2021-04-13 21:07:52 --> URI Class Initialized
INFO - 2021-04-13 21:07:52 --> Output Class Initialized
ERROR - 2021-04-13 21:07:52 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 21:07:52 --> Security Class Initialized
INFO - 2021-04-13 21:07:52 --> Router Class Initialized
DEBUG - 2021-04-13 21:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:07:52 --> Input Class Initialized
INFO - 2021-04-13 21:07:52 --> Language Class Initialized
INFO - 2021-04-13 21:07:52 --> Output Class Initialized
ERROR - 2021-04-13 21:07:52 --> 404 Page Not Found: user/Assets/img
INFO - 2021-04-13 21:07:52 --> Security Class Initialized
DEBUG - 2021-04-13 21:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:07:52 --> Input Class Initialized
INFO - 2021-04-13 21:07:52 --> Language Class Initialized
ERROR - 2021-04-13 21:07:52 --> 404 Page Not Found: user/Assets/img
INFO - 2021-04-13 21:07:52 --> Config Class Initialized
INFO - 2021-04-13 21:07:52 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:07:52 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:07:52 --> Utf8 Class Initialized
INFO - 2021-04-13 21:07:52 --> URI Class Initialized
INFO - 2021-04-13 21:07:52 --> Router Class Initialized
INFO - 2021-04-13 21:07:52 --> Output Class Initialized
INFO - 2021-04-13 21:07:52 --> Security Class Initialized
DEBUG - 2021-04-13 21:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:07:52 --> Input Class Initialized
INFO - 2021-04-13 21:07:52 --> Language Class Initialized
ERROR - 2021-04-13 21:07:52 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 21:07:52 --> Config Class Initialized
INFO - 2021-04-13 21:07:52 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:07:52 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:07:52 --> Utf8 Class Initialized
INFO - 2021-04-13 21:07:52 --> URI Class Initialized
INFO - 2021-04-13 21:07:52 --> Router Class Initialized
INFO - 2021-04-13 21:07:52 --> Output Class Initialized
INFO - 2021-04-13 21:07:52 --> Security Class Initialized
DEBUG - 2021-04-13 21:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:07:52 --> Input Class Initialized
INFO - 2021-04-13 21:07:52 --> Language Class Initialized
ERROR - 2021-04-13 21:07:52 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 21:07:52 --> Config Class Initialized
INFO - 2021-04-13 21:07:52 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:07:52 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:07:52 --> Utf8 Class Initialized
INFO - 2021-04-13 21:07:52 --> URI Class Initialized
INFO - 2021-04-13 21:07:52 --> Router Class Initialized
INFO - 2021-04-13 21:07:52 --> Output Class Initialized
INFO - 2021-04-13 21:07:52 --> Security Class Initialized
DEBUG - 2021-04-13 21:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:07:52 --> Input Class Initialized
INFO - 2021-04-13 21:07:52 --> Language Class Initialized
ERROR - 2021-04-13 21:07:52 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 21:07:52 --> Config Class Initialized
INFO - 2021-04-13 21:07:52 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:07:52 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:07:52 --> Utf8 Class Initialized
INFO - 2021-04-13 21:07:52 --> URI Class Initialized
INFO - 2021-04-13 21:07:52 --> Router Class Initialized
INFO - 2021-04-13 21:07:52 --> Output Class Initialized
INFO - 2021-04-13 21:07:52 --> Security Class Initialized
DEBUG - 2021-04-13 21:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:07:52 --> Input Class Initialized
INFO - 2021-04-13 21:07:52 --> Language Class Initialized
ERROR - 2021-04-13 21:07:52 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 21:07:52 --> Config Class Initialized
INFO - 2021-04-13 21:07:52 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:07:52 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:07:52 --> Utf8 Class Initialized
INFO - 2021-04-13 21:07:52 --> URI Class Initialized
INFO - 2021-04-13 21:07:52 --> Router Class Initialized
INFO - 2021-04-13 21:07:52 --> Output Class Initialized
INFO - 2021-04-13 21:07:52 --> Security Class Initialized
DEBUG - 2021-04-13 21:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:07:52 --> Input Class Initialized
INFO - 2021-04-13 21:07:52 --> Language Class Initialized
ERROR - 2021-04-13 21:07:52 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 21:07:52 --> Config Class Initialized
INFO - 2021-04-13 21:07:52 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:07:52 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:07:52 --> Utf8 Class Initialized
INFO - 2021-04-13 21:07:52 --> URI Class Initialized
INFO - 2021-04-13 21:07:52 --> Router Class Initialized
INFO - 2021-04-13 21:07:52 --> Output Class Initialized
INFO - 2021-04-13 21:07:52 --> Security Class Initialized
DEBUG - 2021-04-13 21:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:07:52 --> Input Class Initialized
INFO - 2021-04-13 21:07:52 --> Language Class Initialized
ERROR - 2021-04-13 21:07:52 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 21:07:52 --> Config Class Initialized
INFO - 2021-04-13 21:07:52 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:07:52 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:07:52 --> Utf8 Class Initialized
INFO - 2021-04-13 21:07:52 --> URI Class Initialized
INFO - 2021-04-13 21:07:52 --> Router Class Initialized
INFO - 2021-04-13 21:07:52 --> Output Class Initialized
INFO - 2021-04-13 21:07:52 --> Security Class Initialized
DEBUG - 2021-04-13 21:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:07:52 --> Input Class Initialized
INFO - 2021-04-13 21:07:52 --> Language Class Initialized
ERROR - 2021-04-13 21:07:52 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 21:07:52 --> Config Class Initialized
INFO - 2021-04-13 21:07:52 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:07:52 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:07:52 --> Utf8 Class Initialized
INFO - 2021-04-13 21:07:52 --> URI Class Initialized
INFO - 2021-04-13 21:07:52 --> Router Class Initialized
INFO - 2021-04-13 21:07:52 --> Output Class Initialized
INFO - 2021-04-13 21:07:52 --> Security Class Initialized
DEBUG - 2021-04-13 21:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:07:52 --> Input Class Initialized
INFO - 2021-04-13 21:07:52 --> Language Class Initialized
ERROR - 2021-04-13 21:07:52 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 21:07:52 --> Config Class Initialized
INFO - 2021-04-13 21:07:52 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:07:52 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:07:52 --> Utf8 Class Initialized
INFO - 2021-04-13 21:07:52 --> URI Class Initialized
INFO - 2021-04-13 21:07:52 --> Router Class Initialized
INFO - 2021-04-13 21:07:52 --> Output Class Initialized
INFO - 2021-04-13 21:07:52 --> Security Class Initialized
DEBUG - 2021-04-13 21:07:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:07:52 --> Input Class Initialized
INFO - 2021-04-13 21:07:52 --> Language Class Initialized
ERROR - 2021-04-13 21:07:52 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 21:11:24 --> Config Class Initialized
INFO - 2021-04-13 21:11:24 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:11:24 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:11:24 --> Utf8 Class Initialized
INFO - 2021-04-13 21:11:24 --> URI Class Initialized
INFO - 2021-04-13 21:11:24 --> Router Class Initialized
INFO - 2021-04-13 21:11:24 --> Output Class Initialized
INFO - 2021-04-13 21:11:24 --> Security Class Initialized
DEBUG - 2021-04-13 21:11:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:11:24 --> Input Class Initialized
INFO - 2021-04-13 21:11:24 --> Language Class Initialized
ERROR - 2021-04-13 21:11:24 --> Severity: error --> Exception: syntax error, unexpected 'else' (T_ELSE) C:\xampp1\htdocs\FoodTruck\php\application\controllers\user\Dashboard.php 41
INFO - 2021-04-13 21:16:11 --> Config Class Initialized
INFO - 2021-04-13 21:16:11 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:16:11 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:16:11 --> Utf8 Class Initialized
INFO - 2021-04-13 21:16:11 --> URI Class Initialized
INFO - 2021-04-13 21:16:11 --> Router Class Initialized
INFO - 2021-04-13 21:16:11 --> Output Class Initialized
INFO - 2021-04-13 21:16:11 --> Security Class Initialized
DEBUG - 2021-04-13 21:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:16:11 --> Input Class Initialized
INFO - 2021-04-13 21:16:11 --> Language Class Initialized
INFO - 2021-04-13 21:16:11 --> Loader Class Initialized
INFO - 2021-04-13 21:16:11 --> Helper loaded: url_helper
INFO - 2021-04-13 21:16:11 --> Helper loaded: form_helper
INFO - 2021-04-13 21:16:11 --> Helper loaded: common_helper
INFO - 2021-04-13 21:16:11 --> Helper loaded: util_helper
INFO - 2021-04-13 21:16:11 --> Database Driver Class Initialized
DEBUG - 2021-04-13 21:16:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 21:16:11 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 21:16:11 --> Form Validation Class Initialized
INFO - 2021-04-13 21:16:11 --> Controller Class Initialized
INFO - 2021-04-13 21:16:11 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-13 21:16:11 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 21:16:11 --> Final output sent to browser
DEBUG - 2021-04-13 21:16:11 --> Total execution time: 0.0324
INFO - 2021-04-13 21:16:11 --> Config Class Initialized
INFO - 2021-04-13 21:16:11 --> Hooks Class Initialized
INFO - 2021-04-13 21:16:11 --> Config Class Initialized
INFO - 2021-04-13 21:16:11 --> Config Class Initialized
INFO - 2021-04-13 21:16:11 --> Hooks Class Initialized
INFO - 2021-04-13 21:16:11 --> Hooks Class Initialized
INFO - 2021-04-13 21:16:11 --> Config Class Initialized
INFO - 2021-04-13 21:16:11 --> Hooks Class Initialized
INFO - 2021-04-13 21:16:11 --> Config Class Initialized
INFO - 2021-04-13 21:16:11 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:16:11 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:16:11 --> Utf8 Class Initialized
DEBUG - 2021-04-13 21:16:11 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:16:11 --> Utf8 Class Initialized
INFO - 2021-04-13 21:16:11 --> URI Class Initialized
DEBUG - 2021-04-13 21:16:11 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:16:11 --> Utf8 Class Initialized
INFO - 2021-04-13 21:16:11 --> URI Class Initialized
INFO - 2021-04-13 21:16:11 --> Router Class Initialized
INFO - 2021-04-13 21:16:11 --> URI Class Initialized
INFO - 2021-04-13 21:16:11 --> Router Class Initialized
INFO - 2021-04-13 21:16:11 --> Output Class Initialized
INFO - 2021-04-13 21:16:11 --> Router Class Initialized
INFO - 2021-04-13 21:16:11 --> Output Class Initialized
INFO - 2021-04-13 21:16:11 --> Security Class Initialized
INFO - 2021-04-13 21:16:11 --> Output Class Initialized
INFO - 2021-04-13 21:16:11 --> Security Class Initialized
DEBUG - 2021-04-13 21:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:16:11 --> Input Class Initialized
INFO - 2021-04-13 21:16:11 --> Security Class Initialized
INFO - 2021-04-13 21:16:11 --> Language Class Initialized
DEBUG - 2021-04-13 21:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:16:11 --> Input Class Initialized
DEBUG - 2021-04-13 21:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:16:11 --> Input Class Initialized
INFO - 2021-04-13 21:16:11 --> Language Class Initialized
ERROR - 2021-04-13 21:16:11 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 21:16:11 --> Language Class Initialized
ERROR - 2021-04-13 21:16:11 --> 404 Page Not Found: user/Assets/css
ERROR - 2021-04-13 21:16:11 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 21:16:11 --> Config Class Initialized
INFO - 2021-04-13 21:16:11 --> Hooks Class Initialized
INFO - 2021-04-13 21:16:11 --> Config Class Initialized
INFO - 2021-04-13 21:16:11 --> Config Class Initialized
INFO - 2021-04-13 21:16:11 --> Hooks Class Initialized
INFO - 2021-04-13 21:16:11 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:16:11 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:16:11 --> Utf8 Class Initialized
INFO - 2021-04-13 21:16:11 --> URI Class Initialized
DEBUG - 2021-04-13 21:16:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 21:16:11 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:16:11 --> Router Class Initialized
INFO - 2021-04-13 21:16:11 --> Utf8 Class Initialized
INFO - 2021-04-13 21:16:11 --> Utf8 Class Initialized
INFO - 2021-04-13 21:16:11 --> URI Class Initialized
INFO - 2021-04-13 21:16:11 --> URI Class Initialized
INFO - 2021-04-13 21:16:11 --> Output Class Initialized
INFO - 2021-04-13 21:16:11 --> Router Class Initialized
INFO - 2021-04-13 21:16:11 --> Router Class Initialized
INFO - 2021-04-13 21:16:11 --> Security Class Initialized
DEBUG - 2021-04-13 21:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:16:11 --> Output Class Initialized
INFO - 2021-04-13 21:16:11 --> Input Class Initialized
INFO - 2021-04-13 21:16:11 --> Output Class Initialized
INFO - 2021-04-13 21:16:11 --> Language Class Initialized
INFO - 2021-04-13 21:16:11 --> Security Class Initialized
INFO - 2021-04-13 21:16:11 --> Security Class Initialized
ERROR - 2021-04-13 21:16:11 --> 404 Page Not Found: user/Assets/js
DEBUG - 2021-04-13 21:16:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 21:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:16:11 --> Input Class Initialized
INFO - 2021-04-13 21:16:11 --> Input Class Initialized
INFO - 2021-04-13 21:16:11 --> Language Class Initialized
INFO - 2021-04-13 21:16:11 --> Language Class Initialized
ERROR - 2021-04-13 21:16:11 --> 404 Page Not Found: user/Assets/js
ERROR - 2021-04-13 21:16:11 --> 404 Page Not Found: user/Assets/js
DEBUG - 2021-04-13 21:16:11 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:16:11 --> Config Class Initialized
INFO - 2021-04-13 21:16:11 --> Hooks Class Initialized
INFO - 2021-04-13 21:16:11 --> Utf8 Class Initialized
DEBUG - 2021-04-13 21:16:11 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:16:11 --> Config Class Initialized
INFO - 2021-04-13 21:16:11 --> Hooks Class Initialized
INFO - 2021-04-13 21:16:11 --> Utf8 Class Initialized
DEBUG - 2021-04-13 21:16:11 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:16:11 --> Utf8 Class Initialized
INFO - 2021-04-13 21:16:11 --> URI Class Initialized
INFO - 2021-04-13 21:16:11 --> URI Class Initialized
DEBUG - 2021-04-13 21:16:11 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:16:11 --> Router Class Initialized
INFO - 2021-04-13 21:16:11 --> URI Class Initialized
INFO - 2021-04-13 21:16:11 --> Utf8 Class Initialized
INFO - 2021-04-13 21:16:11 --> Router Class Initialized
INFO - 2021-04-13 21:16:11 --> Output Class Initialized
INFO - 2021-04-13 21:16:11 --> Router Class Initialized
INFO - 2021-04-13 21:16:11 --> URI Class Initialized
INFO - 2021-04-13 21:16:11 --> Security Class Initialized
DEBUG - 2021-04-13 21:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:16:11 --> Output Class Initialized
INFO - 2021-04-13 21:16:11 --> Output Class Initialized
INFO - 2021-04-13 21:16:11 --> Input Class Initialized
INFO - 2021-04-13 21:16:11 --> Router Class Initialized
INFO - 2021-04-13 21:16:11 --> Language Class Initialized
INFO - 2021-04-13 21:16:11 --> Security Class Initialized
ERROR - 2021-04-13 21:16:11 --> 404 Page Not Found: user/Assets/img
DEBUG - 2021-04-13 21:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:16:11 --> Input Class Initialized
INFO - 2021-04-13 21:16:11 --> Output Class Initialized
INFO - 2021-04-13 21:16:11 --> Language Class Initialized
INFO - 2021-04-13 21:16:11 --> Security Class Initialized
INFO - 2021-04-13 21:16:11 --> Security Class Initialized
ERROR - 2021-04-13 21:16:11 --> 404 Page Not Found: user/Assets/css
DEBUG - 2021-04-13 21:16:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 21:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:16:11 --> Input Class Initialized
INFO - 2021-04-13 21:16:11 --> Input Class Initialized
INFO - 2021-04-13 21:16:11 --> Language Class Initialized
INFO - 2021-04-13 21:16:11 --> Language Class Initialized
ERROR - 2021-04-13 21:16:11 --> 404 Page Not Found: user/Assets/img
INFO - 2021-04-13 21:16:11 --> Config Class Initialized
ERROR - 2021-04-13 21:16:11 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 21:16:11 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:16:11 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:16:11 --> Utf8 Class Initialized
INFO - 2021-04-13 21:16:11 --> URI Class Initialized
INFO - 2021-04-13 21:16:11 --> Router Class Initialized
INFO - 2021-04-13 21:16:11 --> Output Class Initialized
INFO - 2021-04-13 21:16:11 --> Security Class Initialized
DEBUG - 2021-04-13 21:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:16:11 --> Input Class Initialized
INFO - 2021-04-13 21:16:11 --> Language Class Initialized
INFO - 2021-04-13 21:16:11 --> Config Class Initialized
INFO - 2021-04-13 21:16:11 --> Hooks Class Initialized
ERROR - 2021-04-13 21:16:11 --> 404 Page Not Found: user/Assets/js
DEBUG - 2021-04-13 21:16:11 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:16:11 --> Utf8 Class Initialized
INFO - 2021-04-13 21:16:11 --> URI Class Initialized
INFO - 2021-04-13 21:16:11 --> Router Class Initialized
INFO - 2021-04-13 21:16:11 --> Output Class Initialized
INFO - 2021-04-13 21:16:11 --> Security Class Initialized
DEBUG - 2021-04-13 21:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:16:11 --> Input Class Initialized
INFO - 2021-04-13 21:16:11 --> Language Class Initialized
ERROR - 2021-04-13 21:16:11 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 21:16:11 --> Config Class Initialized
INFO - 2021-04-13 21:16:11 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:16:11 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:16:11 --> Utf8 Class Initialized
INFO - 2021-04-13 21:16:11 --> URI Class Initialized
INFO - 2021-04-13 21:16:11 --> Router Class Initialized
INFO - 2021-04-13 21:16:11 --> Output Class Initialized
INFO - 2021-04-13 21:16:11 --> Security Class Initialized
DEBUG - 2021-04-13 21:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:16:11 --> Input Class Initialized
INFO - 2021-04-13 21:16:11 --> Language Class Initialized
ERROR - 2021-04-13 21:16:11 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 21:16:11 --> Config Class Initialized
INFO - 2021-04-13 21:16:11 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:16:11 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:16:11 --> Utf8 Class Initialized
INFO - 2021-04-13 21:16:11 --> URI Class Initialized
INFO - 2021-04-13 21:16:11 --> Router Class Initialized
INFO - 2021-04-13 21:16:11 --> Output Class Initialized
INFO - 2021-04-13 21:16:11 --> Security Class Initialized
DEBUG - 2021-04-13 21:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:16:11 --> Input Class Initialized
INFO - 2021-04-13 21:16:11 --> Language Class Initialized
ERROR - 2021-04-13 21:16:11 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 21:16:11 --> Config Class Initialized
INFO - 2021-04-13 21:16:11 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:16:11 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:16:11 --> Utf8 Class Initialized
INFO - 2021-04-13 21:16:11 --> URI Class Initialized
INFO - 2021-04-13 21:16:11 --> Router Class Initialized
INFO - 2021-04-13 21:16:11 --> Output Class Initialized
INFO - 2021-04-13 21:16:11 --> Security Class Initialized
DEBUG - 2021-04-13 21:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:16:11 --> Input Class Initialized
INFO - 2021-04-13 21:16:11 --> Language Class Initialized
ERROR - 2021-04-13 21:16:11 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 21:16:11 --> Config Class Initialized
INFO - 2021-04-13 21:16:11 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:16:11 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:16:11 --> Utf8 Class Initialized
INFO - 2021-04-13 21:16:11 --> URI Class Initialized
INFO - 2021-04-13 21:16:11 --> Router Class Initialized
INFO - 2021-04-13 21:16:11 --> Output Class Initialized
INFO - 2021-04-13 21:16:11 --> Security Class Initialized
DEBUG - 2021-04-13 21:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:16:11 --> Input Class Initialized
INFO - 2021-04-13 21:16:11 --> Language Class Initialized
ERROR - 2021-04-13 21:16:11 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 21:16:11 --> Config Class Initialized
INFO - 2021-04-13 21:16:11 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:16:11 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:16:11 --> Utf8 Class Initialized
INFO - 2021-04-13 21:16:11 --> URI Class Initialized
INFO - 2021-04-13 21:16:11 --> Router Class Initialized
INFO - 2021-04-13 21:16:11 --> Output Class Initialized
INFO - 2021-04-13 21:16:11 --> Security Class Initialized
DEBUG - 2021-04-13 21:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:16:11 --> Input Class Initialized
INFO - 2021-04-13 21:16:11 --> Language Class Initialized
ERROR - 2021-04-13 21:16:11 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 21:16:11 --> Config Class Initialized
INFO - 2021-04-13 21:16:11 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:16:11 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:16:11 --> Utf8 Class Initialized
INFO - 2021-04-13 21:16:11 --> URI Class Initialized
INFO - 2021-04-13 21:16:11 --> Router Class Initialized
INFO - 2021-04-13 21:16:11 --> Output Class Initialized
INFO - 2021-04-13 21:16:11 --> Security Class Initialized
DEBUG - 2021-04-13 21:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:16:11 --> Input Class Initialized
INFO - 2021-04-13 21:16:11 --> Language Class Initialized
ERROR - 2021-04-13 21:16:11 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 21:16:11 --> Config Class Initialized
INFO - 2021-04-13 21:16:11 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:16:11 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:16:11 --> Utf8 Class Initialized
INFO - 2021-04-13 21:16:11 --> URI Class Initialized
INFO - 2021-04-13 21:16:11 --> Router Class Initialized
INFO - 2021-04-13 21:16:11 --> Output Class Initialized
INFO - 2021-04-13 21:16:11 --> Security Class Initialized
DEBUG - 2021-04-13 21:16:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:16:11 --> Input Class Initialized
INFO - 2021-04-13 21:16:11 --> Language Class Initialized
ERROR - 2021-04-13 21:16:11 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 21:44:56 --> Config Class Initialized
INFO - 2021-04-13 21:44:56 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:44:56 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:44:56 --> Utf8 Class Initialized
INFO - 2021-04-13 21:44:56 --> URI Class Initialized
INFO - 2021-04-13 21:44:56 --> Router Class Initialized
INFO - 2021-04-13 21:44:56 --> Output Class Initialized
INFO - 2021-04-13 21:44:56 --> Security Class Initialized
DEBUG - 2021-04-13 21:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:44:56 --> Input Class Initialized
INFO - 2021-04-13 21:44:56 --> Language Class Initialized
INFO - 2021-04-13 21:44:56 --> Loader Class Initialized
INFO - 2021-04-13 21:44:56 --> Helper loaded: url_helper
INFO - 2021-04-13 21:44:56 --> Helper loaded: form_helper
INFO - 2021-04-13 21:44:56 --> Helper loaded: common_helper
INFO - 2021-04-13 21:44:56 --> Helper loaded: util_helper
INFO - 2021-04-13 21:44:56 --> Database Driver Class Initialized
DEBUG - 2021-04-13 21:44:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 21:44:56 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 21:44:56 --> Form Validation Class Initialized
INFO - 2021-04-13 21:44:56 --> Controller Class Initialized
INFO - 2021-04-13 21:44:56 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-13 21:44:56 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 21:44:56 --> Final output sent to browser
DEBUG - 2021-04-13 21:44:56 --> Total execution time: 0.0312
INFO - 2021-04-13 21:44:56 --> Config Class Initialized
INFO - 2021-04-13 21:44:56 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:44:56 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:44:56 --> Utf8 Class Initialized
INFO - 2021-04-13 21:44:56 --> URI Class Initialized
INFO - 2021-04-13 21:44:56 --> Router Class Initialized
INFO - 2021-04-13 21:44:56 --> Config Class Initialized
INFO - 2021-04-13 21:44:56 --> Hooks Class Initialized
INFO - 2021-04-13 21:44:56 --> Output Class Initialized
INFO - 2021-04-13 21:44:56 --> Config Class Initialized
INFO - 2021-04-13 21:44:56 --> Hooks Class Initialized
INFO - 2021-04-13 21:44:56 --> Security Class Initialized
DEBUG - 2021-04-13 21:44:56 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:44:56 --> Utf8 Class Initialized
DEBUG - 2021-04-13 21:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:44:56 --> Input Class Initialized
DEBUG - 2021-04-13 21:44:56 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:44:56 --> Language Class Initialized
INFO - 2021-04-13 21:44:56 --> URI Class Initialized
INFO - 2021-04-13 21:44:56 --> Utf8 Class Initialized
INFO - 2021-04-13 21:44:56 --> URI Class Initialized
INFO - 2021-04-13 21:44:56 --> Router Class Initialized
ERROR - 2021-04-13 21:44:56 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 21:44:56 --> Output Class Initialized
INFO - 2021-04-13 21:44:56 --> Router Class Initialized
INFO - 2021-04-13 21:44:56 --> Security Class Initialized
DEBUG - 2021-04-13 21:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:44:56 --> Output Class Initialized
INFO - 2021-04-13 21:44:56 --> Input Class Initialized
INFO - 2021-04-13 21:44:56 --> Language Class Initialized
INFO - 2021-04-13 21:44:56 --> Security Class Initialized
ERROR - 2021-04-13 21:44:56 --> 404 Page Not Found: user/Assets/css
DEBUG - 2021-04-13 21:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:44:56 --> Input Class Initialized
INFO - 2021-04-13 21:44:56 --> Language Class Initialized
ERROR - 2021-04-13 21:44:56 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 21:44:56 --> Config Class Initialized
INFO - 2021-04-13 21:44:56 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:44:56 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:44:56 --> Utf8 Class Initialized
INFO - 2021-04-13 21:44:56 --> Config Class Initialized
INFO - 2021-04-13 21:44:56 --> Hooks Class Initialized
INFO - 2021-04-13 21:44:56 --> URI Class Initialized
INFO - 2021-04-13 21:44:56 --> Config Class Initialized
INFO - 2021-04-13 21:44:56 --> Router Class Initialized
INFO - 2021-04-13 21:44:56 --> Hooks Class Initialized
INFO - 2021-04-13 21:44:56 --> Output Class Initialized
DEBUG - 2021-04-13 21:44:56 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:44:56 --> Utf8 Class Initialized
INFO - 2021-04-13 21:44:56 --> Security Class Initialized
INFO - 2021-04-13 21:44:56 --> URI Class Initialized
DEBUG - 2021-04-13 21:44:56 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 21:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:44:56 --> Utf8 Class Initialized
INFO - 2021-04-13 21:44:56 --> Input Class Initialized
INFO - 2021-04-13 21:44:56 --> Router Class Initialized
INFO - 2021-04-13 21:44:56 --> Language Class Initialized
INFO - 2021-04-13 21:44:56 --> Config Class Initialized
INFO - 2021-04-13 21:44:56 --> Hooks Class Initialized
INFO - 2021-04-13 21:44:56 --> Output Class Initialized
INFO - 2021-04-13 21:44:56 --> URI Class Initialized
ERROR - 2021-04-13 21:44:56 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 21:44:56 --> Security Class Initialized
DEBUG - 2021-04-13 21:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:44:56 --> Input Class Initialized
INFO - 2021-04-13 21:44:56 --> Router Class Initialized
INFO - 2021-04-13 21:44:56 --> Language Class Initialized
DEBUG - 2021-04-13 21:44:56 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:44:56 --> Utf8 Class Initialized
INFO - 2021-04-13 21:44:56 --> Output Class Initialized
ERROR - 2021-04-13 21:44:56 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 21:44:56 --> URI Class Initialized
INFO - 2021-04-13 21:44:56 --> Security Class Initialized
INFO - 2021-04-13 21:44:56 --> Router Class Initialized
DEBUG - 2021-04-13 21:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:44:56 --> Input Class Initialized
INFO - 2021-04-13 21:44:56 --> Output Class Initialized
INFO - 2021-04-13 21:44:56 --> Language Class Initialized
INFO - 2021-04-13 21:44:56 --> Config Class Initialized
INFO - 2021-04-13 21:44:56 --> Hooks Class Initialized
INFO - 2021-04-13 21:44:56 --> Security Class Initialized
ERROR - 2021-04-13 21:44:56 --> 404 Page Not Found: user/Assets/css
DEBUG - 2021-04-13 21:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:44:56 --> Input Class Initialized
INFO - 2021-04-13 21:44:56 --> Language Class Initialized
DEBUG - 2021-04-13 21:44:56 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:44:56 --> Config Class Initialized
INFO - 2021-04-13 21:44:56 --> Utf8 Class Initialized
INFO - 2021-04-13 21:44:56 --> Hooks Class Initialized
INFO - 2021-04-13 21:44:56 --> Config Class Initialized
ERROR - 2021-04-13 21:44:56 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 21:44:56 --> URI Class Initialized
INFO - 2021-04-13 21:44:56 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:44:56 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:44:56 --> Router Class Initialized
INFO - 2021-04-13 21:44:56 --> Utf8 Class Initialized
INFO - 2021-04-13 21:44:56 --> URI Class Initialized
INFO - 2021-04-13 21:44:56 --> Output Class Initialized
DEBUG - 2021-04-13 21:44:56 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:44:56 --> Utf8 Class Initialized
INFO - 2021-04-13 21:44:56 --> Router Class Initialized
INFO - 2021-04-13 21:44:56 --> Security Class Initialized
INFO - 2021-04-13 21:44:56 --> URI Class Initialized
DEBUG - 2021-04-13 21:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:44:56 --> Output Class Initialized
INFO - 2021-04-13 21:44:56 --> Input Class Initialized
INFO - 2021-04-13 21:44:56 --> Language Class Initialized
INFO - 2021-04-13 21:44:56 --> Router Class Initialized
INFO - 2021-04-13 21:44:56 --> Security Class Initialized
DEBUG - 2021-04-13 21:44:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 21:44:56 --> 404 Page Not Found: user/Assets/img
INFO - 2021-04-13 21:44:56 --> Input Class Initialized
INFO - 2021-04-13 21:44:56 --> Output Class Initialized
INFO - 2021-04-13 21:44:56 --> Language Class Initialized
INFO - 2021-04-13 21:44:56 --> Config Class Initialized
INFO - 2021-04-13 21:44:56 --> Security Class Initialized
INFO - 2021-04-13 21:44:56 --> Hooks Class Initialized
ERROR - 2021-04-13 21:44:56 --> 404 Page Not Found: user/Assets/css
DEBUG - 2021-04-13 21:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:44:56 --> Input Class Initialized
INFO - 2021-04-13 21:44:56 --> Language Class Initialized
DEBUG - 2021-04-13 21:44:56 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:44:56 --> Utf8 Class Initialized
INFO - 2021-04-13 21:44:56 --> URI Class Initialized
ERROR - 2021-04-13 21:44:56 --> 404 Page Not Found: user/Assets/img
INFO - 2021-04-13 21:44:56 --> Router Class Initialized
INFO - 2021-04-13 21:44:56 --> Output Class Initialized
INFO - 2021-04-13 21:44:56 --> Security Class Initialized
DEBUG - 2021-04-13 21:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:44:56 --> Input Class Initialized
INFO - 2021-04-13 21:44:56 --> Config Class Initialized
INFO - 2021-04-13 21:44:56 --> Hooks Class Initialized
INFO - 2021-04-13 21:44:56 --> Language Class Initialized
ERROR - 2021-04-13 21:44:56 --> 404 Page Not Found: user/Assets/js
DEBUG - 2021-04-13 21:44:56 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:44:56 --> Utf8 Class Initialized
INFO - 2021-04-13 21:44:56 --> URI Class Initialized
INFO - 2021-04-13 21:44:56 --> Router Class Initialized
INFO - 2021-04-13 21:44:56 --> Output Class Initialized
INFO - 2021-04-13 21:44:56 --> Security Class Initialized
DEBUG - 2021-04-13 21:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:44:56 --> Input Class Initialized
INFO - 2021-04-13 21:44:56 --> Language Class Initialized
ERROR - 2021-04-13 21:44:56 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 21:44:56 --> Config Class Initialized
INFO - 2021-04-13 21:44:56 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:44:56 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:44:56 --> Utf8 Class Initialized
INFO - 2021-04-13 21:44:56 --> URI Class Initialized
INFO - 2021-04-13 21:44:56 --> Router Class Initialized
INFO - 2021-04-13 21:44:56 --> Output Class Initialized
INFO - 2021-04-13 21:44:56 --> Security Class Initialized
DEBUG - 2021-04-13 21:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:44:56 --> Input Class Initialized
INFO - 2021-04-13 21:44:56 --> Language Class Initialized
ERROR - 2021-04-13 21:44:56 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 21:44:56 --> Config Class Initialized
INFO - 2021-04-13 21:44:56 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:44:56 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:44:56 --> Utf8 Class Initialized
INFO - 2021-04-13 21:44:56 --> URI Class Initialized
INFO - 2021-04-13 21:44:56 --> Router Class Initialized
INFO - 2021-04-13 21:44:56 --> Output Class Initialized
INFO - 2021-04-13 21:44:56 --> Security Class Initialized
DEBUG - 2021-04-13 21:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:44:56 --> Input Class Initialized
INFO - 2021-04-13 21:44:56 --> Language Class Initialized
ERROR - 2021-04-13 21:44:56 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 21:44:56 --> Config Class Initialized
INFO - 2021-04-13 21:44:56 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:44:56 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:44:56 --> Utf8 Class Initialized
INFO - 2021-04-13 21:44:56 --> URI Class Initialized
INFO - 2021-04-13 21:44:56 --> Router Class Initialized
INFO - 2021-04-13 21:44:56 --> Output Class Initialized
INFO - 2021-04-13 21:44:56 --> Security Class Initialized
DEBUG - 2021-04-13 21:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:44:56 --> Input Class Initialized
INFO - 2021-04-13 21:44:56 --> Language Class Initialized
ERROR - 2021-04-13 21:44:56 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 21:44:56 --> Config Class Initialized
INFO - 2021-04-13 21:44:56 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:44:56 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:44:56 --> Utf8 Class Initialized
INFO - 2021-04-13 21:44:56 --> URI Class Initialized
INFO - 2021-04-13 21:44:56 --> Router Class Initialized
INFO - 2021-04-13 21:44:56 --> Output Class Initialized
INFO - 2021-04-13 21:44:56 --> Security Class Initialized
DEBUG - 2021-04-13 21:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:44:56 --> Input Class Initialized
INFO - 2021-04-13 21:44:56 --> Language Class Initialized
ERROR - 2021-04-13 21:44:56 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 21:44:56 --> Config Class Initialized
INFO - 2021-04-13 21:44:56 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:44:56 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:44:56 --> Utf8 Class Initialized
INFO - 2021-04-13 21:44:56 --> URI Class Initialized
INFO - 2021-04-13 21:44:56 --> Router Class Initialized
INFO - 2021-04-13 21:44:56 --> Output Class Initialized
INFO - 2021-04-13 21:44:56 --> Security Class Initialized
DEBUG - 2021-04-13 21:44:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:44:56 --> Input Class Initialized
INFO - 2021-04-13 21:44:56 --> Language Class Initialized
ERROR - 2021-04-13 21:44:56 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 21:45:40 --> Config Class Initialized
INFO - 2021-04-13 21:45:40 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:45:40 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:45:40 --> Utf8 Class Initialized
INFO - 2021-04-13 21:45:40 --> URI Class Initialized
INFO - 2021-04-13 21:45:40 --> Router Class Initialized
INFO - 2021-04-13 21:45:40 --> Output Class Initialized
INFO - 2021-04-13 21:45:40 --> Security Class Initialized
DEBUG - 2021-04-13 21:45:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:45:40 --> Input Class Initialized
INFO - 2021-04-13 21:45:40 --> Language Class Initialized
ERROR - 2021-04-13 21:45:40 --> 404 Page Not Found: user/Home/index
INFO - 2021-04-13 21:45:44 --> Config Class Initialized
INFO - 2021-04-13 21:45:44 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:45:44 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:45:44 --> Utf8 Class Initialized
INFO - 2021-04-13 21:45:44 --> URI Class Initialized
INFO - 2021-04-13 21:45:44 --> Router Class Initialized
INFO - 2021-04-13 21:45:44 --> Output Class Initialized
INFO - 2021-04-13 21:45:44 --> Security Class Initialized
DEBUG - 2021-04-13 21:45:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:45:44 --> Input Class Initialized
INFO - 2021-04-13 21:45:44 --> Language Class Initialized
INFO - 2021-04-13 21:45:44 --> Loader Class Initialized
INFO - 2021-04-13 21:45:44 --> Helper loaded: url_helper
INFO - 2021-04-13 21:45:44 --> Helper loaded: form_helper
INFO - 2021-04-13 21:45:44 --> Helper loaded: common_helper
INFO - 2021-04-13 21:45:44 --> Helper loaded: util_helper
INFO - 2021-04-13 21:45:44 --> Database Driver Class Initialized
DEBUG - 2021-04-13 21:45:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 21:45:44 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 21:45:44 --> Form Validation Class Initialized
INFO - 2021-04-13 21:45:44 --> Controller Class Initialized
INFO - 2021-04-13 21:45:44 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-13 21:45:44 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 21:45:44 --> Final output sent to browser
DEBUG - 2021-04-13 21:45:44 --> Total execution time: 0.0255
INFO - 2021-04-13 21:45:57 --> Config Class Initialized
INFO - 2021-04-13 21:45:57 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:45:57 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:45:57 --> Utf8 Class Initialized
INFO - 2021-04-13 21:45:57 --> URI Class Initialized
INFO - 2021-04-13 21:45:57 --> Router Class Initialized
INFO - 2021-04-13 21:45:57 --> Output Class Initialized
INFO - 2021-04-13 21:45:57 --> Security Class Initialized
DEBUG - 2021-04-13 21:45:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:45:57 --> Input Class Initialized
INFO - 2021-04-13 21:45:57 --> Language Class Initialized
INFO - 2021-04-13 21:45:57 --> Loader Class Initialized
INFO - 2021-04-13 21:45:57 --> Helper loaded: url_helper
INFO - 2021-04-13 21:45:57 --> Helper loaded: form_helper
INFO - 2021-04-13 21:45:57 --> Helper loaded: common_helper
INFO - 2021-04-13 21:45:57 --> Helper loaded: util_helper
INFO - 2021-04-13 21:45:57 --> Database Driver Class Initialized
DEBUG - 2021-04-13 21:45:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 21:45:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 21:45:57 --> Form Validation Class Initialized
INFO - 2021-04-13 21:45:57 --> Controller Class Initialized
INFO - 2021-04-13 21:45:57 --> Model Class Initialized
INFO - 2021-04-13 21:45:57 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-13 21:45:57 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 21:45:57 --> Final output sent to browser
DEBUG - 2021-04-13 21:45:57 --> Total execution time: 0.0250
INFO - 2021-04-13 21:46:04 --> Config Class Initialized
INFO - 2021-04-13 21:46:04 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:46:04 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:46:04 --> Utf8 Class Initialized
INFO - 2021-04-13 21:46:04 --> URI Class Initialized
INFO - 2021-04-13 21:46:04 --> Router Class Initialized
INFO - 2021-04-13 21:46:04 --> Output Class Initialized
INFO - 2021-04-13 21:46:04 --> Security Class Initialized
DEBUG - 2021-04-13 21:46:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:46:04 --> Input Class Initialized
INFO - 2021-04-13 21:46:04 --> Language Class Initialized
INFO - 2021-04-13 21:46:04 --> Loader Class Initialized
INFO - 2021-04-13 21:46:04 --> Helper loaded: url_helper
INFO - 2021-04-13 21:46:04 --> Helper loaded: form_helper
INFO - 2021-04-13 21:46:04 --> Helper loaded: common_helper
INFO - 2021-04-13 21:46:04 --> Helper loaded: util_helper
INFO - 2021-04-13 21:46:04 --> Database Driver Class Initialized
DEBUG - 2021-04-13 21:46:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 21:46:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 21:46:04 --> Form Validation Class Initialized
INFO - 2021-04-13 21:46:04 --> Controller Class Initialized
INFO - 2021-04-13 21:46:04 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-13 21:46:04 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 21:46:04 --> Final output sent to browser
DEBUG - 2021-04-13 21:46:04 --> Total execution time: 0.0251
INFO - 2021-04-13 21:49:00 --> Config Class Initialized
INFO - 2021-04-13 21:49:00 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:49:00 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:49:00 --> Utf8 Class Initialized
INFO - 2021-04-13 21:49:00 --> URI Class Initialized
DEBUG - 2021-04-13 21:49:00 --> No URI present. Default controller set.
INFO - 2021-04-13 21:49:00 --> Router Class Initialized
INFO - 2021-04-13 21:49:00 --> Output Class Initialized
INFO - 2021-04-13 21:49:00 --> Security Class Initialized
DEBUG - 2021-04-13 21:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:49:00 --> Input Class Initialized
INFO - 2021-04-13 21:49:00 --> Language Class Initialized
INFO - 2021-04-13 21:49:00 --> Loader Class Initialized
INFO - 2021-04-13 21:49:00 --> Helper loaded: url_helper
INFO - 2021-04-13 21:49:00 --> Helper loaded: form_helper
INFO - 2021-04-13 21:49:00 --> Helper loaded: common_helper
INFO - 2021-04-13 21:49:00 --> Helper loaded: util_helper
INFO - 2021-04-13 21:49:00 --> Database Driver Class Initialized
DEBUG - 2021-04-13 21:49:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 21:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 21:49:00 --> Form Validation Class Initialized
INFO - 2021-04-13 21:49:00 --> Controller Class Initialized
INFO - 2021-04-13 21:49:00 --> Model Class Initialized
INFO - 2021-04-13 21:49:00 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-13 21:49:00 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 21:49:00 --> Final output sent to browser
DEBUG - 2021-04-13 21:49:00 --> Total execution time: 0.0360
INFO - 2021-04-13 21:49:02 --> Config Class Initialized
INFO - 2021-04-13 21:49:02 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:49:02 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:49:02 --> Utf8 Class Initialized
INFO - 2021-04-13 21:49:02 --> URI Class Initialized
INFO - 2021-04-13 21:49:02 --> Router Class Initialized
INFO - 2021-04-13 21:49:02 --> Output Class Initialized
INFO - 2021-04-13 21:49:02 --> Security Class Initialized
DEBUG - 2021-04-13 21:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:49:02 --> Input Class Initialized
INFO - 2021-04-13 21:49:02 --> Language Class Initialized
ERROR - 2021-04-13 21:49:02 --> 404 Page Not Found: Logout/index
INFO - 2021-04-13 21:49:03 --> Config Class Initialized
INFO - 2021-04-13 21:49:03 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:49:03 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:49:03 --> Utf8 Class Initialized
INFO - 2021-04-13 21:49:03 --> URI Class Initialized
INFO - 2021-04-13 21:49:03 --> Router Class Initialized
INFO - 2021-04-13 21:49:03 --> Output Class Initialized
INFO - 2021-04-13 21:49:03 --> Security Class Initialized
DEBUG - 2021-04-13 21:49:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:49:03 --> Input Class Initialized
INFO - 2021-04-13 21:49:03 --> Language Class Initialized
ERROR - 2021-04-13 21:49:03 --> 404 Page Not Found: Logout/index
INFO - 2021-04-13 21:49:04 --> Config Class Initialized
INFO - 2021-04-13 21:49:04 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:49:04 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:49:04 --> Utf8 Class Initialized
INFO - 2021-04-13 21:49:04 --> URI Class Initialized
DEBUG - 2021-04-13 21:49:04 --> No URI present. Default controller set.
INFO - 2021-04-13 21:49:04 --> Router Class Initialized
INFO - 2021-04-13 21:49:04 --> Output Class Initialized
INFO - 2021-04-13 21:49:04 --> Security Class Initialized
DEBUG - 2021-04-13 21:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:49:04 --> Input Class Initialized
INFO - 2021-04-13 21:49:04 --> Language Class Initialized
INFO - 2021-04-13 21:49:04 --> Loader Class Initialized
INFO - 2021-04-13 21:49:04 --> Helper loaded: url_helper
INFO - 2021-04-13 21:49:04 --> Helper loaded: form_helper
INFO - 2021-04-13 21:49:04 --> Helper loaded: common_helper
INFO - 2021-04-13 21:49:04 --> Helper loaded: util_helper
INFO - 2021-04-13 21:49:04 --> Database Driver Class Initialized
DEBUG - 2021-04-13 21:49:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 21:49:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 21:49:04 --> Form Validation Class Initialized
INFO - 2021-04-13 21:49:04 --> Controller Class Initialized
INFO - 2021-04-13 21:49:04 --> Model Class Initialized
INFO - 2021-04-13 21:49:04 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-13 21:49:04 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 21:49:04 --> Final output sent to browser
DEBUG - 2021-04-13 21:49:04 --> Total execution time: 0.0278
INFO - 2021-04-13 21:49:09 --> Config Class Initialized
INFO - 2021-04-13 21:49:09 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:49:09 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:49:09 --> Utf8 Class Initialized
INFO - 2021-04-13 21:49:09 --> URI Class Initialized
INFO - 2021-04-13 21:49:09 --> Router Class Initialized
INFO - 2021-04-13 21:49:09 --> Output Class Initialized
INFO - 2021-04-13 21:49:09 --> Security Class Initialized
DEBUG - 2021-04-13 21:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:49:09 --> Input Class Initialized
INFO - 2021-04-13 21:49:09 --> Language Class Initialized
INFO - 2021-04-13 21:49:09 --> Loader Class Initialized
INFO - 2021-04-13 21:49:09 --> Helper loaded: url_helper
INFO - 2021-04-13 21:49:09 --> Helper loaded: form_helper
INFO - 2021-04-13 21:49:09 --> Helper loaded: common_helper
INFO - 2021-04-13 21:49:09 --> Helper loaded: util_helper
INFO - 2021-04-13 21:49:09 --> Database Driver Class Initialized
DEBUG - 2021-04-13 21:49:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 21:49:09 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 21:49:09 --> Form Validation Class Initialized
INFO - 2021-04-13 21:49:09 --> Controller Class Initialized
INFO - 2021-04-13 21:49:09 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-13 21:49:09 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 21:49:09 --> Final output sent to browser
DEBUG - 2021-04-13 21:49:09 --> Total execution time: 0.0276
INFO - 2021-04-13 21:49:09 --> Config Class Initialized
INFO - 2021-04-13 21:49:09 --> Hooks Class Initialized
INFO - 2021-04-13 21:49:09 --> Config Class Initialized
INFO - 2021-04-13 21:49:09 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:49:09 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:49:09 --> Utf8 Class Initialized
DEBUG - 2021-04-13 21:49:09 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:49:09 --> Utf8 Class Initialized
INFO - 2021-04-13 21:49:09 --> URI Class Initialized
INFO - 2021-04-13 21:49:09 --> URI Class Initialized
INFO - 2021-04-13 21:49:09 --> Router Class Initialized
INFO - 2021-04-13 21:49:09 --> Router Class Initialized
INFO - 2021-04-13 21:49:09 --> Output Class Initialized
INFO - 2021-04-13 21:49:09 --> Output Class Initialized
INFO - 2021-04-13 21:49:09 --> Security Class Initialized
INFO - 2021-04-13 21:49:09 --> Security Class Initialized
DEBUG - 2021-04-13 21:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:49:09 --> Input Class Initialized
INFO - 2021-04-13 21:49:09 --> Language Class Initialized
DEBUG - 2021-04-13 21:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:49:09 --> Input Class Initialized
INFO - 2021-04-13 21:49:09 --> Language Class Initialized
ERROR - 2021-04-13 21:49:09 --> 404 Page Not Found: user/Assets/css
ERROR - 2021-04-13 21:49:09 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 21:49:09 --> Config Class Initialized
INFO - 2021-04-13 21:49:09 --> Hooks Class Initialized
INFO - 2021-04-13 21:49:09 --> Config Class Initialized
INFO - 2021-04-13 21:49:09 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:49:09 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:49:09 --> Utf8 Class Initialized
INFO - 2021-04-13 21:49:09 --> URI Class Initialized
DEBUG - 2021-04-13 21:49:09 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:49:09 --> Utf8 Class Initialized
INFO - 2021-04-13 21:49:09 --> Router Class Initialized
INFO - 2021-04-13 21:49:09 --> URI Class Initialized
INFO - 2021-04-13 21:49:09 --> Router Class Initialized
INFO - 2021-04-13 21:49:09 --> Config Class Initialized
INFO - 2021-04-13 21:49:09 --> Hooks Class Initialized
INFO - 2021-04-13 21:49:09 --> Output Class Initialized
INFO - 2021-04-13 21:49:09 --> Output Class Initialized
INFO - 2021-04-13 21:49:09 --> Security Class Initialized
INFO - 2021-04-13 21:49:09 --> Security Class Initialized
DEBUG - 2021-04-13 21:49:09 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 21:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:49:09 --> Utf8 Class Initialized
INFO - 2021-04-13 21:49:09 --> Input Class Initialized
DEBUG - 2021-04-13 21:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:49:09 --> Input Class Initialized
INFO - 2021-04-13 21:49:09 --> Language Class Initialized
INFO - 2021-04-13 21:49:09 --> URI Class Initialized
INFO - 2021-04-13 21:49:09 --> Config Class Initialized
INFO - 2021-04-13 21:49:09 --> Hooks Class Initialized
INFO - 2021-04-13 21:49:09 --> Language Class Initialized
INFO - 2021-04-13 21:49:09 --> Router Class Initialized
ERROR - 2021-04-13 21:49:09 --> 404 Page Not Found: user/Assets/css
ERROR - 2021-04-13 21:49:09 --> 404 Page Not Found: user/Assets/css
DEBUG - 2021-04-13 21:49:09 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:49:09 --> Output Class Initialized
INFO - 2021-04-13 21:49:09 --> Utf8 Class Initialized
INFO - 2021-04-13 21:49:09 --> Security Class Initialized
INFO - 2021-04-13 21:49:09 --> URI Class Initialized
DEBUG - 2021-04-13 21:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:49:09 --> Router Class Initialized
INFO - 2021-04-13 21:49:09 --> Input Class Initialized
INFO - 2021-04-13 21:49:09 --> Language Class Initialized
INFO - 2021-04-13 21:49:09 --> Output Class Initialized
INFO - 2021-04-13 21:49:09 --> Config Class Initialized
INFO - 2021-04-13 21:49:09 --> Hooks Class Initialized
INFO - 2021-04-13 21:49:09 --> Security Class Initialized
INFO - 2021-04-13 21:49:09 --> Config Class Initialized
INFO - 2021-04-13 21:49:09 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:49:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 21:49:09 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:49:09 --> Utf8 Class Initialized
ERROR - 2021-04-13 21:49:09 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 21:49:09 --> Input Class Initialized
INFO - 2021-04-13 21:49:09 --> URI Class Initialized
DEBUG - 2021-04-13 21:49:09 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:49:09 --> Utf8 Class Initialized
INFO - 2021-04-13 21:49:09 --> Router Class Initialized
INFO - 2021-04-13 21:49:09 --> URI Class Initialized
INFO - 2021-04-13 21:49:09 --> Router Class Initialized
INFO - 2021-04-13 21:49:09 --> Language Class Initialized
INFO - 2021-04-13 21:49:09 --> Output Class Initialized
INFO - 2021-04-13 21:49:09 --> Output Class Initialized
ERROR - 2021-04-13 21:49:09 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 21:49:09 --> Security Class Initialized
INFO - 2021-04-13 21:49:09 --> Security Class Initialized
DEBUG - 2021-04-13 21:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:49:09 --> Input Class Initialized
INFO - 2021-04-13 21:49:09 --> Language Class Initialized
DEBUG - 2021-04-13 21:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:49:09 --> Input Class Initialized
INFO - 2021-04-13 21:49:09 --> Language Class Initialized
ERROR - 2021-04-13 21:49:09 --> 404 Page Not Found: user/Assets/js
ERROR - 2021-04-13 21:49:09 --> 404 Page Not Found: user/Assets/img
INFO - 2021-04-13 21:49:09 --> Config Class Initialized
INFO - 2021-04-13 21:49:09 --> Hooks Class Initialized
INFO - 2021-04-13 21:49:09 --> Config Class Initialized
INFO - 2021-04-13 21:49:09 --> Hooks Class Initialized
INFO - 2021-04-13 21:49:09 --> Config Class Initialized
INFO - 2021-04-13 21:49:09 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:49:09 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:49:09 --> Utf8 Class Initialized
DEBUG - 2021-04-13 21:49:09 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:49:09 --> URI Class Initialized
INFO - 2021-04-13 21:49:09 --> Utf8 Class Initialized
DEBUG - 2021-04-13 21:49:09 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:49:09 --> Utf8 Class Initialized
INFO - 2021-04-13 21:49:09 --> URI Class Initialized
INFO - 2021-04-13 21:49:09 --> Router Class Initialized
INFO - 2021-04-13 21:49:09 --> URI Class Initialized
INFO - 2021-04-13 21:49:09 --> Router Class Initialized
INFO - 2021-04-13 21:49:09 --> Output Class Initialized
INFO - 2021-04-13 21:49:09 --> Router Class Initialized
INFO - 2021-04-13 21:49:09 --> Output Class Initialized
INFO - 2021-04-13 21:49:09 --> Security Class Initialized
INFO - 2021-04-13 21:49:09 --> Output Class Initialized
INFO - 2021-04-13 21:49:09 --> Security Class Initialized
DEBUG - 2021-04-13 21:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:49:09 --> Input Class Initialized
INFO - 2021-04-13 21:49:09 --> Security Class Initialized
DEBUG - 2021-04-13 21:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:49:09 --> Language Class Initialized
INFO - 2021-04-13 21:49:09 --> Input Class Initialized
DEBUG - 2021-04-13 21:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:49:09 --> Input Class Initialized
INFO - 2021-04-13 21:49:09 --> Language Class Initialized
ERROR - 2021-04-13 21:49:09 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 21:49:09 --> Language Class Initialized
ERROR - 2021-04-13 21:49:09 --> 404 Page Not Found: user/Assets/img
ERROR - 2021-04-13 21:49:09 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 21:49:09 --> Config Class Initialized
INFO - 2021-04-13 21:49:09 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:49:09 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:49:09 --> Utf8 Class Initialized
INFO - 2021-04-13 21:49:09 --> URI Class Initialized
INFO - 2021-04-13 21:49:09 --> Router Class Initialized
INFO - 2021-04-13 21:49:09 --> Output Class Initialized
INFO - 2021-04-13 21:49:09 --> Security Class Initialized
DEBUG - 2021-04-13 21:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:49:09 --> Input Class Initialized
INFO - 2021-04-13 21:49:09 --> Language Class Initialized
ERROR - 2021-04-13 21:49:09 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 21:49:09 --> Config Class Initialized
INFO - 2021-04-13 21:49:09 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:49:09 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:49:09 --> Utf8 Class Initialized
INFO - 2021-04-13 21:49:09 --> URI Class Initialized
INFO - 2021-04-13 21:49:09 --> Router Class Initialized
INFO - 2021-04-13 21:49:09 --> Output Class Initialized
INFO - 2021-04-13 21:49:09 --> Security Class Initialized
DEBUG - 2021-04-13 21:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:49:09 --> Input Class Initialized
INFO - 2021-04-13 21:49:09 --> Language Class Initialized
ERROR - 2021-04-13 21:49:09 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 21:49:09 --> Config Class Initialized
INFO - 2021-04-13 21:49:09 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:49:09 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:49:09 --> Utf8 Class Initialized
INFO - 2021-04-13 21:49:09 --> URI Class Initialized
INFO - 2021-04-13 21:49:09 --> Router Class Initialized
INFO - 2021-04-13 21:49:09 --> Output Class Initialized
INFO - 2021-04-13 21:49:09 --> Security Class Initialized
DEBUG - 2021-04-13 21:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:49:09 --> Input Class Initialized
INFO - 2021-04-13 21:49:09 --> Language Class Initialized
ERROR - 2021-04-13 21:49:09 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 21:49:09 --> Config Class Initialized
INFO - 2021-04-13 21:49:09 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:49:09 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:49:09 --> Utf8 Class Initialized
INFO - 2021-04-13 21:49:09 --> URI Class Initialized
INFO - 2021-04-13 21:49:09 --> Router Class Initialized
INFO - 2021-04-13 21:49:09 --> Output Class Initialized
INFO - 2021-04-13 21:49:09 --> Security Class Initialized
DEBUG - 2021-04-13 21:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:49:09 --> Input Class Initialized
INFO - 2021-04-13 21:49:09 --> Language Class Initialized
ERROR - 2021-04-13 21:49:09 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 21:49:09 --> Config Class Initialized
INFO - 2021-04-13 21:49:09 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:49:09 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:49:09 --> Utf8 Class Initialized
INFO - 2021-04-13 21:49:09 --> URI Class Initialized
INFO - 2021-04-13 21:49:09 --> Router Class Initialized
INFO - 2021-04-13 21:49:09 --> Output Class Initialized
INFO - 2021-04-13 21:49:09 --> Security Class Initialized
DEBUG - 2021-04-13 21:49:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:49:09 --> Input Class Initialized
INFO - 2021-04-13 21:49:09 --> Language Class Initialized
ERROR - 2021-04-13 21:49:09 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 21:53:13 --> Config Class Initialized
INFO - 2021-04-13 21:53:13 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:53:13 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:53:13 --> Utf8 Class Initialized
INFO - 2021-04-13 21:53:13 --> URI Class Initialized
INFO - 2021-04-13 21:53:13 --> Router Class Initialized
INFO - 2021-04-13 21:53:13 --> Output Class Initialized
INFO - 2021-04-13 21:53:13 --> Security Class Initialized
DEBUG - 2021-04-13 21:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:53:13 --> Input Class Initialized
INFO - 2021-04-13 21:53:13 --> Language Class Initialized
INFO - 2021-04-13 21:53:13 --> Loader Class Initialized
INFO - 2021-04-13 21:53:13 --> Helper loaded: url_helper
INFO - 2021-04-13 21:53:13 --> Helper loaded: form_helper
INFO - 2021-04-13 21:53:13 --> Helper loaded: common_helper
INFO - 2021-04-13 21:53:13 --> Helper loaded: util_helper
INFO - 2021-04-13 21:53:13 --> Database Driver Class Initialized
DEBUG - 2021-04-13 21:53:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 21:53:13 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 21:53:13 --> Form Validation Class Initialized
INFO - 2021-04-13 21:53:13 --> Controller Class Initialized
INFO - 2021-04-13 21:53:13 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-13 21:53:13 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 21:53:13 --> Final output sent to browser
DEBUG - 2021-04-13 21:53:13 --> Total execution time: 0.0385
INFO - 2021-04-13 21:53:13 --> Config Class Initialized
INFO - 2021-04-13 21:53:13 --> Hooks Class Initialized
INFO - 2021-04-13 21:53:13 --> Config Class Initialized
INFO - 2021-04-13 21:53:13 --> Hooks Class Initialized
INFO - 2021-04-13 21:53:13 --> Config Class Initialized
INFO - 2021-04-13 21:53:13 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:53:13 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:53:13 --> Utf8 Class Initialized
INFO - 2021-04-13 21:53:13 --> Config Class Initialized
INFO - 2021-04-13 21:53:13 --> URI Class Initialized
INFO - 2021-04-13 21:53:13 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:53:13 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:53:13 --> Utf8 Class Initialized
INFO - 2021-04-13 21:53:13 --> Router Class Initialized
INFO - 2021-04-13 21:53:13 --> URI Class Initialized
DEBUG - 2021-04-13 21:53:13 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:53:13 --> Utf8 Class Initialized
INFO - 2021-04-13 21:53:13 --> Router Class Initialized
INFO - 2021-04-13 21:53:13 --> Output Class Initialized
INFO - 2021-04-13 21:53:13 --> URI Class Initialized
INFO - 2021-04-13 21:53:13 --> Security Class Initialized
INFO - 2021-04-13 21:53:13 --> Output Class Initialized
INFO - 2021-04-13 21:53:13 --> Router Class Initialized
DEBUG - 2021-04-13 21:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:53:13 --> Security Class Initialized
INFO - 2021-04-13 21:53:13 --> Input Class Initialized
INFO - 2021-04-13 21:53:13 --> Output Class Initialized
INFO - 2021-04-13 21:53:13 --> Language Class Initialized
DEBUG - 2021-04-13 21:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:53:13 --> Input Class Initialized
INFO - 2021-04-13 21:53:13 --> Security Class Initialized
INFO - 2021-04-13 21:53:13 --> Language Class Initialized
ERROR - 2021-04-13 21:53:13 --> 404 Page Not Found: user/Assets/css
DEBUG - 2021-04-13 21:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:53:13 --> Input Class Initialized
ERROR - 2021-04-13 21:53:13 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 21:53:13 --> Language Class Initialized
ERROR - 2021-04-13 21:53:13 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 21:53:13 --> Config Class Initialized
INFO - 2021-04-13 21:53:13 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:53:13 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:53:13 --> Config Class Initialized
INFO - 2021-04-13 21:53:13 --> Hooks Class Initialized
INFO - 2021-04-13 21:53:13 --> Utf8 Class Initialized
INFO - 2021-04-13 21:53:13 --> Config Class Initialized
INFO - 2021-04-13 21:53:13 --> Hooks Class Initialized
INFO - 2021-04-13 21:53:13 --> URI Class Initialized
DEBUG - 2021-04-13 21:53:13 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:53:13 --> Router Class Initialized
INFO - 2021-04-13 21:53:13 --> Utf8 Class Initialized
DEBUG - 2021-04-13 21:53:13 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 21:53:13 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:53:13 --> Utf8 Class Initialized
INFO - 2021-04-13 21:53:13 --> URI Class Initialized
INFO - 2021-04-13 21:53:13 --> Output Class Initialized
INFO - 2021-04-13 21:53:13 --> Utf8 Class Initialized
INFO - 2021-04-13 21:53:13 --> URI Class Initialized
INFO - 2021-04-13 21:53:13 --> Security Class Initialized
INFO - 2021-04-13 21:53:13 --> URI Class Initialized
INFO - 2021-04-13 21:53:13 --> Router Class Initialized
INFO - 2021-04-13 21:53:13 --> Router Class Initialized
DEBUG - 2021-04-13 21:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:53:13 --> Input Class Initialized
INFO - 2021-04-13 21:53:13 --> Router Class Initialized
INFO - 2021-04-13 21:53:13 --> Language Class Initialized
ERROR - 2021-04-13 21:53:13 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 21:53:13 --> Output Class Initialized
INFO - 2021-04-13 21:53:13 --> Output Class Initialized
INFO - 2021-04-13 21:53:13 --> Security Class Initialized
INFO - 2021-04-13 21:53:13 --> Security Class Initialized
DEBUG - 2021-04-13 21:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:53:13 --> Input Class Initialized
DEBUG - 2021-04-13 21:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:53:13 --> Language Class Initialized
INFO - 2021-04-13 21:53:13 --> Input Class Initialized
INFO - 2021-04-13 21:53:13 --> Language Class Initialized
ERROR - 2021-04-13 21:53:13 --> 404 Page Not Found: user/Assets/js
ERROR - 2021-04-13 21:53:13 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 21:53:13 --> Config Class Initialized
INFO - 2021-04-13 21:53:13 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:53:13 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:53:13 --> Utf8 Class Initialized
INFO - 2021-04-13 21:53:13 --> URI Class Initialized
INFO - 2021-04-13 21:53:13 --> Router Class Initialized
INFO - 2021-04-13 21:53:13 --> Output Class Initialized
INFO - 2021-04-13 21:53:13 --> Security Class Initialized
INFO - 2021-04-13 21:53:13 --> Config Class Initialized
INFO - 2021-04-13 21:53:13 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:53:13 --> Input Class Initialized
INFO - 2021-04-13 21:53:13 --> Language Class Initialized
DEBUG - 2021-04-13 21:53:13 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:53:13 --> Utf8 Class Initialized
INFO - 2021-04-13 21:53:13 --> Config Class Initialized
INFO - 2021-04-13 21:53:13 --> Hooks Class Initialized
INFO - 2021-04-13 21:53:13 --> URI Class Initialized
ERROR - 2021-04-13 21:53:13 --> 404 Page Not Found: user/Assets/img
INFO - 2021-04-13 21:53:13 --> Router Class Initialized
INFO - 2021-04-13 21:53:13 --> Output Class Initialized
DEBUG - 2021-04-13 21:53:13 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:53:13 --> Utf8 Class Initialized
INFO - 2021-04-13 21:53:13 --> Config Class Initialized
INFO - 2021-04-13 21:53:13 --> Output Class Initialized
INFO - 2021-04-13 21:53:13 --> URI Class Initialized
INFO - 2021-04-13 21:53:13 --> Security Class Initialized
INFO - 2021-04-13 21:53:13 --> Security Class Initialized
INFO - 2021-04-13 21:53:13 --> Router Class Initialized
DEBUG - 2021-04-13 21:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:53:13 --> Input Class Initialized
DEBUG - 2021-04-13 21:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:53:13 --> Input Class Initialized
INFO - 2021-04-13 21:53:13 --> Output Class Initialized
INFO - 2021-04-13 21:53:13 --> Language Class Initialized
INFO - 2021-04-13 21:53:13 --> Language Class Initialized
INFO - 2021-04-13 21:53:13 --> Hooks Class Initialized
INFO - 2021-04-13 21:53:13 --> Security Class Initialized
ERROR - 2021-04-13 21:53:13 --> 404 Page Not Found: user/Assets/img
DEBUG - 2021-04-13 21:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:53:13 --> Input Class Initialized
ERROR - 2021-04-13 21:53:13 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 21:53:13 --> Language Class Initialized
ERROR - 2021-04-13 21:53:13 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 21:53:13 --> Config Class Initialized
DEBUG - 2021-04-13 21:53:13 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:53:13 --> Hooks Class Initialized
INFO - 2021-04-13 21:53:13 --> Utf8 Class Initialized
INFO - 2021-04-13 21:53:13 --> URI Class Initialized
DEBUG - 2021-04-13 21:53:13 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:53:13 --> Utf8 Class Initialized
INFO - 2021-04-13 21:53:13 --> Router Class Initialized
INFO - 2021-04-13 21:53:13 --> URI Class Initialized
INFO - 2021-04-13 21:53:13 --> Output Class Initialized
INFO - 2021-04-13 21:53:13 --> Router Class Initialized
INFO - 2021-04-13 21:53:13 --> Security Class Initialized
INFO - 2021-04-13 21:53:13 --> Output Class Initialized
DEBUG - 2021-04-13 21:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:53:13 --> Input Class Initialized
INFO - 2021-04-13 21:53:13 --> Config Class Initialized
INFO - 2021-04-13 21:53:13 --> Hooks Class Initialized
INFO - 2021-04-13 21:53:13 --> Security Class Initialized
INFO - 2021-04-13 21:53:13 --> Language Class Initialized
DEBUG - 2021-04-13 21:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:53:13 --> Input Class Initialized
DEBUG - 2021-04-13 21:53:13 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:53:13 --> Language Class Initialized
ERROR - 2021-04-13 21:53:13 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 21:53:13 --> Utf8 Class Initialized
INFO - 2021-04-13 21:53:13 --> URI Class Initialized
ERROR - 2021-04-13 21:53:13 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 21:53:13 --> Router Class Initialized
INFO - 2021-04-13 21:53:13 --> Output Class Initialized
INFO - 2021-04-13 21:53:13 --> Security Class Initialized
DEBUG - 2021-04-13 21:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:53:13 --> Input Class Initialized
INFO - 2021-04-13 21:53:13 --> Language Class Initialized
ERROR - 2021-04-13 21:53:13 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 21:53:13 --> Config Class Initialized
INFO - 2021-04-13 21:53:13 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:53:13 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:53:13 --> Utf8 Class Initialized
INFO - 2021-04-13 21:53:13 --> URI Class Initialized
INFO - 2021-04-13 21:53:13 --> Router Class Initialized
INFO - 2021-04-13 21:53:13 --> Output Class Initialized
INFO - 2021-04-13 21:53:13 --> Security Class Initialized
DEBUG - 2021-04-13 21:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:53:13 --> Input Class Initialized
INFO - 2021-04-13 21:53:13 --> Language Class Initialized
ERROR - 2021-04-13 21:53:13 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 21:53:13 --> Config Class Initialized
INFO - 2021-04-13 21:53:13 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:53:13 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:53:13 --> Utf8 Class Initialized
INFO - 2021-04-13 21:53:13 --> URI Class Initialized
INFO - 2021-04-13 21:53:13 --> Router Class Initialized
INFO - 2021-04-13 21:53:13 --> Output Class Initialized
INFO - 2021-04-13 21:53:13 --> Security Class Initialized
DEBUG - 2021-04-13 21:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:53:13 --> Input Class Initialized
INFO - 2021-04-13 21:53:13 --> Language Class Initialized
ERROR - 2021-04-13 21:53:13 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 21:53:13 --> Config Class Initialized
INFO - 2021-04-13 21:53:13 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:53:13 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:53:13 --> Utf8 Class Initialized
INFO - 2021-04-13 21:53:13 --> URI Class Initialized
INFO - 2021-04-13 21:53:13 --> Router Class Initialized
INFO - 2021-04-13 21:53:13 --> Output Class Initialized
INFO - 2021-04-13 21:53:13 --> Security Class Initialized
DEBUG - 2021-04-13 21:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:53:13 --> Input Class Initialized
INFO - 2021-04-13 21:53:13 --> Language Class Initialized
ERROR - 2021-04-13 21:53:13 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 21:53:13 --> Config Class Initialized
INFO - 2021-04-13 21:53:13 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:53:13 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:53:13 --> Utf8 Class Initialized
INFO - 2021-04-13 21:53:13 --> URI Class Initialized
INFO - 2021-04-13 21:53:13 --> Router Class Initialized
INFO - 2021-04-13 21:53:13 --> Output Class Initialized
INFO - 2021-04-13 21:53:13 --> Security Class Initialized
DEBUG - 2021-04-13 21:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:53:13 --> Input Class Initialized
INFO - 2021-04-13 21:53:13 --> Language Class Initialized
ERROR - 2021-04-13 21:53:13 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 21:53:13 --> Config Class Initialized
INFO - 2021-04-13 21:53:13 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:53:13 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:53:13 --> Utf8 Class Initialized
INFO - 2021-04-13 21:53:13 --> URI Class Initialized
INFO - 2021-04-13 21:53:13 --> Router Class Initialized
INFO - 2021-04-13 21:53:13 --> Output Class Initialized
INFO - 2021-04-13 21:53:13 --> Security Class Initialized
DEBUG - 2021-04-13 21:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:53:13 --> Input Class Initialized
INFO - 2021-04-13 21:53:13 --> Language Class Initialized
ERROR - 2021-04-13 21:53:13 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 21:53:14 --> Config Class Initialized
INFO - 2021-04-13 21:53:14 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:53:14 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:53:14 --> Utf8 Class Initialized
INFO - 2021-04-13 21:53:14 --> URI Class Initialized
INFO - 2021-04-13 21:53:14 --> Router Class Initialized
INFO - 2021-04-13 21:53:14 --> Output Class Initialized
INFO - 2021-04-13 21:53:14 --> Security Class Initialized
DEBUG - 2021-04-13 21:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:53:14 --> Input Class Initialized
INFO - 2021-04-13 21:53:14 --> Language Class Initialized
INFO - 2021-04-13 21:53:14 --> Loader Class Initialized
INFO - 2021-04-13 21:53:14 --> Helper loaded: url_helper
INFO - 2021-04-13 21:53:14 --> Helper loaded: form_helper
INFO - 2021-04-13 21:53:14 --> Helper loaded: common_helper
INFO - 2021-04-13 21:53:14 --> Helper loaded: util_helper
INFO - 2021-04-13 21:53:14 --> Database Driver Class Initialized
DEBUG - 2021-04-13 21:53:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 21:53:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 21:53:14 --> Form Validation Class Initialized
INFO - 2021-04-13 21:53:14 --> Controller Class Initialized
INFO - 2021-04-13 21:53:14 --> Model Class Initialized
INFO - 2021-04-13 21:53:14 --> Config Class Initialized
INFO - 2021-04-13 21:53:14 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:53:14 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:53:14 --> Utf8 Class Initialized
INFO - 2021-04-13 21:53:14 --> URI Class Initialized
INFO - 2021-04-13 21:53:14 --> Router Class Initialized
INFO - 2021-04-13 21:53:14 --> Output Class Initialized
INFO - 2021-04-13 21:53:14 --> Security Class Initialized
DEBUG - 2021-04-13 21:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:53:14 --> Input Class Initialized
INFO - 2021-04-13 21:53:14 --> Language Class Initialized
INFO - 2021-04-13 21:53:14 --> Loader Class Initialized
INFO - 2021-04-13 21:53:14 --> Helper loaded: url_helper
INFO - 2021-04-13 21:53:14 --> Helper loaded: form_helper
INFO - 2021-04-13 21:53:14 --> Helper loaded: common_helper
INFO - 2021-04-13 21:53:14 --> Helper loaded: util_helper
INFO - 2021-04-13 21:53:14 --> Database Driver Class Initialized
DEBUG - 2021-04-13 21:53:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 21:53:14 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 21:53:14 --> Form Validation Class Initialized
INFO - 2021-04-13 21:53:14 --> Controller Class Initialized
INFO - 2021-04-13 21:53:14 --> Model Class Initialized
INFO - 2021-04-13 21:53:14 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-13 21:53:14 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 21:53:14 --> Final output sent to browser
DEBUG - 2021-04-13 21:53:14 --> Total execution time: 0.0392
INFO - 2021-04-13 21:54:06 --> Config Class Initialized
INFO - 2021-04-13 21:54:06 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:54:06 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:54:06 --> Utf8 Class Initialized
INFO - 2021-04-13 21:54:06 --> URI Class Initialized
INFO - 2021-04-13 21:54:06 --> Router Class Initialized
INFO - 2021-04-13 21:54:06 --> Output Class Initialized
INFO - 2021-04-13 21:54:06 --> Security Class Initialized
DEBUG - 2021-04-13 21:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:54:06 --> Input Class Initialized
INFO - 2021-04-13 21:54:06 --> Language Class Initialized
INFO - 2021-04-13 21:54:06 --> Loader Class Initialized
INFO - 2021-04-13 21:54:06 --> Helper loaded: url_helper
INFO - 2021-04-13 21:54:06 --> Helper loaded: form_helper
INFO - 2021-04-13 21:54:06 --> Helper loaded: common_helper
INFO - 2021-04-13 21:54:06 --> Helper loaded: util_helper
INFO - 2021-04-13 21:54:06 --> Database Driver Class Initialized
DEBUG - 2021-04-13 21:54:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 21:54:06 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 21:54:06 --> Form Validation Class Initialized
INFO - 2021-04-13 21:54:06 --> Controller Class Initialized
INFO - 2021-04-13 21:54:06 --> Model Class Initialized
INFO - 2021-04-13 21:54:06 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 21:54:06 --> Final output sent to browser
DEBUG - 2021-04-13 21:54:06 --> Total execution time: 0.0350
INFO - 2021-04-13 21:54:06 --> Config Class Initialized
INFO - 2021-04-13 21:54:06 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:54:06 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:54:06 --> Utf8 Class Initialized
INFO - 2021-04-13 21:54:06 --> URI Class Initialized
INFO - 2021-04-13 21:54:06 --> Config Class Initialized
INFO - 2021-04-13 21:54:06 --> Router Class Initialized
INFO - 2021-04-13 21:54:06 --> Hooks Class Initialized
INFO - 2021-04-13 21:54:06 --> Output Class Initialized
DEBUG - 2021-04-13 21:54:06 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:54:06 --> Utf8 Class Initialized
INFO - 2021-04-13 21:54:06 --> Security Class Initialized
INFO - 2021-04-13 21:54:06 --> URI Class Initialized
DEBUG - 2021-04-13 21:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:54:06 --> Input Class Initialized
INFO - 2021-04-13 21:54:06 --> Language Class Initialized
INFO - 2021-04-13 21:54:06 --> Router Class Initialized
ERROR - 2021-04-13 21:54:06 --> 404 Page Not Found: Fasset/img
INFO - 2021-04-13 21:54:06 --> Output Class Initialized
INFO - 2021-04-13 21:54:06 --> Security Class Initialized
DEBUG - 2021-04-13 21:54:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:54:06 --> Input Class Initialized
INFO - 2021-04-13 21:54:06 --> Language Class Initialized
ERROR - 2021-04-13 21:54:06 --> 404 Page Not Found: Fasset/img
INFO - 2021-04-13 21:54:19 --> Config Class Initialized
INFO - 2021-04-13 21:54:19 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:54:19 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:54:19 --> Utf8 Class Initialized
INFO - 2021-04-13 21:54:19 --> URI Class Initialized
INFO - 2021-04-13 21:54:19 --> Router Class Initialized
INFO - 2021-04-13 21:54:19 --> Output Class Initialized
INFO - 2021-04-13 21:54:19 --> Security Class Initialized
DEBUG - 2021-04-13 21:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:54:19 --> Input Class Initialized
INFO - 2021-04-13 21:54:19 --> Language Class Initialized
INFO - 2021-04-13 21:54:19 --> Loader Class Initialized
INFO - 2021-04-13 21:54:19 --> Helper loaded: url_helper
INFO - 2021-04-13 21:54:19 --> Helper loaded: form_helper
INFO - 2021-04-13 21:54:19 --> Helper loaded: common_helper
INFO - 2021-04-13 21:54:19 --> Helper loaded: util_helper
INFO - 2021-04-13 21:54:19 --> Database Driver Class Initialized
DEBUG - 2021-04-13 21:54:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 21:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 21:54:19 --> Form Validation Class Initialized
INFO - 2021-04-13 21:54:19 --> Controller Class Initialized
INFO - 2021-04-13 21:54:19 --> Model Class Initialized
INFO - 2021-04-13 21:54:19 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-04-13 21:54:19 --> Config Class Initialized
INFO - 2021-04-13 21:54:19 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:54:19 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:54:19 --> Utf8 Class Initialized
INFO - 2021-04-13 21:54:19 --> URI Class Initialized
INFO - 2021-04-13 21:54:19 --> Router Class Initialized
INFO - 2021-04-13 21:54:19 --> Output Class Initialized
INFO - 2021-04-13 21:54:19 --> Security Class Initialized
DEBUG - 2021-04-13 21:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:54:19 --> Input Class Initialized
INFO - 2021-04-13 21:54:19 --> Language Class Initialized
INFO - 2021-04-13 21:54:19 --> Loader Class Initialized
INFO - 2021-04-13 21:54:19 --> Helper loaded: url_helper
INFO - 2021-04-13 21:54:19 --> Helper loaded: form_helper
INFO - 2021-04-13 21:54:19 --> Helper loaded: common_helper
INFO - 2021-04-13 21:54:19 --> Helper loaded: util_helper
INFO - 2021-04-13 21:54:19 --> Database Driver Class Initialized
DEBUG - 2021-04-13 21:54:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 21:54:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 21:54:19 --> Form Validation Class Initialized
INFO - 2021-04-13 21:54:19 --> Controller Class Initialized
INFO - 2021-04-13 21:54:19 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-13 21:54:19 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 21:54:19 --> Final output sent to browser
DEBUG - 2021-04-13 21:54:19 --> Total execution time: 0.0262
INFO - 2021-04-13 21:54:19 --> Config Class Initialized
INFO - 2021-04-13 21:54:19 --> Hooks Class Initialized
INFO - 2021-04-13 21:54:19 --> Config Class Initialized
INFO - 2021-04-13 21:54:19 --> Hooks Class Initialized
INFO - 2021-04-13 21:54:19 --> Config Class Initialized
DEBUG - 2021-04-13 21:54:19 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:54:19 --> Hooks Class Initialized
INFO - 2021-04-13 21:54:19 --> Utf8 Class Initialized
INFO - 2021-04-13 21:54:19 --> URI Class Initialized
DEBUG - 2021-04-13 21:54:19 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:54:19 --> Utf8 Class Initialized
DEBUG - 2021-04-13 21:54:19 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:54:19 --> Utf8 Class Initialized
INFO - 2021-04-13 21:54:19 --> Router Class Initialized
INFO - 2021-04-13 21:54:19 --> URI Class Initialized
INFO - 2021-04-13 21:54:19 --> URI Class Initialized
INFO - 2021-04-13 21:54:19 --> Output Class Initialized
INFO - 2021-04-13 21:54:19 --> Router Class Initialized
INFO - 2021-04-13 21:54:19 --> Router Class Initialized
INFO - 2021-04-13 21:54:19 --> Security Class Initialized
INFO - 2021-04-13 21:54:19 --> Output Class Initialized
INFO - 2021-04-13 21:54:19 --> Output Class Initialized
DEBUG - 2021-04-13 21:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:54:19 --> Input Class Initialized
INFO - 2021-04-13 21:54:19 --> Security Class Initialized
INFO - 2021-04-13 21:54:19 --> Security Class Initialized
INFO - 2021-04-13 21:54:19 --> Language Class Initialized
DEBUG - 2021-04-13 21:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 21:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:54:19 --> Input Class Initialized
INFO - 2021-04-13 21:54:19 --> Input Class Initialized
INFO - 2021-04-13 21:54:19 --> Language Class Initialized
ERROR - 2021-04-13 21:54:19 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 21:54:19 --> Language Class Initialized
ERROR - 2021-04-13 21:54:19 --> 404 Page Not Found: user/Assets/css
ERROR - 2021-04-13 21:54:19 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 21:54:19 --> Config Class Initialized
INFO - 2021-04-13 21:54:19 --> Hooks Class Initialized
INFO - 2021-04-13 21:54:19 --> Config Class Initialized
INFO - 2021-04-13 21:54:19 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:54:19 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:54:19 --> Utf8 Class Initialized
DEBUG - 2021-04-13 21:54:19 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:54:19 --> Config Class Initialized
INFO - 2021-04-13 21:54:19 --> Utf8 Class Initialized
INFO - 2021-04-13 21:54:19 --> Hooks Class Initialized
INFO - 2021-04-13 21:54:19 --> Config Class Initialized
INFO - 2021-04-13 21:54:19 --> URI Class Initialized
INFO - 2021-04-13 21:54:19 --> Hooks Class Initialized
INFO - 2021-04-13 21:54:19 --> URI Class Initialized
INFO - 2021-04-13 21:54:19 --> Router Class Initialized
INFO - 2021-04-13 21:54:19 --> Router Class Initialized
INFO - 2021-04-13 21:54:19 --> Output Class Initialized
INFO - 2021-04-13 21:54:19 --> Output Class Initialized
INFO - 2021-04-13 21:54:19 --> Security Class Initialized
INFO - 2021-04-13 21:54:19 --> Security Class Initialized
DEBUG - 2021-04-13 21:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:54:19 --> Input Class Initialized
DEBUG - 2021-04-13 21:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:54:19 --> Input Class Initialized
INFO - 2021-04-13 21:54:19 --> Language Class Initialized
INFO - 2021-04-13 21:54:19 --> Language Class Initialized
ERROR - 2021-04-13 21:54:19 --> 404 Page Not Found: user/Assets/css
ERROR - 2021-04-13 21:54:19 --> 404 Page Not Found: user/Assets/js
DEBUG - 2021-04-13 21:54:19 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:54:19 --> Utf8 Class Initialized
INFO - 2021-04-13 21:54:19 --> URI Class Initialized
INFO - 2021-04-13 21:54:19 --> Router Class Initialized
INFO - 2021-04-13 21:54:19 --> Output Class Initialized
INFO - 2021-04-13 21:54:19 --> Security Class Initialized
DEBUG - 2021-04-13 21:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:54:19 --> Input Class Initialized
INFO - 2021-04-13 21:54:19 --> Language Class Initialized
INFO - 2021-04-13 21:54:19 --> Config Class Initialized
INFO - 2021-04-13 21:54:19 --> Hooks Class Initialized
ERROR - 2021-04-13 21:54:19 --> 404 Page Not Found: user/Assets/js
DEBUG - 2021-04-13 21:54:19 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:54:19 --> Utf8 Class Initialized
INFO - 2021-04-13 21:54:19 --> URI Class Initialized
INFO - 2021-04-13 21:54:19 --> Router Class Initialized
INFO - 2021-04-13 21:54:19 --> Output Class Initialized
INFO - 2021-04-13 21:54:19 --> Config Class Initialized
INFO - 2021-04-13 21:54:19 --> Security Class Initialized
INFO - 2021-04-13 21:54:19 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:54:19 --> Input Class Initialized
INFO - 2021-04-13 21:54:19 --> Language Class Initialized
DEBUG - 2021-04-13 21:54:19 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:54:19 --> Utf8 Class Initialized
DEBUG - 2021-04-13 21:54:19 --> UTF-8 Support Enabled
ERROR - 2021-04-13 21:54:19 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 21:54:19 --> URI Class Initialized
INFO - 2021-04-13 21:54:19 --> Utf8 Class Initialized
INFO - 2021-04-13 21:54:19 --> Config Class Initialized
INFO - 2021-04-13 21:54:19 --> Config Class Initialized
INFO - 2021-04-13 21:54:19 --> Hooks Class Initialized
INFO - 2021-04-13 21:54:19 --> Router Class Initialized
INFO - 2021-04-13 21:54:19 --> URI Class Initialized
INFO - 2021-04-13 21:54:19 --> Hooks Class Initialized
INFO - 2021-04-13 21:54:19 --> Router Class Initialized
DEBUG - 2021-04-13 21:54:19 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:54:19 --> Output Class Initialized
INFO - 2021-04-13 21:54:19 --> Utf8 Class Initialized
INFO - 2021-04-13 21:54:19 --> Output Class Initialized
INFO - 2021-04-13 21:54:19 --> Security Class Initialized
INFO - 2021-04-13 21:54:19 --> URI Class Initialized
DEBUG - 2021-04-13 21:54:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 21:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:54:19 --> Security Class Initialized
INFO - 2021-04-13 21:54:19 --> Utf8 Class Initialized
INFO - 2021-04-13 21:54:19 --> Input Class Initialized
INFO - 2021-04-13 21:54:19 --> Router Class Initialized
DEBUG - 2021-04-13 21:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:54:19 --> URI Class Initialized
INFO - 2021-04-13 21:54:19 --> Input Class Initialized
INFO - 2021-04-13 21:54:19 --> Language Class Initialized
INFO - 2021-04-13 21:54:19 --> Output Class Initialized
INFO - 2021-04-13 21:54:19 --> Config Class Initialized
INFO - 2021-04-13 21:54:19 --> Language Class Initialized
INFO - 2021-04-13 21:54:19 --> Hooks Class Initialized
INFO - 2021-04-13 21:54:19 --> Router Class Initialized
ERROR - 2021-04-13 21:54:19 --> 404 Page Not Found: user/Assets/img
INFO - 2021-04-13 21:54:19 --> Security Class Initialized
DEBUG - 2021-04-13 21:54:19 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:54:19 --> Utf8 Class Initialized
ERROR - 2021-04-13 21:54:19 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 21:54:19 --> URI Class Initialized
DEBUG - 2021-04-13 21:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:54:19 --> Input Class Initialized
INFO - 2021-04-13 21:54:19 --> Router Class Initialized
INFO - 2021-04-13 21:54:19 --> Language Class Initialized
INFO - 2021-04-13 21:54:19 --> Output Class Initialized
INFO - 2021-04-13 21:54:19 --> Output Class Initialized
ERROR - 2021-04-13 21:54:19 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 21:54:19 --> Security Class Initialized
INFO - 2021-04-13 21:54:19 --> Security Class Initialized
DEBUG - 2021-04-13 21:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 21:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:54:19 --> Input Class Initialized
INFO - 2021-04-13 21:54:19 --> Input Class Initialized
INFO - 2021-04-13 21:54:19 --> Language Class Initialized
INFO - 2021-04-13 21:54:19 --> Language Class Initialized
ERROR - 2021-04-13 21:54:19 --> 404 Page Not Found: user/Assets/img
ERROR - 2021-04-13 21:54:19 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 21:54:19 --> Config Class Initialized
INFO - 2021-04-13 21:54:19 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:54:19 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:54:19 --> Utf8 Class Initialized
INFO - 2021-04-13 21:54:19 --> URI Class Initialized
INFO - 2021-04-13 21:54:19 --> Router Class Initialized
INFO - 2021-04-13 21:54:19 --> Output Class Initialized
INFO - 2021-04-13 21:54:19 --> Config Class Initialized
INFO - 2021-04-13 21:54:19 --> Security Class Initialized
INFO - 2021-04-13 21:54:19 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:54:19 --> Input Class Initialized
INFO - 2021-04-13 21:54:19 --> Language Class Initialized
DEBUG - 2021-04-13 21:54:19 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:54:19 --> Utf8 Class Initialized
INFO - 2021-04-13 21:54:19 --> URI Class Initialized
ERROR - 2021-04-13 21:54:19 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 21:54:19 --> Router Class Initialized
INFO - 2021-04-13 21:54:19 --> Output Class Initialized
INFO - 2021-04-13 21:54:19 --> Security Class Initialized
DEBUG - 2021-04-13 21:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:54:19 --> Input Class Initialized
INFO - 2021-04-13 21:54:19 --> Language Class Initialized
ERROR - 2021-04-13 21:54:19 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 21:54:19 --> Config Class Initialized
INFO - 2021-04-13 21:54:19 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:54:19 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:54:19 --> Utf8 Class Initialized
INFO - 2021-04-13 21:54:19 --> URI Class Initialized
INFO - 2021-04-13 21:54:19 --> Router Class Initialized
INFO - 2021-04-13 21:54:19 --> Output Class Initialized
INFO - 2021-04-13 21:54:19 --> Security Class Initialized
DEBUG - 2021-04-13 21:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:54:19 --> Input Class Initialized
INFO - 2021-04-13 21:54:19 --> Language Class Initialized
ERROR - 2021-04-13 21:54:19 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 21:54:19 --> Config Class Initialized
INFO - 2021-04-13 21:54:19 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:54:19 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:54:19 --> Utf8 Class Initialized
INFO - 2021-04-13 21:54:19 --> URI Class Initialized
INFO - 2021-04-13 21:54:19 --> Router Class Initialized
INFO - 2021-04-13 21:54:19 --> Output Class Initialized
INFO - 2021-04-13 21:54:19 --> Security Class Initialized
DEBUG - 2021-04-13 21:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:54:19 --> Input Class Initialized
INFO - 2021-04-13 21:54:19 --> Language Class Initialized
ERROR - 2021-04-13 21:54:19 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 21:54:19 --> Config Class Initialized
INFO - 2021-04-13 21:54:19 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:54:19 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:54:19 --> Utf8 Class Initialized
INFO - 2021-04-13 21:54:19 --> URI Class Initialized
INFO - 2021-04-13 21:54:19 --> Router Class Initialized
INFO - 2021-04-13 21:54:19 --> Output Class Initialized
INFO - 2021-04-13 21:54:19 --> Security Class Initialized
DEBUG - 2021-04-13 21:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:54:19 --> Input Class Initialized
INFO - 2021-04-13 21:54:19 --> Language Class Initialized
ERROR - 2021-04-13 21:54:19 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 21:54:19 --> Config Class Initialized
INFO - 2021-04-13 21:54:19 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:54:19 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:54:19 --> Utf8 Class Initialized
INFO - 2021-04-13 21:54:19 --> URI Class Initialized
INFO - 2021-04-13 21:54:19 --> Router Class Initialized
INFO - 2021-04-13 21:54:19 --> Output Class Initialized
INFO - 2021-04-13 21:54:19 --> Security Class Initialized
DEBUG - 2021-04-13 21:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:54:19 --> Input Class Initialized
INFO - 2021-04-13 21:54:19 --> Language Class Initialized
ERROR - 2021-04-13 21:54:19 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 21:54:19 --> Config Class Initialized
INFO - 2021-04-13 21:54:19 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:54:19 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:54:19 --> Utf8 Class Initialized
INFO - 2021-04-13 21:54:19 --> URI Class Initialized
INFO - 2021-04-13 21:54:19 --> Router Class Initialized
INFO - 2021-04-13 21:54:19 --> Output Class Initialized
INFO - 2021-04-13 21:54:19 --> Security Class Initialized
DEBUG - 2021-04-13 21:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:54:19 --> Input Class Initialized
INFO - 2021-04-13 21:54:19 --> Language Class Initialized
ERROR - 2021-04-13 21:54:19 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 21:54:19 --> Config Class Initialized
INFO - 2021-04-13 21:54:19 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:54:19 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:54:19 --> Utf8 Class Initialized
INFO - 2021-04-13 21:54:19 --> URI Class Initialized
INFO - 2021-04-13 21:54:19 --> Router Class Initialized
INFO - 2021-04-13 21:54:19 --> Output Class Initialized
INFO - 2021-04-13 21:54:19 --> Security Class Initialized
DEBUG - 2021-04-13 21:54:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:54:19 --> Input Class Initialized
INFO - 2021-04-13 21:54:19 --> Language Class Initialized
ERROR - 2021-04-13 21:54:19 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 21:54:20 --> Config Class Initialized
INFO - 2021-04-13 21:54:20 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:54:20 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:54:20 --> Utf8 Class Initialized
INFO - 2021-04-13 21:54:20 --> URI Class Initialized
INFO - 2021-04-13 21:54:20 --> Router Class Initialized
INFO - 2021-04-13 21:54:20 --> Output Class Initialized
INFO - 2021-04-13 21:54:20 --> Security Class Initialized
DEBUG - 2021-04-13 21:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:54:20 --> Input Class Initialized
INFO - 2021-04-13 21:54:20 --> Language Class Initialized
INFO - 2021-04-13 21:54:20 --> Loader Class Initialized
INFO - 2021-04-13 21:54:20 --> Helper loaded: url_helper
INFO - 2021-04-13 21:54:20 --> Helper loaded: form_helper
INFO - 2021-04-13 21:54:20 --> Helper loaded: common_helper
INFO - 2021-04-13 21:54:20 --> Helper loaded: util_helper
INFO - 2021-04-13 21:54:20 --> Database Driver Class Initialized
DEBUG - 2021-04-13 21:54:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 21:54:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 21:54:20 --> Form Validation Class Initialized
INFO - 2021-04-13 21:54:20 --> Controller Class Initialized
INFO - 2021-04-13 21:54:20 --> Model Class Initialized
INFO - 2021-04-13 21:54:20 --> Config Class Initialized
INFO - 2021-04-13 21:54:20 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:54:20 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:54:20 --> Utf8 Class Initialized
INFO - 2021-04-13 21:54:20 --> URI Class Initialized
INFO - 2021-04-13 21:54:20 --> Router Class Initialized
INFO - 2021-04-13 21:54:20 --> Output Class Initialized
INFO - 2021-04-13 21:54:20 --> Security Class Initialized
DEBUG - 2021-04-13 21:54:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:54:20 --> Input Class Initialized
INFO - 2021-04-13 21:54:20 --> Language Class Initialized
INFO - 2021-04-13 21:54:20 --> Loader Class Initialized
INFO - 2021-04-13 21:54:20 --> Helper loaded: url_helper
INFO - 2021-04-13 21:54:20 --> Helper loaded: form_helper
INFO - 2021-04-13 21:54:20 --> Helper loaded: common_helper
INFO - 2021-04-13 21:54:20 --> Helper loaded: util_helper
INFO - 2021-04-13 21:54:20 --> Database Driver Class Initialized
DEBUG - 2021-04-13 21:54:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 21:54:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 21:54:20 --> Form Validation Class Initialized
INFO - 2021-04-13 21:54:20 --> Controller Class Initialized
INFO - 2021-04-13 21:54:20 --> Model Class Initialized
INFO - 2021-04-13 21:54:20 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-13 21:54:20 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 21:54:20 --> Final output sent to browser
DEBUG - 2021-04-13 21:54:20 --> Total execution time: 0.0278
INFO - 2021-04-13 21:54:26 --> Config Class Initialized
INFO - 2021-04-13 21:54:26 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:54:26 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:54:26 --> Utf8 Class Initialized
INFO - 2021-04-13 21:54:26 --> URI Class Initialized
INFO - 2021-04-13 21:54:26 --> Router Class Initialized
INFO - 2021-04-13 21:54:26 --> Output Class Initialized
INFO - 2021-04-13 21:54:26 --> Security Class Initialized
DEBUG - 2021-04-13 21:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:54:26 --> Input Class Initialized
INFO - 2021-04-13 21:54:26 --> Language Class Initialized
INFO - 2021-04-13 21:54:26 --> Loader Class Initialized
INFO - 2021-04-13 21:54:26 --> Helper loaded: url_helper
INFO - 2021-04-13 21:54:26 --> Helper loaded: form_helper
INFO - 2021-04-13 21:54:26 --> Helper loaded: common_helper
INFO - 2021-04-13 21:54:26 --> Helper loaded: util_helper
INFO - 2021-04-13 21:54:26 --> Database Driver Class Initialized
DEBUG - 2021-04-13 21:54:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 21:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 21:54:26 --> Form Validation Class Initialized
INFO - 2021-04-13 21:54:26 --> Controller Class Initialized
INFO - 2021-04-13 21:54:26 --> Model Class Initialized
INFO - 2021-04-13 21:54:26 --> Config Class Initialized
INFO - 2021-04-13 21:54:26 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:54:26 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:54:26 --> Utf8 Class Initialized
INFO - 2021-04-13 21:54:26 --> URI Class Initialized
INFO - 2021-04-13 21:54:26 --> Router Class Initialized
INFO - 2021-04-13 21:54:26 --> Output Class Initialized
INFO - 2021-04-13 21:54:26 --> Security Class Initialized
DEBUG - 2021-04-13 21:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:54:26 --> Input Class Initialized
INFO - 2021-04-13 21:54:26 --> Language Class Initialized
INFO - 2021-04-13 21:54:26 --> Loader Class Initialized
INFO - 2021-04-13 21:54:26 --> Helper loaded: url_helper
INFO - 2021-04-13 21:54:26 --> Helper loaded: form_helper
INFO - 2021-04-13 21:54:26 --> Helper loaded: common_helper
INFO - 2021-04-13 21:54:26 --> Helper loaded: util_helper
INFO - 2021-04-13 21:54:26 --> Database Driver Class Initialized
DEBUG - 2021-04-13 21:54:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 21:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 21:54:26 --> Form Validation Class Initialized
INFO - 2021-04-13 21:54:26 --> Controller Class Initialized
INFO - 2021-04-13 21:54:26 --> Model Class Initialized
INFO - 2021-04-13 21:54:26 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-13 21:54:26 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 21:54:26 --> Final output sent to browser
DEBUG - 2021-04-13 21:54:26 --> Total execution time: 0.0264
INFO - 2021-04-13 21:54:27 --> Config Class Initialized
INFO - 2021-04-13 21:54:27 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:54:27 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:54:27 --> Utf8 Class Initialized
INFO - 2021-04-13 21:54:27 --> URI Class Initialized
INFO - 2021-04-13 21:54:27 --> Router Class Initialized
INFO - 2021-04-13 21:54:27 --> Output Class Initialized
INFO - 2021-04-13 21:54:27 --> Security Class Initialized
DEBUG - 2021-04-13 21:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:54:27 --> Input Class Initialized
INFO - 2021-04-13 21:54:27 --> Language Class Initialized
INFO - 2021-04-13 21:54:27 --> Loader Class Initialized
INFO - 2021-04-13 21:54:27 --> Helper loaded: url_helper
INFO - 2021-04-13 21:54:27 --> Helper loaded: form_helper
INFO - 2021-04-13 21:54:27 --> Helper loaded: common_helper
INFO - 2021-04-13 21:54:27 --> Helper loaded: util_helper
INFO - 2021-04-13 21:54:27 --> Database Driver Class Initialized
DEBUG - 2021-04-13 21:54:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 21:54:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 21:54:27 --> Form Validation Class Initialized
INFO - 2021-04-13 21:54:27 --> Controller Class Initialized
INFO - 2021-04-13 21:54:27 --> Model Class Initialized
INFO - 2021-04-13 21:54:27 --> Config Class Initialized
INFO - 2021-04-13 21:54:27 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:54:27 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:54:27 --> Utf8 Class Initialized
INFO - 2021-04-13 21:54:27 --> URI Class Initialized
INFO - 2021-04-13 21:54:27 --> Router Class Initialized
INFO - 2021-04-13 21:54:27 --> Output Class Initialized
INFO - 2021-04-13 21:54:27 --> Security Class Initialized
DEBUG - 2021-04-13 21:54:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:54:27 --> Input Class Initialized
INFO - 2021-04-13 21:54:27 --> Language Class Initialized
INFO - 2021-04-13 21:54:27 --> Loader Class Initialized
INFO - 2021-04-13 21:54:27 --> Helper loaded: url_helper
INFO - 2021-04-13 21:54:27 --> Helper loaded: form_helper
INFO - 2021-04-13 21:54:27 --> Helper loaded: common_helper
INFO - 2021-04-13 21:54:27 --> Helper loaded: util_helper
INFO - 2021-04-13 21:54:27 --> Database Driver Class Initialized
DEBUG - 2021-04-13 21:54:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 21:54:27 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 21:54:27 --> Form Validation Class Initialized
INFO - 2021-04-13 21:54:27 --> Controller Class Initialized
INFO - 2021-04-13 21:54:27 --> Model Class Initialized
INFO - 2021-04-13 21:54:27 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-13 21:54:27 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 21:54:27 --> Final output sent to browser
DEBUG - 2021-04-13 21:54:27 --> Total execution time: 0.0290
INFO - 2021-04-13 21:55:00 --> Config Class Initialized
INFO - 2021-04-13 21:55:00 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:55:00 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:55:00 --> Utf8 Class Initialized
INFO - 2021-04-13 21:55:00 --> URI Class Initialized
INFO - 2021-04-13 21:55:00 --> Router Class Initialized
INFO - 2021-04-13 21:55:00 --> Output Class Initialized
INFO - 2021-04-13 21:55:00 --> Security Class Initialized
DEBUG - 2021-04-13 21:55:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:55:00 --> Input Class Initialized
INFO - 2021-04-13 21:55:00 --> Language Class Initialized
INFO - 2021-04-13 21:55:00 --> Loader Class Initialized
INFO - 2021-04-13 21:55:00 --> Helper loaded: url_helper
INFO - 2021-04-13 21:55:00 --> Helper loaded: form_helper
INFO - 2021-04-13 21:55:00 --> Helper loaded: common_helper
INFO - 2021-04-13 21:55:00 --> Helper loaded: util_helper
INFO - 2021-04-13 21:55:00 --> Database Driver Class Initialized
DEBUG - 2021-04-13 21:55:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 21:55:00 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 21:55:00 --> Form Validation Class Initialized
INFO - 2021-04-13 21:55:00 --> Controller Class Initialized
INFO - 2021-04-13 21:55:00 --> Model Class Initialized
INFO - 2021-04-13 21:55:00 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 21:55:00 --> Final output sent to browser
DEBUG - 2021-04-13 21:55:00 --> Total execution time: 0.0321
INFO - 2021-04-13 21:55:01 --> Config Class Initialized
INFO - 2021-04-13 21:55:01 --> Hooks Class Initialized
INFO - 2021-04-13 21:55:01 --> Config Class Initialized
INFO - 2021-04-13 21:55:01 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:55:01 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:55:01 --> Utf8 Class Initialized
DEBUG - 2021-04-13 21:55:01 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:55:01 --> Utf8 Class Initialized
INFO - 2021-04-13 21:55:01 --> URI Class Initialized
INFO - 2021-04-13 21:55:01 --> URI Class Initialized
INFO - 2021-04-13 21:55:01 --> Router Class Initialized
INFO - 2021-04-13 21:55:01 --> Router Class Initialized
INFO - 2021-04-13 21:55:01 --> Output Class Initialized
INFO - 2021-04-13 21:55:01 --> Output Class Initialized
INFO - 2021-04-13 21:55:01 --> Security Class Initialized
INFO - 2021-04-13 21:55:01 --> Security Class Initialized
DEBUG - 2021-04-13 21:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:55:01 --> Input Class Initialized
INFO - 2021-04-13 21:55:01 --> Language Class Initialized
DEBUG - 2021-04-13 21:55:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:55:01 --> Input Class Initialized
INFO - 2021-04-13 21:55:01 --> Language Class Initialized
ERROR - 2021-04-13 21:55:01 --> 404 Page Not Found: Fasset/img
ERROR - 2021-04-13 21:55:01 --> 404 Page Not Found: Fasset/img
INFO - 2021-04-13 21:55:17 --> Config Class Initialized
INFO - 2021-04-13 21:55:17 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:55:17 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:55:17 --> Utf8 Class Initialized
INFO - 2021-04-13 21:55:17 --> URI Class Initialized
INFO - 2021-04-13 21:55:17 --> Router Class Initialized
INFO - 2021-04-13 21:55:17 --> Output Class Initialized
INFO - 2021-04-13 21:55:17 --> Security Class Initialized
DEBUG - 2021-04-13 21:55:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:55:17 --> Input Class Initialized
INFO - 2021-04-13 21:55:17 --> Language Class Initialized
INFO - 2021-04-13 21:55:17 --> Loader Class Initialized
INFO - 2021-04-13 21:55:17 --> Helper loaded: url_helper
INFO - 2021-04-13 21:55:17 --> Helper loaded: form_helper
INFO - 2021-04-13 21:55:17 --> Helper loaded: common_helper
INFO - 2021-04-13 21:55:17 --> Helper loaded: util_helper
INFO - 2021-04-13 21:55:17 --> Database Driver Class Initialized
DEBUG - 2021-04-13 21:55:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 21:55:17 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 21:55:17 --> Form Validation Class Initialized
INFO - 2021-04-13 21:55:17 --> Controller Class Initialized
INFO - 2021-04-13 21:55:17 --> Model Class Initialized
INFO - 2021-04-13 21:55:17 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 21:55:17 --> Final output sent to browser
DEBUG - 2021-04-13 21:55:17 --> Total execution time: 0.0249
INFO - 2021-04-13 21:55:32 --> Config Class Initialized
INFO - 2021-04-13 21:55:32 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:55:32 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:55:32 --> Utf8 Class Initialized
INFO - 2021-04-13 21:55:32 --> URI Class Initialized
INFO - 2021-04-13 21:55:32 --> Router Class Initialized
INFO - 2021-04-13 21:55:32 --> Output Class Initialized
INFO - 2021-04-13 21:55:32 --> Security Class Initialized
DEBUG - 2021-04-13 21:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:55:32 --> Input Class Initialized
INFO - 2021-04-13 21:55:32 --> Language Class Initialized
INFO - 2021-04-13 21:55:32 --> Loader Class Initialized
INFO - 2021-04-13 21:55:32 --> Helper loaded: url_helper
INFO - 2021-04-13 21:55:32 --> Helper loaded: form_helper
INFO - 2021-04-13 21:55:32 --> Helper loaded: common_helper
INFO - 2021-04-13 21:55:32 --> Helper loaded: util_helper
INFO - 2021-04-13 21:55:32 --> Database Driver Class Initialized
DEBUG - 2021-04-13 21:55:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 21:55:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 21:55:32 --> Form Validation Class Initialized
INFO - 2021-04-13 21:55:32 --> Controller Class Initialized
INFO - 2021-04-13 21:55:32 --> Model Class Initialized
INFO - 2021-04-13 21:55:32 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-04-13 21:55:32 --> Config Class Initialized
INFO - 2021-04-13 21:55:32 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:55:32 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:55:32 --> Utf8 Class Initialized
INFO - 2021-04-13 21:55:32 --> URI Class Initialized
INFO - 2021-04-13 21:55:32 --> Router Class Initialized
INFO - 2021-04-13 21:55:32 --> Output Class Initialized
INFO - 2021-04-13 21:55:32 --> Security Class Initialized
DEBUG - 2021-04-13 21:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:55:32 --> Input Class Initialized
INFO - 2021-04-13 21:55:32 --> Language Class Initialized
INFO - 2021-04-13 21:55:32 --> Loader Class Initialized
INFO - 2021-04-13 21:55:32 --> Helper loaded: url_helper
INFO - 2021-04-13 21:55:32 --> Helper loaded: form_helper
INFO - 2021-04-13 21:55:32 --> Helper loaded: common_helper
INFO - 2021-04-13 21:55:32 --> Helper loaded: util_helper
INFO - 2021-04-13 21:55:32 --> Database Driver Class Initialized
DEBUG - 2021-04-13 21:55:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 21:55:32 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 21:55:32 --> Form Validation Class Initialized
INFO - 2021-04-13 21:55:32 --> Controller Class Initialized
INFO - 2021-04-13 21:55:32 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-13 21:55:32 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 21:55:32 --> Final output sent to browser
DEBUG - 2021-04-13 21:55:32 --> Total execution time: 0.0259
INFO - 2021-04-13 21:55:32 --> Config Class Initialized
INFO - 2021-04-13 21:55:32 --> Config Class Initialized
INFO - 2021-04-13 21:55:32 --> Hooks Class Initialized
INFO - 2021-04-13 21:55:32 --> Config Class Initialized
INFO - 2021-04-13 21:55:32 --> Hooks Class Initialized
INFO - 2021-04-13 21:55:32 --> Config Class Initialized
INFO - 2021-04-13 21:55:32 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:55:32 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:55:32 --> Utf8 Class Initialized
DEBUG - 2021-04-13 21:55:32 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:55:32 --> Utf8 Class Initialized
DEBUG - 2021-04-13 21:55:32 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:55:32 --> Utf8 Class Initialized
INFO - 2021-04-13 21:55:32 --> URI Class Initialized
INFO - 2021-04-13 21:55:32 --> URI Class Initialized
INFO - 2021-04-13 21:55:32 --> URI Class Initialized
INFO - 2021-04-13 21:55:32 --> Router Class Initialized
INFO - 2021-04-13 21:55:32 --> Router Class Initialized
INFO - 2021-04-13 21:55:32 --> Router Class Initialized
INFO - 2021-04-13 21:55:32 --> Output Class Initialized
INFO - 2021-04-13 21:55:32 --> Output Class Initialized
INFO - 2021-04-13 21:55:32 --> Output Class Initialized
INFO - 2021-04-13 21:55:32 --> Security Class Initialized
INFO - 2021-04-13 21:55:32 --> Security Class Initialized
INFO - 2021-04-13 21:55:32 --> Security Class Initialized
DEBUG - 2021-04-13 21:55:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 21:55:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 21:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:55:32 --> Input Class Initialized
INFO - 2021-04-13 21:55:32 --> Input Class Initialized
INFO - 2021-04-13 21:55:32 --> Input Class Initialized
INFO - 2021-04-13 21:55:32 --> Language Class Initialized
INFO - 2021-04-13 21:55:32 --> Language Class Initialized
INFO - 2021-04-13 21:55:32 --> Language Class Initialized
ERROR - 2021-04-13 21:55:32 --> 404 Page Not Found: user/Assets/css
ERROR - 2021-04-13 21:55:32 --> 404 Page Not Found: user/Assets/css
ERROR - 2021-04-13 21:55:32 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 21:55:32 --> Hooks Class Initialized
INFO - 2021-04-13 21:55:32 --> Config Class Initialized
INFO - 2021-04-13 21:55:32 --> Config Class Initialized
DEBUG - 2021-04-13 21:55:32 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:55:32 --> Hooks Class Initialized
INFO - 2021-04-13 21:55:32 --> Utf8 Class Initialized
INFO - 2021-04-13 21:55:32 --> Hooks Class Initialized
INFO - 2021-04-13 21:55:32 --> URI Class Initialized
INFO - 2021-04-13 21:55:32 --> Config Class Initialized
DEBUG - 2021-04-13 21:55:32 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:55:32 --> Utf8 Class Initialized
INFO - 2021-04-13 21:55:32 --> Hooks Class Initialized
INFO - 2021-04-13 21:55:32 --> URI Class Initialized
INFO - 2021-04-13 21:55:32 --> Router Class Initialized
INFO - 2021-04-13 21:55:32 --> Router Class Initialized
INFO - 2021-04-13 21:55:32 --> Output Class Initialized
INFO - 2021-04-13 21:55:32 --> Output Class Initialized
INFO - 2021-04-13 21:55:32 --> Security Class Initialized
DEBUG - 2021-04-13 21:55:32 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:55:32 --> Security Class Initialized
INFO - 2021-04-13 21:55:32 --> Utf8 Class Initialized
DEBUG - 2021-04-13 21:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:55:32 --> Input Class Initialized
INFO - 2021-04-13 21:55:32 --> Language Class Initialized
DEBUG - 2021-04-13 21:55:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 21:55:32 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:55:32 --> Input Class Initialized
INFO - 2021-04-13 21:55:32 --> Utf8 Class Initialized
INFO - 2021-04-13 21:55:32 --> URI Class Initialized
ERROR - 2021-04-13 21:55:32 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 21:55:32 --> Language Class Initialized
INFO - 2021-04-13 21:55:32 --> URI Class Initialized
INFO - 2021-04-13 21:55:32 --> Router Class Initialized
INFO - 2021-04-13 21:55:32 --> Router Class Initialized
INFO - 2021-04-13 21:55:32 --> Output Class Initialized
INFO - 2021-04-13 21:55:32 --> Output Class Initialized
ERROR - 2021-04-13 21:55:32 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 21:55:32 --> Security Class Initialized
INFO - 2021-04-13 21:55:32 --> Security Class Initialized
DEBUG - 2021-04-13 21:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:55:32 --> Input Class Initialized
DEBUG - 2021-04-13 21:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:55:32 --> Input Class Initialized
INFO - 2021-04-13 21:55:32 --> Language Class Initialized
INFO - 2021-04-13 21:55:32 --> Language Class Initialized
ERROR - 2021-04-13 21:55:32 --> 404 Page Not Found: user/Assets/js
ERROR - 2021-04-13 21:55:33 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 21:55:33 --> Config Class Initialized
INFO - 2021-04-13 21:55:33 --> Hooks Class Initialized
INFO - 2021-04-13 21:55:33 --> Config Class Initialized
INFO - 2021-04-13 21:55:33 --> Hooks Class Initialized
INFO - 2021-04-13 21:55:33 --> Config Class Initialized
INFO - 2021-04-13 21:55:33 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:55:33 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:55:33 --> Utf8 Class Initialized
INFO - 2021-04-13 21:55:33 --> URI Class Initialized
INFO - 2021-04-13 21:55:33 --> Router Class Initialized
DEBUG - 2021-04-13 21:55:33 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:55:33 --> Output Class Initialized
INFO - 2021-04-13 21:55:33 --> Utf8 Class Initialized
INFO - 2021-04-13 21:55:33 --> Security Class Initialized
INFO - 2021-04-13 21:55:33 --> URI Class Initialized
DEBUG - 2021-04-13 21:55:33 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:55:33 --> Utf8 Class Initialized
DEBUG - 2021-04-13 21:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:55:33 --> URI Class Initialized
INFO - 2021-04-13 21:55:33 --> Input Class Initialized
INFO - 2021-04-13 21:55:33 --> Router Class Initialized
INFO - 2021-04-13 21:55:33 --> Language Class Initialized
INFO - 2021-04-13 21:55:33 --> Router Class Initialized
INFO - 2021-04-13 21:55:33 --> Output Class Initialized
ERROR - 2021-04-13 21:55:33 --> 404 Page Not Found: user/Assets/img
INFO - 2021-04-13 21:55:33 --> Output Class Initialized
INFO - 2021-04-13 21:55:33 --> Security Class Initialized
INFO - 2021-04-13 21:55:33 --> Security Class Initialized
DEBUG - 2021-04-13 21:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:55:33 --> Input Class Initialized
INFO - 2021-04-13 21:55:33 --> Config Class Initialized
INFO - 2021-04-13 21:55:33 --> Language Class Initialized
INFO - 2021-04-13 21:55:33 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:55:33 --> Input Class Initialized
INFO - 2021-04-13 21:55:33 --> Language Class Initialized
ERROR - 2021-04-13 21:55:33 --> 404 Page Not Found: user/Assets/img
DEBUG - 2021-04-13 21:55:33 --> UTF-8 Support Enabled
ERROR - 2021-04-13 21:55:33 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 21:55:33 --> Utf8 Class Initialized
INFO - 2021-04-13 21:55:33 --> URI Class Initialized
INFO - 2021-04-13 21:55:33 --> Router Class Initialized
INFO - 2021-04-13 21:55:33 --> Output Class Initialized
INFO - 2021-04-13 21:55:33 --> Security Class Initialized
DEBUG - 2021-04-13 21:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:55:33 --> Input Class Initialized
INFO - 2021-04-13 21:55:33 --> Language Class Initialized
ERROR - 2021-04-13 21:55:33 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 21:55:33 --> Config Class Initialized
INFO - 2021-04-13 21:55:33 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:55:33 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:55:33 --> Utf8 Class Initialized
INFO - 2021-04-13 21:55:33 --> URI Class Initialized
INFO - 2021-04-13 21:55:33 --> Router Class Initialized
INFO - 2021-04-13 21:55:33 --> Output Class Initialized
INFO - 2021-04-13 21:55:33 --> Security Class Initialized
DEBUG - 2021-04-13 21:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:55:33 --> Input Class Initialized
INFO - 2021-04-13 21:55:33 --> Language Class Initialized
ERROR - 2021-04-13 21:55:33 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 21:55:33 --> Config Class Initialized
INFO - 2021-04-13 21:55:33 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:55:33 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:55:33 --> Utf8 Class Initialized
INFO - 2021-04-13 21:55:33 --> URI Class Initialized
INFO - 2021-04-13 21:55:33 --> Router Class Initialized
INFO - 2021-04-13 21:55:33 --> Output Class Initialized
INFO - 2021-04-13 21:55:33 --> Security Class Initialized
DEBUG - 2021-04-13 21:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:55:33 --> Input Class Initialized
INFO - 2021-04-13 21:55:33 --> Language Class Initialized
ERROR - 2021-04-13 21:55:33 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 21:55:33 --> Config Class Initialized
INFO - 2021-04-13 21:55:33 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:55:33 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:55:33 --> Utf8 Class Initialized
INFO - 2021-04-13 21:55:33 --> URI Class Initialized
INFO - 2021-04-13 21:55:33 --> Router Class Initialized
INFO - 2021-04-13 21:55:33 --> Output Class Initialized
INFO - 2021-04-13 21:55:33 --> Security Class Initialized
DEBUG - 2021-04-13 21:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:55:33 --> Input Class Initialized
INFO - 2021-04-13 21:55:33 --> Language Class Initialized
ERROR - 2021-04-13 21:55:33 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 21:55:33 --> Config Class Initialized
INFO - 2021-04-13 21:55:33 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:55:33 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:55:33 --> Utf8 Class Initialized
INFO - 2021-04-13 21:55:33 --> URI Class Initialized
INFO - 2021-04-13 21:55:33 --> Router Class Initialized
INFO - 2021-04-13 21:55:33 --> Output Class Initialized
INFO - 2021-04-13 21:55:33 --> Security Class Initialized
DEBUG - 2021-04-13 21:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:55:33 --> Input Class Initialized
INFO - 2021-04-13 21:55:33 --> Language Class Initialized
ERROR - 2021-04-13 21:55:33 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 21:55:33 --> Config Class Initialized
INFO - 2021-04-13 21:55:33 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:55:33 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:55:33 --> Utf8 Class Initialized
INFO - 2021-04-13 21:55:33 --> URI Class Initialized
INFO - 2021-04-13 21:55:33 --> Router Class Initialized
INFO - 2021-04-13 21:55:33 --> Output Class Initialized
INFO - 2021-04-13 21:55:33 --> Security Class Initialized
DEBUG - 2021-04-13 21:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:55:33 --> Input Class Initialized
INFO - 2021-04-13 21:55:33 --> Language Class Initialized
ERROR - 2021-04-13 21:55:33 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 21:55:33 --> Config Class Initialized
INFO - 2021-04-13 21:55:33 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:55:33 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:55:33 --> Utf8 Class Initialized
INFO - 2021-04-13 21:55:33 --> URI Class Initialized
INFO - 2021-04-13 21:55:33 --> Router Class Initialized
INFO - 2021-04-13 21:55:33 --> Output Class Initialized
INFO - 2021-04-13 21:55:33 --> Security Class Initialized
DEBUG - 2021-04-13 21:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:55:33 --> Input Class Initialized
INFO - 2021-04-13 21:55:33 --> Language Class Initialized
ERROR - 2021-04-13 21:55:33 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 21:55:33 --> Config Class Initialized
INFO - 2021-04-13 21:55:33 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:55:33 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:55:33 --> Utf8 Class Initialized
INFO - 2021-04-13 21:55:33 --> URI Class Initialized
INFO - 2021-04-13 21:55:33 --> Router Class Initialized
INFO - 2021-04-13 21:55:33 --> Output Class Initialized
INFO - 2021-04-13 21:55:33 --> Security Class Initialized
DEBUG - 2021-04-13 21:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:55:33 --> Input Class Initialized
INFO - 2021-04-13 21:55:33 --> Language Class Initialized
ERROR - 2021-04-13 21:55:33 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 21:55:33 --> Config Class Initialized
INFO - 2021-04-13 21:55:33 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:55:33 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:55:33 --> Utf8 Class Initialized
INFO - 2021-04-13 21:55:33 --> URI Class Initialized
INFO - 2021-04-13 21:55:33 --> Router Class Initialized
INFO - 2021-04-13 21:55:33 --> Output Class Initialized
INFO - 2021-04-13 21:55:33 --> Security Class Initialized
DEBUG - 2021-04-13 21:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:55:33 --> Input Class Initialized
INFO - 2021-04-13 21:55:33 --> Language Class Initialized
ERROR - 2021-04-13 21:55:33 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 21:55:33 --> Config Class Initialized
INFO - 2021-04-13 21:55:33 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:55:33 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:55:33 --> Utf8 Class Initialized
INFO - 2021-04-13 21:55:33 --> URI Class Initialized
INFO - 2021-04-13 21:55:33 --> Router Class Initialized
INFO - 2021-04-13 21:55:33 --> Output Class Initialized
INFO - 2021-04-13 21:55:33 --> Security Class Initialized
DEBUG - 2021-04-13 21:55:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:55:33 --> Input Class Initialized
INFO - 2021-04-13 21:55:33 --> Language Class Initialized
ERROR - 2021-04-13 21:55:33 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 21:55:34 --> Config Class Initialized
INFO - 2021-04-13 21:55:34 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:55:34 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:55:34 --> Utf8 Class Initialized
INFO - 2021-04-13 21:55:34 --> URI Class Initialized
INFO - 2021-04-13 21:55:34 --> Router Class Initialized
INFO - 2021-04-13 21:55:34 --> Output Class Initialized
INFO - 2021-04-13 21:55:34 --> Security Class Initialized
DEBUG - 2021-04-13 21:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:55:34 --> Input Class Initialized
INFO - 2021-04-13 21:55:34 --> Language Class Initialized
INFO - 2021-04-13 21:55:34 --> Loader Class Initialized
INFO - 2021-04-13 21:55:34 --> Helper loaded: url_helper
INFO - 2021-04-13 21:55:34 --> Helper loaded: form_helper
INFO - 2021-04-13 21:55:34 --> Helper loaded: common_helper
INFO - 2021-04-13 21:55:34 --> Helper loaded: util_helper
INFO - 2021-04-13 21:55:34 --> Database Driver Class Initialized
DEBUG - 2021-04-13 21:55:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 21:55:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 21:55:34 --> Form Validation Class Initialized
INFO - 2021-04-13 21:55:34 --> Controller Class Initialized
INFO - 2021-04-13 21:55:34 --> Model Class Initialized
INFO - 2021-04-13 21:55:34 --> Config Class Initialized
INFO - 2021-04-13 21:55:34 --> Hooks Class Initialized
DEBUG - 2021-04-13 21:55:34 --> UTF-8 Support Enabled
INFO - 2021-04-13 21:55:34 --> Utf8 Class Initialized
INFO - 2021-04-13 21:55:34 --> URI Class Initialized
INFO - 2021-04-13 21:55:34 --> Router Class Initialized
INFO - 2021-04-13 21:55:34 --> Output Class Initialized
INFO - 2021-04-13 21:55:34 --> Security Class Initialized
DEBUG - 2021-04-13 21:55:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 21:55:34 --> Input Class Initialized
INFO - 2021-04-13 21:55:34 --> Language Class Initialized
INFO - 2021-04-13 21:55:34 --> Loader Class Initialized
INFO - 2021-04-13 21:55:34 --> Helper loaded: url_helper
INFO - 2021-04-13 21:55:34 --> Helper loaded: form_helper
INFO - 2021-04-13 21:55:34 --> Helper loaded: common_helper
INFO - 2021-04-13 21:55:34 --> Helper loaded: util_helper
INFO - 2021-04-13 21:55:34 --> Database Driver Class Initialized
DEBUG - 2021-04-13 21:55:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 21:55:34 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 21:55:34 --> Form Validation Class Initialized
INFO - 2021-04-13 21:55:34 --> Controller Class Initialized
INFO - 2021-04-13 21:55:34 --> Model Class Initialized
INFO - 2021-04-13 21:55:34 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-13 21:55:34 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 21:55:34 --> Final output sent to browser
DEBUG - 2021-04-13 21:55:34 --> Total execution time: 0.0272
INFO - 2021-04-13 22:08:29 --> Config Class Initialized
INFO - 2021-04-13 22:08:29 --> Hooks Class Initialized
DEBUG - 2021-04-13 22:08:29 --> UTF-8 Support Enabled
INFO - 2021-04-13 22:08:29 --> Utf8 Class Initialized
INFO - 2021-04-13 22:08:29 --> URI Class Initialized
INFO - 2021-04-13 22:08:29 --> Router Class Initialized
INFO - 2021-04-13 22:08:29 --> Output Class Initialized
INFO - 2021-04-13 22:08:29 --> Security Class Initialized
DEBUG - 2021-04-13 22:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 22:08:29 --> Input Class Initialized
INFO - 2021-04-13 22:08:29 --> Language Class Initialized
INFO - 2021-04-13 22:08:29 --> Loader Class Initialized
INFO - 2021-04-13 22:08:29 --> Helper loaded: url_helper
INFO - 2021-04-13 22:08:29 --> Helper loaded: form_helper
INFO - 2021-04-13 22:08:29 --> Helper loaded: common_helper
INFO - 2021-04-13 22:08:29 --> Helper loaded: util_helper
INFO - 2021-04-13 22:08:29 --> Database Driver Class Initialized
DEBUG - 2021-04-13 22:08:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 22:08:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 22:08:29 --> Form Validation Class Initialized
INFO - 2021-04-13 22:08:29 --> Controller Class Initialized
INFO - 2021-04-13 22:08:29 --> Model Class Initialized
INFO - 2021-04-13 22:08:29 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 22:08:29 --> Final output sent to browser
DEBUG - 2021-04-13 22:08:29 --> Total execution time: 0.0256
INFO - 2021-04-13 22:08:29 --> Config Class Initialized
INFO - 2021-04-13 22:08:29 --> Hooks Class Initialized
INFO - 2021-04-13 22:08:29 --> Config Class Initialized
INFO - 2021-04-13 22:08:29 --> Hooks Class Initialized
DEBUG - 2021-04-13 22:08:29 --> UTF-8 Support Enabled
INFO - 2021-04-13 22:08:29 --> Utf8 Class Initialized
DEBUG - 2021-04-13 22:08:29 --> UTF-8 Support Enabled
INFO - 2021-04-13 22:08:29 --> Utf8 Class Initialized
INFO - 2021-04-13 22:08:29 --> URI Class Initialized
INFO - 2021-04-13 22:08:29 --> URI Class Initialized
INFO - 2021-04-13 22:08:29 --> Router Class Initialized
INFO - 2021-04-13 22:08:29 --> Router Class Initialized
INFO - 2021-04-13 22:08:29 --> Output Class Initialized
INFO - 2021-04-13 22:08:29 --> Output Class Initialized
INFO - 2021-04-13 22:08:29 --> Security Class Initialized
INFO - 2021-04-13 22:08:29 --> Security Class Initialized
DEBUG - 2021-04-13 22:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 22:08:29 --> Input Class Initialized
DEBUG - 2021-04-13 22:08:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 22:08:29 --> Input Class Initialized
INFO - 2021-04-13 22:08:29 --> Language Class Initialized
INFO - 2021-04-13 22:08:29 --> Language Class Initialized
ERROR - 2021-04-13 22:08:29 --> 404 Page Not Found: Fasset/img
ERROR - 2021-04-13 22:08:29 --> 404 Page Not Found: Fasset/img
INFO - 2021-04-13 22:08:52 --> Config Class Initialized
INFO - 2021-04-13 22:08:52 --> Hooks Class Initialized
DEBUG - 2021-04-13 22:08:52 --> UTF-8 Support Enabled
INFO - 2021-04-13 22:08:52 --> Utf8 Class Initialized
INFO - 2021-04-13 22:08:52 --> URI Class Initialized
INFO - 2021-04-13 22:08:52 --> Router Class Initialized
INFO - 2021-04-13 22:08:52 --> Output Class Initialized
INFO - 2021-04-13 22:08:52 --> Security Class Initialized
DEBUG - 2021-04-13 22:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 22:08:52 --> Input Class Initialized
INFO - 2021-04-13 22:08:52 --> Language Class Initialized
INFO - 2021-04-13 22:08:52 --> Loader Class Initialized
INFO - 2021-04-13 22:08:52 --> Helper loaded: url_helper
INFO - 2021-04-13 22:08:52 --> Helper loaded: form_helper
INFO - 2021-04-13 22:08:52 --> Helper loaded: common_helper
INFO - 2021-04-13 22:08:52 --> Helper loaded: util_helper
INFO - 2021-04-13 22:08:52 --> Database Driver Class Initialized
DEBUG - 2021-04-13 22:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 22:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 22:08:52 --> Form Validation Class Initialized
INFO - 2021-04-13 22:08:52 --> Controller Class Initialized
INFO - 2021-04-13 22:08:52 --> Model Class Initialized
INFO - 2021-04-13 22:08:52 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-04-13 22:08:52 --> Config Class Initialized
INFO - 2021-04-13 22:08:52 --> Hooks Class Initialized
DEBUG - 2021-04-13 22:08:52 --> UTF-8 Support Enabled
INFO - 2021-04-13 22:08:52 --> Utf8 Class Initialized
INFO - 2021-04-13 22:08:52 --> URI Class Initialized
INFO - 2021-04-13 22:08:52 --> Router Class Initialized
INFO - 2021-04-13 22:08:52 --> Output Class Initialized
INFO - 2021-04-13 22:08:52 --> Security Class Initialized
DEBUG - 2021-04-13 22:08:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 22:08:52 --> Input Class Initialized
INFO - 2021-04-13 22:08:52 --> Language Class Initialized
INFO - 2021-04-13 22:08:52 --> Loader Class Initialized
INFO - 2021-04-13 22:08:52 --> Helper loaded: url_helper
INFO - 2021-04-13 22:08:52 --> Helper loaded: form_helper
INFO - 2021-04-13 22:08:52 --> Helper loaded: common_helper
INFO - 2021-04-13 22:08:52 --> Helper loaded: util_helper
INFO - 2021-04-13 22:08:52 --> Database Driver Class Initialized
DEBUG - 2021-04-13 22:08:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 22:08:52 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 22:08:52 --> Form Validation Class Initialized
INFO - 2021-04-13 22:08:52 --> Controller Class Initialized
INFO - 2021-04-13 22:08:52 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-13 22:08:52 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 22:08:52 --> Final output sent to browser
DEBUG - 2021-04-13 22:08:52 --> Total execution time: 0.0268
INFO - 2021-04-13 22:08:53 --> Config Class Initialized
INFO - 2021-04-13 22:08:53 --> Hooks Class Initialized
INFO - 2021-04-13 22:08:53 --> Config Class Initialized
INFO - 2021-04-13 22:08:53 --> Hooks Class Initialized
INFO - 2021-04-13 22:08:53 --> Config Class Initialized
INFO - 2021-04-13 22:08:53 --> Hooks Class Initialized
INFO - 2021-04-13 22:08:53 --> Config Class Initialized
DEBUG - 2021-04-13 22:08:53 --> UTF-8 Support Enabled
INFO - 2021-04-13 22:08:53 --> Hooks Class Initialized
INFO - 2021-04-13 22:08:53 --> Utf8 Class Initialized
DEBUG - 2021-04-13 22:08:53 --> UTF-8 Support Enabled
INFO - 2021-04-13 22:08:53 --> Utf8 Class Initialized
INFO - 2021-04-13 22:08:53 --> URI Class Initialized
INFO - 2021-04-13 22:08:53 --> URI Class Initialized
DEBUG - 2021-04-13 22:08:53 --> UTF-8 Support Enabled
INFO - 2021-04-13 22:08:53 --> Utf8 Class Initialized
INFO - 2021-04-13 22:08:53 --> Router Class Initialized
INFO - 2021-04-13 22:08:53 --> Router Class Initialized
INFO - 2021-04-13 22:08:53 --> URI Class Initialized
INFO - 2021-04-13 22:08:53 --> Output Class Initialized
INFO - 2021-04-13 22:08:53 --> Router Class Initialized
INFO - 2021-04-13 22:08:53 --> Output Class Initialized
INFO - 2021-04-13 22:08:53 --> Security Class Initialized
INFO - 2021-04-13 22:08:53 --> Output Class Initialized
DEBUG - 2021-04-13 22:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 22:08:53 --> Security Class Initialized
INFO - 2021-04-13 22:08:53 --> Input Class Initialized
DEBUG - 2021-04-13 22:08:53 --> UTF-8 Support Enabled
INFO - 2021-04-13 22:08:53 --> Utf8 Class Initialized
INFO - 2021-04-13 22:08:53 --> Language Class Initialized
DEBUG - 2021-04-13 22:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 22:08:53 --> Input Class Initialized
INFO - 2021-04-13 22:08:53 --> Language Class Initialized
INFO - 2021-04-13 22:08:53 --> URI Class Initialized
ERROR - 2021-04-13 22:08:53 --> 404 Page Not Found: user/Assets/css
ERROR - 2021-04-13 22:08:53 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 22:08:53 --> Router Class Initialized
INFO - 2021-04-13 22:08:53 --> Output Class Initialized
INFO - 2021-04-13 22:08:53 --> Security Class Initialized
INFO - 2021-04-13 22:08:53 --> Security Class Initialized
DEBUG - 2021-04-13 22:08:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 22:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 22:08:53 --> Input Class Initialized
INFO - 2021-04-13 22:08:53 --> Input Class Initialized
INFO - 2021-04-13 22:08:53 --> Language Class Initialized
INFO - 2021-04-13 22:08:53 --> Language Class Initialized
ERROR - 2021-04-13 22:08:53 --> 404 Page Not Found: user/Assets/css
ERROR - 2021-04-13 22:08:53 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 22:08:53 --> Config Class Initialized
INFO - 2021-04-13 22:08:53 --> Config Class Initialized
INFO - 2021-04-13 22:08:53 --> Hooks Class Initialized
INFO - 2021-04-13 22:08:53 --> Hooks Class Initialized
DEBUG - 2021-04-13 22:08:53 --> UTF-8 Support Enabled
INFO - 2021-04-13 22:08:53 --> Utf8 Class Initialized
DEBUG - 2021-04-13 22:08:53 --> UTF-8 Support Enabled
INFO - 2021-04-13 22:08:53 --> Utf8 Class Initialized
INFO - 2021-04-13 22:08:53 --> URI Class Initialized
INFO - 2021-04-13 22:08:53 --> URI Class Initialized
INFO - 2021-04-13 22:08:53 --> Config Class Initialized
INFO - 2021-04-13 22:08:53 --> Hooks Class Initialized
INFO - 2021-04-13 22:08:53 --> Router Class Initialized
INFO - 2021-04-13 22:08:53 --> Config Class Initialized
INFO - 2021-04-13 22:08:53 --> Hooks Class Initialized
INFO - 2021-04-13 22:08:53 --> Router Class Initialized
INFO - 2021-04-13 22:08:53 --> Output Class Initialized
DEBUG - 2021-04-13 22:08:53 --> UTF-8 Support Enabled
INFO - 2021-04-13 22:08:53 --> Output Class Initialized
INFO - 2021-04-13 22:08:53 --> Utf8 Class Initialized
DEBUG - 2021-04-13 22:08:53 --> UTF-8 Support Enabled
INFO - 2021-04-13 22:08:53 --> Security Class Initialized
INFO - 2021-04-13 22:08:53 --> Utf8 Class Initialized
INFO - 2021-04-13 22:08:53 --> Security Class Initialized
INFO - 2021-04-13 22:08:53 --> URI Class Initialized
DEBUG - 2021-04-13 22:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 22:08:53 --> URI Class Initialized
INFO - 2021-04-13 22:08:53 --> Input Class Initialized
DEBUG - 2021-04-13 22:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 22:08:53 --> Router Class Initialized
INFO - 2021-04-13 22:08:53 --> Input Class Initialized
INFO - 2021-04-13 22:08:53 --> Router Class Initialized
INFO - 2021-04-13 22:08:53 --> Language Class Initialized
INFO - 2021-04-13 22:08:53 --> Output Class Initialized
INFO - 2021-04-13 22:08:53 --> Output Class Initialized
ERROR - 2021-04-13 22:08:53 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 22:08:53 --> Security Class Initialized
INFO - 2021-04-13 22:08:53 --> Security Class Initialized
DEBUG - 2021-04-13 22:08:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 22:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 22:08:53 --> Input Class Initialized
INFO - 2021-04-13 22:08:53 --> Input Class Initialized
INFO - 2021-04-13 22:08:53 --> Language Class Initialized
INFO - 2021-04-13 22:08:53 --> Language Class Initialized
ERROR - 2021-04-13 22:08:53 --> 404 Page Not Found: user/Assets/img
INFO - 2021-04-13 22:08:53 --> Language Class Initialized
ERROR - 2021-04-13 22:08:53 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 22:08:53 --> Config Class Initialized
ERROR - 2021-04-13 22:08:53 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 22:08:53 --> Hooks Class Initialized
DEBUG - 2021-04-13 22:08:53 --> UTF-8 Support Enabled
INFO - 2021-04-13 22:08:53 --> Utf8 Class Initialized
INFO - 2021-04-13 22:08:53 --> URI Class Initialized
INFO - 2021-04-13 22:08:53 --> Config Class Initialized
INFO - 2021-04-13 22:08:53 --> Hooks Class Initialized
INFO - 2021-04-13 22:08:53 --> Router Class Initialized
INFO - 2021-04-13 22:08:53 --> Config Class Initialized
INFO - 2021-04-13 22:08:53 --> Hooks Class Initialized
INFO - 2021-04-13 22:08:53 --> Output Class Initialized
DEBUG - 2021-04-13 22:08:53 --> UTF-8 Support Enabled
INFO - 2021-04-13 22:08:53 --> Utf8 Class Initialized
INFO - 2021-04-13 22:08:53 --> Security Class Initialized
INFO - 2021-04-13 22:08:53 --> URI Class Initialized
DEBUG - 2021-04-13 22:08:53 --> UTF-8 Support Enabled
INFO - 2021-04-13 22:08:53 --> Router Class Initialized
DEBUG - 2021-04-13 22:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 22:08:53 --> Utf8 Class Initialized
INFO - 2021-04-13 22:08:53 --> Input Class Initialized
INFO - 2021-04-13 22:08:53 --> Output Class Initialized
INFO - 2021-04-13 22:08:53 --> Language Class Initialized
INFO - 2021-04-13 22:08:53 --> URI Class Initialized
INFO - 2021-04-13 22:08:53 --> Security Class Initialized
ERROR - 2021-04-13 22:08:53 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 22:08:53 --> Router Class Initialized
DEBUG - 2021-04-13 22:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 22:08:53 --> Input Class Initialized
INFO - 2021-04-13 22:08:53 --> Language Class Initialized
INFO - 2021-04-13 22:08:53 --> Output Class Initialized
ERROR - 2021-04-13 22:08:53 --> 404 Page Not Found: user/Assets/img
INFO - 2021-04-13 22:08:53 --> Security Class Initialized
DEBUG - 2021-04-13 22:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 22:08:53 --> Input Class Initialized
INFO - 2021-04-13 22:08:53 --> Language Class Initialized
ERROR - 2021-04-13 22:08:53 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 22:08:53 --> Config Class Initialized
INFO - 2021-04-13 22:08:53 --> Hooks Class Initialized
DEBUG - 2021-04-13 22:08:53 --> UTF-8 Support Enabled
INFO - 2021-04-13 22:08:53 --> Utf8 Class Initialized
INFO - 2021-04-13 22:08:53 --> URI Class Initialized
INFO - 2021-04-13 22:08:53 --> Router Class Initialized
INFO - 2021-04-13 22:08:53 --> Output Class Initialized
INFO - 2021-04-13 22:08:53 --> Security Class Initialized
DEBUG - 2021-04-13 22:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 22:08:53 --> Input Class Initialized
INFO - 2021-04-13 22:08:53 --> Language Class Initialized
ERROR - 2021-04-13 22:08:53 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 22:08:53 --> Config Class Initialized
INFO - 2021-04-13 22:08:53 --> Hooks Class Initialized
DEBUG - 2021-04-13 22:08:53 --> UTF-8 Support Enabled
INFO - 2021-04-13 22:08:53 --> Utf8 Class Initialized
INFO - 2021-04-13 22:08:53 --> URI Class Initialized
INFO - 2021-04-13 22:08:53 --> Router Class Initialized
INFO - 2021-04-13 22:08:53 --> Output Class Initialized
INFO - 2021-04-13 22:08:53 --> Security Class Initialized
DEBUG - 2021-04-13 22:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 22:08:53 --> Input Class Initialized
INFO - 2021-04-13 22:08:53 --> Language Class Initialized
ERROR - 2021-04-13 22:08:53 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 22:08:53 --> Config Class Initialized
INFO - 2021-04-13 22:08:53 --> Hooks Class Initialized
DEBUG - 2021-04-13 22:08:53 --> UTF-8 Support Enabled
INFO - 2021-04-13 22:08:53 --> Utf8 Class Initialized
INFO - 2021-04-13 22:08:53 --> URI Class Initialized
INFO - 2021-04-13 22:08:53 --> Router Class Initialized
INFO - 2021-04-13 22:08:53 --> Output Class Initialized
INFO - 2021-04-13 22:08:53 --> Security Class Initialized
DEBUG - 2021-04-13 22:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 22:08:53 --> Input Class Initialized
INFO - 2021-04-13 22:08:53 --> Language Class Initialized
ERROR - 2021-04-13 22:08:53 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 22:08:53 --> Config Class Initialized
INFO - 2021-04-13 22:08:53 --> Hooks Class Initialized
DEBUG - 2021-04-13 22:08:53 --> UTF-8 Support Enabled
INFO - 2021-04-13 22:08:53 --> Utf8 Class Initialized
INFO - 2021-04-13 22:08:53 --> URI Class Initialized
INFO - 2021-04-13 22:08:53 --> Router Class Initialized
INFO - 2021-04-13 22:08:53 --> Output Class Initialized
INFO - 2021-04-13 22:08:53 --> Security Class Initialized
DEBUG - 2021-04-13 22:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 22:08:53 --> Input Class Initialized
INFO - 2021-04-13 22:08:53 --> Language Class Initialized
ERROR - 2021-04-13 22:08:53 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 22:08:53 --> Config Class Initialized
INFO - 2021-04-13 22:08:53 --> Hooks Class Initialized
DEBUG - 2021-04-13 22:08:53 --> UTF-8 Support Enabled
INFO - 2021-04-13 22:08:53 --> Utf8 Class Initialized
INFO - 2021-04-13 22:08:53 --> URI Class Initialized
INFO - 2021-04-13 22:08:53 --> Router Class Initialized
INFO - 2021-04-13 22:08:53 --> Output Class Initialized
INFO - 2021-04-13 22:08:53 --> Security Class Initialized
DEBUG - 2021-04-13 22:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 22:08:53 --> Input Class Initialized
INFO - 2021-04-13 22:08:53 --> Language Class Initialized
ERROR - 2021-04-13 22:08:53 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 22:08:53 --> Config Class Initialized
INFO - 2021-04-13 22:08:53 --> Hooks Class Initialized
DEBUG - 2021-04-13 22:08:53 --> UTF-8 Support Enabled
INFO - 2021-04-13 22:08:53 --> Utf8 Class Initialized
INFO - 2021-04-13 22:08:53 --> URI Class Initialized
INFO - 2021-04-13 22:08:53 --> Router Class Initialized
INFO - 2021-04-13 22:08:53 --> Output Class Initialized
INFO - 2021-04-13 22:08:53 --> Security Class Initialized
DEBUG - 2021-04-13 22:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 22:08:53 --> Input Class Initialized
INFO - 2021-04-13 22:08:53 --> Language Class Initialized
ERROR - 2021-04-13 22:08:53 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 22:08:53 --> Config Class Initialized
INFO - 2021-04-13 22:08:53 --> Hooks Class Initialized
DEBUG - 2021-04-13 22:08:53 --> UTF-8 Support Enabled
INFO - 2021-04-13 22:08:53 --> Utf8 Class Initialized
INFO - 2021-04-13 22:08:53 --> URI Class Initialized
INFO - 2021-04-13 22:08:53 --> Router Class Initialized
INFO - 2021-04-13 22:08:53 --> Output Class Initialized
INFO - 2021-04-13 22:08:53 --> Security Class Initialized
DEBUG - 2021-04-13 22:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 22:08:53 --> Input Class Initialized
INFO - 2021-04-13 22:08:53 --> Language Class Initialized
ERROR - 2021-04-13 22:08:53 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 22:08:53 --> Config Class Initialized
INFO - 2021-04-13 22:08:53 --> Hooks Class Initialized
DEBUG - 2021-04-13 22:08:53 --> UTF-8 Support Enabled
INFO - 2021-04-13 22:08:53 --> Utf8 Class Initialized
INFO - 2021-04-13 22:08:53 --> URI Class Initialized
INFO - 2021-04-13 22:08:53 --> Router Class Initialized
INFO - 2021-04-13 22:08:53 --> Output Class Initialized
INFO - 2021-04-13 22:08:53 --> Security Class Initialized
DEBUG - 2021-04-13 22:08:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 22:08:53 --> Input Class Initialized
INFO - 2021-04-13 22:08:53 --> Language Class Initialized
ERROR - 2021-04-13 22:08:53 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 22:08:57 --> Config Class Initialized
INFO - 2021-04-13 22:08:57 --> Hooks Class Initialized
DEBUG - 2021-04-13 22:08:57 --> UTF-8 Support Enabled
INFO - 2021-04-13 22:08:57 --> Utf8 Class Initialized
INFO - 2021-04-13 22:08:57 --> URI Class Initialized
INFO - 2021-04-13 22:08:57 --> Router Class Initialized
INFO - 2021-04-13 22:08:57 --> Output Class Initialized
INFO - 2021-04-13 22:08:57 --> Security Class Initialized
DEBUG - 2021-04-13 22:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 22:08:57 --> Input Class Initialized
INFO - 2021-04-13 22:08:57 --> Language Class Initialized
INFO - 2021-04-13 22:08:57 --> Loader Class Initialized
INFO - 2021-04-13 22:08:57 --> Helper loaded: url_helper
INFO - 2021-04-13 22:08:57 --> Helper loaded: form_helper
INFO - 2021-04-13 22:08:57 --> Helper loaded: common_helper
INFO - 2021-04-13 22:08:57 --> Helper loaded: util_helper
INFO - 2021-04-13 22:08:57 --> Database Driver Class Initialized
DEBUG - 2021-04-13 22:08:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 22:08:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 22:08:57 --> Form Validation Class Initialized
INFO - 2021-04-13 22:08:57 --> Controller Class Initialized
INFO - 2021-04-13 22:08:57 --> Model Class Initialized
INFO - 2021-04-13 22:08:57 --> Config Class Initialized
INFO - 2021-04-13 22:08:57 --> Hooks Class Initialized
DEBUG - 2021-04-13 22:08:57 --> UTF-8 Support Enabled
INFO - 2021-04-13 22:08:57 --> Utf8 Class Initialized
INFO - 2021-04-13 22:08:57 --> URI Class Initialized
INFO - 2021-04-13 22:08:57 --> Router Class Initialized
INFO - 2021-04-13 22:08:57 --> Output Class Initialized
INFO - 2021-04-13 22:08:57 --> Security Class Initialized
DEBUG - 2021-04-13 22:08:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 22:08:57 --> Input Class Initialized
INFO - 2021-04-13 22:08:57 --> Language Class Initialized
INFO - 2021-04-13 22:08:57 --> Loader Class Initialized
INFO - 2021-04-13 22:08:57 --> Helper loaded: url_helper
INFO - 2021-04-13 22:08:57 --> Helper loaded: form_helper
INFO - 2021-04-13 22:08:57 --> Helper loaded: common_helper
INFO - 2021-04-13 22:08:57 --> Helper loaded: util_helper
INFO - 2021-04-13 22:08:57 --> Database Driver Class Initialized
DEBUG - 2021-04-13 22:08:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 22:08:57 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 22:08:57 --> Form Validation Class Initialized
INFO - 2021-04-13 22:08:57 --> Controller Class Initialized
INFO - 2021-04-13 22:08:57 --> Model Class Initialized
INFO - 2021-04-13 22:08:57 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-13 22:08:57 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 22:08:57 --> Final output sent to browser
DEBUG - 2021-04-13 22:08:57 --> Total execution time: 0.0276
INFO - 2021-04-13 22:09:02 --> Config Class Initialized
INFO - 2021-04-13 22:09:02 --> Hooks Class Initialized
DEBUG - 2021-04-13 22:09:02 --> UTF-8 Support Enabled
INFO - 2021-04-13 22:09:02 --> Utf8 Class Initialized
INFO - 2021-04-13 22:09:02 --> URI Class Initialized
INFO - 2021-04-13 22:09:02 --> Router Class Initialized
INFO - 2021-04-13 22:09:02 --> Output Class Initialized
INFO - 2021-04-13 22:09:02 --> Security Class Initialized
DEBUG - 2021-04-13 22:09:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 22:09:02 --> Input Class Initialized
INFO - 2021-04-13 22:09:02 --> Language Class Initialized
INFO - 2021-04-13 22:09:02 --> Loader Class Initialized
INFO - 2021-04-13 22:09:02 --> Helper loaded: url_helper
INFO - 2021-04-13 22:09:02 --> Helper loaded: form_helper
INFO - 2021-04-13 22:09:02 --> Helper loaded: common_helper
INFO - 2021-04-13 22:09:02 --> Helper loaded: util_helper
INFO - 2021-04-13 22:09:02 --> Database Driver Class Initialized
DEBUG - 2021-04-13 22:09:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 22:09:02 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 22:09:02 --> Form Validation Class Initialized
INFO - 2021-04-13 22:09:02 --> Controller Class Initialized
INFO - 2021-04-13 22:09:02 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-13 22:09:02 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 22:09:02 --> Final output sent to browser
DEBUG - 2021-04-13 22:09:02 --> Total execution time: 0.0253
INFO - 2021-04-13 22:09:04 --> Config Class Initialized
INFO - 2021-04-13 22:09:04 --> Hooks Class Initialized
DEBUG - 2021-04-13 22:09:04 --> UTF-8 Support Enabled
INFO - 2021-04-13 22:09:04 --> Utf8 Class Initialized
INFO - 2021-04-13 22:09:04 --> URI Class Initialized
INFO - 2021-04-13 22:09:04 --> Router Class Initialized
INFO - 2021-04-13 22:09:04 --> Output Class Initialized
INFO - 2021-04-13 22:09:04 --> Security Class Initialized
DEBUG - 2021-04-13 22:09:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 22:09:04 --> Input Class Initialized
INFO - 2021-04-13 22:09:04 --> Language Class Initialized
INFO - 2021-04-13 22:09:04 --> Loader Class Initialized
INFO - 2021-04-13 22:09:04 --> Helper loaded: url_helper
INFO - 2021-04-13 22:09:04 --> Helper loaded: form_helper
INFO - 2021-04-13 22:09:04 --> Helper loaded: common_helper
INFO - 2021-04-13 22:09:04 --> Helper loaded: util_helper
INFO - 2021-04-13 22:09:04 --> Database Driver Class Initialized
DEBUG - 2021-04-13 22:09:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 22:09:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 22:09:04 --> Form Validation Class Initialized
INFO - 2021-04-13 22:09:04 --> Controller Class Initialized
INFO - 2021-04-13 22:09:04 --> Model Class Initialized
INFO - 2021-04-13 22:09:04 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 22:09:04 --> Final output sent to browser
DEBUG - 2021-04-13 22:09:04 --> Total execution time: 0.0292
INFO - 2021-04-13 22:09:07 --> Config Class Initialized
INFO - 2021-04-13 22:09:07 --> Hooks Class Initialized
DEBUG - 2021-04-13 22:09:07 --> UTF-8 Support Enabled
INFO - 2021-04-13 22:09:07 --> Utf8 Class Initialized
INFO - 2021-04-13 22:09:07 --> URI Class Initialized
INFO - 2021-04-13 22:09:07 --> Router Class Initialized
INFO - 2021-04-13 22:09:07 --> Output Class Initialized
INFO - 2021-04-13 22:09:07 --> Security Class Initialized
DEBUG - 2021-04-13 22:09:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 22:09:07 --> Input Class Initialized
INFO - 2021-04-13 22:09:07 --> Language Class Initialized
INFO - 2021-04-13 22:09:07 --> Loader Class Initialized
INFO - 2021-04-13 22:09:07 --> Helper loaded: url_helper
INFO - 2021-04-13 22:09:07 --> Helper loaded: form_helper
INFO - 2021-04-13 22:09:07 --> Helper loaded: common_helper
INFO - 2021-04-13 22:09:07 --> Helper loaded: util_helper
INFO - 2021-04-13 22:09:07 --> Database Driver Class Initialized
DEBUG - 2021-04-13 22:09:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 22:09:07 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 22:09:07 --> Form Validation Class Initialized
INFO - 2021-04-13 22:09:07 --> Controller Class Initialized
INFO - 2021-04-13 22:09:07 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-13 22:09:07 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 22:09:07 --> Final output sent to browser
DEBUG - 2021-04-13 22:09:07 --> Total execution time: 0.0253
INFO - 2021-04-13 22:09:19 --> Config Class Initialized
INFO - 2021-04-13 22:09:19 --> Hooks Class Initialized
DEBUG - 2021-04-13 22:09:19 --> UTF-8 Support Enabled
INFO - 2021-04-13 22:09:19 --> Utf8 Class Initialized
INFO - 2021-04-13 22:09:19 --> URI Class Initialized
INFO - 2021-04-13 22:09:19 --> Router Class Initialized
INFO - 2021-04-13 22:09:19 --> Output Class Initialized
INFO - 2021-04-13 22:09:19 --> Security Class Initialized
DEBUG - 2021-04-13 22:09:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 22:09:19 --> Input Class Initialized
INFO - 2021-04-13 22:09:19 --> Language Class Initialized
INFO - 2021-04-13 22:09:19 --> Loader Class Initialized
INFO - 2021-04-13 22:09:19 --> Helper loaded: url_helper
INFO - 2021-04-13 22:09:19 --> Helper loaded: form_helper
INFO - 2021-04-13 22:09:19 --> Helper loaded: common_helper
INFO - 2021-04-13 22:09:19 --> Helper loaded: util_helper
INFO - 2021-04-13 22:09:19 --> Database Driver Class Initialized
DEBUG - 2021-04-13 22:09:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 22:09:19 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 22:09:19 --> Form Validation Class Initialized
INFO - 2021-04-13 22:09:19 --> Controller Class Initialized
INFO - 2021-04-13 22:09:19 --> Model Class Initialized
INFO - 2021-04-13 22:09:19 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 22:09:19 --> Final output sent to browser
DEBUG - 2021-04-13 22:09:19 --> Total execution time: 0.0363
INFO - 2021-04-13 22:09:20 --> Config Class Initialized
INFO - 2021-04-13 22:09:20 --> Hooks Class Initialized
DEBUG - 2021-04-13 22:09:20 --> UTF-8 Support Enabled
INFO - 2021-04-13 22:09:20 --> Utf8 Class Initialized
INFO - 2021-04-13 22:09:20 --> URI Class Initialized
DEBUG - 2021-04-13 22:09:20 --> No URI present. Default controller set.
INFO - 2021-04-13 22:09:20 --> Router Class Initialized
INFO - 2021-04-13 22:09:20 --> Output Class Initialized
INFO - 2021-04-13 22:09:20 --> Security Class Initialized
DEBUG - 2021-04-13 22:09:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 22:09:20 --> Input Class Initialized
INFO - 2021-04-13 22:09:20 --> Language Class Initialized
INFO - 2021-04-13 22:09:20 --> Loader Class Initialized
INFO - 2021-04-13 22:09:20 --> Helper loaded: url_helper
INFO - 2021-04-13 22:09:20 --> Helper loaded: form_helper
INFO - 2021-04-13 22:09:20 --> Helper loaded: common_helper
INFO - 2021-04-13 22:09:20 --> Helper loaded: util_helper
INFO - 2021-04-13 22:09:20 --> Database Driver Class Initialized
DEBUG - 2021-04-13 22:09:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 22:09:20 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 22:09:20 --> Form Validation Class Initialized
INFO - 2021-04-13 22:09:20 --> Controller Class Initialized
INFO - 2021-04-13 22:09:20 --> Model Class Initialized
INFO - 2021-04-13 22:09:20 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\index.php
INFO - 2021-04-13 22:09:20 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 22:09:20 --> Final output sent to browser
DEBUG - 2021-04-13 22:09:20 --> Total execution time: 0.0261
INFO - 2021-04-13 22:45:04 --> Config Class Initialized
INFO - 2021-04-13 22:45:04 --> Hooks Class Initialized
DEBUG - 2021-04-13 22:45:04 --> UTF-8 Support Enabled
INFO - 2021-04-13 22:45:04 --> Utf8 Class Initialized
INFO - 2021-04-13 22:45:04 --> URI Class Initialized
INFO - 2021-04-13 22:45:04 --> Router Class Initialized
INFO - 2021-04-13 22:45:04 --> Output Class Initialized
INFO - 2021-04-13 22:45:04 --> Security Class Initialized
DEBUG - 2021-04-13 22:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 22:45:04 --> Input Class Initialized
INFO - 2021-04-13 22:45:04 --> Language Class Initialized
INFO - 2021-04-13 22:45:04 --> Loader Class Initialized
INFO - 2021-04-13 22:45:04 --> Helper loaded: url_helper
INFO - 2021-04-13 22:45:04 --> Helper loaded: form_helper
INFO - 2021-04-13 22:45:04 --> Helper loaded: common_helper
INFO - 2021-04-13 22:45:04 --> Helper loaded: util_helper
INFO - 2021-04-13 22:45:04 --> Database Driver Class Initialized
DEBUG - 2021-04-13 22:45:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 22:45:04 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 22:45:04 --> Form Validation Class Initialized
INFO - 2021-04-13 22:45:04 --> Controller Class Initialized
INFO - 2021-04-13 22:45:04 --> Model Class Initialized
INFO - 2021-04-13 22:45:04 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\login.php
INFO - 2021-04-13 22:45:04 --> Final output sent to browser
DEBUG - 2021-04-13 22:45:04 --> Total execution time: 0.0265
INFO - 2021-04-13 22:45:04 --> Config Class Initialized
INFO - 2021-04-13 22:45:04 --> Config Class Initialized
INFO - 2021-04-13 22:45:04 --> Hooks Class Initialized
INFO - 2021-04-13 22:45:04 --> Hooks Class Initialized
DEBUG - 2021-04-13 22:45:04 --> UTF-8 Support Enabled
INFO - 2021-04-13 22:45:04 --> Utf8 Class Initialized
DEBUG - 2021-04-13 22:45:04 --> UTF-8 Support Enabled
INFO - 2021-04-13 22:45:04 --> Utf8 Class Initialized
INFO - 2021-04-13 22:45:04 --> URI Class Initialized
INFO - 2021-04-13 22:45:04 --> URI Class Initialized
INFO - 2021-04-13 22:45:04 --> Router Class Initialized
INFO - 2021-04-13 22:45:04 --> Router Class Initialized
INFO - 2021-04-13 22:45:04 --> Output Class Initialized
INFO - 2021-04-13 22:45:04 --> Output Class Initialized
INFO - 2021-04-13 22:45:04 --> Security Class Initialized
INFO - 2021-04-13 22:45:04 --> Security Class Initialized
DEBUG - 2021-04-13 22:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 22:45:04 --> Input Class Initialized
DEBUG - 2021-04-13 22:45:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 22:45:04 --> Input Class Initialized
INFO - 2021-04-13 22:45:04 --> Language Class Initialized
INFO - 2021-04-13 22:45:04 --> Language Class Initialized
ERROR - 2021-04-13 22:45:04 --> 404 Page Not Found: Fasset/img
ERROR - 2021-04-13 22:45:04 --> 404 Page Not Found: Fasset/img
INFO - 2021-04-13 22:45:29 --> Config Class Initialized
INFO - 2021-04-13 22:45:29 --> Hooks Class Initialized
DEBUG - 2021-04-13 22:45:29 --> UTF-8 Support Enabled
INFO - 2021-04-13 22:45:29 --> Utf8 Class Initialized
INFO - 2021-04-13 22:45:29 --> URI Class Initialized
INFO - 2021-04-13 22:45:29 --> Router Class Initialized
INFO - 2021-04-13 22:45:29 --> Output Class Initialized
INFO - 2021-04-13 22:45:29 --> Security Class Initialized
DEBUG - 2021-04-13 22:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 22:45:29 --> Input Class Initialized
INFO - 2021-04-13 22:45:29 --> Language Class Initialized
INFO - 2021-04-13 22:45:29 --> Loader Class Initialized
INFO - 2021-04-13 22:45:29 --> Helper loaded: url_helper
INFO - 2021-04-13 22:45:29 --> Helper loaded: form_helper
INFO - 2021-04-13 22:45:29 --> Helper loaded: common_helper
INFO - 2021-04-13 22:45:29 --> Helper loaded: util_helper
INFO - 2021-04-13 22:45:29 --> Database Driver Class Initialized
DEBUG - 2021-04-13 22:45:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 22:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 22:45:29 --> Form Validation Class Initialized
INFO - 2021-04-13 22:45:29 --> Controller Class Initialized
INFO - 2021-04-13 22:45:29 --> Model Class Initialized
INFO - 2021-04-13 22:45:29 --> Language file loaded: language/english/form_validation_lang.php
INFO - 2021-04-13 22:45:29 --> Config Class Initialized
INFO - 2021-04-13 22:45:29 --> Hooks Class Initialized
DEBUG - 2021-04-13 22:45:29 --> UTF-8 Support Enabled
INFO - 2021-04-13 22:45:29 --> Utf8 Class Initialized
INFO - 2021-04-13 22:45:29 --> URI Class Initialized
INFO - 2021-04-13 22:45:29 --> Router Class Initialized
INFO - 2021-04-13 22:45:29 --> Output Class Initialized
INFO - 2021-04-13 22:45:29 --> Security Class Initialized
DEBUG - 2021-04-13 22:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 22:45:29 --> Input Class Initialized
INFO - 2021-04-13 22:45:29 --> Language Class Initialized
INFO - 2021-04-13 22:45:29 --> Loader Class Initialized
INFO - 2021-04-13 22:45:29 --> Helper loaded: url_helper
INFO - 2021-04-13 22:45:29 --> Helper loaded: form_helper
INFO - 2021-04-13 22:45:29 --> Helper loaded: common_helper
INFO - 2021-04-13 22:45:29 --> Helper loaded: util_helper
INFO - 2021-04-13 22:45:29 --> Database Driver Class Initialized
DEBUG - 2021-04-13 22:45:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
INFO - 2021-04-13 22:45:29 --> Session: Class initialized using 'files' driver.
INFO - 2021-04-13 22:45:29 --> Form Validation Class Initialized
INFO - 2021-04-13 22:45:29 --> Controller Class Initialized
INFO - 2021-04-13 22:45:29 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\user/account.php
INFO - 2021-04-13 22:45:29 --> File loaded: C:\xampp1\htdocs\FoodTruck\php\application\views\_layout.php
INFO - 2021-04-13 22:45:29 --> Final output sent to browser
DEBUG - 2021-04-13 22:45:29 --> Total execution time: 0.0262
INFO - 2021-04-13 22:45:29 --> Config Class Initialized
INFO - 2021-04-13 22:45:29 --> Hooks Class Initialized
DEBUG - 2021-04-13 22:45:29 --> UTF-8 Support Enabled
INFO - 2021-04-13 22:45:29 --> Utf8 Class Initialized
INFO - 2021-04-13 22:45:29 --> URI Class Initialized
INFO - 2021-04-13 22:45:29 --> Router Class Initialized
INFO - 2021-04-13 22:45:29 --> Output Class Initialized
INFO - 2021-04-13 22:45:29 --> Security Class Initialized
DEBUG - 2021-04-13 22:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 22:45:29 --> Input Class Initialized
INFO - 2021-04-13 22:45:29 --> Config Class Initialized
INFO - 2021-04-13 22:45:29 --> Language Class Initialized
INFO - 2021-04-13 22:45:29 --> Hooks Class Initialized
ERROR - 2021-04-13 22:45:29 --> 404 Page Not Found: user/Assets/css
DEBUG - 2021-04-13 22:45:29 --> UTF-8 Support Enabled
INFO - 2021-04-13 22:45:29 --> Utf8 Class Initialized
INFO - 2021-04-13 22:45:29 --> URI Class Initialized
INFO - 2021-04-13 22:45:29 --> Router Class Initialized
INFO - 2021-04-13 22:45:29 --> Output Class Initialized
INFO - 2021-04-13 22:45:29 --> Security Class Initialized
DEBUG - 2021-04-13 22:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 22:45:29 --> Input Class Initialized
INFO - 2021-04-13 22:45:29 --> Config Class Initialized
INFO - 2021-04-13 22:45:29 --> Hooks Class Initialized
INFO - 2021-04-13 22:45:29 --> Language Class Initialized
DEBUG - 2021-04-13 22:45:29 --> UTF-8 Support Enabled
INFO - 2021-04-13 22:45:29 --> Utf8 Class Initialized
INFO - 2021-04-13 22:45:29 --> URI Class Initialized
ERROR - 2021-04-13 22:45:29 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 22:45:29 --> Router Class Initialized
INFO - 2021-04-13 22:45:29 --> Config Class Initialized
INFO - 2021-04-13 22:45:29 --> Config Class Initialized
INFO - 2021-04-13 22:45:29 --> Hooks Class Initialized
INFO - 2021-04-13 22:45:29 --> Hooks Class Initialized
INFO - 2021-04-13 22:45:29 --> Output Class Initialized
INFO - 2021-04-13 22:45:29 --> Security Class Initialized
DEBUG - 2021-04-13 22:45:29 --> UTF-8 Support Enabled
INFO - 2021-04-13 22:45:29 --> Utf8 Class Initialized
DEBUG - 2021-04-13 22:45:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 22:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 22:45:29 --> Input Class Initialized
INFO - 2021-04-13 22:45:29 --> Utf8 Class Initialized
INFO - 2021-04-13 22:45:29 --> Language Class Initialized
INFO - 2021-04-13 22:45:29 --> URI Class Initialized
INFO - 2021-04-13 22:45:29 --> URI Class Initialized
ERROR - 2021-04-13 22:45:29 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 22:45:29 --> Router Class Initialized
INFO - 2021-04-13 22:45:29 --> Router Class Initialized
INFO - 2021-04-13 22:45:29 --> Output Class Initialized
INFO - 2021-04-13 22:45:29 --> Output Class Initialized
INFO - 2021-04-13 22:45:29 --> Security Class Initialized
DEBUG - 2021-04-13 22:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 22:45:29 --> Input Class Initialized
INFO - 2021-04-13 22:45:29 --> Language Class Initialized
ERROR - 2021-04-13 22:45:29 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 22:45:29 --> Config Class Initialized
INFO - 2021-04-13 22:45:29 --> Config Class Initialized
INFO - 2021-04-13 22:45:29 --> Hooks Class Initialized
INFO - 2021-04-13 22:45:29 --> Config Class Initialized
INFO - 2021-04-13 22:45:29 --> Hooks Class Initialized
INFO - 2021-04-13 22:45:29 --> Hooks Class Initialized
DEBUG - 2021-04-13 22:45:29 --> UTF-8 Support Enabled
INFO - 2021-04-13 22:45:29 --> Utf8 Class Initialized
DEBUG - 2021-04-13 22:45:29 --> UTF-8 Support Enabled
INFO - 2021-04-13 22:45:29 --> URI Class Initialized
INFO - 2021-04-13 22:45:29 --> Utf8 Class Initialized
INFO - 2021-04-13 22:45:29 --> Security Class Initialized
INFO - 2021-04-13 22:45:29 --> Config Class Initialized
INFO - 2021-04-13 22:45:29 --> Router Class Initialized
DEBUG - 2021-04-13 22:45:29 --> UTF-8 Support Enabled
INFO - 2021-04-13 22:45:29 --> URI Class Initialized
INFO - 2021-04-13 22:45:29 --> Utf8 Class Initialized
INFO - 2021-04-13 22:45:29 --> Hooks Class Initialized
INFO - 2021-04-13 22:45:29 --> Output Class Initialized
DEBUG - 2021-04-13 22:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 22:45:29 --> URI Class Initialized
INFO - 2021-04-13 22:45:29 --> Input Class Initialized
INFO - 2021-04-13 22:45:29 --> Security Class Initialized
INFO - 2021-04-13 22:45:29 --> Language Class Initialized
INFO - 2021-04-13 22:45:29 --> Router Class Initialized
INFO - 2021-04-13 22:45:29 --> Router Class Initialized
DEBUG - 2021-04-13 22:45:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 22:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 22:45:29 --> Input Class Initialized
INFO - 2021-04-13 22:45:29 --> Utf8 Class Initialized
INFO - 2021-04-13 22:45:29 --> Language Class Initialized
INFO - 2021-04-13 22:45:29 --> Output Class Initialized
ERROR - 2021-04-13 22:45:29 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 22:45:29 --> Output Class Initialized
ERROR - 2021-04-13 22:45:29 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 22:45:29 --> URI Class Initialized
INFO - 2021-04-13 22:45:29 --> Security Class Initialized
INFO - 2021-04-13 22:45:29 --> Security Class Initialized
INFO - 2021-04-13 22:45:29 --> Router Class Initialized
DEBUG - 2021-04-13 22:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 22:45:29 --> Input Class Initialized
DEBUG - 2021-04-13 22:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 22:45:29 --> Language Class Initialized
INFO - 2021-04-13 22:45:29 --> Input Class Initialized
INFO - 2021-04-13 22:45:29 --> Output Class Initialized
INFO - 2021-04-13 22:45:29 --> Language Class Initialized
ERROR - 2021-04-13 22:45:29 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 22:45:29 --> Security Class Initialized
ERROR - 2021-04-13 22:45:29 --> 404 Page Not Found: user/Assets/css
DEBUG - 2021-04-13 22:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 22:45:29 --> Input Class Initialized
INFO - 2021-04-13 22:45:29 --> Language Class Initialized
ERROR - 2021-04-13 22:45:29 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 22:45:29 --> Config Class Initialized
INFO - 2021-04-13 22:45:29 --> Config Class Initialized
INFO - 2021-04-13 22:45:29 --> Config Class Initialized
INFO - 2021-04-13 22:45:29 --> Hooks Class Initialized
INFO - 2021-04-13 22:45:29 --> Hooks Class Initialized
INFO - 2021-04-13 22:45:29 --> Hooks Class Initialized
DEBUG - 2021-04-13 22:45:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 22:45:29 --> UTF-8 Support Enabled
INFO - 2021-04-13 22:45:29 --> Utf8 Class Initialized
INFO - 2021-04-13 22:45:29 --> Utf8 Class Initialized
INFO - 2021-04-13 22:45:29 --> URI Class Initialized
INFO - 2021-04-13 22:45:29 --> URI Class Initialized
INFO - 2021-04-13 22:45:29 --> Router Class Initialized
INFO - 2021-04-13 22:45:29 --> Router Class Initialized
INFO - 2021-04-13 22:45:29 --> Output Class Initialized
INFO - 2021-04-13 22:45:29 --> Output Class Initialized
DEBUG - 2021-04-13 22:45:29 --> UTF-8 Support Enabled
INFO - 2021-04-13 22:45:29 --> Utf8 Class Initialized
INFO - 2021-04-13 22:45:29 --> Security Class Initialized
INFO - 2021-04-13 22:45:29 --> Security Class Initialized
DEBUG - 2021-04-13 22:45:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 22:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 22:45:29 --> Input Class Initialized
INFO - 2021-04-13 22:45:29 --> Input Class Initialized
INFO - 2021-04-13 22:45:29 --> Config Class Initialized
INFO - 2021-04-13 22:45:29 --> Hooks Class Initialized
INFO - 2021-04-13 22:45:29 --> Language Class Initialized
INFO - 2021-04-13 22:45:29 --> Language Class Initialized
INFO - 2021-04-13 22:45:29 --> URI Class Initialized
ERROR - 2021-04-13 22:45:29 --> 404 Page Not Found: user/Assets/img
ERROR - 2021-04-13 22:45:29 --> 404 Page Not Found: user/Assets/img
DEBUG - 2021-04-13 22:45:29 --> UTF-8 Support Enabled
INFO - 2021-04-13 22:45:29 --> Utf8 Class Initialized
INFO - 2021-04-13 22:45:29 --> Router Class Initialized
INFO - 2021-04-13 22:45:29 --> URI Class Initialized
INFO - 2021-04-13 22:45:29 --> Router Class Initialized
INFO - 2021-04-13 22:45:29 --> Output Class Initialized
INFO - 2021-04-13 22:45:29 --> Output Class Initialized
INFO - 2021-04-13 22:45:29 --> Security Class Initialized
INFO - 2021-04-13 22:45:29 --> Security Class Initialized
DEBUG - 2021-04-13 22:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 22:45:29 --> Input Class Initialized
DEBUG - 2021-04-13 22:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 22:45:29 --> Language Class Initialized
INFO - 2021-04-13 22:45:29 --> Input Class Initialized
INFO - 2021-04-13 22:45:29 --> Language Class Initialized
ERROR - 2021-04-13 22:45:29 --> 404 Page Not Found: user/Assets/js
ERROR - 2021-04-13 22:45:29 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 22:45:29 --> Config Class Initialized
INFO - 2021-04-13 22:45:29 --> Hooks Class Initialized
DEBUG - 2021-04-13 22:45:29 --> UTF-8 Support Enabled
INFO - 2021-04-13 22:45:29 --> Utf8 Class Initialized
INFO - 2021-04-13 22:45:29 --> URI Class Initialized
INFO - 2021-04-13 22:45:29 --> Router Class Initialized
INFO - 2021-04-13 22:45:29 --> Output Class Initialized
INFO - 2021-04-13 22:45:29 --> Security Class Initialized
DEBUG - 2021-04-13 22:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 22:45:29 --> Input Class Initialized
INFO - 2021-04-13 22:45:29 --> Language Class Initialized
ERROR - 2021-04-13 22:45:29 --> 404 Page Not Found: user/Assets/css
INFO - 2021-04-13 22:45:29 --> Config Class Initialized
INFO - 2021-04-13 22:45:29 --> Hooks Class Initialized
DEBUG - 2021-04-13 22:45:29 --> UTF-8 Support Enabled
INFO - 2021-04-13 22:45:29 --> Utf8 Class Initialized
INFO - 2021-04-13 22:45:29 --> URI Class Initialized
INFO - 2021-04-13 22:45:29 --> Router Class Initialized
INFO - 2021-04-13 22:45:29 --> Output Class Initialized
INFO - 2021-04-13 22:45:29 --> Security Class Initialized
DEBUG - 2021-04-13 22:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 22:45:29 --> Input Class Initialized
INFO - 2021-04-13 22:45:29 --> Language Class Initialized
ERROR - 2021-04-13 22:45:29 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 22:45:29 --> Config Class Initialized
INFO - 2021-04-13 22:45:29 --> Hooks Class Initialized
DEBUG - 2021-04-13 22:45:29 --> UTF-8 Support Enabled
INFO - 2021-04-13 22:45:29 --> Utf8 Class Initialized
INFO - 2021-04-13 22:45:29 --> URI Class Initialized
INFO - 2021-04-13 22:45:29 --> Router Class Initialized
INFO - 2021-04-13 22:45:29 --> Output Class Initialized
INFO - 2021-04-13 22:45:29 --> Security Class Initialized
DEBUG - 2021-04-13 22:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 22:45:29 --> Input Class Initialized
INFO - 2021-04-13 22:45:29 --> Language Class Initialized
ERROR - 2021-04-13 22:45:29 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 22:45:29 --> Config Class Initialized
INFO - 2021-04-13 22:45:29 --> Hooks Class Initialized
DEBUG - 2021-04-13 22:45:29 --> UTF-8 Support Enabled
INFO - 2021-04-13 22:45:29 --> Utf8 Class Initialized
INFO - 2021-04-13 22:45:29 --> URI Class Initialized
INFO - 2021-04-13 22:45:29 --> Router Class Initialized
INFO - 2021-04-13 22:45:29 --> Output Class Initialized
INFO - 2021-04-13 22:45:29 --> Security Class Initialized
DEBUG - 2021-04-13 22:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 22:45:29 --> Input Class Initialized
INFO - 2021-04-13 22:45:29 --> Language Class Initialized
ERROR - 2021-04-13 22:45:29 --> 404 Page Not Found: user/Assets/js
INFO - 2021-04-13 22:45:29 --> Config Class Initialized
INFO - 2021-04-13 22:45:29 --> Hooks Class Initialized
DEBUG - 2021-04-13 22:45:29 --> UTF-8 Support Enabled
INFO - 2021-04-13 22:45:29 --> Utf8 Class Initialized
INFO - 2021-04-13 22:45:29 --> URI Class Initialized
INFO - 2021-04-13 22:45:29 --> Router Class Initialized
INFO - 2021-04-13 22:45:29 --> Output Class Initialized
INFO - 2021-04-13 22:45:29 --> Security Class Initialized
DEBUG - 2021-04-13 22:45:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2021-04-13 22:45:29 --> Input Class Initialized
INFO - 2021-04-13 22:45:29 --> Language Class Initialized
ERROR - 2021-04-13 22:45:29 --> 404 Page Not Found: user/Assets/js
