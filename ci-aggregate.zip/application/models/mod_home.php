<?php
class mod_home extends CI_Model
{
	public function get_min()
	{
		$this->db->select_max('id');
		$this->db->get('reg');
	}
}