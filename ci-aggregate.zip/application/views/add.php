<?php
$x = array(2,3,5);
echo array_sum($x);
?>
