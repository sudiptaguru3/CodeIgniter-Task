<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<?php
// echo $this->db->last_query();
// echo "<hr />";
echo $records[0]['id'];
$i=1;
// foreach($records as $row){
// 	echo "<strong>".$i++."</strong>";
// 	echo "<em>".$row['id']."</em>";
// 	echo $row['name'];
// 	echo $row['email'];
// 	echo $row['address'];
// 	echo $row['phone'];
// 	echo "<br>";
// }
?>
</body>
</html>