<?php
class User_controller extends CI_Controller {
	function __construct(){
		parent::__construct();
		$this->load->model('User');
	}
	public function login()
	{
		$this->load->view('user_login');
	}
	public function login_check()
	{
		$email=$this->input->post('email');
		$password=md5($this->input->post('email'));
		$data=array('email'=>$email,'passwo')
	}
}