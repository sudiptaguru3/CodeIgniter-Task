<?php 
class Home extends CI_Controller
{
	function __construct() { 
        parent::__construct(); 
         
        // Load form validation ibrary & user model 
        //  
        // $this->load->model('mod_home');
    } 

	public function index()
	{
		// $this->db->select_min("id");
		// $this->db->order_by("name desc,address desc");
		// $this->db->order_by("name","desc");
		// $this->db->group_by("name");
		// $this->db->join("reg","reg.id=users.gender-id");
		// $this->db->join("student","student.id=student.subject-id");
		$this->db->where("gender","Male")->where("first_name","Sudipta")->order_by("first_name");
		// $reg = $this->db->get("reg");
		$reg = $this->db->get("users");
		$data=array();
		$data['records'] = $reg->result_array();
		$this->load->view('home',$data);
	}
}