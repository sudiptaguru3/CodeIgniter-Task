<?php 
class Home extends CI_Controller
{
	function __construct() { 
        parent::__construct(); 
         
        // Load form validation ibrary & user model 
        //  
        // $this->load->model('mod_home');
    } 

	public function index()
	{
		$this->db->select_max("id");
		$reg = $this->db->get("reg");
		$data=array();
		$data['records'] = $reg->result_array();
		$this->load->view('home',$data);
	}
}