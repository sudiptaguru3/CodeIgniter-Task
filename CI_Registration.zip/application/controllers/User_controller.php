<?php defined('BASEPATH') OR exit('No direct script access allowed'); 
 
class User_controller extends CI_Controller { 
     
    function __construct() { 
        parent::__construct(); 
         
        // Load form validation ibrary & user model 
        //  
        $this->load->model('User');
    } 
    public function login()
    {
        $this->load->view('user_login');
    } 

    public function login_check()
    {
        $email=$this->input->post('email');
        $password=md5($this->input->post('password'));
        $data = array('email'=>$email,'password'=>$password);
        //$data = array('name'=>$name,'email'=>$email,'password'=>$password);
        $row = $this->User->login_check($data);
echo "<pre>";
        print_r($row);
        if ($row == TRUE) {
         
            $session_data = array(
            'id' => $row[0]->id
            // 'first_name' => $row[0]->first_name,
            // 'email' => $row[0]->email
            );
            $this->session->set_userdata('logged_in', $session_data);
           // redirect('user_controller/userProfile');
            redirect('adminController');
        }else{
            // $this->session->set_flashdata('res_msg', '<h5 style="color:red; border: 1px solid red;">OOPS! Please Enter Correct Email or Password</h5>');
            redirect('User_controller/login');
        }
        
          
    } 

    public function userProfile()
    {
        
        $logged_in=$this->session->userdata('logged_in');
 $user_id=$logged_in['id'];
        $data['profile']=$this->User->get_user($user_id);
        //print_r($data['profile']);
        // $this->load->model('User');
        if(isset($logged_in['id'])){
            $this->load->view('user_profile',$data);
        }
        else{
            redirect('user_controller/login');
        }
    }
    
    public function update(){
        $id = $this->input->post('id',TRUE);
        $first_name = $this->input->post('first_name',TRUE);
        $last_name = $this->input->post('last_name',TRUE);
        $data  = array(
                'id' => $id,
                'first_name' => $first_name,
                'last_name' => $last_name
            );
        $this->User->update($data);
        redirect('User_controller/login');
    }

    public function registration(){ 


    $data = $userData = array(); 
         
        // If registration request is submitted 
        if($this->input->post()){ 
            $this->form_validation->set_rules('first_name', 'First Name', 'required|alpha'); 
            $this->form_validation->set_rules('last_name', 'Last Name', 'required|alpha'); 
            $this->form_validation->set_rules('email', 'Email', 'required|trim|valid_email|is_unique[users.email]',
                       array('is_unique' => 'The email address %s provided already exists. Please signup.')); 
            $this->form_validation->set_rules('password', 'password', 'required|min_length[8]|max_length[15]'); 
            
            $this->form_validation->set_rules('conf_password', 'confirm password', 'required|matches[password]|min_length[8]|max_length[15]');

            $this->form_validation-> set_rules('gender', 'Gender', 'required' );

            $this->form_validation->
             set_rules('phone','contact no','required|exact_length[10]');
 
            $userData = array( 
                'first_name' => strip_tags($this->input->post('first_name')), 
                'last_name' => strip_tags($this->input->post('last_name')), 
                'email' => strip_tags($this->input->post('email')), 
                'password' => md5($this->input->post('password')), 
                'gender' => $this->input->post('gender'), 
                'phone' => strip_tags($this->input->post('phone')),
                'file' => strip_tags($_FILES['file']['name']) 
            ); 
            // print_r($userData);
            // die;
 
            if($this->form_validation->run() == true){
//print_r($_POST);
        //print_r($_FILES); die();
                /*File upload code start*/

                $config['upload_path']   = 'uploads/'; 
                $config['allowed_types'] = 'gif|jpg|png|jpeg|pdf'; 
                $config['max_size']      = 1000000000; 
                $config['max_width']     = 1024; 
                $config['max_height']    = 768;  
                $this->load->library('upload', $config);
                $this->upload->do_upload('file');
                /*File upload code end*/

                $insert = $this->User->insert($userData); 
                if($insert){ 
                    $this->session->set_userdata('success_msg', 'Your account registration has been successful. Please login to your account.'); 
            redirect('user_controller/login');
                    // $data['success_msg']= 'Your account registration has been successful. Please login to your account.';

                }else{ 
                    $data['error_msg'] = 'Some problems occured in registration, please try again.'; 
                } 
            }else{ 
                $data['error_msg'] = 'Please fill all the fields.'; 
            } 
        } 
         
        // Posted data 
        $data['user'] = $userData; 
         
        // Load view 
         
        $this->load->view('user_registration', $data); 
         
    }
    
    
    public function logout(){ 
        // $this->session->unset_userdata('lolgin_check'); 
        // $this->session->unset_userdata(''); 
        $this->session->sess_destroy(); 
        //$this->load->view('user_login');
        redirect('user_controller/login');
    }
}
?>