<!DOCTYPE html>
<html>
<head>
	<title>User details</title>
</head>
<body>
	<!-- <?php print_r($users); ?> -->
<h1>User Account Details</h1>
<table>
	<tr>
		<td>First name</td>
		<td>Account no</td>
	</tr>
	<?php foreach($users as $user): ?>
	<tr>
		<td><?php echo $user['Firstname']; ?></td>
		<td><?php echo $user['accountno']; ?></td>
		<!-- <td><?php echo $user->Firstname ?></td>
		<td><?php echo $user->accountno ?></td> -->
	</tr>
<?php endforeach; ?>
</table>
</body>
</html>