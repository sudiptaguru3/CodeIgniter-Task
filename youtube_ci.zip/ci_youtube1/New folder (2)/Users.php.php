<?php
class Users extends MY_controller
{
	public function index()
	{
		echo "Testing";
	}

}