<?php
class admin extends MY_controller
{
	
}
?>