<?php
class CI_Controller
{
	public function view($index)
	{
		echo "View Display".$index;
	}
}
class Welcome extends CI_Controller
{
	private $load;
	public function __construct()
	{
		$load=new CI_Controller();
	}
	public function something()
	{
		$this->load->view("index.php");
	}
}