<?php
class MY_controller extends CI_Controller
{
	// public function __construct()
	// {
	// 	echo "Testing";
	// // if(!$this->isauthorized() {return redirect 'home';})
	// }
}