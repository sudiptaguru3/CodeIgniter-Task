<?php
class Users extends CI_Controller
{
	public function User()
	{
		// echo "Users Data";
		$this->load->model('Usermodel');
		$data['users']=$this->Usermodel->getUserdata();
		print_r($data);
		$this->load->view('Users/userlist',$data);
	}
}
?>