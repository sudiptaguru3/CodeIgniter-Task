<?php
class Authenticate extends CI_model
{
	public function getdata()
	{
		return ['ABC'=>'ABC value','XYZ'=>'XYZ value'];
	}
}