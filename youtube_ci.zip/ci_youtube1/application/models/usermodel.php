<?php
class Usermodel extends CI_model
{
	public function getUserdata()
	{
		return [
			['Firstname'=>'Sudipta Guru','AccountNO'=>'85138'],
			['Firstname'=>'Sudip Das','AccountNO'=>'86178'],
		];
		// $this->load->model('Usermodel');
		// $data['users']=$this->Usermodel->getUserdata();
		// $this->load->view('Users/userlist',$data);
		// $this->load->database();
		// $q=$this->db->where("id",2)
		//             ->get("users");
		// $this->db->where("id",2);
		// $q=$this->db->query("select * from users");
		// $q=$this->db->get("users",1,2);
		// return $q->result_array();
	}
}
?>