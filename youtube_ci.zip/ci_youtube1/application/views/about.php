<!DOCTYPE html>
<html>
<head>
	<title>My new page</title>
</head>
<body>
<h1>Hello</h1>
</body>
</html>