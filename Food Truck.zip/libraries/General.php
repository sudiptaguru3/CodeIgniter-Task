<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class General{
	public $ci;
	function __construct(){
		$this->ci=& get_instance();
		$this->ci->load->database();
	}
	public function insert($table,$data){
		$this->ci->db->insert($table,$data);
		return $this->ci->db->insert_id();
	}
	public function update($table,$condition,$data){
		$this->ci->db->where($condition);
		$this->ci->db->update($table,$data);
		//echo $this->db->last_query();exit();
		return true;
	}
	public function delete($table,$condition){
		$this->ci->db->where($condition);
		$this->ci->db->delete($table);
		return true;
	}
	public function get_all_details($table,$condition=array(),$order=''){
		$this->ci->db->select('*');
		$this->ci->db->from($table);
		$this->ci->db->where($condition);
		$this->ci->db->order_by($order);
		$query=$this->ci->db->get();
		return $query->result_array();
	}
	public function get_details($table,$condition=array(),$order=''){
		$this->ci->db->select('*');
		$this->ci->db->from($table);
		$this->ci->db->where($condition);
		$this->ci->db->order_by($order);
		$query=$this->ci->db->get();
		return $query->row_array();
	}
}