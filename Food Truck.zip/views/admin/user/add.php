<div class="content-wrapper">
<div class="content-header">
   <div class="container-fluid">
      <div class="row mb-2">
         <div class="col-sm-6">
         </div>
         <!-- /.col -->
         <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
               <li><a href="<?=base_url('administrator/User')?>"><i class="fa fa-plus"></i> List User</a></li>
            </ol>
         </div>
         <!-- /.col -->
      </div>
      <!-- /.row -->
   </div>
   <!-- /.container-fluid -->
</div>
<!-- Main content -->
<section class="content">
   <div class="container-fluid">
   <div class="row">
   <!-- left column -->
   <div class="col-md-6">
   <!-- general form elements -->
   <div class="card card-primary">
      <div class="card-header">
         <h3 class="card-title">Add User</h3>
      </div>
      <!-- /.card-header -->
      <!-- form start -->
      <div class="card-body">
         <form action="" method="post">
            <div class="form-group">
               <label for="exampleInputEmail1">First Name</label>
               <input type="text" class="form-control" id="first_name" name="first_name" value="<?=set_value('first_name')?>" placeholder="Enter first name">
            </div>
            <div class="form-group">
               <label for="exampleInputEmail1">Last Name</label>
               <input type="text" class="form-control" id="last_name" name="last_name"  value="<?=set_value('last_name')?>" placeholder="Enter last name">
            </div>
            <div class="form-group">
               <label for="exampleInputEmail1">Email</label>
               <input type="text" class="form-control" id="email" name="email"   value="<?=set_value('email')?>" placeholder="Enter email">
            </div>
            <div class="form-group">
               <label for="exampleInputEmail1">Password</label>
               <input type="password" class="form-control" id="password" name="password"  placeholder="Enter password">
            </div>
            <div class="form-group">
               <label for="exampleInputEmail1">Confirm password</label>
               <input type="password" class="form-control" id="confirm_password" name="confirm_password"  placeholder="Enter password">
            </div>
            <div class="form-group">
               <label for="role">Select Role</label>
               <select class="form-control" name="role" id="role">
                  <option value="">--select--</option>
                
                  <option value="2">Food Truck Owner</option>
                  <option value="3">Customer</option>
                
                
               </select>
            </div>
            <div class="form-check-inline">
               <input class="form-check-input" type="radio" value="1" name="status" checked>
               <label class="form-check-label">Active</label>
            </div>
            <div class="form-check-inline">
               <input class="form-check-input" type="radio" value="0" name="status">
               <label class="form-check-label">Inactive</label>
            </div>
            <!-- /.card-body -->
      </div>
    
      <div class="card-footer">
      <button type="submit" class="btn btn-primary">Submit</button>
      </div>
      </form>
     </div>
     </div>
      <div class="col-md-6">
         <!-- general form elements -->
         <?php echo validation_errors(); ?>
         <?php
            if($this -> session -> flashdata('success')) {?>
         <div class="alert alert-info" role="alert">
            <?=$this -> session -> flashdata('success')?>
         </div>
         <?php } ?>
         <?php
            if($this -> session -> flashdata('error')) {?>
         <div class="alert alert-danger" role="alert">
            <?=$this -> session -> flashdata('error')?>
         </div>
         <?php } ?>
      </div>
     </div>
      </div>
</section>
</div>