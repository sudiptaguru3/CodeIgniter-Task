 <div class="content-wrapper">
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
          
          </div><!-- /.col -->
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li><a href="<?=base_url('administrator/Role')?>"><i class="fa fa-list"></i> Role List</a></li>
              
            </ol>
          </div><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>



    <!-- Main content -->
  <section class="content">
      <div class="container-fluid">
        <div class="row">
          <!-- left column -->
          <div class="col-md-6">
            <!-- general form elements -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Add Role</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form action="" method="post">
                <div class="card-body">
                  <div class="form-group">
                    <label for="exampleInputEmail1">Role Name</label>
                    <input type="text" class="form-control" id="role" name="role"  placeholder="Enter role">
                  </div>
                              
                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">Submit</button>
                </div>
              </form>
            </div>


           

          </div>


         <div class="col-md-6">
            <!-- general form elements -->
           
            <?php echo validation_errors(); ?>
            <?php
            if($this -> session -> flashdata('success')) {?>
                <div class="alert alert-info" role="alert">
                  <?=$this -> session -> flashdata('success')?>
                </div>

            <?php } ?>

                <?php
            if($this -> session -> flashdata('error')) {?>
                <div class="alert alert-danger" role="alert">
                  <?=$this -> session -> flashdata('error')?>
                </div>

            <?php } ?>
    

             
          

          </div>
 
          
              </div>
           
      </div>
    </section>
 
  </div>