  <!-- Main Footer -->
  <footer class="main-footer">
    <strong>Copyright &copy; <?=date('Y')?> <a href="#">Robust</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      <b>Beta Version</b> 1.0.1
    </div>
  </footer>
</div>
<!-- ./wrapper -->

<!-- REQUIRED SCRIPTS -->

<!-- Bootstrap -->
<script src="<?=base_url('assets/admin/')?>plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- overlayScrollbars -->
<script src="<?=base_url('assets/admin/')?>plugins/overlayScrollbars/js/jquery.overlayScrollbars.min.js"></script>
<!-- AdminLTE App -->
<script src="<?=base_url('assets/admin/')?>dist/js/adminlte.js"></script>

<!-- PAGE PLUGINS -->
<!-- jQuery Mapael -->
<script src="<?=base_url('assets/admin/')?>plugins/jquery-mousewheel/jquery.mousewheel.js"></script>
<script src="<?=base_url('assets/admin/')?>plugins/raphael/raphael.min.js"></script>
<script src="<?=base_url('assets/admin/')?>plugins/jquery-mapael/jquery.mapael.min.js"></script>
<script src="<?=base_url('assets/admin/')?>plugins/jquery-mapael/maps/usa_states.min.js"></script>
<!-- ChartJS -->
<script src="<?=base_url('assets/admin/')?>plugins/chart.js/Chart.min.js"></script>

<!-- AdminLTE for demo purposes -->
<script src="<?=base_url('assets/admin/')?>dist/js/demo.js"></script>
<!-- AdminLTE dashboard demo (This is only for demo purposes) -->
<script src="<?=base_url('assets/admin/')?>dist/js/pages/dashboard2.js"></script>
<script src="<?=base_url('assets/admin/')?>plugins/sweetalert2/sweetalert2.min.js"></script>
<script>
  var base_url="<?= base_url()?>";

$(document).ready(function() {  
  var success_msg = "<?=$this->session->flashdata('success_msg')?>";
  var error_msg  = "<?=$this->session->flashdata('error_msg')?>";

 var Toast = Swal.mixin({
      toast: true,
      position: 'top-end',
      showConfirmButton: false,
      timer: 3000
    });
  if(success_msg!=''){    
    Toast.fire({
        icon: 'success',
        title: success_msg
      });

  }

  if(error_msg!=''){    
   Toast.fire({
        icon: 'error',
        title: error_msg
      });

  }
});
</script>

<script type="text/javascript"> 
      $(function(){
    setTimeout(function(){
        $(".alert").fadeOut("slow");
        }, 4000);
      });
   
</script>
</body>
</html>