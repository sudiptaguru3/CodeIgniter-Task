<div class="content-wrapper">
<div class="content-header">
   <div class="container-fluid">
      <div class="row mb-2">
         <div class="col-sm-6">
         </div>
         <!-- /.col -->
         <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
               <li><a href="<?=base_url('administrator/Company/add')?>"><i class="fa fa-plus"></i> Add Company</a></li>
            </ol>
         </div>
         <!-- /.col -->
      </div>
      <!-- /.row -->
   </div>
   <!-- /.container-fluid -->
</div>
    <!-- Main content -->
  <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">
             <?php if($this -> session -> flashdata('success')) {?>
                <div class="alert alert-info" role="alert">
                  <?=$this -> session -> flashdata('success')?>
                </div>

            <?php } ?>

          </div>
        </div>
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- general form elements -->
          <div class="card">
              <div class="card-header">
                <h3 class="card-title">Company List</h3>

                <div class="card-tools">
                  <div class="input-group input-group-sm" style="width: 150px;">
                    <input type="text" name="table_search" class="form-control float-right" placeholder="Search">

                    <div class="input-group-append">
                      <button type="submit" class="btn btn-default">
                        <i class="fas fa-search"></i>
                      </button>
                    </div>
                  </div>
                </div>
              </div>
              <!-- /.card-header -->
              <div class="card-body table-responsive p-0">
                <table class="table table-hover text-nowrap">
                  <thead>
                    <tr>
                     
                       <th>Sno.</th>
                      <th>Name</th>
                      <th>Email</th>
                      <th>Phone</th>   
                      <th>Alt. phone</th>                                  
                      <th>Action</th>
                   
                    </tr>
                  </thead>
                  <tbody>
                  <?php
                  if (count($company)){
                    foreach ($company as  $k => $u) {?>
                    <tr>
                       <td><?=$k+1?></td>
                      <td><?=$u['company_name']?></td>
                      <td><?=$u['company_email']?></td>
                      <td><?=$u['company_phone']?></td>
                   
                      <td><?=$u['alternate_phone']?></td>
                      
                      <td> 
                      <a  href="<?=base_url('administrator/Company/edit/'.$u['id'])?>"><i class="fa fa-edit"></i></a> | 
                      <a onclick ="return confirm('Do you want to delete?');" href="<?=base_url('administrator/Company/destroy/'.$u['id'])?>"><i class="fa fa-trash"></i></a> </td>
                     <td>
                  <select class="form-control" name="status" id="status_<?=$u['id']?>" onchange="changeStatus(this.id, this.value);">
                  <option value="">--select--</option>
                  <option value="0" <?php if ($u['company_status'] == '0') echo ' selected';?>>Inactive</option>
                  <option value="1" <?php if ($u['company_status'] == '1') echo ' selected';?>>Active</option>
                  
                  </select>
                     </td>
                    </tr>
                   <?php 
                 }
                 }
                   ?>
                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>

          </div>


       
 
          
              </div>
           
      </div>
    </section>
  </div>
  <script>
 
   function changeStatus(id, val) {


    if (!confirm("Do you want to change status?")){
      return false;
    }
         
      if (val ==  ""){
        alert("Please select...");
        return false;

      }

       var status = val;
       var uid = id.split('_')[1];

      $.ajax({
          url:"<?=base_url('administrator/Company/changeUserStatusAjax')?>",
          type:"post",
          data:{uid:uid, status:status}
      }).done(function(response){
        if (response == "1"){
          let txtStatus = status == "1"  ? "Activated..." : "Deactivated...";
          alert("Company "+txtStatus);
        }
        else {
          alert("Problem changing the status. Try again.")
        }

      }).catch(function(error){
          console.log(error);
      });
}
 
  </script