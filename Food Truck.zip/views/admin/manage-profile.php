 <div class="content-wrapper" style="min-height: 1329.44px;">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Profile</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="<?=base_url('admin')?>">Home</a></li>
              <li class="breadcrumb-item active">User Profile</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-6">

            <!-- Profile Image -->
            <div class="card card-primary card-outline">
              <div class="card-header p-2">
                <h5 class="card-title">Edit Profile</h5>
              </div><!-- /.card-header -->
              <div class="card-body box-profile">
                    <form class="form-horizontal" action="" method="post">
                      <div class="form-group row">
                        <label for="inputName" class="col-sm-2 col-form-label">Name</label>
                        <div class="col-sm-10">
                          <input type="email" class="form-control" id="inputName" placeholder="Name">
                        </div>
                      </div>
                      <div class="form-group row">
                        <label for="inputEmail" class="col-sm-2 col-form-label">Email</label>
                        <div class="col-sm-10">
                          <input type="email" class="form-control" id="inputEmail" placeholder="Email">
                        </div>
                      </div>
                      <div class="form-group row">
                        <label for="inputName2" class="col-sm-2 col-form-label">Name</label>
                        <div class="col-sm-10">
                          <input type="text" class="form-control" id="inputName2" placeholder="Name">
                        </div>
                      </div>
                      <div class="form-group row">
                        <label for="inputExperience" class="col-sm-2 col-form-label">Experience</label>
                        <div class="col-sm-10">
                          <textarea class="form-control" id="inputExperience" placeholder="Experience"></textarea>
                        </div>
                      </div>
                      <div class="form-group row">
                        <label for="inputSkills" class="col-sm-2 col-form-label">Skills</label>
                        <div class="col-sm-10">
                          <input type="text" class="form-control" id="inputSkills" placeholder="Skills">
                        </div>
                      </div>

                      <div class="form-group row">
                        <div class="offset-sm-2 col-sm-10">
                          <button type="submit" class="btn btn-danger">Submit</button>
                        </div>
                      </div>
                    </form>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->

            <!-- /.card -->
          </div>
          <!-- /.col -->
          <div class="col-md-6">
            <div class="card card-info card-outline">
              <div class="card-header p-2">
                <h5 class="card-title">Change Password</h5>
              </div><!-- /.card-header -->
              <div class="card-body">

                    <form class="form-horizontal" id="pasFrm" action="<?=base_url('admin/updatePassword')?>" method="post">
                      <div class="form-group row">
                        <label  class="col-sm-4 col-form-label">Old Password</label>
                        <div class="col-sm-8">
                          <input type="password" name="old_password" id="old_password" class="form-control" required>
                        </div>
                      </div>
                      <div class="form-group row">
                        <label  class="col-sm-4 col-form-label">New Password</label>
                        <div class="col-sm-8">
                          <input type="password" name="password" id="password" class="form-control"  required>
                        </div>
                      </div>
                      <div class="form-group row">
                        <label  class="col-sm-4 col-form-label">Confirm Password</label>
                        <div class="col-sm-8">
                          <input type="password" name="cnf_password" id="cnf_password" class="form-control"  required>
                        </div>
                      </div>
                      <div class="form-group row">
                        <div class="offset-sm-4 col-sm-8">
                          <button type="submit" class="btn btn-danger pasFrm">Submit</button>
                        </div>
                      </div>
                    </form>
           
              </div><!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <script>
    $(document).ready(function() {
      var Toast = Swal.mixin({
        toast: true,
        position: 'top-end',
        showConfirmButton: false,
        timer: 3000
      });
      $(document).on('click','.pasFrm',function(event) {
        event.preventDefault();
        var pass=$('#password').val();
        var cnf_pass=$('#cnf_password').val();
        if( pass !='' && cnf_pass !=''){
          if(pass != cnf_pass){
              Toast.fire({
              icon: 'error',
              title: 'Password Does Not Match!'
            });
              $('#cnf_password').focus();

              $('#cnf_password').val('');
              return false;
          }else{
            $('#pasFrm').submit();
          }
        }else{
          Toast.fire({
              icon: 'error',
              title: 'Please Enter Password!'
            });
        }
      })
    })
    
  </script>