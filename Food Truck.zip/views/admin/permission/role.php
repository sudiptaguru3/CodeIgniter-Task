 <div class="content-wrapper">
    <div class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
          
          </div><!-- /.col -->
         <!-- <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li><a href=""><i class="fa fa-plus"></i> Add Role</a></li>
              
            </ol>
          </div>--><!-- /.col -->
        </div><!-- /.row -->
      </div><!-- /.container-fluid -->
    </div>

    <!-- Main content -->
  <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">
             <?php if($this -> session -> flashdata('success')) {?>
                <div class="alert alert-info" role="alert">
                  <?=$this -> session -> flashdata('success')?>
                </div>

            <?php } ?>

          </div>
        </div>
        <div class="row">
          <!-- left column -->
          <div class="col-md-12">
            <!-- general form elements -->
          <div class="card">
              <div class="card-header">
                <h3 class="card-title">Permission List</h3>            
              </div>
              <!-- /.card-header -->
              <div class="card-body">

              <div class="form-group">
                <label>Select Role</label>
                <select class="form-control" name="role" id="role">
                  <option value="">--select--</option>
                  <?php
                  if (count($role)){
                    foreach ($role as $row){?>
                       <option value="<?=$row['group_id']?>"><?=$row['name']?></option>
                   <?php
                    }
                  }
                  ?>
                </select>

           <!--pernission menu-->
           <br />
            <div id="menu4">

        
            </div>

           <!-- menu end -->
            </div>

          </div>
              </div>
           
      </div>
    </section>
  </div>

  <script>
  $(function(){
    $("#role").change(function(){
      var role = this.value;
      if (role == ""){
        alert("Select role...");
        return false;
      }

       $("#menu4").empty();
      $.ajax({
              url:"<?=base_url('administrator/Permission/listMenuAjax')?>",
              type:'post',
              data:{role:role},
              beforeSend:function(){
                $("#menu4").html('<p class="text-center" style="color:blue;">Loading...</p>');
              }
      }).done(function(response){
        

         var data = JSON.parse(response);

         $("#menu4").html(data.menu_vw);

         var arr = [];

          if (data.menu_assigned.length > 0){
            for (i in data.menu_assigned){
              arr.push(data.menu_assigned[i].menu_id);
            }
   console.log(arr);
            var v;
            $(".menu").each(function(){
               v = this.value;
              if (arr.indexOf(v) == -1) {
              
                $(this).prop("checked", false);
              }
              else {
              
                $(this).prop("checked", true);
              }
            });
          }
          

      }).catch(function(error){
          console.log(error);
      });
    });
  })
  </script>


