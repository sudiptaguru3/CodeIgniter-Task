<!doctype html>
<html>
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<link rel="icon" href="<?=base_url()?>fassets/img/fav-icon.png">
<link rel="preconnect" href="https://fonts.gstatic.com">
<link href="https://use.fontawesome.com/releases/v5.0.4/css/all.css" rel="stylesheet">
<!-- Bootstrap core CSS -->
<link rel="stylesheet" type="text/css" href="<?=base_url()?>fassets/css/bootstrap.min.css">
<link rel="stylesheet" type="text/css" href="<?=base_url()?>fassets/css/bootstrap-theme.min.css">
<link rel="stylesheet" type="text/css" href="<?=base_url()?>fassets/css/theme.css">
<link rel="stylesheet" type="text/css" href="<?=base_url()?>fassets/css/responsive.css">
<title><?= $title ?> | <?= $this -> sitename ?></title>
</head>
<body>

<div class="register-page">
		<div class="register-bg">
			<h2>REGISTER</h2>
			<div class="row">
			<div class="col-md-12">
         <!-- general form elements -->
         <?php echo validation_errors(); ?>
         <?php
            if($this -> session -> flashdata('success')) {?>
         <div class="alert alert-info alert-dismissible" role="alert">
				<a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
            <?=$this -> session -> flashdata('success')?>
         </div>
         <?php } ?>
         <?php
            if(!empty($error)) {?>
         <div class="alert alert-danger alert-dismissible" role="alert">
		 <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
           <?=$error?>
         </div>
         <?php } ?>
      </div>
	  </div>
			<form method="post" action="" autocomplete="off">
			<div class="row">
			
				<div class="col-md-6">
					<div class="form-group">
						<input type="text" name="first_name" value="<?=set_value('first_name')?>" placeholder="First name" class="form-control">
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group">
						<input type="text" name="last_name" value="<?=set_value('last_name')?>" autocomplete="off" placeholder="Last name" class="form-control">
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group">
						<input type="text" name="email" value="<?=set_value('email')?>" autocomplete="off" placeholder="Email" class="form-control">
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group">
						<input type="text" name="contact_no" value="<?=set_value('contact_no')?>" autocomplete="off" placeholder="Contact No" class="form-control">
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group">
						<input type="password" name="password"  autocomplete="off" placeholder="Password" class="form-control">
					</div>
				</div>
				<div class="col-md-6">
					<div class="form-group">
						<input type="password" name="confirm_password" autocomplete="off" placeholder="Confirm Password" class="form-control">
					</div>
				</div>
				<div class="col-md-12">
				<div class="form-group">
					<div class="form-check">
					  <input class="form-check-input" name="agree" type="checkbox" id="gridCheck">
					  <label class="form-check-label" for="gridCheck">
						I agree all statements in Terms of service
					  </label>
					</div>
				  </div>
				</div>
			  <div class="col-md-12">
				  <div class="form-group">
				  	<button type="submit" >SIGN UP</button>
				</div>
			
			</div>
				<h5>Already have an account? <a href="#">Sign In!</a></h5>
			</div>
			</form>
		</div>
	</div>

 


<!-- Bootstrap core JavaScript --> 
<!--<script src="https://code.jquery.com/jquery-3.4.1.js"></script>--> 
<script src="<?=base_url()?>fassets/js/jquery.1.11.3.min.js"></script> 
<script src="<?=base_url()?>fassets/js/bootstrap.min.js"></script> 	
<script src="<?=base_url()?>fassets/js/theme.js"></script> 
</body>
</html>
