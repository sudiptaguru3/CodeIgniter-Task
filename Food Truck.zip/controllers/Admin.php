<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Admin extends MY_Controller
{
	
	public function __construct()
	{
		parent::__construct();
	}

	private function _loadView($data)
	{
		$this->load->view('admin/layouts/index', $data);
	}

	public function index(){
		if($this->is_logged_in_admin()):
	    	redirect('admin/dashboard');
	    endif; 
				
		 	
		$this->load->view('admin/login');
	}


	public function login()
	{
		if($this->input->post()):
			$postData=$this->input->post();
			if(!empty($postData['email']) && !empty($postData['email'])):
				$condition['email'] 		= $postData['email'];
				$condition['password']		= md5($postData['password']);
				//$condition['group_id']		= 1;
				$userDetails				= $this->mcommon->getRow('user', $condition);
			
				if(empty($userDetails)):							
					$this->session->set_flashdata('error_msg', "Invalid email or password.");
					redirect('admin');					
				else:
					if($userDetails['status']!= 1):
						$this->session->set_flashdata('error_msg', "Your account activation is pending. Check your email to activate account.");
					else:					
						$this->session->set_userdata('admin_details',$userDetails);	
					
						redirect('admin/dashboard');						
					endif;
				endif;
			else:
				$this->session->set_flashdata('error_msg', "Please fill up all the required fields.");
				redirect('admin');	
			endif;
		endif;
		
	}
	public function dashboard()
	{
		if(!$this->is_logged_in_admin()):
	    	redirect('admin');
	    endif;

	    $data = array();
	    $data['content']='admin/dashboard';
	    $data['title']='Dashboard';
	    $this->_loadView($data);
	}

	public function profile()
	{
		if(!$this->is_logged_in_admin()):
	    	redirect('admin');
	    endif;

	    $data = array();
	    $data['content']='admin/manage-profile';
	    $data['title']='Manage Profile';
	    $this->_loadView($data);
	}



	public function updatePassword()
	{
		if(!$this->is_logged_in_admin()):
	    	redirect('admin');
	    endif;

	    if($this->input->post()):
			$postData=$this->input->post();
			$userId = $this->session->admin_details['user_id'];
			$passCheck=$this->mcommon->getRow('user',
								array(
									'user_id' => $userId,
									'password'=> md5($postData['old_password'])
								)
							);
			if(!empty($passCheck)):
				$updatePassword = array(
									'password' => md5($postData['password']), 
								);
				$upadte=$this->mcommon->update('user',
									array('user_id' =>$userId),$updatePassword
								);
				if($upadte):
					$this->session->set_flashdata('success_msg', "Password Updated successfully!");
				endif;
			else:
				$this->session->set_flashdata('error_msg', "Old Password Does Not Match !");
			endif;
			redirect('admin/profile');

		   	
	    endif;
	}

	public function logout()
	{
		if(!$this->is_logged_in_admin()):
	    	redirect('admin');
	    endif;

	    $this->session->unset_userdata('admin_details');
	    $this->session->set_flashdata('success_msg', "Logged out successfully.");
		redirect('admin','refresh');
	}
}