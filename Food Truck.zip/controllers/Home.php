<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends Public_Controller
{
	
	public function __construct()
	{
		parent::__construct();

	}

	
	public function index(){
        
		$this -> data['main']='index';
	    $this -> data['title']='Home';
	    $this -> load -> view('_layout', $this -> data);
				
	}

    public function register(){
		$this -> data['error'] = '';
		$this->form_validation->set_rules('first_name','First name','trim|required');
		$this->form_validation->set_rules('last_name','Last name','trim|required');
		$this->form_validation->set_rules('email','Email','trim|required|valid_email|is_unique[user.email]');
		$this->form_validation->set_rules('contact_no','Contact no','trim|required|numeric');
		$this->form_validation->set_rules('password','Password','trim|required|matches[confirm_password]');
		$this->form_validation->set_rules('confirm_password','Confirm password','trim|required|matches[password]');
		$this->form_validation->set_rules('agree','Terms & Conditions','required');
		if ($this->form_validation->run() === TRUE) {
		  
			$postData = array();		
			$postData = $this->input->post();
			$array	= array(
								'first_name' => $postData['first_name'],
								'mobile' => $postData['first_name'],
								'last_name' => $postData['last_name'],
								'email'	=>	$postData['email'],
								'password'	=>	password_hash($postData['password'],PASSWORD_BCRYPT),
								'group_id'  => 3
			
		                   );
			$this->db->insert('user', $array);

			if ($this -> db -> insert_id()){
				$this -> session -> set_flashdata('success','Registered successfully!');
				redirect('/register','refresh');
			}
			$this->data['error'] = 'Problem resgistering. Try again';
		}
		
		
	    $this -> data['title'] = 'Register';
	    $this -> load -> view('register', $this -> data);
				
	}

}