<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Company extends MY_Controller
{
	
	public function __construct()
	{
		parent::__construct();

		/*if($this->is_logged_in_admin()):
	    	redirect('admin/role/add');
	    endif; */
	   
	    $this -> load -> model('admin/Company_m');
	}

	private function _loadView($data)
	{
		$this->load->view('admin/layouts/index', $data);
	}

	public function index(){
		$this -> data['content']='admin/company/list';
	    $this -> data['title']='Company List';
	    $this -> data['company'] = $this -> Company_m -> get();
	   // echo '<pre>';print_r($this -> data['company']);die;
	    $this->_loadView($this -> data);
				
	}

	public function add(){
		
	    $this->form_validation->set_rules(
	        'company_email', 'Email',
	        'required|trim|valid_email|is_unique[company.company_email]',
	        array(
	                'required'      => 'You have not provided %s.',
	                'is_unique'     => 'This %s already exists.'
	        )
		);

		$this->form_validation->set_rules('company_name','Company name','trim|required');
		$this->form_validation->set_rules('company_phone','Company phone','trim|required|numeric');
		$this->form_validation->set_rules('alternate_phone','Alternate phone','trim|required|numeric');
		$this->form_validation->set_rules('company_address','Company address','trim');
		$this->form_validation->set_rules('company_password','Password','required');
		$this->form_validation->set_rules('contact_name','Contact name','trim');
		$this->form_validation->set_rules('contact_phone','Contact phone','trim|numeric');
		$this->form_validation->set_rules('contact_email','Contact email','trim|valid_email');
		
		if ($this -> form_validation -> run() === TRUE){
			//echo "vxvxf";die;
				$postData = $this -> input ->post();
				$d = array(
							'company_name' => $postData['company_name'],
							'company_email' => $postData['company_email'],
							'company_phone' =>  $postData['company_phone'],
							'alternate_phone' =>  $postData['alternate_phone'],
							'company_address' => $postData['company_address'],
							'company_password' =>  md5($postData['company_password']),
							'contact_name' =>  $postData['contact_name'],
							'contact_phone' =>  $postData['contact_phone'],
							'contact_email' =>  $postData['contact_email'],
							'created_on' => date('Y-m-d H:i:s'),
							'updated_on' => date('Y-m-d H:i:s'),
							'company_status' => $postData['status']

					);
				

				$this -> db ->insert('company',$d);
				if ($this -> db -> insert_id()){
					$this -> session ->set_flashdata('success','Added successfully!');
				}
				else {
					$this -> session ->set_flashdata('error','Problem saving company! Try again.');
				}
				redirect('administrator/company/add');

		}
     
  	
	    $this -> data['content']='admin/company/add';
	    $this -> data['title']='Add Company';
	    $this->_loadView($this -> data);	 	
		
	}

	public function edit($id){

		if(!$id){
			show_404();
		}

		$this -> data['company']= $this -> Company_m -> get($id);

		//echo '<pre>';print_r($this -> data);die;
		
	    $this -> data['content']='admin/company/edit';
	    $this -> data['title']='Edit Company';

	    $this->_loadView($this -> data);	 	
		
	}

	function update($id){
		
	
		$this->form_validation->set_rules('company_name','Company name','trim|required');
		
		$this->form_validation->set_rules('company_phone','Company phone','trim|required');
		$this->form_validation->set_rules('alternate_phone','Alternate phone','trim');
		$this->form_validation->set_rules('company_address','Company address','trim');
		
		$this->form_validation->set_rules('contact_name','Contact name','trim');
		$this->form_validation->set_rules('contact_phone','Contact phone','trim');
		$this->form_validation->set_rules('contact_email','Contact email','trim|valid_email');
	//	echo 'hi';
	//	echo '<pre>';print_r($_POST);die;


		if ($this -> form_validation -> run() === TRUE){
				$postData = $this -> input ->post();

				$d = array(
							'company_name' => $postData['company_name'],
							'company_phone' =>  $postData['company_phone'],
							'alternate_phone' =>  $postData['alternate_phone'],
							'company_address' => $postData['company_address'],							
							'contact_name' =>  $postData['contact_name'],
							'contact_phone' =>  $postData['contact_phone'],
							'contact_email' =>  $postData['contact_email'],
							'updated_on' => date('Y-m-d H:i:s'),
							'company_status' => $postData['status']

					);

			/*	if (isset($postData ['company_password'])){
					$d['company_password'] =  md5($postData['company_password']);
				}
*/
	
				$company_id = $postData['company_id'];
				$status = $this -> db ->update('company', $d, array('id' => $company_id));
				

				if ($status){
					$this -> session ->set_flashdata('success','Updated successfully!');
				}
				else {
					$this -> session ->set_flashdata('error','Problem updating company! Try again.');
				}
				 redirect('administrator/Company/edit/'.$id);	

		}
		else {

				$this -> session ->set_flashdata('fail',validation_errors());			
					 redirect('administrator/Company/edit/'.$id);	
				
		}

  	

	 
	}


	public function destroy($id){
		if (!$id){
		  show_404();
		}

		$this -> db -> update('company', array('is_deleted' => '1'), ['id' => $id]);
		$this -> session ->set_flashdata('success', 'Company deleted...');	
		redirect('administrator/Company');	
	}

	function changeUserStatusAjax(){
		$company_id = $this -> input ->post('uid');
		$status = $this -> input ->post('status');

		$this -> db -> where('id' , $company_id);

		$s =$this -> db -> update('company',['company_status' => $status]);
		if ($s){
			echo "1";
		}
		else {
			echo "0";
		}


	}

	function back(){
		redirect(base_url('admin'));
	}
}

