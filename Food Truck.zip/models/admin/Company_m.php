<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Company_m extends CI_Model
{
	private $_table = 'company';

	public function __construct()
	{
		parent::__construct();
		
	}

	function get($id = ''){
		if ($id){

			return $this -> db -> get_where($this -> _table,['id' => $id]) -> row_array()	;
		}

		else {
			$sql = "select * from company where is_deleted='0'  order by company_name asc";

   
			return $this -> db -> query($sql) -> result_array();
		}	
	}

}
