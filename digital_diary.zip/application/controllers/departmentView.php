<?php
   defined('BASEPATH') OR exit('No direct script access allowed');
   
   class departmentView extends CI_Controller 
   {
   	function __construct()
   	{
   		parent::__construct();
   		// $this->load->database();
   		$this->load->model('Department_model');
   	}
   
   	public function index()
   	{	
   		$this->load->model('Department_model');
   		$data['test']=$this->Department_model->get_data();
   
   		// $this->load->view('include/header');
   		// $this->load->view('include/sidebar');
   		$this->load->view('viewDepartment', $data);
   		// $this->load->view('include/footer');
   		
   	}
   
   	public function edit()
   	{
   		 $id=$this->uri->segment(3); 
   		 $this->load->model('Department_model');
   		 $data['user']= $this->Department_model->get_data($id);
   		 
   		 // echo "<pre>";
   		 // print_r($data);die();

//---------------------- adding update form to fetch data in form------------------------
   

   		// $this->load->view('include/header');
   		// $this->load->view('include/sidebar');
   		$this->load->view('updateDepartment',$data);
   		// $this->load->view('admin_user_add', $data);
   		// $this->load->view('include/footer');
   
   	}
   
   	public function update_user() 
   	{   
   
   	 $id=$this->input->post('id');
   
   
   //----------------------file upload code------------------
   
   
       if(!empty($_FILES['profile_pic']['name']))
       {
              $config['upload_path'] = 'uploads/';
              $config['allowed_types'] = 'jpg|jpeg|png|gif';
              $config['file_name'] = $_FILES['profile_pic']['name'];
                   
                   //Load upload library and initialize configuration
              $this->load->library('upload',$config);
              $this->upload->initialize($config);
                   
              if($this->upload->do_upload('profile_pic'))
                {
                 $uploadData = $this->upload->data();
                 $picture = $uploadData['file_name'];
                }
              else
               {
                  $picture = '';
               }
        }
        // else
        // {
        //     $picture = '';
        // }
   
   //-------------------file upload code end here----------------------------------------
   
   
     if($_FILES['profile_pic']['name']!='')
     {
      $data = array(
           // 'table_name' => 'admin_user', // pass the real table name
           'automobile_name' => $this->input->post('automobile_name'),
           'automobile_type' => $this->input->post('automobile_type'),
           'status' => $this->input->post('status'),
           'brand_name' => $this->input->post('brand_name'),
           'profile_pic'=>$_FILES['profile_pic']['name']
           );
     }
     else
     {
      $data = array(
           // 'table_name' => 'admin_user', // pass the real table name
           'automobile_name' => $this->input->post('automobile_name'),
           'automobile_type' => $this->input->post('automobile_type'),
           'status' => $this->input->post('status'),
           'brand_name' => $this->input->post('brand_name')
       );
     }
   
       
   
       // echo "<pre>";
       // print_r($data);die();
   
       $this->load->model('Department_model');
   
       if($this->Department_model->upddata($data,$id)) 
       {  
           // echo("update successful");
           redirect('departmentView');
   
       }
       else
       {
           echo("update not successful");
       }
   
   }
   
   	public function delete_row($id='')
   	{  
   		$this->load->model('Department_model');
   		$id=$this->uri->segment(3);
   	    $this->Department_model->delete_data($id);
   	    redirect('departmentView');
   	}


  public function edit_status()
  {
    // print_r($_POST);die();

    $id= $this->input->post('id'); 
    $status = $this->input->post('status');
    
     $this->load->model('Department_model');
   
       if($this->Department_model->update_status($status,$id)) 
       {  
           echo '1';
       }
       else
       {
           echo '0';
       }
    
  }

   
   }
   
   ?>