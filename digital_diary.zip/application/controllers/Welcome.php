<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {
	function __construct(){
		parent::__construct();
		// $this->load->database();
	}
	

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */
	public function index()
	{
		$this->load->view('welcome_message');
	}
	public function admin()
	{

		$admin_logged_in=$this->session->userdata('admin_logged_in'); 
		if(isset($admin_logged_in[0]['id'] )>0)
		{
			// $this->load->view('logout');
			// redirect('welcome/admin');

		// $this->load->view('include/header');
		// $this->load->view('include/sidebar');
		$this->load->view('addDepartment');
		// $this->load->view('include/footer');

		}
		else
		{
			$this->load->view('login');
		}

		
	}
	public function addCategory()
	{
		$this->load->view('include/header');
		$this->load->view('include/sidebar');
		$this->load->view('category/addCategory');
		$this->load->view('include/footer');
	}
	public function savedata()
	{
		
	$category_name = $this->input->post('category_name');
	$category_slug = $this->input->post('category_slug');
	$insertArray=[
		'category_name'=>$category_name,
		'category_slug'=>$category_slug
	];


		$this->Category_model->register($insertArray);
		$this->load->view('category/addCategory');
	}	
}
