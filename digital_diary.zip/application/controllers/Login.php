<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller 
{

	public function index()
	{


		$admin_logged_in=$this->session->userdata('admin_logged_in'); 
		

		if(isset($admin_logged_in[0]['id'] )>0)
		{
			// $this->load->view('logout');
			redirect('welcome/admin');
		}
		else
		{
			$this->load->view('login');
		}
		
	}


	public function logincheck()
	{
		
		// $this->input->post('username');
		$this->load->model('inventory');

		$this->form_validation->set_rules('email', 'Email Address', 'trim|required|valid_email');
		$this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[4]|max_length[32]');

		$this->form_validation->set_error_delimiters('<div class="error">', '</div>');

		if($this->form_validation->run() == FALSE)
		{
			$this->load->view('login');
			// redirect('login');
		}
		else
		{

		$data['email']=$this->input->post('email');
		$data['password']=$this->input->post('password');

		$user=$this->inventory->admin_login($data);

		// echo $this->db->last_query();

		// count($login_check_data) > 0

		if(count($user)>0)
			{
					$this->session->set_userdata('admin_logged_in', $user);
			        // echo "login Successfully";
			        // $this->load->view('logout');
			        redirect('login/dashboard');
			}
			else
			{
					echo "Insert error !";
			}

		}
	}


	public function dashboard()
	{
		// echo "<pre>";
		//  print_r($_SESSION);
		// $this->load->view('logout');

		  $admin_logged_in=$this->session->userdata('admin_logged_in'); 
		  $user_id=$admin_logged_in[0]['id'];


		if($user_id >0)
		{
			// $this->load->view('logout');
			redirect('welcome/admin');
		}
		else
		{
			redirect('login');
		}

	}


	public function logout()
	{
		session_destroy();
        redirect('login');
	}

}


?>
