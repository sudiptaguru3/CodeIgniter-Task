<!DOCTYPE html>
<html>
<head>
  <title>logout</title>
</head>
<body>
<form action="<?php echo base_url('login/logout'); ?>" method="post">
  <input type="submit" name="submit" value="Logout">
</form>
</body>
</html>