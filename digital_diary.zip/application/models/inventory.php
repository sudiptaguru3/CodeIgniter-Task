<?php
defined('BASEPATH') OR exit('No direct script access allowed');
class Inventory extends CI_Model {


    public function __construct()
    {
        parent::__construct();
        $this->load->database();

    }


     public function admin_login($data='')
    {
        if(!empty($data))
        {
            // $this->db->where('email',$data['email']);
            // $this->db->where('password',$data['password']);

            $this->db->where(['email'=>$data['email'],'password'=>$data['password']]);
            $qry = $this->db->get('login');
            return $qry->result_array();
        }
        
    }

        
}

?>  
